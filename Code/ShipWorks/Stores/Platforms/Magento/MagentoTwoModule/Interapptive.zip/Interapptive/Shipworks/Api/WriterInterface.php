<?php
/**
 * Copyright � 2015 ShipWorks. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Interapptive\Shipworks\Api;

/**
 * Interface providing ShipWorks response writing
 *
 * @api
 */
interface WriterInterface
{
    /**
     * @param $count
     * @return string
     */
    public function writeOrdersCount($count);

    /**
     * @param $orders
     * @return string
     */
    public function writeOrders($orders);

    /**
     * Statuses Available in Magento
     * @param \Interapptive\Shipworks\Model\ShipWorks
     * @return string
     */
    public function writeModule($shipworks);

    /**
     * @param string $code
     * @param string $message
     * @return string
     */
    public function writeException($code, $message);


    /**
     * @param \Magento\Sales\Model\Order $order
     * @param string $message
     * @return string
     */
    public function writeSuccess($order, $message);
}
