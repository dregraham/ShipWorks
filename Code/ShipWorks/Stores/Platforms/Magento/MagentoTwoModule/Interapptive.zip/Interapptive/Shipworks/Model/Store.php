<?php
/**
 * ShipWorks
 *
 * PHP Version 5
 *
 * @category ShipWorks
 * @package  Interapptive\ShipWorks
 * @author   ShipWorks <support@shipworks.com>
 * @license  www.shipworks.com Commercial License
 * @link     www.shipworks.com
 */
namespace Interapptive\Shipworks\Model;
/**
 * Class Store
 *
 * @category ShipWorks
 * @package  Interapptive\ShipWorks
 * @author   ShipWorks <support@shipworks.com>
 * @license  www.shipworks.com Commercial License
 * @link     www.shipworks.com
 */
class Store implements \Interapptive\Shipworks\Api\StoreInterface
{
    /**
     * Returns the store information
     *
     * @return string
     */
    public function getStore()
    {
        //Generate the Store XML
        $store = new \SimpleXMLElement('<Store/>');

        $name = '';
        $owner = '';
        $email = '';
        $state = '';
        $country = '';
        $website = '';

        $store->addChild('Name', $name);
        $store->addChild('Owner', $owner);
        $store->addChild('Email', $email);
        $store->addChild('State', $state);
        $store->addChild('Country', $country);
        $store->addChild('Website', $website);

        return $store->asXML();
    }

    /**
     * Returns all of the available statuses in Magento
     *
     * @return string
     */
    public function getStatusCodes()
    {
        // TODO: Write orders as xml
        return "Not Implemented";
    }
}
