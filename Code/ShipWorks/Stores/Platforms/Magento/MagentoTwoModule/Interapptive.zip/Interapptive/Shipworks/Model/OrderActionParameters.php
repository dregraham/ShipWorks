<?php

namespace Interapptive\Shipworks\Model;

class OrderActionParameters
{
    public $OrderId;
    public $TrackingNumber;
    public $Comments;
    public $SendInvoiceEmail;
    public $SendShipmentEmail;
    public $Carrier;
    public $Service;

    /**
     * @param \string[] $data
     */
    public function __construct($data)
    {
        $this->OrderId = isset($data['OrderId']) ? self::SanitizeInt($data['OrderId']) : '';
        $this->TrackingNumber = isset($data['Tracking']) ? self::SanitizeString($data['Tracking']) : '';
        $this->Comments = isset($data['Comments']) ?self::SanitizeString($data['Comments']) : '';
        $this->SendInvoiceEmail = isset($data['SendInvoiceEmail']) ? self::SanitizeBool($data['SendInvoiceEmail']) : '';
        $this->SendShipmentEmail = isset($data['SendShipmentEmail']) ? self::SanitizeBool($data['SendShipmentEmail']) : '';
        $this->Carrier = isset($data['Carrier']) ? self::SanitizeString($data['Carrier']) : '';
        $this->Service = isset($data['Service']) ? self::SanitizeString($data['Service']) : '';
    }

    /**
     * @param \string $string
     * @return \string
     */
    private static function SanitizeString($string)
    {
        return preg_replace('/[^\da-z ]/i', '', $string);
    }

    /**
     * @param \string $string
     * @return \int
     */
    private static function SanitizeInt($string)
    {
        return preg_replace('/[^0-9]/', '', $string);
    }

    /**
     * @param \string $string
     * @return \bool
     */
    private static function SanitizeBool($string)
    {
        if(trim(strtolower($string)) == "true") {
            return true;
        } elseif(trim(strtolower($string)) == "false") {
            return false;
        } else {
            return (bool)$string;
        }
    }
}