<?php
/**
 * ShipWorks
 *
 * PHP Version 5
 *
 * @category ShipWorks
 * @package  Interapptive\ShipWorks
 * @author   ShipWorks <support@shipworks.com>
 * @license  www.shipworks.com Commercial License
 * @link     www.shipworks.com
 */
namespace Interapptive\Shipworks\Model;
/**
 * Class Store
 *
 * @category ShipWorks
 * @package  Interapptive\ShipWorks
 * @author   ShipWorks <support@shipworks.com>
 * @license  www.shipworks.com Commercial License
 * @link     www.shipworks.com
 */
class ShipWorks implements \Interapptive\Shipworks\Api\ShipWorksInterface
{
    const MODULE_VERSION = '3.10.0';

    const SCHEMA_VERSION = '1.1.0';

    public $Platform = 'Magento';

    public $Developer = 'Interapptive, Inc (support@interapptive.com)';

    public $DownloadStrategy = 'ByModifiedTime';

    public $OnlineCustomerID = ['supported' => 'true',
                                'dataType' => 'text'];

    public $OnlineStatus = ['supported'    => 'true',
                            'dataType' => 'text',
                            'downloadOnly' => 'true'];

    public $OnlineShipmentUpdate = ['supported' => 'false'];

    // Instance of \Interapptive\Shipworks\Model\XMLWriter
    protected  $Writer;

    /**
     * @param XMLWriter $writer
     */
    public function __construct(
        \Interapptive\Shipworks\Model\XMLWriter $writer
    )
    {
        $this->Writer = $writer;
    }

    /**
     * Returns Module configuration
     *
     * @return string
     */
    public function getModule()
    {
        return $this->Writer->writeModule($this);
    }

}