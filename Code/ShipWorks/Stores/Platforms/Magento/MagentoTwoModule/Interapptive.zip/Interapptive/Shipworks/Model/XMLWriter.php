<?php
namespace Interapptive\Shipworks\Model;
/**
 * Class XMLWriter
 *
 * @category ShipWorks
 * @package  Interapptive\ShipWorks
 * @author   ShipWorks <support@shipworks.com>
 * @license  www.shipworks.com Commercial License
 * @link     www.shipworks.com
 */
class XMLWriter implements \Interapptive\Shipworks\Api\WriterInterface
{
    /**
     * Takes an orders collection and returns orders
     * xml in ShipWorks schema 1.1.0 XML
     *
     * @param int $count The order to write to xml
     * @return string orders xml
     */
    public function writeOrdersCount($count)
    {
        $result = (int)$count;
        return "<OrderCount>$result</OrderCount>";
    }

    /**
     * Takes an orders collection and returns orders
     * xml in ShipWorks schema 1.1.0 XML
     *
     * @param \Magento\Sales\Model\Resource\Order\Collection $orders The order to write to xml
     * @return string orders xml
     */
    public function writeOrders($orders)
    {
        // Create a new document
        $ordersDOM = new \DOMDocument;
        $ordersDOM->formatOutput = true;
        $ordersDOM->loadXML('<Orders/>');

        foreach($orders as $order) {
            // create the order node
            $node = $this->writeOrder($order);
            // Add the node to the orders dom
            if ($node instanceof \DOMNode) {
                $this->addToXML($ordersDOM, $node);
            }
        }
        return $ordersDOM->saveXML();
    }

    /**
     * Writes an exception
     *
     * @param \string $code
     * @param \string $message
     *
     * @return \string xml error
     */
    public function writeException($code, $message)
    {
        $errorXml = new \SimpleXMLElement("<Error/>");
        $errorXml->addChild("Code", $code);
        $errorXml->addChild("Description", $message);
        return $errorXml->saveXML();
    }

    /**
     * Writes an exception
     *
     * @param \Magento\Sales\Model\Order $order
     * @param \string $message
     *
     * @return \string xml error
     */
    public function writeSuccess($order, $message = "")
    {
        $successXml = new \SimpleXMLElement("<Success/>");
        $successXml->addChild("Message", $message);
        return $successXml->saveXML();
    }

    /**
     * returns a node for the given order
     *
     * @param \Magento\Sales\Model\Order $order
     * @returns \DOMNode order node
     */
    private function writeOrder($order)
    {
        //Generate the Order XML
        $orderXML = new \SimpleXMLElement("<Order/>");

        $incrementId = $order->getIncrementId();

        $orderPrefix = '';
        $orderNumber = '';
        $orderPostfix = '';

        $numberArray = str_split($incrementId);

        foreach ($numberArray as $orderNumberPart) {
            if (!is_numeric($orderNumberPart) && $orderNumber == '') {
                $orderPrefix .= $orderNumberPart;
            } elseif (is_numeric($orderNumberPart) && $orderPostfix == '') {
                $orderNumber .= $orderNumberPart;
            } elseif ($orderNumber != '') {
                $orderPostfix .= $orderNumberPart;
            }
        }

        $orderXML->addChild("OrderNumber", $orderNumber);
        $orderXML->addChild("OrderNumberPrefix", $orderPrefix);
        $orderXML->addChild("OrderNumberPostfix", $orderPostfix);
        $orderXML->addChild("OrderDate", $order->getCreatedAt());
        $orderXML->addChild("LastModified", $order->getUpdatedAt());
        $orderXML->addChild("ShippingMethod", $order->getShippingDescription());
        $orderXML->addChild("StatusCode", $order->getStatus());
        $orderXML->addChild("CustomerID", $order->getCustomerId());

        $orderXML->addChild("Debug");
        $orderXML->Debug->addChild("OrderID", $order->getId());

        // Create a new document
        $orderDOM = new \DOMDocument;
        $orderDOM->formatOutput = true;

        // Load XML
        $orderDOM->loadXML($orderXML->asXML());

        // Add Shipping Node into the order dom
        $this->addToXML(
            $orderDOM, $this->writeOrderAddress($order, "BillingAddress")
        );

        // Add Billing Node into the order dom
        $this->addToXML(
            $orderDOM, $this->writeOrderAddress($order, "ShippingAddress")
        );

        //Payment Information
        $this->addToXML(
            $orderDOM, $this->writeOrderPayment($order->getPayment())
        );

        //Order Totals
        $this->addToXML($orderDOM, $this->writeOrderTotals($order));

        //Order Items
        $this->addToXML(
            $orderDOM, $this->writeOrderItems($order->getAllItems())
        );

        return $orderDOM->getElementsByTagName("Order")->item(0);
    }

    /**
     * Takes an DOMDocument and imports DOMNode into it
     *
     * @param \DOMDocument $DOM  DOMDocument to import the node into
     * @param \DOMNode     $Node DOMNode to be imported
     *
     * @return \DOMDocument
     */
    private function addToXML($DOM, $Node)
    {
        $Node = $DOM->importNode($Node, true);
        $DOM->documentElement->appendChild($Node);

        return $DOM;
    }

    /**
     * writes an address node
     *
     * @param \Magento\Sales\Model\Order $order
     * @param string $rootElement
     *
     * @return \DOMNode
     */
    private function writeOrderAddress($order, $rootElement)
    {

        $addressXML = new \SimpleXMLElement("<$rootElement/>");

        $address = $order->getShippingAddress();

        // sometimes the shipping address isn't specified, so use billing
        // Or we are writing the billing address so we use billing
        if (!$address || $rootElement == "BillingAddress")
        {
            $address = $order->getBillingAddress();
        }

        $billFullName = $order->getBillingAddress()->getName();
        $billStreet1 = $order->getBillingAddress()->getStreetLine(1);
        $billCity = $order->getBillingAddress()->getCity();
        $billZip = $order->getBillingAddress()->getPostcode();

        $addressXML->addChild('FullName', $address->getName());
        $addressXML->addChild('Company', $address->getCompany());
        $addressXML->addChild('Street1', $address->getStreetLine(1));
        $addressXML->addChild('Street2', $address->getStreetLine(2));
        $addressXML->addChild('Street3', $address->getStreetLine(3));
        $addressXML->addChild('City', $address->getCity());
        $addressXML->addChild('State', $address->getRegionCode());
        $addressXML->addChild('PostalCode', $address->getPostcode());
        $addressXML->addChild('Country', $address->getCountryId());
        $addressXML->addChild('Phone', $address->getTelephone());

        // if the addressses appear to be the same, use customer email as shipping email too
        if ($address->getName() == $billFullName &&
            $address->getStreetLine(1) == $billStreet1 &&
            $address->getCity() == $billCity &&
            $address->getPostcode() == $billZip ||
            $rootElement == 'BillingAddress')
        {
            $addressXML->addChild('Email', $order->getCustomerEmail());
        }

        $Dom = new \DOMDocument();

        $Dom->loadXML($addressXML->asXML());

        return $Dom->getElementsByTagName($rootElement)->item(0);
    }

    /**
     * Writes order payment element from ShipWorks Schema 1.1.0 XSD
     *
     * @param \Magento\Sales\Model\Order\Payment $payment
     *
     * @return \DOMNode
     */
    private function writeOrderPayment($payment)
    {
        $paymentXML = new \SimpleXMLElement("<Payment/>");

        $paymentXML->addChild("Method",$payment->getMethodInstance()->getTitle());

        // CC info
        $cc_num = $payment->getCcLast4();
        if (!empty($cc_num)) {
            $cc_num = '************' . $payment->getCcLast4();
        }
        $cc_year = sprintf('%02u%s', $payment->getCcExpMonth(), substr($payment->getCcExpYear(), 2));

        $paymentXML->addChild("CreditCard");
        $paymentXML->CreditCard->addChild("Type", $payment->getCcType());
        $paymentXML->CreditCard->addChild("Type", $payment->getCcOwner());
        $paymentXML->CreditCard->addChild("Type", $cc_num);
        $paymentXML->CreditCard->addChild("Type", $cc_year);

        $Dom = new \DOMDocument();

        $Dom->loadXML($paymentXML->asXML());

        return $Dom->getElementsByTagName("Payment")->item(0);
    }

    /**
     * Writes order total information
     *
     * @param \Magento\Sales\Model\Order $order
     *
     * @return \DOMNode
     */
    private function writeOrderTotals($order)
    {
        // Create a new document
        $totalsDOM = new \DOMDocument;
        $totalsDOM->formatOutput = true;

        // Load XML
        $totalsDOM->loadXML("<Totals/>");

        //Order Subtotal
        $this->addToXML(
            $totalsDOM, $this->writeOrderTotal(
            "Order Subtotal", $order->getSubtotal(), "ot_subtotal", "none"
        )
        );

        //Order Shipping and Handling
        $this->addToXML(
            $totalsDOM, $this->writeOrderTotal(
            "Shipping and Handling", $order->getShippingAmount(), "shipping",
            "add"
        )
        );

        //TAX
        if ($order->getTaxAmount() > 0) {
            $this->addToXML(
                $totalsDOM, $this->writeOrderTotal(
                "Tax", $order->getTaxAmount(), "tax", "add"
            )
            );
        }

        if ($order->getAdjustmentPositive()) {
            $this->addToXML(
                $totalsDOM, $this->writeOrderTotal(
                "Adjustment Refund", $order->getAdjustmentPositive(), "refund",
                "subtract"
            )
            );
        }

        if ($order->getAdjustmentNegative()) {
            $this->addToXML(
                $totalsDOM, $this->writeOrderTotal(
                "Adjustment Fee", $order->getAdjustmentPositive(), "fee", "add"
            )
            );
        }

        $this->addToXML(
            $totalsDOM, $this->writeOrderTotal(
            "Grand Total", $order->getGrandTotal(), "total", "none"
        )
        );

        return $totalsDOM->getElementsByTagName("Totals")->item(0);

    }

    /**
     * @param  $name
     * @param  $value
     * @param  $class
     * @param $impact
     *
     * @return \DOMNode
     */
    private function writeOrderTotal($name, $value, $class, $impact = "add")
    {

        $totalXML = new \SimpleXMLElement("<Total>$value</Total>");

        $totalXML->addAttribute("name", $name);
        $totalXML->addAttribute("class", $class);
        $totalXML->addAttribute("impact", $impact);

        $Dom = new \DOMDocument();

        $Dom->loadXML($totalXML->asXML());

        return $Dom->getElementsByTagName("Total")->item(0);
    }

    /**
     * Writes the order items xml node
     *
     * @param \Magento\Sales\Model\Order\Item[] $items
     *
     * @return \DOMNode
     */
    private function writeOrderItems($items)
    {
        // Create a new document
        $itemsDOM = new \DOMDocument;
        $itemsDOM->formatOutput = true;

        // Load XML
        $itemsDOM->loadXML('<Items/>');

        foreach ($items as $item) {
            $this->addToXML($itemsDOM, $this->writeOrderItem($item));
        }

        return $itemsDOM->getElementsByTagName('Items')->item(0);
    }

    /**
     * Writes the order item xml node
     *
     * @param \Magento\Sales\Model\Order\Item $item
     *
     * @return \DOMNode
     */
    private function writeOrderItem($item)
    {
        // Create a new document
        $itemXml = new \SimpleXMLElement("<Item/>");

        // Build the item xml using simple xml
        $itemXml->addChild('Name', $item->getName());
        $itemXml->addChild('SKU', $item->getSku());
        $itemXml->addChild('Weight', (int)$item->getWeight());

        // Create a new document
        $itemDOM = new \DOMDocument;
        $itemDOM->formatOutput = true;

        // Load XML
        $itemDOM->loadXML($itemXml->saveXML());

        // Return DOMNode
        return $itemDOM->getElementsByTagName('Item')->item(0);
    }


    /**
     * @param \Interapptive\Shipworks\Model\ShipWorks
     * @return string
     */
    public function writeModule($shipworks){
        //Generate the Module XML
        $moduleXML = new \SimpleXMLElement('<Module/>');

        $moduleXML->addChild('Platform', $shipworks->Platform);
        $moduleXML->addChild('Developer', $shipworks->Developer);

        $moduleXML->addChild('Capabilities');
        $moduleXML->Capabilities->addChild(
            'DownloadStrategy', $shipworks->DownloadStrategy
        );

        $moduleXML->Capabilities->addChild('OnlineCustomerID');
        foreach ($shipworks->OnlineCustomerID as $name => $value) {
            $moduleXML->Capabilities->OnlineCustomerID->addAttribute(
                $name, $value
            );
        }

        $moduleXML->Capabilities->addChild('OnlineStatus');
        foreach ($shipworks->OnlineStatus as $name => $value) {
            $moduleXML->Capabilities->OnlineStatus->addAttribute($name, $value);
        }

        $moduleXML->Capabilities->addChild('OnlineShipmentUpdate');
        foreach ($shipworks->OnlineShipmentUpdate as $name => $value) {
            $moduleXML->Capabilities->OnlineShipmentUpdate->addAttribute(
                $name, $value
            );
        }

        return $moduleXML->asXML();
    }
}