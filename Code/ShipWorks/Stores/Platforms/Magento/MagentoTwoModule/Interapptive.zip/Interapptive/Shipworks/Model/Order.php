<?php
/**
 * ShipWorks
 *
 * PHP Version 5
 *
 * @category ShipWorks
 * @package  Interapptive\ShipWorks
 * @author   ShipWorks <support@shipworks.com>
 * @license  www.shipworks.com Commercial License
 * @link     www.shipworks.com
 */
namespace Interapptive\Shipworks\Model;

/**
 * Class Order
 *
 * @category ShipWorks
 * @package  Interapptive\ShipWorks
 * @author   ShipWorks <support@shipworks.com>
 * @license  www.shipworks.com Commercial License
 * @link     www.shipworks.com
 */
class Order implements \Interapptive\Shipworks\Api\OrderInterface
{
    // Instance of \Magento\Sales\Model\Resource\Order\CollectionFactory
    protected $OrderCollectionFactory;

    // Instance of \Interapptive\Shipworks\Model\XMLWriter
    protected  $Writer;

    // Instance of \Magento\Sales\Model\Order\ShipmentFactory
    protected $ShipmentFactory;

    // Instance of \Magento\Sales\Model\Order\Shipment\TrackFactory
    protected $TrackFactory;

    // Instance of \Magento\Sales\Model\OrderFactory
    protected $OrderFactory;

    // Instance of \Magento\Framework\ObjectManagerInterface
    protected $ObjectManager;

    /**
     * @param \Magento\Sales\Model\Resource\Order\CollectionFactory $collectionFactory
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param XMLWriter $writer
     * @param \Magento\Sales\Model\Order\ShipmentFactory $shipmentFactory
     * @param \Magento\Sales\Model\Order\Shipment\TrackFactory $trackFactory
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     */
    public function __construct(
        \Magento\Sales\Model\Resource\Order\CollectionFactory $collectionFactory,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Interapptive\Shipworks\Model\XMLWriter $writer,
        \Magento\Sales\Model\Order\ShipmentFactory $shipmentFactory,
        \Magento\Sales\Model\Order\Shipment\TrackFactory $trackFactory,
        \Magento\Sales\Model\OrderFactory $orderFactory
    )
    {
        $this->OrderCollectionFactory = $collectionFactory;
        $this->Writer = $writer;
        $this->ShipmentFactory = $shipmentFactory;
        $this->TrackFactory = $trackFactory;
        $this->OrderFactory = $orderFactory;
        $this->ObjectManager = $objectManager;
    }


    /**
     * Returns the count of orders from the given start date
     *
     * @param string $start
     * @return string
     */
    public function getCount($start)
    {
        $startDate = new \DateTime($start, new \DateTimeZone('UTC'));
        $formattedDate = $startDate->format('Y-m-d H:i:s');

        $orderCollection = $this->OrderCollectionFactory->create();

        $count = (int)$orderCollection
                    ->addFieldToFilter('updated_at', array('gt' => $formattedDate))
                    ->getSize();

        return $this->Writer->writeOrdersCount($count);
    }

    /**
     * Gets orders that match the parameters
     *
     * @api
     * @param string $start date to return orders from
     * @param int $maxcount number of orders to return
     * @return string
     */
    public function getOrders($start, $maxcount = 50)
    {
        // Get orders from the start date
        $startDate = new \DateTime($start, new \DateTimeZone('UTC'));
        $formattedDate = $startDate->format('Y-m-d H:i:s');

        $orderCollection = $this->OrderCollectionFactory->create();

        // Grab the orders from the start date limited to
        // the max count
        $orders = $orderCollection
            ->addFieldToFilter('updated_at', array('gt' => $formattedDate))
            ->setOrder('updated_at', 'asc')
            ->setCurPage(1)
            ->setPageSize((int)$maxcount)
            ->loadData();

        $processedIds = array();
        $lastModified = '';

        // We have to do this rather than getAllIds() because getAllIds() does not respect the page size
        foreach ($orders as $order) {
            // add orders id to an array
            array_push($processedIds, $order->getId());
            //Grab the last last modified date
            $lastModified = $order->getUpdatedAt();
        }

        //If order 50 and 50+ share the same lastmodified timestamp, we need to get all of them so that
        //The next GetOrders call does not skip those orders
        if (!empty($processedIds) and $lastModified != '') {
            $missingOrders = $this->OrderCollectionFactory->create();

            $missingOrders->addFieldToFilter('updated_at', array('eq' => $lastModified))
                ->addFieldToFilter('entity_id', array('nin' => $processedIds))
                ->loadData();

            foreach ($missingOrders as $missingOrder) {
                $orders->addItem($missingOrder);
            }
        }

        return $this->Writer->writeOrders($orders);
    }


    /**
     * @param \string   $action
     * @param \string[] $data
     * @throws \Magento\Framework\Exception\LocalizedException
     * @return \string
     */
    public function updateOrders($action, $data)
    {
        $params = new OrderActionParameters($data);
        try {
            $order = $this->OrderFactory->create()->load($params->OrderId);

            switch (strtolower(trim($action))) {
                case 'complete':
                    // Try to add tracking first
                    $this->addTracking($order, $params);
                    // assume that tracking added successfully so now we can invoice
                    $this->invoice($order, $params);
                    break;
                case 'cancel':
                    $this->cancelOrder($order);
                    break;
                case 'hold':
                    $this->holdOrder($order);
                    break;
                default:
                    throw new \Magento\Framework\Exception\LocalizedException(__("Unknown Order action '$action''"));
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            return $this->Writer->writeException('100', $e->getMessage());
        }
        return $this->Writer->writeSuccess($order);
    }

    /**
     * places an order on hold the order
     *
     * @param \Magento\Sales\Model\Order $order
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function holdOrder($order)
    {
        if(!$order->canHold()){
            throw new \Magento\Framework\Exception\LocalizedException(__('Order cannot be place on Hold'));
        }

        $order->hold();
        $order->save();
    }

    /**
     * cancels an order
     *
     * @param \Magento\Sales\Model\Order $order
     * @returns \bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function cancelOrder($order)
    {
        if(!$order->canCancel()){
            throw new \Magento\Framework\Exception\LocalizedException(__('Order cannot be Canceled'));
        }

        $order->cancel();
        $order->save();
    }

    /**
     * Add Tracking
     *
     * @param \Magento\Sales\Model\Order $order
     * @param \Interapptive\ShipWorks\Model\OrderActionParameters
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function addTracking($order, $params)
    {
        if ($order->canship()) {
            // No Shipments exist so we need to create one
            $shipment = $this->ShipmentFactory->create($order);
        } else {
            // Shipments exist, grab the last one to add tracking to
            $shipment = $order->getShipmentsCollection()->getLastItem();
        }

        if (!$shipment) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Unable to load Shipment'));
        }

        $track = $this->TrackFactory->create(
        )->setNumber(
            $params->TrackingNumber
        )->setCarrierCode(
            $params->Carrier
        )->setTitle(
            $params->Service
        );

        $shipment->addTrack($track);
        foreach ($order->getAllItems() as $item) {
            $item->setQtyShipped($item->getQtyToShip());
            $item->save();
        }

        $transactionSave = $this->ObjectManager->create('Magento\Framework\DB\Transaction')
            ->addObject($shipment)
            ->addObject($order);

        $transactionSave->save();
    }


    /**
     * Invoices the order
     *
     * @param \Magento\Sales\Model\Order $order
     * @param \Interapptive\ShipWorks\Model\OrderActionParameters
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function invoice($order, $params)
    {
        if (!$order->canInvoice()) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Order cannot be Invoiced'));
        }

        $invoice = $order->prepareInvoice();

        if (!$invoice) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Unable to load Invoice'));
        }

        $invoice->register();
        $invoice->addComment($params->Comments,$params->SendInvoiceEmail);

        if ($invoice->canCapture()) {
            $invoice->capture();
        }

        $transactionSave = $this->ObjectManager->create('Magento\Framework\DB\Transaction')
            ->addObject($invoice)
            ->addObject($invoice->getOrder());

        $transactionSave->save();
    }
}