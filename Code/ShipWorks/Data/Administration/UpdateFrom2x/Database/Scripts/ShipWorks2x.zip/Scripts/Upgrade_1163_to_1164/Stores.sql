
CREATE TABLE dbo.Tmp_Stores
	(
	StoreID int NOT NULL IDENTITY (1, 1),
	RowVersion timestamp NOT NULL,
	StoreType int NOT NULL,
	StoreName nvarchar(75) NOT NULL,
	LicenseKey nvarchar(150) NOT NULL,
	CompanyName nvarchar(60) NOT NULL,
	CompanyAddress1 nvarchar(60) NOT NULL,
	CompanyAddress2 nvarchar(60) NOT NULL,
	CompanyAddress3 nvarchar(60) NOT NULL,
	CompanyCity nvarchar(50) NOT NULL,
	CompanyStateProvCode nvarchar(5) NOT NULL,
	CompanyPostalCode nvarchar(10) NOT NULL,
	CompanyCountryCode nvarchar(5) NOT NULL,
	CompanyUrl nvarchar(150) NOT NULL,
	CompanyFax nvarchar(50) NOT NULL,
	CompanyPhone nvarchar(50) NOT NULL,
	CompanyEmail nvarchar(50) NOT NULL,
	CompanyLogo nvarchar(300) NOT NULL,
	LastUpdateTime datetime NOT NULL,
	DownloadAddressCasing bit NOT NULL,
	EmailDefaultAccountID int NOT NULL,
	EmailLogSaveMessage bit NOT NULL,
	EmailLogSaveMessageImages bit NOT NULL,
	OrderStatusStrings nvarchar(500) NOT NULL,
	ItemStatusStrings nvarchar(500) NOT NULL,
	OrderNumberPrefix nvarchar(10) NOT NULL,
	OrderNumberPostfix nvarchar(10) NOT NULL,
	StoreUsername nvarchar(50) NOT NULL,
	StorePassword nvarchar(50) NOT NULL,
	StoreSavePassword bit NOT NULL,
	MivaPassphrase nvarchar(50) NOT NULL,
	MivaSiteID nchar(8) NOT NULL,
	MivaModuleUrl nvarchar(300) NOT NULL,
	MivaStoreCode nvarchar(50) NOT NULL,
	MivaConnectSecure bit NOT NULL,
	MivaRemovedDeletedBatches bit NOT NULL,
	MivaSebenzaExtraMsg bit NOT NULL,
	MivaLiveManualOrderNumbers bit NOT NULL,
	eBayUserID nvarchar(50) NOT NULL,
	eBayToken text NOT NULL,
	eBayTokenExpire datetime NOT NULL,
	eBayDownloadItemDetails bit NOT NULL,
	ShopSiteCgiUrl nvarchar(300) NOT NULL,
	ShopSiteConnectSecure bit NOT NULL,
	ShopSiteTimeZoneID smallint NOT NULL,
	YahooPopServer nvarchar(150) NOT NULL,
	MarketworksCorpServer bit NOT NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO

SET IDENTITY_INSERT dbo.Tmp_Stores ON
GO

IF EXISTS(SELECT * FROM dbo.Stores)
	 EXEC('INSERT INTO dbo.Tmp_Stores (StoreID, StoreType, StoreName, LicenseKey, CompanyName, CompanyAddress1, CompanyAddress2, CompanyAddress3, CompanyCity, CompanyStateProvCode, CompanyPostalCode, CompanyCountryCode, CompanyUrl, CompanyFax, CompanyPhone, CompanyEmail, CompanyLogo, LastUpdateTime, DownloadAddressCasing, EmailDefaultAccountID, EmailLogSaveMessage, EmailLogSaveMessageImages, OrderStatusStrings, ItemStatusStrings, OrderNumberPrefix, OrderNumberPostfix, StoreUsername, StorePassword, StoreSavePassword, MivaPassphrase, MivaSiteID, MivaModuleUrl, MivaStoreCode, MivaConnectSecure, MivaRemovedDeletedBatches, MivaSebenzaExtraMsg, MivaLiveManualOrderNumbers, eBayUserID, eBayToken, eBayTokenExpire, eBayDownloadItemDetails, ShopSiteCgiUrl, ShopSiteConnectSecure, ShopSiteTimeZoneID, YahooPopServer, MarketworksCorpServer)
		                        SELECT StoreID, StoreType, StoreName, '''',       CompanyName, CompanyAddress1, CompanyAddress2, CompanyAddress3, CompanyCity, CompanyStateProvCode, CompanyPostalCode, CompanyCountryCode, CompanyUrl, CompanyFax, CompanyPhone, CompanyEmail, CompanyLogo, LastUpdateTime, DownloadAddressCasing, EmailDefaultAccountID, EmailLogSaveMessage, EmailLogSaveMessageImages, OrderStatusStrings, ItemStatusStrings, OrderNumberPrefix, OrderNumberPostfix, StoreUsername, StorePassword, StoreSavePassword, MivaPassphrase, MivaSiteID, MivaModuleUrl, MivaStoreCode, MivaConnectSecure, MivaRemovedDeletedBatches, MivaSebenzaExtraMsg, MivaLiveManualOrderNumbers, eBayUserID, eBayToken, eBayTokenExpire, eBayDownloadItemDetails, ShopSiteCgiUrl, ShopSiteConnectSecure, ShopSiteTimeZoneID, YahooPopServer, MarketworksCorpServer FROM dbo.Stores TABLOCKX')
GO

SET IDENTITY_INSERT dbo.Tmp_Stores OFF
GO

ALTER TABLE dbo.Shipments DROP CONSTRAINT FK_Shipments_Stores
GO
ALTER TABLE dbo.ClientStoreSettings DROP CONSTRAINT FK_ClientStoreSettings_Stores
GO
ALTER TABLE dbo.MivaBatches DROP CONSTRAINT FK_MivaBatches_Stores
GO
ALTER TABLE dbo.UpsPreferences DROP CONSTRAINT FK_UpsPreferences_Stores
GO
ALTER TABLE dbo.DownloadLog DROP CONSTRAINT FK_DownloadLog_Stores
GO
ALTER TABLE dbo.Downloaded DROP CONSTRAINT FK_Downloaded_Stores
GO
ALTER TABLE dbo.EmailAccounts DROP CONSTRAINT FK_EmailAccounts_Stores
GO
ALTER TABLE dbo.EmailLog DROP CONSTRAINT FK_EmailLog_Stores
GO
ALTER TABLE dbo.Customers DROP CONSTRAINT FK_Customers_Stores
GO
ALTER TABLE dbo.Orders DROP CONSTRAINT FK_Orders_Stores
GO
ALTER TABLE dbo.Actions DROP CONSTRAINT FK_Actions_Stores
GO
ALTER TABLE dbo.Notifications DROP CONSTRAINT FK_Notifications_Stores
GO
ALTER TABLE dbo.FedexPreferences DROP CONSTRAINT FK_FedexPreferences_Stores
GO

DROP TABLE dbo.Stores
GO

EXECUTE sp_rename N'dbo.Tmp_Stores', N'Stores', 'OBJECT'
GO

ALTER TABLE dbo.Stores ADD CONSTRAINT
	PK_Stores PRIMARY KEY CLUSTERED 
	(
	StoreID
	)

GO

ALTER TABLE dbo.Stores ADD CONSTRAINT
	UQ_Stores_StoreName UNIQUE NONCLUSTERED 
	(
	StoreName
	)

GO

ALTER TABLE dbo.Stores WITH NOCHECK ADD CONSTRAINT
	CK_ValidStoreType CHECK (([StoreType] >= 0 or [StoreType] <= 4))
GO


ALTER TABLE dbo.FedexPreferences WITH NOCHECK ADD CONSTRAINT
	FK_FedexPreferences_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.Notifications WITH NOCHECK ADD CONSTRAINT
	FK_Notifications_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.Actions WITH NOCHECK ADD CONSTRAINT
	FK_Actions_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.Orders WITH NOCHECK ADD CONSTRAINT
	FK_Orders_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.Customers WITH NOCHECK ADD CONSTRAINT
	FK_Customers_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.EmailLog WITH NOCHECK ADD CONSTRAINT
	FK_EmailLog_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.EmailAccounts WITH NOCHECK ADD CONSTRAINT
	FK_EmailAccounts_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.Downloaded WITH NOCHECK ADD CONSTRAINT
	FK_Downloaded_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.DownloadLog WITH NOCHECK ADD CONSTRAINT
	FK_DownloadLog_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.UpsPreferences WITH NOCHECK ADD CONSTRAINT
	FK_UpsPreferences_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.MivaBatches WITH NOCHECK ADD CONSTRAINT
	FK_MivaBatches_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.ClientStoreSettings WITH NOCHECK ADD CONSTRAINT
	FK_ClientStoreSettings_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.Shipments WITH NOCHECK ADD CONSTRAINT
	FK_Shipments_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

----------------------------
--- PROCEDURE GetAllStores
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllStores]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [GetAllStores]
GO

CREATE PROCEDURE GetAllStores
AS
   SELECT *
   FROM [Stores]
GO

----------------------------
--- PROCEDURE DeleteStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteStore]
GO

CREATE PROCEDURE DeleteStore
(
   @StoreID int
)
AS
   DELETE OrderItemAttributes
     FROM OrderItemAttributes a, OrderItems i, Orders o
     WHERE a.OrderItemID = i.OrderItemID AND i.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE OrderItems
     FROM OrderItems i, Orders o
     WHERE i.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE OrderCharges
     FROM OrderCharges c, Orders o
     WHERE c.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE PaymentDetails
     FROM PaymentDetails p, Orders o
     WHERE p.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE MivaSebenzaMsgs
     FROM MivaSebenzaMsgs m, Orders o
     WHERE m.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE UpsPackages
     FROM UpsPackages p, Shipments s
     WHERE p.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE UpsShipments
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE FedexPackages
     FROM FedexPackages p, Shipments s
     WHERE p.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE FedexShipments
     FROM FedexShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE Shipments
     FROM Shipments s
     WHERE s.StoreID = @StoreID
     
   DELETE FROM UpsPreferences
     WHERE [StoreID] = @StoreID
   
   DELETE FROM EmailAccounts
     WHERE [StoreID] = @StoreID
  
   DELETE FROM Orders
     WHERE [StoreID] = @StoreID

   DELETE FROM Downloaded
     WHERE [StoreID] = @StoreID
     
   DELETE FROM MivaBatches
     WHERE [StoreID] = @StoreID
     
   DELETE FROM DownloadLog
     WHERE [StoreID] = @StoreID
     
   DELETE FROM EmailLog
     WHERE [StoreID] = @StoreID
    
    DELETE FROM Actions
     WHERE [StoreID] = @StoreID
 
    DELETE FROM Notifications
     WHERE [StoreID] = @StoreID

   DELETE FROM Customers
     WHERE [StoreID] = @StoreID   
     
   DELETE FROM [Stores]
     WHERE [StoreID] = @StoreID
     
GO

----------------------------
--- PROCEDURE AddStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddStore]
GO

CREATE PROCEDURE AddStore
(
   @StoreType int,  
   @StoreName nvarchar(75),
   @LicenseKey nvarchar (150),  
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int,  
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit,
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(50),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit, 
   @MivaLiveManualOrderNumbers bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @MarketworksCorpServer bit
)
AS
   INSERT INTO [Stores]
   (
        [StoreType], 
        [StoreName], 
        [LicenseKey],
        [CompanyName], 
        [CompanyAddress1], 
        [CompanyAddress2], 
        [CompanyAddress3], 
        [CompanyCity], 
        [CompanyStateProvCode], 
        [CompanyPostalCode], 
        [CompanyCountryCode], 
        [CompanyUrl], 
        [CompanyFax], 
        [CompanyPhone], 
        [CompanyEmail], 
        [CompanyLogo],
        [LastUpdateTime], 
        [DownloadAddressCasing],
        [EmailDefaultAccountID], 
        [EmailLogSaveMessage],
        [EmailLogSaveMessageImages],
        [OrderStatusStrings], 
        [ItemStatusStrings], 
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [StoreUsername], 
        [StorePassword], 
        [StoreSavePassword], 
        [MivaPassphrase], 
        [MivaSiteID], 
        [MivaModuleUrl], 
        [MivaStoreCode], 
        [MivaConnectSecure], 
        [MivaRemovedDeletedBatches], 
        [MivaSebenzaExtraMsg], 
        [MivaLiveManualOrderNumbers],
        [eBayUserID], 
        [eBayToken], 
        [eBayTokenExpire],
        [eBayDownloadItemDetails],
		[ShopSiteCgiUrl],
		[ShopSiteConnectSecure],
		[ShopSiteTimeZoneID],
        [YahooPopServer],
        [MarketworksCorpServer]
   )
   VALUES 
   (
        @StoreType, 
        @StoreName, 
        @LicenseKey,
        @CompanyName, 
        @CompanyAddress1,
        @CompanyAddress2, 
        @CompanyAddress3, 
        @CompanyCity, 
        @CompanyStateProvCode, 
        @CompanyPostalCode, 
        @CompanyCountryCode, 
        @CompanyUrl, 
        @CompanyFax, 
        @CompanyPhone, 
        @CompanyEmail, 
        @CompanyLogo,
        @LastUpdateTime, 
        @DownloadAddressCasing,
        @EmailDefaultAccountID, 
        @EmailLogSaveMessage,
        @EmailLogSaveMessageImages,
        @OrderStatusStrings,
        @ItemStatusStrings, 
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @StoreUsername, 
        @StorePassword, 
        @StoreSavePassword, 
        @MivaPassphrase, 
        @MivaSiteID, 
        @MivaModuleUrl, 
        @MivaStoreCode, 
        @MivaConnectSecure, 
        @MivaRemovedDeletedBatches, 
        @MivaSebenzaExtraMsg, 
        @MivaLiveManualOrderNumbers,
        @eBayUserID, 
        @eBayToken, 
        @eBayTokenExpire,
        @eBayDownloadItemDetails,
		@ShopSiteCgiUrl,
		@ShopSiteConnectSecure,
		@ShopSiteTimeZoneID,
        @YahooPopServer,
        @MarketworksCorpServer
)
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, RowVersion
   FROM Stores
   WHERE StoreID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE SaveLastUpdateTime
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveLastUpdateTime]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveLastUpdateTime]
GO

CREATE PROCEDURE SaveLastUpdateTime
(
   @StoreID int,
   @LastUpdateTime datetime
)
AS
    UPDATE [Stores]
    SET [LastUpdateTime]=@LastUpdateTime
    WHERE [StoreID] = @StoreID

   SET NOCOUNT ON

   SELECT *
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE SaveEmailSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveEmailSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveEmailSettings]
GO

CREATE PROCEDURE SaveEmailSettings
(
   @StoreID int,
   @EmailDefaultAccountID int,
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit
)
AS
    UPDATE Stores
      SET EmailDefaultAccountID = @EmailDefaultAccountID,
          EmailLogSaveMessage = @EmailLogSaveMessage,
          EmailLogSaveMessageImages = @EmailLogSaveMessageImages
      WHERE StoreID = @StoreID

   SET NOCOUNT ON

   SELECT *
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO


----------------------------
--- PROCEDURE UpdateStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateStore]
GO

CREATE PROCEDURE UpdateStore
(
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @StoreType int,  
   @StoreName nvarchar(75),  
   @LicenseKey nvarchar (150),
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int, 
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit, 
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(50),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit,  
   @MivaLiveManualOrderNumbers bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @MarketworksCorpServer bit
)
AS
   UPDATE [Stores]
   SET [StoreType]=@StoreType, 
       [StoreName]=@StoreName, 
       [LicenseKey]=@LicenseKey,
       [CompanyName]=@CompanyName, 
       [CompanyAddress1]=@CompanyAddress1, 
       [CompanyAddress2]=@CompanyAddress2, 
       [CompanyAddress3]=@CompanyAddress3, 
       [CompanyCity]=@CompanyCity, 
       [CompanyStateProvCode]=@CompanyStateProvCode, 
       [CompanyPostalCode]=@CompanyPostalCode, 
       [CompanyCountryCode]=@CompanyCountryCode, 
       [CompanyUrl]=@CompanyUrl, 
       [CompanyFax]=@CompanyFax, 
       [CompanyPhone]=@CompanyPhone, 
       [CompanyEmail]=@CompanyEmail, 
       [CompanyLogo]=@CompanyLogo,
       [LastUpdateTime]=@LastUpdateTime, 
       [DownloadAddressCasing]=@DownloadAddressCasing,
       [EmailDefaultAccountID]=@EmailDefaultAccountID, 
       [EmailLogSaveMessage]=@EmailLogSaveMessage,
       [EmailLogSaveMessageImages]=@EmailLogSaveMessageImages,
       [OrderStatusStrings]=@OrderStatusStrings, 
       [ItemStatusStrings]=@ItemStatusStrings, 
       [OrderNumberPrefix]=@OrderNumberPrefix,
       [OrderNumberPostfix]=@OrderNumberPostfix,
       [StoreUsername]=@StoreUsername, 
       [StorePassword]=@StorePassword, 
       [StoreSavePassword]=@StoreSavePassword, 
       [MivaPassphrase]=@MivaPassphrase, 
       [MivaSiteID]=@MivaSiteID,
       [MivaModuleUrl]=@MivaModuleUrl, 
       [MivaStoreCode]=@MivaStoreCode, 
       [MivaConnectSecure]=@MivaConnectSecure, 
       [MivaRemovedDeletedBatches]=@MivaRemovedDeletedBatches, 
       [MivaSebenzaExtraMsg]=@MivaSebenzaExtraMsg, 
       [MivaLiveManualOrderNumbers]=@MivaLiveManualOrderNumbers,
       [eBayUserID]=@eBayUserID, 
       [eBayToken]=@eBayToken, 
       [eBayTokenExpire]=@eBayTokenExpire,
       [eBayDownloadItemDetails]=@eBayDownloadItemDetails,
	   [ShopSiteCgiUrl]=@ShopSiteCgiUrl,
	   [ShopSiteConnectSecure]=@ShopSiteConnectSecure,
	   [ShopSiteTimeZoneID] = @ShopSiteTimeZoneID,
       [YahooPopServer]=@YahooPopServer,
       [MarketworksCorpServer] = @MarketworksCorpServer
    WHERE [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

