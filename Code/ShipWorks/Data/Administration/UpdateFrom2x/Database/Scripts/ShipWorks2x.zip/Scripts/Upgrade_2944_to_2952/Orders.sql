-----------------------------
--- TRIGGER TG_Orders_Customers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Orders_Customers]'))
   drop trigger dbo.[TG_Orders_Customers]
GO

CREATE TRIGGER dbo.TG_Orders_Customers ON Orders WITH ENCRYPTION INSTEAD OF INSERT
AS

    if ( (SELECT Count(*) FROM inserted) > 1 )
    begin
         RAISERROR ('Only one order can be added at a time.', 16, 1)
         ROLLBACK TRANSACTION
         return
    end

    DECLARE @customerID int
    SELECT @customerID = NULL
    
    -- See if a valid customer is already specified
    SELECT @customerID = i.CustomerID
      FROM inserted i, Customers c
      WHERE i.StoreID = c.StoreID AND i.CustomerID = c.CustomerID AND i.CustomerID > 0
      
    -- Determine the store type
    DECLARE @storeType int
    SELECT @storeType = StoreType
      FROM Stores s, inserted i
      WHERE s.StoreID = i.StoreID
      
    -- Get fields we need
    DECLARE @eBayBuyerID nvarchar (50)
    DECLARE @isManual bit
    SELECT @eBayBuyerID = eBayBuyerID, @isManual = IsManual
		FROM inserted

	-- Match up based on ebay buyer id (if ebay)
    if (@customerID IS NULL and @storeType = 1)
    begin
    		
		SELECT @customerID = c.CustomerID
		FROM inserted i, Customers c
		WHERE
			i.StoreID = c.StoreID AND
			(i.eBayBuyerID != '' AND i.eBayBuyerID = c.eBayBuyerID)
			
		if (@customerID IS NOT NULL) print('Matched on eBayBuyerID')
		
		-- If we didnt find it, then we have to check one more thing.  buyers can
		-- change their buyer id's.  So we see if we find an email match, and if we do
		-- that means they changed their buyer id.
		if (@customerID IS NULL)
		begin
			-- Match up customers based on bill email address
			SELECT @customerID = c.CustomerID
			FROM inserted i, Customers c
			WHERE
				i.StoreID = c.StoreID AND
				(i.BillEmail != '' AND i.BillEmail = c.BillEmail)
				
			if (@customerID IS NOT NULL) 
			begin
			    print('ebay buyer changed id, Matched on Email')
			    
			end
		end
    end

	-- Match up based on oscommerce cust id (if osc (or creloaded))
    if (@customerID IS NULL and (@storeType = 5 or @storeType = 9 or @storeType = 13))
    begin
		SELECT @customerID = c.CustomerID
		FROM inserted i, Customers c
		WHERE
			i.StoreID = c.StoreID AND
			(i.osCommerceCustomerID > 0 AND i.osCommerceCustomerID = c.osCommerceCustomerID)
			
		if (@customerID IS NOT NULL) print('Matched on osCommerce Customer ID')
			
    end
    
    -- Match up based on infopia cust id (if infopia)
    if (@customerID IS NULL and @storeType = 8)
    begin
        -- we're only going to trust the infopia id if the physical address matches as well.
    	-- if someone changed their email address AND billing address, they're going to be a new customer in ShipWorks.
		SELECT @customerID = c.CustomerID
		FROM inserted i, Customers c
		WHERE
			i.StoreID = c.StoreID AND
			(i.InfopiaCustomerID > 0 AND i.InfopiaCustomerID = c.InfopiaCustomerID)
			AND c.AddressHash = (i.BillFirstName + i.BillLastName + i.BillAddress1 + i.BillAddress2 + i.BillPostalCode)	
			
		if (@customerID IS NOT NULL) print('Matched on Infopia Customer ID')
			
    end

    -- If it didnt work based on a store specific id, try based on email (except ebay)
    if (@isManual = 1 or (@storeType != 1) )
    begin
    
		if (@customerID IS NULL)
		begin
			-- Match up customers based on bill email address
			SELECT @customerID = c.CustomerID
			FROM inserted i, Customers c
			WHERE
				i.StoreID = c.StoreID AND
				(i.BillEmail != '' AND i.BillEmail = c.BillEmail)
				
			if (@customerID IS NOT NULL) print('Matched on Email')
		end
	        
		-- If it didnt work based on email, try based on addresss
		if (@customerID IS NULL)
		begin

			-- Match up customers based on shipping address
			SELECT @customerID = c.CustomerID
				FROM inserted i, Customers c
				WHERE
					i.StoreID = c.StoreID AND
					c.AddressHash != '' AND
					c.AddressHash = (i.BillFirstName + i.BillLastName + i.BillAddress1 + i.BillAddress2 + i.BillPostalCode)
	    
			if (@customerID IS NOT NULL) print('Matched on Address')
		end
		
    end
    
    -- If we still have not found a correct customer, add an entry to the customers table
    if (@customerID IS NULL)
    begin
			print('No match, adding new customer.')
			
            -- Create a customer for each order that does not yet have a customer
            INSERT INTO Customers 
            (
                StoreID, 
                ShipEmail,     
                ShipFirstName,     
                ShipLastName,     
                ShipCompany,     
                ShipAddress1,     
                ShipAddress2,     
                ShipAddress3,     
                ShipCity,     
                ShipStateProvinceCode,     
                ShipPostalCode,     
                ShipCountryCode,     
                ShipPhone,     
                ShipFax,     
                BillEmail,     
                BillFirstName,     
                BillLastName,     
                BillCompany,     
                BillAddress1,     
                BillAddress2,     
                BillAddress3,     
                BillCity,     
                BillStateProvinceCode,     
                BillPostalCode,     
                BillCountryCode,     
                BillPhone,     
                BillFax,     
                Notes, 
                eBayBuyerID,
                MarketWorksBuyerNumber,
                osCommerceCustomerID,
                ProStoresCustomerNumber,
                InfopiaCustomerID,
                MagentoCustomerID
            )
            SELECT 
                StoreID, 
                ShipEmail,     
                ShipFirstName,     
                ShipLastName,     
                ShipCompany,     
                ShipAddress1,     
                ShipAddress2,     
                ShipAddress3,     
                ShipCity,     
                ShipStateProvinceCode,     
                ShipPostalCode,     
                ShipCountryCode,     
                ShipPhone,     
                ShipFax,    
                BillEmail, 
                BillFirstName, 
                BillLastName, 
                BillCompany, 
                BillAddress1, 
                BillAddress2, 
                BillAddress3, 
                BillCity, 
                BillStateProvinceCode, 
                BillPostalCode, 
                BillCountryCode, 
                BillPhone, 
                BillFax, 
                '',    
                eBayBuyerID,
                MarketWorksBuyerNumber,
                osCommerceCustomerID,
                '',
                InfopiaCustomerID,
                MagentoCustomerID
                
            FROM inserted i

          -- Now we know the customer ID
          SET @customerID = SCOPE_IDENTITY()
    end

    -- We do know the customer, update the existing customer record
    else
    begin
			DECLARE @doUpdate bit
			SELECT @doUpdate = 1
			
			-- For eBay, if this is a return customer who has not checked out yet, some address
			-- information will be blank.  We do not want to overwrite existing good address
			-- information with blank.
			if (@storeType = 1)
			begin
				
				-- If the buyer id is blank, see if the customer has a buyerid to use
				if (@eBayBuyerID = '')
				begin
					SELECT @eBayBuyerID = eBayBuyerID
						FROM Customers
						WHERE CustomerID = @customerID
						
					print('Order eBayBuyerID blank, using customers:')
					print(@eBayBuyerID)
					
				end

				DECLARE @firstName [nvarchar] (30)
				DECLARE @lastName [nvarchar] (30)
				DECLARE @address1 [nvarchar] (60)
				DECLARE @city [nvarchar] (50)
				
				SELECT @firstName = BillFirstName, @lastName = BillLastName, @address1 = BillAddress1, @city = BillCity
				  FROM inserted
				  
				-- If address info is blank, we wont do the update
				if (@firstName = '' and @lastName = '' and @address1 = '' and @city = '')
				begin
					SELECT @doUpdate = 0
				end
				
			end

			if (@doUpdate = 1)
			begin
			
				UPDATE c 
				SET
					c.ShipEmail = i.ShipEmail,     
					c.ShipFirstName = i.ShipFirstName,     
					c.ShipLastName = i.ShipLastName,     
					c.ShipCompany = i.ShipCompany,     
					c.ShipAddress1 = i.ShipAddress1,     
					c.ShipAddress2 = i.ShipAddress2,     
					c.ShipAddress3 = i.ShipAddress3,     
					c.ShipCity = i.ShipCity,     
					c.ShipStateProvinceCode = i.ShipStateProvinceCode,     
					c.ShipPostalCode = i.ShipPostalCode,     
					c.ShipCountryCode = i.ShipCountryCode,     
					c.ShipPhone = i.ShipPhone,     
					c.ShipFax = i.ShipFax,     
					c.BillEmail = i.BillEmail,     
					c.BillFirstName = i.BillFirstName,     
					c.BillLastName = i.BillLastName,     
					c.BillCompany = i.BillCompany,     
					c.BillAddress1 = i.BillAddress1,     
					c.BillAddress2 = i.BillAddress2,     
					c.BillAddress3 = i.BillAddress3,     
					c.BillCity = i.BillCity,     
					c.BillStateProvinceCode = i.BillStateProvinceCode,     
					c.BillPostalCode = i.BillPostalCode,     
					c.BillCountryCode = i.BillCountryCode,     
					c.BillPhone = i.BillPhone,     
					c.BillFax = i.BillFax,
					c.eBayBuyerID = @eBayBuyerID,
					c.MarketWorksBuyerNumber = i.MarketWorksBuyerNumber,
					c.osCommerceCustomerID = i.osCommerceCustomerID,
					c.InfopiaCustomerID = i.InfopiaCustomerID,
					c.MagentoCustomerID = i.MagentoCustomerID
					
				FROM Customers c, inserted i
				WHERE c.CustomerID = @customerID
				
			end
    end
         
    -- Now, we can insert the rows into the real orders table
    INSERT INTO Orders 
    (
        OrderNumber, 
        StoreID, 
        CustomerID, 
        OrderDate, 
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1, 
        ShipAddress2, 
        ShipAddress3, 
        ShipCity, 
        ShipStateProvinceCode, 
        ShipPostalCode, 
        ShipCountryCode, 
        ShipEmail, 
        ShipPhone,
        ShipFax,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1, 
        BillAddress2, 
        BillAddress3, 
        BillCity, 
        BillStateProvinceCode, 
        BillPostalCode, 
        BillCountryCode, 
        BillEmail, 
        BillPhone,
        BillFax,
        CustomerComments,
        RequestedShipping,
        Total, 
        Notes, 
        Status,
        IsManual,
        OrderNumberPrefix,
        OrderNumberPostfix,
        OnlineLastModified, 
        eBayOrderID, 
        eBayOrderCreated,
        eBayBuyerID, 
        eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate,
        eBayPaymentStatus, 
        eBayPaymentMethod, 
        eBayCheckoutStatus, 
        eBayCompleteStatus, 
        eBayLeftFeedback, 
        eBayLeftFeedbackType, 
        eBayLeftFeedbackComments, 
        eBayReceivedFeedbackType, 
        eBayReceivedFeedbackComments, 
        eBayMyEbayStatus,
        eBaySellerPaidStatus,
        eBayAllowEdit, 
        eBaySellingManagerRecord,
        PayPalAddressStatus,
        PayPalTransactionID,
        MarketWorksUserNumber,
        MarketWorksInvoiceNumber,
        MarketWorksBuyerNumber,
        MivaBatchID,
        MivaStatus,
        MarketWorksParcelID,
        osCommerceCustomerID,
        osCommerceStatusCode,
        YahooOrderID,
        ProStoresStatus,
        ProStoresConfirmation,
        ChannelAdvisorReportID,
        ChannelAdvisorResellerID,
        ChannelAdvisorDistributionCenter,
        ChannelAdvisorOrderID,
	    InfopiaCustomerID,
	    InfopiaStatus,
	    AmazonOrderID,
	    AmazonStatusDocumentID,
	    AmazonCommission,
	    XCartStatus,
	    OrderMotionShipmentID,
	    OrderMotionPromotion,
	    WasArchived,
	    ClickCartProStatusCode,
	    ClickCartProID,
	    PayPalFee,
	    PayPalPaymentStatus,
	    VolusionStatus,
	    NetworkSolutionsStatus,
	    NetworkSolutionsOrderID,
	    MagentoStatusCode,
	    MagentoCustomerID,
	    MagentoOrderID,
	    AmeriCommerceStatusCode,
	    CommerceInterfaceStatusCode,
	    CommerceInterfaceOrderNumber,
	    ProStoresAuthorizationDate
	    
    )
       SELECT         
        OrderNumber, 
        StoreID, 
        @customerID, 
        OrderDate, 
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1, 
        ShipAddress2, 
        ShipAddress3, 
        ShipCity, 
        ShipStateProvinceCode, 
        ShipPostalCode, 
        ShipCountryCode, 
        ShipEmail, 
        ShipPhone,
        ShipFax,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1, 
        BillAddress2, 
        BillAddress3, 
        BillCity, 
        BillStateProvinceCode, 
        BillPostalCode, 
        BillCountryCode, 
        BillEmail, 
        BillPhone,
        BillFax,
        CustomerComments,
        RequestedShipping,
        Total, 
        Notes, 
        Status,
        IsManual,
        OrderNumberPrefix,
        OrderNumberPostfix,
        OnlineLastModified, 
        eBayOrderID,
        eBayOrderCreated,
        @eBayBuyerID, 
        eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate,
        eBayPaymentStatus, 
        eBayPaymentMethod, 
        eBayCheckoutStatus, 
        eBayCompleteStatus, 
        eBayLeftFeedback, 
        eBayLeftFeedbackType, 
        eBayLeftFeedbackComments, 
        eBayReceivedFeedbackType, 
        eBayReceivedFeedbackComments, 
        eBayMyEbayStatus, 
        eBaySellerPaidStatus,
        eBayAllowEdit, 
        eBaySellingManagerRecord,
        PayPalAddressStatus,
        PayPalTransactionID,
        MarketWorksUserNumber,
        MarketWorksInvoiceNumber,
        MarketWorksBuyerNumber,
        MivaBatchID,
		MivaStatus,        
        MarketWorksParcelID,
        osCommerceCustomerID,
        osCommerceStatusCode,
        YahooOrderID,
        ProStoresStatus,
        ProStoresConfirmation,
        ChannelAdvisorReportID,
        ChannelAdvisorResellerID,
        ChannelAdvisorDistributionCenter,
        ChannelAdvisorOrderID,
	    InfopiaCustomerID,
	    InfopiaStatus,
	    AmazonOrderID,
	    AmazonStatusDocumentID,
	    AmazonCommission,
	    XCartStatus,
	    OrderMotionShipmentID,
	    OrderMotionPromotion,
	    WasArchived,
	    ClickCartProStatusCode,
	    ClickCartProID,
	    PayPalFee,
	    PayPalPaymentStatus,
	    VolusionStatus,
	    NetworkSolutionsStatus,
	    NetworkSolutionsOrderID,
	    MagentoStatusCode,
	    MagentoCustomerID,
	    MagentoOrderID,
	    AmeriCommerceStatusCode ,
	    CommerceInterfaceStatusCode,
	    CommerceInterfaceOrderNumber,
	    ProStoresAuthorizationDate
     FROM inserted i
GO