----------------------------
--- PROCEDURE AddFedexClosing
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.AddFedexClosing') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure dbo.AddFedexClosing
GO

CREATE PROCEDURE dbo.AddFedexClosing
(
	@ShipperID int,
	@ShipperAccountNumber int,
	@CloseDate datetime,
	@ReportPaths nvarchar (450)
)
WITH ENCRYPTION
AS
    INSERT INTO FedexClosings
    (
        ShipperID,
        ShipperAccountNumber,
        CloseDate,
        ReportPaths
    )
    VALUES
    (
        @ShipperID,
        @ShipperAccountNumber,
        @CloseDate,
        @ReportPaths
    )
    
    if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT ClosingID
   FROM FedexClosings
   WHERE ClosingID = SCOPE_IDENTITY()
   
   return 1
GO

----------------------------
--- PROCEDURE GetRecentClosings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetRecentClosings') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure dbo.GetRecentClosings
GO

CREATE PROCEDURE dbo.GetRecentClosings
(
	@ShipperID int,
	@MaxDays int
)
WITH ENCRYPTION
AS 
    if ( (SELECT Count(*) FROM FedexClosings) = 0)
        return 0
    
    SELECT fc.*
    FROM FedexClosings fc
    WHERE fc.CloseDate >= DATEADD(day, -@MaxDays, (SELECT MAX(fcInner.CloseDate) FROM FedexClosings fcInner)) AND
      fc.ShipperID = @ShipperID
    ORDER BY CloseDate ASC

GO