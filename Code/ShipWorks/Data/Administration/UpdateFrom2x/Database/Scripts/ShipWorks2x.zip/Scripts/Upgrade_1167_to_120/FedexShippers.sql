-----------------------------
--- TABLE FedexShippers
-----------------------------
CREATE TABLE dbo.FedexShippers
(
    FedexShipperID int IDENTITY (1, 1) NOT NULL ,
    [RowVersion] timestamp NOT NULL,
    AccountNumber int NOT NULL ,
    MeterNumber int NOT NULL ,
    UseAlternate bit NOT NULL,
    Company nvarchar (35) NOT NULL ,
    ContactName nvarchar (35) NOT NULL,
    Address1 nvarchar (60) NOT NULL ,
    Address2 nvarchar (60) NOT NULL ,
    City nvarchar (50) NOT NULL ,
    StateProvinceCode nvarchar (5) NOT NULL ,
    PostalCode nvarchar (10) NOT NULL ,
    CountryCode nvarchar (5) NOT NULL ,
    ContactEmail nvarchar (25) NOT NULL ,
    ContactPhone nvarchar (25) NOT NULL ,
    ContactFax nvarchar (25) NOT NULL ,
    AlternateCompany nvarchar (35) NOT NULL ,
    AlternateContactName nvarchar (35) NOT NULL,
    AlternateAddress1 nvarchar (60) NOT NULL ,
    AlternateAddress2 nvarchar (60) NOT NULL ,
    AlternateCity nvarchar (50) NOT NULL ,
    AlternateStateProvinceCode nvarchar (5) NOT NULL ,
    AlternatePostalCode nvarchar (10) NOT NULL ,
    AlternateCountryCode nvarchar (5) NOT NULL ,
    AlternateContactEmail nvarchar (25) NOT NULL ,
    AlternateContactPhone nvarchar (25) NOT NULL ,
    AlternateContactFax nvarchar (25) NOT NULL ,
    SignatureReleaseNumber varchar (10) NOT NULL,
    CONSTRAINT [PK_FedexShippers] PRIMARY KEY CLUSTERED ([FedexShipperID])
)
GO

----------------------------
--- PROCEDURE AddFedexShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFedexShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddFedexShipper]
GO

CREATE PROCEDURE dbo.AddFedexShipper
(
    @AccountNumber int ,
    @MeterNumber int ,
    @UseAlternate bit ,
    @Company nvarchar (35) ,
    @ContactName nvarchar (35) ,
    @Address1 nvarchar (60) ,
    @Address2 nvarchar (60) ,
    @City nvarchar (50) ,
    @StateProvinceCode nvarchar (5) ,
    @PostalCode nvarchar (10) ,
    @CountryCode nvarchar (5) ,
    @ContactEmail nvarchar (25) ,
    @ContactPhone nvarchar (25) ,
    @ContactFax nvarchar (25) ,
    @AlternateCompany nvarchar (35) ,
    @AlternateContactName nvarchar (35) ,
    @AlternateAddress1 nvarchar (60) ,
    @AlternateAddress2 nvarchar (60) ,
    @AlternateCity nvarchar (50) ,
    @AlternateStateProvinceCode nvarchar (5) ,
    @AlternatePostalCode nvarchar (10) ,
    @AlternateCountryCode nvarchar (5) ,
    @AlternateContactEmail nvarchar (25) ,
    @AlternateContactPhone nvarchar (25) ,
    @AlternateContactFax nvarchar (25),
    @SignatureReleaseNumber varchar (10)
)
AS
   INSERT INTO FedexShippers 
   (
        AccountNumber,
        MeterNumber,
        UseAlternate,
        Company,
        ContactName,
        Address1,
        Address2,
        City,
        StateProvinceCode,
        PostalCode,
        CountryCode,
        ContactEmail,
        ContactPhone,
        ContactFax,
        AlternateCompany,
        AlternateContactName,
        AlternateAddress1,
        AlternateAddress2,
        AlternateCity,
        AlternateStateProvinceCode,
        AlternatePostalCode,
        AlternateCountryCode,
        AlternateContactEmail,
        AlternateContactPhone,
        AlternateContactFax,
        SignatureReleaseNumber
   )
   VALUES 
   (
        @AccountNumber,
        @MeterNumber,
        @UseAlternate,
        @Company,
        @ContactName,
        @Address1,
        @Address2,
        @City,
        @StateProvinceCode,
        @PostalCode,
        @CountryCode,
        @ContactEmail,
        @ContactPhone,
        @ContactFax,
        @AlternateCompany,
        @AlternateContactName,
        @AlternateAddress1,
        @AlternateAddress2,
        @AlternateCity,
        @AlternateStateProvinceCode,
        @AlternatePostalCode,
        @AlternateCountryCode,
        @AlternateContactEmail,
        @AlternateContactPhone,
        @AlternateContactFax,
        @SignatureReleaseNumber
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT FedexShipperID, [RowVersion]
     FROM FedexShippers
     WHERE FedexShipperID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateFedexShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFedexShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFedexShipper]
GO

CREATE PROCEDURE dbo.UpdateFedexShipper
(
    @FedexShipperID int,
    @RowVersion timestamp,
    @AccountNumber int ,
    @MeterNumber int ,
    @UseAlternate bit ,
    @Company nvarchar (35) ,
    @ContactName nvarchar (35) ,
    @Address1 nvarchar (60) ,
    @Address2 nvarchar (60) ,
    @City nvarchar (50) ,
    @StateProvinceCode nvarchar (5) ,
    @PostalCode nvarchar (10) ,
    @CountryCode nvarchar (5) ,
    @ContactEmail nvarchar (25) ,
    @ContactPhone nvarchar (25) ,
    @ContactFax nvarchar (25) ,
    @AlternateCompany nvarchar (35) ,
    @AlternateContactName nvarchar (35) ,
    @AlternateAddress1 nvarchar (60) ,
    @AlternateAddress2 nvarchar (60) ,
    @AlternateCity nvarchar (50) ,
    @AlternateStateProvinceCode nvarchar (5) ,
    @AlternatePostalCode nvarchar (10) ,
    @AlternateCountryCode nvarchar (5) ,
    @AlternateContactEmail nvarchar (25) ,
    @AlternateContactPhone nvarchar (25) ,
    @AlternateContactFax nvarchar (25),
    @SignatureReleaseNumber varchar (10)
)
AS
   UPDATE FedexShippers
      SET           
        AccountNumber = @AccountNumber,
        MeterNumber = @MeterNumber,
        UseAlternate = @UseAlternate,
        Company = @Company,
        ContactName = @ContactName,
        Address1 = @Address1,
        Address2 = @Address2,
        City = @City,
        StateProvinceCode = @StateProvinceCode,
        PostalCode = @PostalCode,
        CountryCode = @CountryCode,
        ContactEmail = @ContactEmail,
        ContactPhone = @ContactPhone,
        ContactFax = @ContactFax,
        AlternateCompany = @AlternateCompany,
        AlternateContactName = @AlternateContactName,
        AlternateAddress1 = @AlternateAddress1,
        AlternateAddress2 = @AlternateAddress2,
        AlternateCity = @AlternateCity,
        AlternateStateProvinceCode = @AlternateStateProvinceCode,
        AlternatePostalCode = @AlternatePostalCode,
        AlternateCountryCode = @AlternateCountryCode,
        AlternateContactEmail = @AlternateContactEmail,
        AlternateContactPhone = @AlternateContactPhone,
        AlternateContactFax = @AlternateContactFax,
        SignatureReleaseNumber = @SignatureReleaseNumber
      WHERE FedexShipperID = @FedexShipperID and [RowVersion] = @RowVersion
      
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT FedexShipperID, [RowVersion]
       FROM FedexShippers
       WHERE FedexShipperID = @FedexShipperID

    return 1
GO

-----------------------------
--- Procedure DeleteFedexShipper
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteFedexShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteFedexShipper]
GO

CREATE PROCEDURE dbo.DeleteFedexShipper
(
   @FedexShipperID int
)
AS
    DELETE FROM FedexShippers
    WHERE FedexShipperID = @FedexShipperID
GO

----------------------------
--- PROCEDURE GetAllFedexShippers
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllFedexShippers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllFedexShippers]
GO

CREATE PROCEDURE dbo.GetAllFedexShippers 
AS
   SELECT *
   FROM FedexShippers
GO