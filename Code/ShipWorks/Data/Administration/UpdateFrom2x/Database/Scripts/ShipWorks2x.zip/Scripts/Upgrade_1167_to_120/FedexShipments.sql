-----------------------------
--- TABLE FedexShipments
-----------------------------
CREATE TABLE dbo.FedexShipments
(
	ShipmentID int NOT NULL ,
	[RowVersion] timestamp NOT NULL,
    ReferenceNumber nvarchar (50) NOT NULL ,
    ServiceType smallint NOT NULL ,
    PackagingType smallint NOT NULL,
    Voided bit NOT NULL,
    GroundClosedID int NOT NULL,
    ArrivalDate datetime NOT NULL,
    ThermalLabel bit NOT NULL,
    FormID varchar (4) NOT NULL,
    PayorType smallint NOT NULL,
    PayorAccountNumber nvarchar (12) NOT NULL,
    DutiesPayorType smallint NOT NULL,
    DutiesPayorAccountNumber nvarchar (12) NOT NULL,
    FreightInsidePickup bit NOT NULL,
    FreightInsideDelivery bit NOT NULL,
    FreightBookingNumber varchar (12) NOT NULL,
    SaturdayPickup bit NOT NULL,
    SaturdayDelivery bit NOT NULL,
    SignatureOption int NOT NULL,
    NonStandardContainer bit NOT NULL,
    HomeDeliveryType int NOT NULL,
    HomeDeliveryInstructions varchar (74) NOT NULL,
    HomeDeliveryDate datetime NOT NULL,
    HomeDeliveryPhone varchar (16) NOT NULL,
    ShipAlertRecipientAddress nvarchar (35) NOT NULL,
	ShipAlertRecipientShip bit NOT NULL,
    ShipAlertRecipientDelivery bit NOT NULL,
    ShipAlertSenderShip bit NOT NULL,
    ShipAlertSenderDelivery bit NOT NULL,
    ShipAlertOther1Address nvarchar (120) NOT NULL,
    ShipAlertOther1Ship bit NOT NULL,
    ShipAlertOther1Delivery bit NOT NULL,
    ShipAlertExpressMessage nvarchar (75) NOT NULL,
    ShipAlertGroundEnable bit NOT NULL,
    ShipAlertGroundAddress nvarchar (35) NOT NULL,
    ShipAlertGroundMessage nvarchar (75) NOT NULL,
    CodEnable bit NOT NULL,
    CodAmount money NOT NULL,
    CodType int NOT NULL,
    CodAddFreight bit NOT NULL,
    CodReturnContactName nvarchar (35) NOT NULL,
    CodReturnCompany nvarchar (35) NOT NULL,
    CodReturnAddress1 nvarchar (35) NOT NULL,
    CodReturnAddress2 nvarchar (35) NOT NULL,
    CodReturnCity nvarchar (35) NOT NULL,
    CodReturnStateProvinceCode nvarchar (2) NOT NULL,
    CodReturnPostalCode nvarchar (16) NOT NULL,
    CodReturnPhone nvarchar (16) NOT NULL,
    CodReturnLabelPath nvarchar (350) NOT NULL,
	BrokerEnable bit NOT NULL,
    BrokerAccount nvarchar (12) NOT NULL,
    BrokerContactName nvarchar (35) NOT NULL,
    BrokerCompany nvarchar (35) NOT NULL,
    BrokerAddress1 nvarchar (35) NOT NULL,
    BrokerAddress2 nvarchar (35) NOT NULL,
    BrokerCity nvarchar (35) NOT NULL,
    BrokerStateProvinceCode nvarchar (2) NOT NULL,
    BrokerPostalCode nvarchar (16) NOT NULL,
    BrokerPhone nvarchar (16) NOT NULL,
    CustomsDocuments bit NOT NULL,
    CustomsDocumentsDescription varchar(50) NOT NULL,
    CustomsRecipientTIN varchar(15) NOT NULL,
    CustomsTermsOfSale int NOT NULL,
    CustomsRelatedParties bit NOT NULL,
    CustomsNafta bit NOT NULL,
    CustomsTotalValue money NOT NULL,
    CustomsCanadaPackageType int NOT NULL,
    CommercialInvoiceEnabled bit NOT NULL,
    CommercialInvoiceComments nvarchar(200) NOT NULL,
    CommercialInvoiceFreight money NOT NULL,
    CommercialInvoiceInsurance money NOT NULL,
    CommercialInvoiceAdditional money NOT NULL,
    CommercialInvoicePurpose int NOT NULL,
    SedRequired bit NOT NULL,
    SedID varchar(15) NOT NULL,
    SedIDType int NOT NULL,
    SedUseExemption bit NOT NULL,
    SedExemption varchar(32) NOT NULL,
    AdmissibilityPackaging int NOT NULL,
    ImporterDifferent bit NOT NULL,
    ImporterAccount nvarchar (12) NOT NULL,
    ImporterTIN nvarchar (15) NOT NULL,
    ImporterContactName nvarchar (35) NOT NULL,
    ImporterCompany nvarchar (35) NOT NULL,
    ImporterAddress1 nvarchar (35) NOT NULL,
    ImporterAddress2 nvarchar (35) NOT NULL,
    ImporterCity nvarchar (35) NOT NULL,
    ImporterStateProvinceCode nvarchar (2) NOT NULL,
    ImporterPostalCode nvarchar (16) NOT NULL,
    ImporterCountryCode nvarchar (16) NOT NULL,
    ImporterPhone nvarchar (16) NOT NULL,
    ShipToResidential bit NOT NULL,
    ShipFromShipperID int NOT NULL ,
	ShipFromContactName nvarchar (30) NOT NULL ,
	ShipFromCompany nvarchar (30) NOT NULL ,
	ShipFromAddress1 nvarchar (60) NOT NULL ,
	ShipFromAddress2 nvarchar (60) NOT NULL ,
	ShipFromCity nvarchar (50) NOT NULL ,
	ShipFromStateProvinceCode nvarchar (5) NOT NULL ,
	ShipFromPostalCode nvarchar (10) NOT NULL ,
	ShipFromCountryCode nvarchar (5) NOT NULL ,
    ShipFromContactEmail nvarchar (25) NOT NULL ,
	ShipFromContactPhone nvarchar (25) NOT NULL ,
	ShipFromContactFax nvarchar (25) NOT NULL ,
    CONSTRAINT [IX_FedexShipments_ShipmentID] UNIQUE NONCLUSTERED (ShipmentID),
	CONSTRAINT [FK_FedexShipments_Shipments] FOREIGN KEY ([ShipmentID]) REFERENCES [Shipments] ([ShipmentID]) 
)
GO

-----------------------------
--- Procedure GetOrderFedexShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderFedexShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderFedexShipments]
GO

CREATE PROCEDURE dbo.GetOrderFedexShipments
(
    @OrderID int
)
AS
   SELECT u.*
   FROM FedexShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerFedexShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerFedexShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerFedexShipments]
GO

CREATE PROCEDURE dbo.GetCustomerFedexShipments
(
    @CustomerID int
)
AS
   SELECT u.*
   FROM FedexShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderFedexShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderFedexShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderFedexShipmentRange]
GO

CREATE PROCEDURE dbo.GetOrderFedexShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT u.*
     FROM FedexShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerFedexShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerFedexShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerFedexShipmentRange]
GO

CREATE PROCEDURE dbo.GetCustomerFedexShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT u.*
     FROM FedexShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure UpdateFedexShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFedexShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFedexShipment]
GO

CREATE PROCEDURE dbo.UpdateFedexShipment
(
    @ShipmentID int,
    @RowVersion timestamp ,
    @ReferenceNumber nvarchar (50)  ,
    @ServiceType smallint,
    @PackagingType smallint,
    @Voided bit ,
    @GroundClosedID int,
    @ArrivalDate datetime ,
    @ThermalLabel bit,
    @FormID varchar (4),
    @PayorType smallint,
    @PayorAccountNumber nvarchar (12),
    @DutiesPayorType smallint,
    @DutiesPayorAccountNumber nvarchar (12),
    @FreightInsidePickup bit,
    @FreightInsideDelivery bit,
    @FreightBookingNumber varchar (12),
    @SaturdayPickup bit,
    @SaturdayDelivery bit,
    @SignatureOption int,
    @NonStandardContainer bit,
    @HomeDeliveryType int,
    @HomeDeliveryInstructions varchar (74),
    @HomeDeliveryDate datetime,
    @HomeDeliveryPhone varchar (16),
    @ShipAlertRecipientAddress nvarchar (35),
    @ShipAlertRecipientShip bit,
    @ShipAlertRecipientDelivery bit,
    @ShipAlertSenderShip bit,
    @ShipAlertSenderDelivery bit,
    @ShipAlertOther1Address nvarchar (120),
    @ShipAlertOther1Ship bit,
    @ShipAlertOther1Delivery bit,
    @ShipAlertExpressMessage nvarchar (75),
    @ShipAlertGroundEnable bit,
    @ShipAlertGroundAddress nvarchar (35),
    @ShipAlertGroundMessage nvarchar (75),
    @CodEnable bit,
    @CodAmount money,
    @CodType int,
    @CodAddFreight bit,
    @CodReturnContactName nvarchar (35),
    @CodReturnCompany nvarchar (35),
    @CodReturnAddress1 nvarchar (35),
    @CodReturnAddress2 nvarchar (35),
    @CodReturnCity nvarchar (35),
    @CodReturnStateProvinceCode nvarchar (2),
    @CodReturnPostalCode nvarchar (16),
    @CodReturnPhone nvarchar (16),
    @CodReturnLabelPath nvarchar (350),
    @BrokerEnable bit,
    @BrokerAccount nvarchar (12),
    @BrokerContactName nvarchar (35),
    @BrokerCompany nvarchar (35),
    @BrokerAddress1 nvarchar (35),
    @BrokerAddress2 nvarchar (35),
    @BrokerCity nvarchar (35),
    @BrokerStateProvinceCode nvarchar (2),
    @BrokerPostalCode nvarchar (16),
    @BrokerPhone nvarchar (16),
    @CustomsDocuments bit,
    @CustomsDocumentsDescription varchar(50),
    @CustomsRecipientTIN varchar(15),
    @CustomsTermsOfSale int,
    @CustomsRelatedParties bit,
    @CustomsNafta bit,
    @CustomsTotalValue money,
    @CustomsCanadaPackageType int,
    @CommercialInvoiceEnabled bit,
    @CommercialInvoiceComments nvarchar(200),
    @CommercialInvoiceFreight money,
    @CommercialInvoiceInsurance money,
    @CommercialInvoiceAdditional money,
    @CommercialInvoicePurpose int,
    @SedRequired bit,
    @SedID varchar(15),
    @SedIDType int,
    @SedUseExemption bit,
    @SedExemption varchar(32),
    @AdmissibilityPackaging int,
    @ImporterDifferent bit,
    @ImporterAccount nvarchar (12),
    @ImporterTIN nvarchar (15),
    @ImporterContactName nvarchar (35),
    @ImporterCompany nvarchar (35),
    @ImporterAddress1 nvarchar (35),
    @ImporterAddress2 nvarchar (35),
    @ImporterCity nvarchar (35),
    @ImporterStateProvinceCode nvarchar (2),
    @ImporterPostalCode nvarchar (16),
    @ImporterCountryCode nvarchar (16),
    @ImporterPhone nvarchar (16),
    @ShipToResidential bit ,
    @ShipFromShipperID int  ,
	@ShipFromContactName nvarchar (30)  ,
	@ShipFromCompany nvarchar (30)  ,
	@ShipFromAddress1 nvarchar (60)  ,
	@ShipFromAddress2 nvarchar (60)  ,
	@ShipFromCity nvarchar (50)  ,
	@ShipFromStateProvinceCode nvarchar (5)  ,
	@ShipFromPostalCode nvarchar (10)  ,
	@ShipFromCountryCode nvarchar (5)  ,
    @ShipFromContactEmail nvarchar (25)  ,
	@ShipFromContactPhone nvarchar (25)  ,
	@ShipFromContactFax nvarchar (25)
)
AS
    UPDATE [FedexShipments]
    SET 
        ReferenceNumber = @ReferenceNumber,
        ServiceType = @ServiceType,
        PackagingType = @PackagingType,
        Voided = @Voided,
        GroundClosedID = @GroundClosedID,
        ArrivalDate = @ArrivalDate,
        ThermalLabel = @ThermalLabel,
        FormID = @FormID,
        PayorType = @PayorType,
        PayorAccountNumber = @PayorAccountNumber,
        DutiesPayorType = @DutiesPayorType,
        DutiesPayorAccountNumber = @DutiesPayorAccountNumber,
        FreightInsidePickup = @FreightInsidePickup,
        FreightInsideDelivery = @FreightInsideDelivery,
        FreightBookingNumber = @FreightBookingNumber,
        SaturdayPickup = @SaturdayPickup,
        SaturdayDelivery = @SaturdayDelivery,
        SignatureOption = @SignatureOption,
        NonStandardContainer = @NonStandardContainer,
		HomeDeliveryType  = @HomeDeliveryType,
		HomeDeliveryInstructions = @HomeDeliveryInstructions,
		HomeDeliveryDate = @HomeDeliveryDate,
		HomeDeliveryPhone = @HomeDeliveryPhone,
		ShipAlertRecipientAddress = @ShipAlertRecipientAddress,
        ShipAlertRecipientShip = @ShipAlertRecipientShip,
        ShipAlertRecipientDelivery = @ShipAlertRecipientDelivery,
        ShipAlertSenderShip = @ShipAlertSenderShip,
        ShipAlertSenderDelivery = @ShipAlertSenderDelivery,
        ShipAlertOther1Address = @ShipAlertOther1Address,
        ShipAlertOther1Ship = @ShipAlertOther1Ship,
        ShipAlertOther1Delivery = @ShipAlertOther1Delivery,
        ShipAlertExpressMessage = @ShipAlertExpressMessage,
        ShipAlertGroundEnable = @ShipAlertGroundEnable,
        ShipAlertGroundAddress = @ShipAlertGroundAddress,
        ShipAlertGroundMessage = @ShipAlertGroundMessage,
		CodEnable = @CodEnable,
		CodAmount = @CodAmount,
		CodType = @CodType,
		CodAddFreight = @CodAddFreight,
		CodReturnContactName = @CodReturnContactName,
		CodReturnCompany = @CodReturnCompany,
		CodReturnAddress1 = @CodReturnAddress1,
		CodReturnAddress2 = @CodReturnAddress2,
		CodReturnCity = @CodReturnCity,
		CodReturnStateProvinceCode = @CodReturnStateProvinceCode,
		CodReturnPostalCode = @CodReturnPostalCode,
		CodReturnPhone = @CodReturnPhone,
		CodReturnLabelPath = @CodReturnLabelPath,
        BrokerEnable = @BrokerEnable,
        BrokerAccount = @BrokerAccount,
        BrokerContactName = @BrokerContactName,
        BrokerCompany = @BrokerCompany,
        BrokerAddress1 = @BrokerAddress1,
        BrokerAddress2 = @BrokerAddress2,
        BrokerCity = @BrokerCity,
        BrokerStateProvinceCode = @BrokerStateProvinceCode,
        BrokerPostalCode = @BrokerPostalCode,
        BrokerPhone = @BrokerPhone,
		CustomsDocuments = @CustomsDocuments,
		CustomsDocumentsDescription = @CustomsDocumentsDescription,
		CustomsRecipientTIN = @CustomsRecipientTIN,
		CustomsTermsOfSale = @CustomsTermsOfSale,
		CustomsRelatedParties = @CustomsRelatedParties,
		CustomsNafta = @CustomsNafta,
		CustomsTotalValue = @CustomsTotalValue,
		CustomsCanadaPackageType = @CustomsCanadaPackageType,
		CommercialInvoiceEnabled = @CommercialInvoiceEnabled,
		CommercialInvoiceComments = @CommercialInvoiceComments,
		CommercialInvoiceFreight = @CommercialInvoiceFreight,
		CommercialInvoiceInsurance = @CommercialInvoiceInsurance,
		CommercialInvoiceAdditional = @CommercialInvoiceAdditional,
		CommercialInvoicePurpose = @CommercialInvoicePurpose,
		SedRequired = @SedRequired,
		SedID = @SedID,
		SedIDType = @SedIDType,
		SedUseExemption = @SedUseExemption,
		SedExemption = @SedExemption,
		AdmissibilityPackaging = @AdmissibilityPackaging,
		ImporterDifferent = @ImporterDifferent,
		ImporterAccount = @ImporterAccount,
		ImporterTIN = @ImporterTIN,
		ImporterContactName = @ImporterContactName,
		ImporterCompany = @ImporterCompany,
		ImporterAddress1 = @ImporterAddress1,
		ImporterAddress2 = @ImporterAddress2,
		ImporterCity = @ImporterCity,
		ImporterStateProvinceCode = @ImporterStateProvinceCode,
		ImporterPostalCode = @ImporterPostalCode,
		ImporterCountryCode = @ImporterCountryCode,
		ImporterPhone = @ImporterPhone,
        ShipToResidential = @ShipToResidential,
	    ShipFromShipperID = @ShipFromShipperID,
	    ShipFromContactName = @ShipFromContactName,
	    ShipFromCompany = @ShipFromCompany,
	    ShipFromAddress1 = @ShipFromAddress1,
	    ShipFromAddress2 = @ShipFromAddress2,
	    ShipFromCity = @ShipFromCity,
	    ShipFromStateProvinceCode = @ShipFromStateProvinceCode,
	    ShipFromPostalCode = @ShipFromPostalCode,
	    ShipFromCountryCode = @ShipFromCountryCode,
        ShipFromContactEmail = @ShipFromContactEmail,
	    ShipFromContactPhone = @ShipFromContactPhone,
	    ShipFromContactFax = @ShipFromContactFax
    WHERE ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM FedexShipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

-----------------------------
--- Procedure AddFedexShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFedexShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddFedexShipment]
GO

CREATE PROCEDURE dbo.AddFedexShipment
(
    @ShipmentID int,
    @ReferenceNumber nvarchar (50)  ,
    @ServiceType smallint,
    @PackagingType smallint,
    @Voided bit ,
    @GroundClosedID int,
    @ArrivalDate datetime ,
    @ThermalLabel bit,
    @FormID varchar (4),
    @PayorType smallint,
    @PayorAccountNumber nvarchar (12),
    @DutiesPayorType smallint,
    @DutiesPayorAccountNumber nvarchar (12),
    @FreightInsidePickup bit,
    @FreightInsideDelivery bit,
    @FreightBookingNumber varchar (12),
    @SaturdayPickup bit,
    @SaturdayDelivery bit,
    @SignatureOption int,
    @NonStandardContainer bit,
    @HomeDeliveryType int,
    @HomeDeliveryInstructions varchar (74),
    @HomeDeliveryDate datetime,
    @HomeDeliveryPhone varchar (16),
    @ShipAlertRecipientAddress nvarchar (35),
    @ShipAlertRecipientShip bit,
    @ShipAlertRecipientDelivery bit,
    @ShipAlertSenderShip bit,
    @ShipAlertSenderDelivery bit,
    @ShipAlertOther1Address nvarchar (120),
    @ShipAlertOther1Ship bit,
    @ShipAlertOther1Delivery bit,
    @ShipAlertExpressMessage nvarchar (75),
    @ShipAlertGroundEnable bit,
    @ShipAlertGroundAddress nvarchar (35),
    @ShipAlertGroundMessage nvarchar (75),
    @CodEnable bit,
    @CodAmount money,
    @CodType int,
    @CodAddFreight bit,
    @CodReturnContactName nvarchar (35),
    @CodReturnCompany nvarchar (35),
    @CodReturnAddress1 nvarchar (35),
    @CodReturnAddress2 nvarchar (35),
    @CodReturnCity nvarchar (35),
    @CodReturnStateProvinceCode nvarchar (2),
    @CodReturnPostalCode nvarchar (16),
    @CodReturnPhone nvarchar (16),
    @CodReturnLabelPath nvarchar (350),
    @BrokerEnable bit,
    @BrokerAccount nvarchar (12),
    @BrokerContactName nvarchar (35),
    @BrokerCompany nvarchar (35),
    @BrokerAddress1 nvarchar (35),
    @BrokerAddress2 nvarchar (35),
    @BrokerCity nvarchar (35),
    @BrokerStateProvinceCode nvarchar (2),
    @BrokerPostalCode nvarchar (16),
    @BrokerPhone nvarchar (16),
    @CustomsDocuments bit,
    @CustomsDocumentsDescription varchar(50),
    @CustomsRecipientTIN varchar(15),
    @CustomsTermsOfSale int,
    @CustomsRelatedParties bit,
    @CustomsNafta bit,
    @CustomsTotalValue money,
    @CustomsCanadaPackageType int,
    @CommercialInvoiceEnabled bit,
    @CommercialInvoiceComments nvarchar(200),
    @CommercialInvoiceFreight money,
    @CommercialInvoiceInsurance money,
    @CommercialInvoiceAdditional money,
    @CommercialInvoicePurpose int,
    @SedRequired bit,
    @SedID varchar(15),
    @SedIDType int,
    @SedUseExemption bit,
    @SedExemption varchar(32),
    @AdmissibilityPackaging int,
    @ImporterDifferent bit,
    @ImporterAccount nvarchar (12),
    @ImporterTIN nvarchar (15),
    @ImporterContactName nvarchar (35),
    @ImporterCompany nvarchar (35),
    @ImporterAddress1 nvarchar (35),
    @ImporterAddress2 nvarchar (35),
    @ImporterCity nvarchar (35),
    @ImporterStateProvinceCode nvarchar (2),
    @ImporterPostalCode nvarchar (16),
    @ImporterCountryCode nvarchar (16),
    @ImporterPhone nvarchar (16),
    @ShipToResidential bit ,
    @ShipFromShipperID int  ,
	@ShipFromContactName nvarchar (30)  ,
	@ShipFromCompany nvarchar (30)  ,
	@ShipFromAddress1 nvarchar (60)  ,
	@ShipFromAddress2 nvarchar (60)  ,
	@ShipFromCity nvarchar (50)  ,
	@ShipFromStateProvinceCode nvarchar (5)  ,
	@ShipFromPostalCode nvarchar (10)  ,
	@ShipFromCountryCode nvarchar (5)  ,
    @ShipFromContactEmail nvarchar (25)  ,
	@ShipFromContactPhone nvarchar (25)  ,
	@ShipFromContactFax nvarchar (25)
)
AS
    if (exists(SELECT * FROM FedexShipments WHERE ShipmentID = @ShipmentID))
    begin
    
        select * from FedexShipments WHERE ShipmentID = @ShipmentID
        
    end
    else
    begin
        INSERT INTO [FedexShipments]
        (
	        ShipmentID,
            ReferenceNumber,
            ServiceType,
            PackagingType,
            Voided,
            GroundClosedID,
            ArrivalDate,
            ThermalLabel,
            FormID,
            PayorType,
            PayorAccountNumber,
            DutiesPayorType,
            DutiesPayorAccountNumber,
            FreightInsidePickup,
            FreightInsideDelivery,
            FreightBookingNumber,
            SaturdayPickup,
            SaturdayDelivery,
            SignatureOption,
            NonStandardContainer,
			HomeDeliveryType,
			HomeDeliveryInstructions,
			HomeDeliveryDate,
			HomeDeliveryPhone,
			ShipAlertRecipientAddress,
            ShipAlertRecipientShip,
            ShipAlertRecipientDelivery,
            ShipAlertSenderShip,
            ShipAlertSenderDelivery,
            ShipAlertOther1Address,
            ShipAlertOther1Ship,
            ShipAlertOther1Delivery,
            ShipAlertExpressMessage,
            ShipAlertGroundEnable,
            ShipAlertGroundAddress,
            ShipAlertGroundMessage,
			CodEnable,
			CodAmount,
			CodType,
			CodAddFreight,
			CodReturnContactName,
			CodReturnCompany,
			CodReturnAddress1,
			CodReturnAddress2,
			CodReturnCity,
			CodReturnStateProvinceCode,
			CodReturnPostalCode,
			CodReturnPhone,
			CodReturnLabelPath,
            BrokerEnable,
            BrokerAccount,
            BrokerContactName,
            BrokerCompany,
            BrokerAddress1,
            BrokerAddress2,
            BrokerCity,
            BrokerStateProvinceCode,
            BrokerPostalCode,
            BrokerPhone,
			CustomsDocuments,
			CustomsDocumentsDescription,
			CustomsRecipientTIN,
			CustomsTermsOfSale,
			CustomsRelatedParties,
			CustomsNafta,
			CustomsTotalValue,
			CustomsCanadaPackageType,
			CommercialInvoiceEnabled,
			CommercialInvoiceComments,
			CommercialInvoiceFreight,
			CommercialInvoiceInsurance,
			CommercialInvoiceAdditional,
			CommercialInvoicePurpose,
			SedRequired,
			SedID,
			SedIDType,
			SedUseExemption,
			SedExemption,
			AdmissibilityPackaging,
			ImporterDifferent,
			ImporterAccount,
			ImporterTIN,
			ImporterContactName,
			ImporterCompany,
			ImporterAddress1,
			ImporterAddress2,
			ImporterCity,
			ImporterStateProvinceCode,
			ImporterPostalCode,
			ImporterCountryCode,
			ImporterPhone,
            ShipToResidential,
            ShipFromShipperID,
	        ShipFromContactName,
	        ShipFromCompany,
	        ShipFromAddress1,
	        ShipFromAddress2,
	        ShipFromCity,
	        ShipFromStateProvinceCode,
	        ShipFromPostalCode,
	        ShipFromCountryCode,
            ShipFromContactEmail ,
	        ShipFromContactPhone,
	        ShipFromContactFax
        )
        VALUES
        (
	        @ShipmentID,
            @ReferenceNumber,
            @ServiceType,
            @PackagingType,
            @Voided,
            @GroundClosedID,
            @ArrivalDate,
            @ThermalLabel,
            @FormID,
            @PayorType,
            @PayorAccountNumber,
            @DutiesPayorType,
            @DutiesPayorAccountNumber,
            @FreightInsidePickup,
            @FreightInsideDelivery,
            @FreightBookingNumber,
            @SaturdayPickup,
            @SaturdayDelivery,
            @SignatureOption,
            @NonStandardContainer,
			@HomeDeliveryType,
			@HomeDeliveryInstructions,
			@HomeDeliveryDate,
			@HomeDeliveryPhone,
			@ShipAlertRecipientAddress,
			@ShipAlertRecipientShip,
            @ShipAlertRecipientDelivery,
            @ShipAlertSenderShip,
            @ShipAlertSenderDelivery,
            @ShipAlertOther1Address,
            @ShipAlertOther1Ship,
            @ShipAlertOther1Delivery,
            @ShipAlertExpressMessage,
            @ShipAlertGroundEnable,
            @ShipAlertGroundAddress,
            @ShipAlertGroundMessage,
			@CodEnable,
			@CodAmount,
			@CodType,
			@CodAddFreight,
			@CodReturnContactName,
			@CodReturnCompany,
			@CodReturnAddress1,
			@CodReturnAddress2,
			@CodReturnCity,
			@CodReturnStateProvinceCode,
			@CodReturnPostalCode,
			@CodReturnPhone,
			@CodReturnLabelPath,
            @BrokerEnable,
            @BrokerAccount,
            @BrokerContactName,
            @BrokerCompany,
            @BrokerAddress1,
            @BrokerAddress2,
            @BrokerCity,
            @BrokerStateProvinceCode,
            @BrokerPostalCode,
            @BrokerPhone,
			@CustomsDocuments,
			@CustomsDocumentsDescription,
			@CustomsRecipientTIN,
			@CustomsTermsOfSale,
			@CustomsRelatedParties,
			@CustomsNafta,
			@CustomsTotalValue,
			@CustomsCanadaPackageType,
			@CommercialInvoiceEnabled,
			@CommercialInvoiceComments,
			@CommercialInvoiceFreight,
			@CommercialInvoiceInsurance,
			@CommercialInvoiceAdditional,
			@CommercialInvoicePurpose,
			@SedRequired,
			@SedID,
			@SedIDType,
			@SedUseExemption,
			@SedExemption,
			@AdmissibilityPackaging,
			@ImporterDifferent,
			@ImporterAccount,
			@ImporterTIN,
			@ImporterContactName,
			@ImporterCompany,
			@ImporterAddress1,
			@ImporterAddress2,
			@ImporterCity,
			@ImporterStateProvinceCode,
			@ImporterPostalCode,
			@ImporterCountryCode,
			@ImporterPhone,
            @ShipToResidential,
            @ShipFromShipperID,
	        @ShipFromContactName,
	        @ShipFromCompany,
	        @ShipFromAddress1,
	        @ShipFromAddress2,
	        @ShipFromCity,
	        @ShipFromStateProvinceCode,
	        @ShipFromPostalCode,
	        @ShipFromCountryCode,
            @ShipFromContactEmail ,
	        @ShipFromContactPhone,
	        @ShipFromContactFax
        )
            
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ShipmentID, RowVersion
        FROM FedexShipments
        WHERE ShipmentID = @ShipmentID

        return 1   
  end
  
GO