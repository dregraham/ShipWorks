---------------------
--- PROCEDURE AddClient
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClient]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddClient]
GO

CREATE PROCEDURE dbo.AddClient
(
   @ClientName nvarchar(50)
)
WITH ENCRYPTION
AS
   INSERT INTO  Clients (ClientName)
   VALUES (@ClientName)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT SCOPE_IDENTITY() AS ClientID

   return 1
GO

----------------------------
--- PROCEDURE UpdateClient
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateClient]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateClient]
GO

CREATE PROCEDURE dbo.UpdateClient
(
   @ClientID int,
   @ClientName nvarchar(50)
)
WITH ENCRYPTION
AS
   UPDATE Clients
      SET ClientName = @ClientName
      WHERE ClientID = @ClientID

   return 1
GO

----------------------------
--- PROCEDURE GetAllClients
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllClients]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllClients]
GO

CREATE PROCEDURE dbo.GetAllClients 
WITH ENCRYPTION
AS
   SELECT *
   FROM Clients
GO
