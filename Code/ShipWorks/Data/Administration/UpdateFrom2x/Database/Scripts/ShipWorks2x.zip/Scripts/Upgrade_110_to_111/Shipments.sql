-- Create trigger to track changes to shipments
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_Shipments]'))
    drop trigger [dbo].[TG_Shipments]
GO

CREATE TRIGGER TG_Shipments ON Shipments FOR UPDATE
AS
    if ( (SELECT COUNT(*) FROM inserted) = 0)
       return;

    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = o.StoreID 
        FROM inserted s, Orders o
        WHERE s.OrderID = o.OrderID
       
    EXEC SetTableLastDbts 'Shipments', @StoreID, @@DBTS
GO