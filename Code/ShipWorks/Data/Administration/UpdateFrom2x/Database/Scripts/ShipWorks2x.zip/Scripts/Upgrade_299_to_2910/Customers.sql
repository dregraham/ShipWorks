-----------------------------
--- Procedure DoesArchivedCustomerExist
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DoesArchivedCustomerExist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DoesArchivedCustomerExist]
GO

CREATE PROCEDURE dbo.DoesArchivedCustomerExist
(
    @CustomerID int,
	@StoreID int,
	@BillEmail nvarchar(50),
	@BillFirstName nvarchar(30),
	@BillLastName nvarchar(30)
)
WITH ENCRYPTION
AS
   if exists (SELECT * FROM [Customers] 
			  WHERE CustomerID = @CustomerID
			  AND StoreID = @StoreID
			  AND BillEmail = @BillEmail
			  AND BillFirstName = @BillFirstName
			  AND BillLastName = @BillLastName	
				)
      SELECT 1
   else
      SELECT 0
GO

drop index customers.IX_Customers_BillEmail
CREATE INDEX IX_Customers_BillEmail
  ON Customers(CustomerID, StoreID, BillEmail, BillFirstName, BillLastName)