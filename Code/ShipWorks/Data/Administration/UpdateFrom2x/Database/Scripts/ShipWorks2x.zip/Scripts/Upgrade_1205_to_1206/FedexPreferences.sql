----------------------------
--- PROCEDURE GetFedexPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetFedexPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetFedexPreferences]
GO

CREATE PROCEDURE dbo.GetFedexPreferences
(
    @StoreID int,
    @ClientID int
)
AS
   -- See if there are any prefs for this store\client
   if (0 = (SELECT COUNT(*)
                FROM FedexPreferences
                WHERE StoreID = @StoreID AND ClientID = @ClientID) )
   begin
   
      -- There are not.  See if there are any for the store to use as a starting point
        INSERT INTO FedexPreferences 
        (
            ClientID,
            StoreID,
            DefaultShipperID,
            DefaultDomesticService,
            DefaultInternationalService,
            DefaultTemplate,
            ThermalPrinterName,
            UseThermalLabels,
            ThermalLabelDocTabType,
		    ReferenceNumber,
		    PackagingType,
		    PackagingLength,
		    PackagingWidth,
		    PackagingHeight ,
		    SignatureOption,
		    PayorType,
		    PayorAccountNumber,
		    DutiesPayorType,
		    DutiesPayorAccountNumber,
		    ShipAlertRecipientAddressUseBill,
		    ShipAlertRecipientShip,
		    ShipAlertRecipientDelivery,
		    ShipAlertSenderShip,
		    ShipAlertSenderDelivery,
		    ShipAlertOther1Address,
		    ShipAlertOther1Ship,
		    ShipAlertOther1Delivery,
		    ShipAlertExpressMessage,
		    ShipAlertGroundEnable,
		    ShipAlertGroundAddressUseBill,
		    ShipAlertGroundMessage,
		    CodEnable,
		    CodType,
		    CodAddFreight,
		    CodUseShipperAddress,
		    CodReturnContactName,
		    CodReturnCompany,
		    CodReturnAddress1,
		    CodReturnAddress2,
		    CodReturnCity,
		    CodReturnStateProvinceCode,
		    CodReturnPostalCode,
		    CodReturnPhone,
		    BrokerEnable,
		    BrokerAccount,
		    BrokerContactName,
		    BrokerCompany,
		    BrokerAddress1,
		    BrokerAddress2,
		    BrokerCity,
		    BrokerStateProvinceCode,
		    BrokerPostalCode,
		    BrokerPhone,
		    MaskAccountNumber
		)
		SELECT TOP 1
            @ClientID,
            StoreID,
            DefaultShipperID,
            DefaultDomesticService,
            DefaultInternationalService,
            DefaultTemplate,
            ThermalPrinterName,
            UseThermalLabels,
            ThermalLabelDocTabType,
		    ReferenceNumber,
		    PackagingType,
		    PackagingLength,
		    PackagingWidth,
		    PackagingHeight ,
		    SignatureOption,
		    PayorType,
		    PayorAccountNumber,
		    DutiesPayorType,
		    DutiesPayorAccountNumber,
		    ShipAlertRecipientAddressUseBill,
		    ShipAlertRecipientShip,
		    ShipAlertRecipientDelivery,
		    ShipAlertSenderShip,
		    ShipAlertSenderDelivery,
		    ShipAlertOther1Address,
		    ShipAlertOther1Ship,
		    ShipAlertOther1Delivery,
		    ShipAlertExpressMessage,
		    ShipAlertGroundEnable,
		    ShipAlertGroundAddressUseBill,
		    ShipAlertGroundMessage,
		    CodEnable,
		    CodType,
		    CodAddFreight,
		    CodUseShipperAddress,
		    CodReturnContactName,
		    CodReturnCompany,
		    CodReturnAddress1,
		    CodReturnAddress2,
		    CodReturnCity,
		    CodReturnStateProvinceCode,
		    CodReturnPostalCode,
		    CodReturnPhone,
		    BrokerEnable,
		    BrokerAccount,
		    BrokerContactName,
		    BrokerCompany,
		    BrokerAddress1,
		    BrokerAddress2,
		    BrokerCity,
		    BrokerStateProvinceCode,
		    BrokerPostalCode,
		    BrokerPhone,
		    MaskAccountNumber
		FROM FedexPreferences WHERE StoreID = @StoreID
	end
	
    SELECT *
        FROM FedexPreferences
        WHERE StoreID = @StoreID AND ClientID = @ClientID
                
GO