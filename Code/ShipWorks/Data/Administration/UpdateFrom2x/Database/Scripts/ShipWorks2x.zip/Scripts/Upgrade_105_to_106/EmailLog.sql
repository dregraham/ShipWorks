----------------------------
--- PROCEDURE GetAllEmailLogs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetAllEmailLogs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure GetAllEmailLogs
GO

CREATE PROCEDURE GetAllEmailLogs
(
   @StoreID int,
   @MinLogID int
)
AS
      SELECT e.*, o.OrderNumber
        FROM EmailLog e, Orders o
        WHERE e.OrderID = o.OrderID AND 
              o.StoreID = @StoreID AND
              e.EmailLogID > @MinLogID
GO
