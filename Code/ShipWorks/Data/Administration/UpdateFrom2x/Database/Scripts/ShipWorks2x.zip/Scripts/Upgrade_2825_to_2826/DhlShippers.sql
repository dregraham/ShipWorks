-----------------------------
--- TABLE DhlShippers
-----------------------------
CREATE TABLE dbo.DhlShippers
(
	DhlShipperID int IDENTITY (1, 1) NOT NULL,
	[RowVersion] timestamp NOT NULL,
	ExpressAccountNumber nvarchar(20) NOT NULL,
	AtHomeAccountNumber nvarchar(20) NOT NULL,
	DomesticShippingKey nvarchar(70) NOT NULL,
	AtHomeShippingKey nvarchar(70) NOT NULL,
	IntlShippingKey nvarchar(70) NOT NULL,
	Company nvarchar(35) NOT NULL,
	ContactName nvarchar(35) NOT NULL,
	Address1 nvarchar(60) NOT NULL,
	Address2 nvarchar(60) NOT NULL,
	City nvarchar(50) NOT NULL,
	StateProvinceCode nvarchar(5) NOT NULL,
	PostalCode nvarchar(10) NOT NULL,
	CountryCode nvarchar(5) NOT NULL,
	ContactEmail nvarchar(35) NOT NULL,
	ContactPhone nvarchar(25) NOT NULL,
	ContactFax nvarchar(25) NOT NULL,
	AlternateCompany nvarchar(35) NOT NULL,
	AlternateContactName nvarchar(35) NOT NULL,
	AlternateAddress1 nvarchar(60) NOT NULL,
	AlternateAddress2 nvarchar(60) NOT NULL,
	AlternateCity nvarchar(50) NOT NULL,
	AlternateStateProvinceCode nvarchar(5) NOT NULL,
	AlternatePostalCode nvarchar(10) NOT NULL,
	AlternateCountryCode nvarchar(5) NOT NULL,
	AlternateContactEmail nvarchar(35) NOT NULL,
	AlternateContactPhone nvarchar(25) NOT NULL,
	AlternateContactFax nvarchar(25) NOT NULL,
	UseAlternateLocation bit NOT NULL,
	CONSTRAINT PK_DhlShippers PRIMARY KEY CLUSTERED ( DhlShipperID )
)
GO


----------------------------
--- PROCEDURE AddDhlShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDhlShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddDhlShipper]
GO

CREATE PROCEDURE dbo.AddDhlShipper
(
	@ExpressAccountNumber nvarchar(20),
	@AtHomeAccountNumber nvarchar(20),
	@DomesticShippingKey nvarchar(70),
	@IntlShippingKey nvarchar(70),
	@AtHomeShippingKey nvarchar(70),
	@Company nvarchar(35),
	@ContactName nvarchar(35),
	@Address1 nvarchar(60),
	@Address2 nvarchar(60),
	@City nvarchar(50),
	@StateProvinceCode nvarchar(5),
	@PostalCode nvarchar(10),
	@CountryCode nvarchar(5),
	@ContactEmail nvarchar(35),
	@ContactPhone nvarchar(25),
	@ContactFax nvarchar(25),
	@AlternateCompany nvarchar(35),
	@AlternateContactName nvarchar(35),
	@AlternateAddress1 nvarchar(60),
	@AlternateAddress2 nvarchar(60),
	@AlternateCity nvarchar(50),
	@AlternateStateProvinceCode nvarchar(5),
	@AlternatePostalCode nvarchar(10),
	@AlternateCountryCode nvarchar(5),
	@AlternateContactEmail nvarchar(35),
	@AlternateContactPhone nvarchar(25),
	@AlternateContactFax nvarchar(25),
	@UseAlternateLocation bit
)
WITH ENCRYPTION
AS
	INSERT INTO DhlShippers
	(
		ExpressAccountNumber,
		AtHomeAccountNumber,
		DomesticShippingKey,
		IntlShippingKey,
		AtHomeShippingKey,
		Company,
		ContactName,
		Address1,
		Address2,
		City,
		StateProvinceCode,
		PostalCode,
		CountryCode,
		ContactEmail,
		ContactPhone,	
		ContactFax,	
		AlternateCompany,
		AlternateContactName,
		AlternateAddress1,
		AlternateAddress2,
		AlternateCity,
		AlternateStateProvinceCode,
		AlternatePostalCode,
		AlternateCountryCode,
		AlternateContactEmail,
		AlternateContactPhone,	
		AlternateContactFax,
		UseAlternateLocation
	)
	VALUES
	(
		@ExpressAccountNumber,
		@AtHomeAccountNumber,
		@DomesticShippingKey,
		@IntlShippingKey,
		@AtHomeShippingKey,
		@Company,
		@ContactName,
		@Address1,
		@Address2,
		@City,
		@StateProvinceCode,
		@PostalCode,
		@CountryCode,
		@ContactEmail,
		@ContactPhone,
		@ContactFax,
		@AlternateCompany,
		@AlternateContactName,
		@AlternateAddress1,
		@AlternateAddress2,
		@AlternateCity,
		@AlternateStateProvinceCode,
		@AlternatePostalCode,
		@AlternateCountryCode,
		@AlternateContactEmail,
		@AlternateContactPhone,
		@AlternateContactFax,
		@UseAlternateLocation
	)
	
	if (@@ROWCOUNT != 1)
		return 0
		
	SET NOCOUNT ON
	
	SELECT DhlShipperID, [RowVersion]
		FROM DhlShippers
		WHERE DhlShipperID = SCOPE_IDENTITY()
		
	RETURN 1
GO
		
----------------------------
--- PROCEDURE UpdateDhlShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateDhlShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateDhlShipper]
GO

CREATE PROCEDURE dbo.UpdateDhlShipper
(
	@DhlShipperID int,
	@RowVersion timestamp,
	@ExpressAccountNumber nvarchar(20),
	@AtHomeAccountNumber nvarchar(20),
	@DomesticShippingKey nvarchar(70),
	@IntlShippingKey nvarchar(70),
	@AtHomeShippingKey nvarchar(70),
	@Company nvarchar(35),
	@ContactName nvarchar(35),
	@Address1 nvarchar(60),
	@Address2 nvarchar(60),
	@City nvarchar(50),
	@StateProvinceCode nvarchar(5),
	@PostalCode nvarchar(10),
	@CountryCode nvarchar(5),
	@ContactEmail nvarchar(35),
	@ContactPhone nvarchar(25),
	@ContactFax nvarchar(25),
	@AlternateCompany nvarchar(35),
	@AlternateContactName nvarchar(35),
	@AlternateAddress1 nvarchar(60),
	@AlternateAddress2 nvarchar(60),
	@AlternateCity nvarchar(50),
	@AlternateStateProvinceCode nvarchar(5),
	@AlternatePostalCode nvarchar(10),
	@AlternateCountryCode nvarchar(5),
	@AlternateContactEmail nvarchar(35),
	@AlternateContactPhone nvarchar(25),
	@AlternateContactFax nvarchar(25),
	@UseAlternateLocation bit
)
WITH ENCRYPTION
AS 
	UPDATE DhlShippers
		SET
			ExpressAccountNumber = @ExpressAccountNumber,
			AtHomeAccountNumber = @AtHomeAccountNumber,
			DomesticShippingKey = @DomesticShippingKey,
			IntlShippingKey = @IntlShippingKey,
			AtHomeShippingKey = @AtHomeShippingKey,
			Company = @Company,
			ContactName = @ContactName,
			Address1 = @Address1,
			Address2 = @Address2,
			City = @City,
			StateProvinceCode = @StateProvinceCode,
			PostalCode = @PostalCode,
			CountryCode = @CountryCode,
			ContactEmail = @ContactEmail,
			ContactPhone = @ContactPhone,
			ContactFax = @ContactFax,
			AlternateCompany = @AlternateCompany,
			AlternateContactName = @AlternateContactName,
			AlternateAddress1 = @AlternateAddress1,
			AlternateAddress2 = @AlternateAddress2,
			AlternateCity = @AlternateCity,
			AlternateStateProvinceCode = @AlternateStateProvinceCode,
			AlternatePostalCode = @AlternatePostalCode,
			AlternateCountryCode = @AlternateCountryCode,
			AlternateContactEmail = @AlternateContactEmail,
			AlternateContactPhone = @AlternateContactPhone,
			AlternateContactFax = @AlternateContactFax,
			UseAlternateLocation = @UseAlternateLocation
		WHERE DhlShipperID = @DhlShipperID AND [RowVersion] = @RowVersion
		
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT DhlShipperID, [RowVersion]
		FROM DhlShippers
		WHERE DhlShipperID = @DhlShipperID
		
	RETURN 1
GO

-----------------------------
--- Procedure DeleteDhlShipper
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteDhlShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteDhlShipper]
GO

CREATE PROCEDURE dbo.DeleteDhlShipper
(
	@DhlShipperID int
)
WITH ENCRYPTION
AS
	DELETE FROM DhlShippers
	WHERE DhlShipperID = @DhlShipperID
GO


----------------------------
--- PROCEDURE GetAllDhlShippers
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllDhlShippers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllDhlShippers]
GO

CREATE PROCEDURE dbo.GetAllDhlShippers 
WITH ENCRYPTION
AS
   SELECT *
   FROM DhlShippers
GO
