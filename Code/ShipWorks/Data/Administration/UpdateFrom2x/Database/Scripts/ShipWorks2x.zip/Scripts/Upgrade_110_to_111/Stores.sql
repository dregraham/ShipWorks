----------------------------
--- PROCEDURE DeleteStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteStore]
GO

CREATE PROCEDURE DeleteStore
(
   @StoreID int
)
AS
   DELETE OrderItemAttributes
     FROM OrderItemAttributes a, OrderItems i, Orders o
     WHERE a.OrderItemID = i.OrderItemID AND i.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE OrderItems
     FROM OrderItems i, Orders o
     WHERE i.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE OrderCharges
     FROM OrderCharges c, Orders o
     WHERE c.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE PaymentDetails
     FROM PaymentDetails p, Orders o
     WHERE p.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE MivaSebenzaMsgs
     FROM MivaSebenzaMsgs m, Orders o
     WHERE m.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE UpsPackages
     FROM UpsPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE UpsShipments
     FROM UpsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE Shipments
     FROM Shipments s, Orders o
     WHERE s.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE FROM UpsPreferences
     WHERE [StoreID] = @StoreID
   
   DELETE FROM EmailAccounts
     WHERE [StoreID] = @StoreID
  
   DELETE FROM Orders
     WHERE [StoreID] = @StoreID

   DELETE FROM Downloaded
     WHERE [StoreID] = @StoreID
     
   DELETE FROM MivaBatches
     WHERE [StoreID] = @StoreID
     
   DELETE FROM DownloadLog
     WHERE [StoreID] = @StoreID
     
   DELETE FROM EmailLog
     WHERE [StoreID] = @StoreID
     
   DELETE FROM Customers
     WHERE [StoreID] = @StoreID   
     
   DELETE FROM [Stores]
     WHERE [StoreID] = @StoreID
     
GO