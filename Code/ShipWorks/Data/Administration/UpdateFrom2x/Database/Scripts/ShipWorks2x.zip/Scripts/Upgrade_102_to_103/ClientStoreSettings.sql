ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Clients
GO

ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Stores
GO

CREATE TABLE dbo.Tmp_ClientStoreSettings
	(
	ClientID int NOT NULL,
	StoreID int NOT NULL,
	RowVersion timestamp NOT NULL,
	LicenseKey nvarchar(150) NOT NULL,
	ActiveTemplate nvarchar(50) NOT NULL,
	ActiveFilter nvarchar(50) NOT NULL,
	PerfDateRangeType int NOT NULL,
	PerfDateRangeDays int NOT NULL,
	PerfDateRangeMax datetime NOT NULL,
	PerfDateRangeMin datetime NOT NULL,
	PerfShowFilterCounts bit NOT NULL,
	FileSaveWebImages bit NOT NULL,
	FileSavePromptEach bit NOT NULL,
	FileSaveNameTemplate nvarchar(50) NOT NULL,
	WolrdShipCsvFilename nvarchar(350) NOT NULL,
	WorldShipOutputType int NOT NULL,
	WorldShipLaunchAfterExport bit NOT NULL,
	WorldShipReferenceNumber1 nvarchar(50) NOT NULL,
	WorldShipReferenceNumber2 nvarchar(50) NOT NULL,
	WorldShipQvnFromName nvarchar (30) NOT NULL,
	WorldShipQvnSubject int NOT NULL,
	WorldShipQvnMemo nvarchar (150) NOT NULL,
	WorldShipQvnFailedAddress nvarchar (50) NOT NULL,
	WorldShipQvnShipNotify bit NOT NULL,
	WorldShipQvnDeliveryNotify bit NOT NULL,
	WorldShipQvnExceptionNotify bit NOT NULL,
	StampsCsvFilename nvarchar(350) NOT NULL,
	StampsLaunchAfterExport bit NOT NULL,
	EndiciaSetService bit NOT NULL,
	EndiciaSetConfirmation bit NOT NULL,
	EndiciaSetWeight bit NOT NULL,
	EndiciaSetDate bit NOT NULL,
	EndiciaDefaultDomesticService int NOT NULL,
	EndiciaDefaultInternationalService int NOT NULL,
	EndiciaDefaultConfirmation int NOT NULL,
	EndiciaDefaultDateAdvance int NOT NULL,
	EndiciaUnattendedPrinting bit NOT NULL,
	EndiciaSpecifyLayout bit NOT NULL,
	EndiciaDefaultLayoutFile nvarchar(350) NOT NULL,
	EndiciaStealthMode bit NOT NULL,
	EndiciaTestMode bit NOT NULL,
	EndiciaCloseOnComplete bit NOT NULL,
	EndiciaRubberStamp1 nvarchar(50) NOT NULL,
	EndiciaRubberStamp2 nvarchar(50) NOT NULL,
	EndiciaRubberStamp3 nvarchar(50) NOT NULL,
	EndiciaRubberStamp4 nvarchar(50) NOT NULL,
	EndiciaRubberStamp5 nvarchar(50) NOT NULL,
	UspsDefaultService int NOT NULL,
	UspsDefaultConfirmation int NOT NULL,
	UspsDefaultRequestAddressService bit NOT NULL,
	UspsDefaultSendConfirmationEmail bit NOT NULL,
	UspsUseLiveServer bit NOT NULL,
	UspsDefaultTemplate nvarchar(50) NOT NULL,
	DownloadAllowed bit NOT NULL,
	DownloadAutoEnable bit NOT NULL,
	DownloadAutoInterval int NOT NULL,
	DownloadNewPlaySound bit NOT NULL,
	DownloadNewPlaySoundFile nvarchar(350) NOT NULL,
	DownloadNewSendEmail bit NOT NULL,
	DownloadNewSendEmailTemplate nvarchar(50) NOT NULL,
	DownloadNewSendEmailTestMode bit NOT NULL,
	DownloadNewSendEmailTestAddress nvarchar(50) NOT NULL,
	DownloadNewPrint bit NOT NULL,
	DownloadNewPrintTemplate nvarchar(50) NOT NULL,
	DownloadErrorPlaySound bit NOT NULL,
	DownloadErrorPlaySoundFile nvarchar(350) NOT NULL
	)
GO

IF EXISTS(SELECT * FROM dbo.ClientStoreSettings)
	 EXEC('INSERT INTO dbo.Tmp_ClientStoreSettings (ClientID, StoreID, LicenseKey, ActiveTemplate, ActiveFilter, PerfDateRangeType, PerfDateRangeDays, PerfDateRangeMax, PerfDateRangeMin, PerfShowFilterCounts, FileSaveWebImages, FileSavePromptEach, FileSaveNameTemplate, WolrdShipCsvFilename, WorldShipOutputType, WorldShipLaunchAfterExport, WorldShipReferenceNumber1, WorldShipReferenceNumber2, WorldShipQvnFromName, WorldShipQvnSubject, WorldShipQvnMemo, WorldShipQvnFailedAddress, WorldShipQvnShipNotify, WorldShipQvnDeliveryNotify, WorldShipQvnExceptionNotify, StampsCsvFilename, StampsLaunchAfterExport, EndiciaSetService, EndiciaSetConfirmation, EndiciaSetWeight, EndiciaSetDate, EndiciaDefaultDomesticService, EndiciaDefaultInternationalService, EndiciaDefaultConfirmation, EndiciaDefaultDateAdvance, EndiciaUnattendedPrinting, EndiciaSpecifyLayout, EndiciaDefaultLayoutFile, EndiciaStealthMode, EndiciaTestMode, EndiciaCloseOnComplete, EndiciaRubberStamp1,    EndiciaRubberStamp2, EndiciaRubberStamp3, EndiciaRubberStamp4, EndiciaRubberStamp5, UspsDefaultService, UspsDefaultConfirmation, UspsDefaultRequestAddressService, UspsDefaultSendConfirmationEmail, UspsUseLiveServer, UspsDefaultTemplate, DownloadAllowed, DownloadAutoEnable, DownloadAutoInterval, DownloadNewPlaySound, DownloadNewPlaySoundFile, DownloadNewSendEmail, DownloadNewSendEmailTemplate, DownloadNewSendEmailTestMode, DownloadNewSendEmailTestAddress, DownloadNewPrint, DownloadNewPrintTemplate, DownloadErrorPlaySound, DownloadErrorPlaySoundFile)
		                                     SELECT ClientID, StoreID, LicenseKey, ActiveTemplate, ActiveFilter, PerfDateRangeType, PerfDateRangeDays, PerfDateRangeMax, PerfDateRangeMin, PerfShowFilterCounts, FileSaveWebImages, FileSavePromptEach, FileSaveNameTemplate, WolrdShipCsvFilename, WorldShipOutputType, WorldShipLaunchAfterExport, WorldShipReferenceNumber,  "",                        "",                   0,                   "",               "",                        1,                      0,                          0,                           StampsCsvFilename, StampsLaunchAfterExport, EndiciaSetService, EndiciaSetConfirmation, EndiciaSetWeight, EndiciaSetDate, EndiciaDefaultDomesticService, EndiciaDefaultInternationalService, EndiciaDefaultConfirmation, EndiciaDefaultDateAdvance, EndiciaUnattendedPrinting, EndiciaSpecifyLayout, EndiciaDefaultLayoutFile, EndiciaStealthMode, EndiciaTestMode, EndiciaCloseOnComplete, "Order Sw_OrderNumber", "",                  "",                  "",                  "",                  UspsDefaultService, UspsDefaultConfirmation, UspsDefaultRequestAddressService, UspsDefaultSendConfirmationEmail, UspsUseLiveServer, UspsDefaultTemplate, DownloadAllowed, DownloadAutoEnable, DownloadAutoInterval, DownloadNewPlaySound, DownloadNewPlaySoundFile, DownloadNewSendEmail, DownloadNewSendEmailTemplate, DownloadNewSendEmailTestMode, DownloadNewSendEmailTestAddress, DownloadNewPrint, DownloadNewPrintTemplate, DownloadErrorPlaySound, DownloadErrorPlaySoundFile FROM dbo.ClientStoreSettings TABLOCKX')
GO

DROP TABLE dbo.ClientStoreSettings
GO

EXECUTE sp_rename N'dbo.Tmp_ClientStoreSettings', N'ClientStoreSettings', 'OBJECT'
GO

ALTER TABLE dbo.ClientStoreSettings ADD CONSTRAINT
	PK_ClientStoreSettings PRIMARY KEY CLUSTERED 
	(
	    ClientID,
	    StoreID
	)
GO

ALTER TABLE dbo.ClientStoreSettings WITH NOCHECK ADD CONSTRAINT
	FK_ClientStoreSettings_Stores FOREIGN KEY (StoreID) 
	    REFERENCES dbo.Stores (StoreID)
GO

ALTER TABLE dbo.ClientStoreSettings WITH NOCHECK ADD CONSTRAINT
	FK_ClientStoreSettings_Clients FOREIGN KEY(ClientID) 
	    REFERENCES dbo.Clients(ClientID)
GO

----------------------------
--- PROCEDURE AddClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddClientStoreSettings]
GO

CREATE PROCEDURE AddClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @LicenseKey nvarchar(150),
   @ActiveTemplate nvarchar(50),
   @ActiveFilter nvarchar(50),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @FileSaveWebImages bit,
   @FileSavePromptEach bit,
   @FileSaveNameTemplate nvarchar(50),
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 nvarchar (50),
   @WorldShipReferenceNumber2 nvarchar (50),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @StampsCsvFilename nvarchar(350),
   @StampsLaunchAfterExport bit,
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaUnattendedPrinting bit,
   @EndiciaSpecifyLayout bit,
   @EndiciaDefaultLayoutFile nvarchar(350),
   @EndiciaStealthMode bit,
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @EndiciaRubberStamp1 nvarchar(50),
   @EndiciaRubberStamp2 nvarchar(50),
   @EndiciaRubberStamp3 nvarchar(50),
   @EndiciaRubberStamp4 nvarchar(50),
   @EndiciaRubberStamp5 nvarchar(50),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DownloadNewPlaySound bit,
   @DownloadNewPlaySoundFile nvarchar(350),
   @DownloadNewSendEmail bit,
   @DownloadNewSendEmailTemplate nvarchar(50),
   @DownloadNewSendEmailTestMode bit,
   @DownloadNewSendEmailTestAddress nvarchar(50),
   @DownloadNewPrint bit,
   @DownloadNewPrintTemplate nvarchar(50),
   @DownloadErrorPlaySound bit,
   @DownloadErrorPlaySoundFile nvarchar(350)
)
AS
   INSERT INTO [ClientStoreSettings]
   (
        [ClientID], 
        [StoreID], 
        [LicenseKey], 
	    [ActiveTemplate],
	    [ActiveFilter],
        [PerfDateRangeType],
        [PerfDateRangeDays], 
        [PerfDateRangeMax], 
        [PerfDateRangeMin], 
        [PerfShowFilterCounts],
	    [FileSaveWebImages],
	    [FileSavePromptEach],
	    [FileSaveNameTemplate],
        [WolrdShipCsvFilename], 
        [WorldShipOutputType], 
        [WorldShipLaunchAfterExport], 
        [WorldShipReferenceNumber1],
        [WorldShipReferenceNumber2],
        [WorldShipQvnFromName],
        [WorldShipQvnSubject],
        [WorldShipQvnMemo],
        [WorldShipQvnFailedAddress],
        [WorldShipQvnShipNotify],
        [WorldShipQvnDeliveryNotify],
        [WorldShipQvnExceptionNotify],
        [StampsCsvFilename], 
        [StampsLaunchAfterExport], 
        [EndiciaSetService], 
        [EndiciaSetConfirmation], 
        [EndiciaSetWeight], 
        [EndiciaSetDate], 
        [EndiciaDefaultDomesticService], 
        [EndiciaDefaultInternationalService],
        [EndiciaDefaultConfirmation], 
        [EndiciaDefaultDateAdvance], 
        [EndiciaUnattendedPrinting], 
        [EndiciaSpecifyLayout], 
        [EndiciaDefaultLayoutFile], 
        [EndiciaStealthMode],
        [EndiciaTestMode], 
        [EndiciaCloseOnComplete], 
        [EndiciaRubberStamp1],
        [EndiciaRubberStamp2],
        [EndiciaRubberStamp3],
        [EndiciaRubberStamp4],
        [EndiciaRubberStamp5],
        [UspsDefaultService], 
        [UspsDefaultConfirmation], 
        [UspsDefaultRequestAddressService], 
        [UspsDefaultSendConfirmationEmail], 
        [UspsUseLiveServer], 
        [UspsDefaultTemplate], 
        [DownloadAllowed],
	    [DownloadAutoEnable],
	    [DownloadAutoInterval],
	    [DownloadNewPlaySound],
	    [DownloadNewPlaySoundFile],
	    [DownloadNewSendEmail],
	    [DownloadNewSendEmailTemplate],
	    [DownloadNewSendEmailTestMode],
	    [DownloadNewSendEmailTestAddress],
	    [DownloadNewPrint],
	    [DownloadNewPrintTemplate],
	    [DownloadErrorPlaySound],
	    [DownloadErrorPlaySoundFile]
   )
   VALUES 
   (
        @ClientID, 
        @StoreID, 
        @LicenseKey, 
	    @ActiveTemplate,
	    @ActiveFilter,
        @PerfDateRangeType,
        @PerfDateRangeDays, 
        @PerfDateRangeMax, 
        @PerfDateRangeMin, 
        @PerfShowFilterCounts,
	    @FileSaveWebImages,
	    @FileSavePromptEach,
	    @FileSaveNameTemplate,
        @WolrdShipCsvFilename, 
        @WorldShipOutputType, 
        @WorldShipLaunchAfterExport, 
        @WorldShipReferenceNumber1,
        @WorldShipReferenceNumber2,
        @WorldShipQvnFromName,
        @WorldShipQvnSubject,
        @WorldShipQvnMemo,
        @WorldShipQvnFailedAddress,
        @WorldShipQvnShipNotify,
        @WorldShipQvnDeliveryNotify,
        @WorldShipQvnExceptionNotify,
        @StampsCsvFilename, 
        @StampsLaunchAfterExport, 
        @EndiciaSetService, 
        @EndiciaSetConfirmation, 
        @EndiciaSetWeight, 
        @EndiciaSetDate, 
        @EndiciaDefaultDomesticService, 
        @EndiciaDefaultInternationalService,
        @EndiciaDefaultConfirmation, 
        @EndiciaDefaultDateAdvance, 
        @EndiciaUnattendedPrinting, 
        @EndiciaSpecifyLayout, 
        @EndiciaDefaultLayoutFile, 
        @EndiciaStealthMode,
        @EndiciaTestMode, 
        @EndiciaCloseOnComplete, 
        @EndiciaRubberStamp1,
        @EndiciaRubberStamp2,
        @EndiciaRubberStamp3,
        @EndiciaRubberStamp4,
        @EndiciaRubberStamp5,
        @UspsDefaultService, 
        @UspsDefaultConfirmation, 
        @UspsDefaultRequestAddressService, 
        @UspsDefaultSendConfirmationEmail, 
        @UspsUseLiveServer, 
        @UspsDefaultTemplate, 
        @DownloadAllowed,
	    @DownloadAutoEnable,
	    @DownloadAutoInterval,
	    @DownloadNewPlaySound,
	    @DownloadNewPlaySoundFile,
	    @DownloadNewSendEmail,
	    @DownloadNewSendEmailTemplate,
	    @DownloadNewSendEmailTestMode,
	    @DownloadNewSendEmailTestAddress,
	    @DownloadNewPrint,
	    @DownloadNewPrintTemplate,
	    @DownloadErrorPlaySound,
	    @DownloadErrorPlaySoundFile
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT RowVersion
   FROM ClientStoreSettings
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateClientStoreSettings]
GO

CREATE PROCEDURE UpdateClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @LicenseKey nvarchar(150),
   @ActiveTemplate nvarchar(50),
   @ActiveFilter nvarchar(50),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @FileSaveWebImages bit,
   @FileSavePromptEach bit,
   @FileSaveNameTemplate nvarchar(50),
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 nvarchar (50),
   @WorldShipReferenceNumber2 nvarchar (50),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @StampsCsvFilename nvarchar(350),
   @StampsLaunchAfterExport bit,
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaUnattendedPrinting bit,
   @EndiciaSpecifyLayout bit,
   @EndiciaDefaultLayoutFile nvarchar(350),
   @EndiciaStealthMode bit,
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @EndiciaRubberStamp1 nvarchar(50),
   @EndiciaRubberStamp2 nvarchar(50),
   @EndiciaRubberStamp3 nvarchar(50),
   @EndiciaRubberStamp4 nvarchar(50),
   @EndiciaRubberStamp5 nvarchar(50),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DownloadNewPlaySound bit,
   @DownloadNewPlaySoundFile nvarchar(350),
   @DownloadNewSendEmail bit,
   @DownloadNewSendEmailTemplate nvarchar(50),
   @DownloadNewSendEmailTestMode bit,
   @DownloadNewSendEmailTestAddress nvarchar(50),
   @DownloadNewPrint bit,
   @DownloadNewPrintTemplate nvarchar(50),
   @DownloadErrorPlaySound bit,
   @DownloadErrorPlaySoundFile nvarchar(350)
)
AS
   UPDATE [ClientStoreSettings]
   SET 
    [LicenseKey] = @LicenseKey, 
    [ActiveTemplate] = @ActiveTemplate,
    [ActiveFilter] = @ActiveFilter,
    [PerfDateRangeType] = @PerfDateRangeType,
    [PerfDateRangeDays] = @PerfDateRangeDays, 
    [PerfDateRangeMax] = @PerfDateRangeMax, 
    [PerfDateRangeMin] = @PerfDateRangeMin, 
    [PerfShowFilterCounts] = @PerfShowFilterCounts,
    [FileSaveWebImages] = @FileSaveWebImages,
    [FileSavePromptEach] = @FileSavePromptEach,
    [FileSaveNameTemplate] = @FileSaveNameTemplate,
    [WolrdShipCsvFilename] = @WolrdShipCsvFilename, 
    [WorldShipOutputType] = @WorldShipOutputType, 
    [WorldShipLaunchAfterExport] = @WorldShipLaunchAfterExport, 
    [WorldShipReferenceNumber1] = @WorldShipReferenceNumber1,
    [WorldShipReferenceNumber2] = @WorldShipReferenceNumber2,
    [WorldShipQvnFromName] = @WorldShipQvnFromName,
    [WorldShipQvnSubject] = @WorldShipQvnSubject,
    [WorldShipQvnMemo] = @WorldShipQvnMemo,
    [WorldShipQvnFailedAddress] = @WorldShipQvnFailedAddress,
    [WorldShipQvnShipNotify] = @WorldShipQvnShipNotify,
    [WorldShipQvnDeliveryNotify] = @WorldShipQvnDeliveryNotify,
    [WorldShipQvnExceptionNotify] = @WorldShipQvnExceptionNotify,
    [StampsCsvFilename] = @StampsCsvFilename, 
    [StampsLaunchAfterExport] = @StampsLaunchAfterExport, 
    [EndiciaSetService] = @EndiciaSetService, 
    [EndiciaSetConfirmation] = @EndiciaSetConfirmation, 
    [EndiciaSetWeight] = @EndiciaSetWeight, 
    [EndiciaSetDate] = @EndiciaSetDate, 
    [EndiciaDefaultDomesticService] = @EndiciaDefaultDomesticService, 
    [EndiciaDefaultInternationalService] = @EndiciaDefaultInternationalService,
    [EndiciaDefaultConfirmation] = @EndiciaDefaultConfirmation, 
    [EndiciaDefaultDateAdvance] = @EndiciaDefaultDateAdvance, 
    [EndiciaUnattendedPrinting] = @EndiciaUnattendedPrinting, 
    [EndiciaSpecifyLayout] = @EndiciaSpecifyLayout, 
    [EndiciaDefaultLayoutFile] = @EndiciaDefaultLayoutFile,
    [EndiciaStealthMode] = @EndiciaStealthMode, 
    [EndiciaTestMode] = @EndiciaTestMode, 
    [EndiciaCloseOnComplete] = @EndiciaCloseOnComplete, 
    [EndiciaRubberStamp1] = @EndiciaRubberStamp1,
    [EndiciaRubberStamp2] = @EndiciaRubberStamp2,
    [EndiciaRubberStamp3] = @EndiciaRubberStamp3,
    [EndiciaRubberStamp4] = @EndiciaRubberStamp4,
    [EndiciaRubberStamp5] = @EndiciaRubberStamp5,
    [UspsDefaultService] = @UspsDefaultService, 
    [UspsDefaultConfirmation] = @UspsDefaultConfirmation, 
    [UspsDefaultRequestAddressService] = @UspsDefaultRequestAddressService, 
    [UspsDefaultSendConfirmationEmail] = @UspsDefaultSendConfirmationEmail, 
    [UspsUseLiveServer] = @UspsUseLiveServer, 
    [UspsDefaultTemplate] = @UspsDefaultTemplate, 
    [DownloadAllowed] = @DownloadAllowed,
    [DownloadAutoEnable] = @DownloadAutoEnable,
    [DownloadAutoInterval] = @DownloadAutoInterval,
    [DownloadNewPlaySound] = @DownloadNewPlaySound,
    [DownloadNewPlaySoundFile] = @DownloadNewPlaySoundFile,
    [DownloadNewSendEmail] = @DownloadNewSendEmail,
    [DownloadNewSendEmailTemplate] = @DownloadNewSendEmailTemplate,
    [DownloadNewSendEmailTestMode] = @DownloadNewSendEmailTestMode,
    [DownloadNewSendEmailTestAddress] = @DownloadNewSendEmailTestAddress,
    [DownloadNewPrint] = @DownloadNewPrint,
    [DownloadNewPrintTemplate] = @DownloadNewPrintTemplate,
    [DownloadErrorPlaySound] = @DownloadErrorPlaySound,
    [DownloadErrorPlaySoundFile] = @DownloadErrorPlaySoundFile
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM [ClientStoreSettings]
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID

   return 1
GO
