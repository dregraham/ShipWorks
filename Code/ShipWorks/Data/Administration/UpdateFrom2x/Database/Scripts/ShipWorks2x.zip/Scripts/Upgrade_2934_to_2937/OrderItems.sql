ALTER TABLE dbo.[OrderItems] ADD
	AmazonConditionNote nvarchar(255) NOT NULL CONSTRAINT DF_OrderItems_AmazonConditionNote DEFAULT ''
GO

ALTER TABLE dbo.[OrderItems] DROP CONSTRAINT DF_OrderItems_AmazonConditionNote
GO


-----------------------------
--- Procedure DeleteOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteOrderItem]
GO

CREATE PROCEDURE dbo.DeleteOrderItem
(
   @OrderItemID int
)
WITH ENCRYPTION
AS
    DELETE FROM OrderItems
    WHERE OrderItemID = @OrderItemID
GO

-----------------------------
--- Procedure GetOrderItemCounts
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderItemCounts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderItemCounts]
GO

CREATE PROCEDURE dbo.GetOrderItemCounts
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT o.OrderID, count(*) as ItemCount
   FROM OrderItems i, Orders o
   WHERE i.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
         o.OrderID > @MinOrderID
   GROUP BY o.OrderID
GO


-----------------------------
--- Procedure GetOrderItemsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderItemsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderItemsRange]
GO

CREATE PROCEDURE dbo.GetOrderItemsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT i.*
   FROM OrderItems i, Orders o
   WHERE i.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
         o.OrderID > @MinOrderID
GO

-----------------------------
--- Procedure GetOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderItem]
GO

CREATE PROCEDURE dbo.GetOrderItem
(
    @OrderItemID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM [OrderItems]
   WHERE OrderItemID = @OrderItemID
GO

-----------------------------
--- Procedure GetOrderItems
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderItems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderItems]
GO

CREATE PROCEDURE dbo.GetOrderItems
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM [OrderItems]
   WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure GetChangedItems
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedItems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedItems]
GO

CREATE PROCEDURE dbo.GetChangedItems
(
   @LastDBTS rowversion,
   @MaxOrderID int,
   @StoreID int
)
WITH ENCRYPTION
AS

   SELECT i.*
      FROM Orders o, OrderItems i
      WHERE (i.RowVersion > @LastDBTS AND o.StoreID = @StoreID AND o.OrderID = i.OrderID) AND
            (o.OrderID <= @MaxOrderID OR @MaxOrderID < 0)

GO

-----------------------------
--- Procedure UpdateOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateOrderItem]
GO

CREATE PROCEDURE dbo.UpdateOrderItem
(
	@OrderItemID int,
	@RowVersion timestamp,
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@SKU nvarchar (100),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@eBaySellingManagerProductName nvarchar(80),
	@eBaySellingManagerProductPart nvarchar(80),
	@eBaySellingManagerRecord int,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@Status nvarchar (50),
	@YahooProductID nvarchar (255),
	@Location nvarchar (100),
	@ISBN nvarchar(30), 
	@UPC nvarchar(30),
	@ChannelAdvisorSiteName varchar(50),
	@ChannelAdvisorBuyerID varchar(80),
	@ChannelAdvisorAuctionID varchar(50),
	@AmazonOrderItemCode bigint,
	@AmazonASIN varchar(32),
	@ChannelAdvisorClassification nvarchar(30),
	@AmazonConditionNote nvarchar(255)
)
WITH ENCRYPTION
AS
    -- Update the item
    UPDATE OrderItems
    SET [OrderID] = @OrderID,
        [Name] = @Name,
        [Code] = @Code,
        SKU = @SKU,
        [Thumbnail] = @Thumbnail,
        [Image] = @Image,
        [UnitPrice] = @UnitPrice,
        [UnitCost] = @UnitCost,
        [Weight] = @Weight,
        [Quantity] = @Quantity,
        [eBayItemID] = @eBayItemID,
        [eBayTransID] = @eBayTransID,
	    eBaySellingManagerProductName = @eBaySellingManagerProductName,
	    eBaySellingManagerProductPart = @eBaySellingManagerProductPart,
	    eBaySellingManagerRecord = @eBaySellingManagerRecord,
        [MivaLineID] = @MivaLineID,
        [MivaProductCode] = @MivaProductCode,
        [Status] = @Status,
        [YahooProductID] = @YahooProductID,
        Location = @Location,
		ISBN = @ISBN, 
		UPC = @UPC,
	    ChannelAdvisorSiteName = @ChannelAdvisorSiteName,
	    ChannelAdvisorBuyerID  = @ChannelAdvisorBuyerID,
	    ChannelAdvisorAuctionID = @ChannelAdvisorAuctionID,
	    AmazonOrderItemCode = @AmazonOrderItemCode,
	    AmazonASIN = @AmazonASIN,
	    ChannelAdvisorClassification = @ChannelAdvisorClassification,
	    AmazonConditionNote = @AmazonConditionNote

    WHERE OrderItemID = @OrderItemID AND RowVersion = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT [RowVersion]
    FROM OrderItems
    WHERE OrderItemID = @OrderItemID

    return 1
GO

-----------------------------
--- Procedure AddOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddOrderItem]
GO

CREATE PROCEDURE dbo.AddOrderItem
(
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@SKU nvarchar (100),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@eBaySellingManagerProductName nvarchar(80),
	@eBaySellingManagerProductPart nvarchar(80),
	@eBaySellingManagerRecord int,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@Status nvarchar (50),
	@YahooProductID nvarchar (255),
	@Location nvarchar (100),
	@ISBN nvarchar(30), 
	@UPC nvarchar(30),
	@ChannelAdvisorSiteName varchar(50),
	@ChannelAdvisorBuyerID varchar(80),
	@ChannelAdvisorAuctionID varchar(50),
	@AmazonOrderItemCode bigint,
	@AmazonASIN varchar(32),
	@ChannelAdvisorClassification nvarchar(30),
	@AmazonConditionNote nvarchar(255)
)
WITH ENCRYPTION
AS
    -- Add the item
    INSERT INTO [OrderItems]
    (
	    [OrderID],
	    [Ordinal],
	    [Name],
	    [Code],
	    SKU,
	    [Thumbnail],
	    [Image],
	    [UnitPrice],
	    [UnitCost],
	    [Weight],
	    [Quantity],
	    [eBayItemID],
	    [eBayTransID],
	    eBaySellingManagerProductName,
	    eBaySellingManagerProductPart,
	    eBaySellingManagerRecord,
	    [MivaLineID],
	    [MivaProductCode],
	    [Status],
	    [YahooProductID],
	    Location,
   		ISBN, 
		UPC,
	    ChannelAdvisorSiteName,
	    ChannelAdvisorBuyerID,
	    ChannelAdvisorAuctionID,
	    AmazonOrderItemCode,
	    AmazonASIN,
	    ChannelAdvisorClassification,
	    AmazonConditionNote
 )
    VALUES
    (
	    @OrderID,
	    @Ordinal,
	    @Name,
	    @Code,
	    @SKU,
	    @Thumbnail,
	    @Image,
	    @UnitPrice,
	    @UnitCost,
	    @Weight,
	    @Quantity,
	    @eBayItemID,
	    @eBayTransID,
	    @eBaySellingManagerProductName,
	    @eBaySellingManagerProductPart,
	    @eBaySellingManagerRecord,
	    @MivaLineID,
	    @MivaProductCode,
	    @Status,
	    @YahooProductID,
	    @Location,
       	@ISBN, 
		@UPC,
	    @ChannelAdvisorSiteName,
	    @ChannelAdvisorBuyerID,
	    @ChannelAdvisorAuctionID,
	    @AmazonOrderItemCode,
	    @AmazonASIN,
	    @ChannelAdvisorClassification,
	    @AmazonConditionNote
	)
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT OrderItemID, [RowVersion]
    FROM OrderItems
    WHERE OrderItemID = SCOPE_IDENTITY()
        
    return 1
GO

-----------------------------
--- Procedure SynchEBayOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchEBayOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchEBayOrderItem]
GO

CREATE PROCEDURE dbo.SynchEBayOrderItem
(
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@SKU nvarchar (100),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@eBaySellingManagerProductName nvarchar(80),
	@eBaySellingManagerProductPart nvarchar(80),
	@eBaySellingManagerRecord int,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@Status nvarchar (50),
	@YahooProductID nvarchar (255),
	@Location nvarchar (100),
	@ISBN nvarchar(30), 
	@UPC nvarchar(30),
	@ChannelAdvisorSiteName varchar(50),
	@ChannelAdvisorBuyerID varchar(80),
	@ChannelAdvisorAuctionID varchar(50),
	@AmazonOrderItemCode bigint,
	@AmazonASIN varchar(32),
	@ChannelAdvisorClassification nvarchar(30),
	@AmazonConditionNote nvarchar(255)
)
WITH ENCRYPTION
AS
   
    -- If this eBay item already exists, we update it
    if exists (
        SELECT * 
        FROM OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID)
    begin
    
        -- Update the item
        UPDATE OrderItems
        SET [OrderID] = @OrderID,
            [Ordinal] = @Ordinal,
            [Name] = @Name,
            [Code] = @Code,
            SKU = @SKU,
            [Thumbnail] = @Thumbnail,
            [Image] = @Image,
            [UnitPrice] = @UnitPrice,
            [UnitCost] = @UnitCost,
            [Weight] = @Weight,
            [Quantity] = @Quantity,
            [eBayItemID] = @eBayItemID,
            [eBayTransID] = @eBayTransID,
	        eBaySellingManagerProductName = @eBaySellingManagerProductName,
	        eBaySellingManagerProductPart = @eBaySellingManagerProductPart,
	        eBaySellingManagerRecord = @eBaySellingManagerRecord,
            [MivaLineID] = @MivaLineID,
            [MivaProductCode] = @MivaProductCode,
            [Status] = @Status,
            [YahooProductID] = @YahooProductID,
            Location = @Location,
     		ISBN = @ISBN, 
			UPC = @UPC,
	        ChannelAdvisorSiteName = @ChannelAdvisorSiteName,
	        ChannelAdvisorBuyerID = @ChannelAdvisorBuyerID,
	        ChannelAdvisorAuctionID = @ChannelAdvisorAuctionID,
	        AmazonOrderItemCode = @AmazonOrderItemCode,
	        AmazonASIN = @AmazonASIN,
	        ChannelAdvisorClassification = @ChannelAdvisorClassification,
	        AmazonConditionNote = @AmazonConditionNote
	   WHERE eBayItemID = @eBayItemID AND
              eBayTransID = @eBayTransID
              
        -- This just lets the .NET data provider know everything is OK
        SELECT OrderItemID, [RowVersion]
        FROM OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItems]
        (
	        [OrderID],
	        [Ordinal],
	        [Name],
	        [Code],
	        SKU,
	        [Thumbnail],
	        [Image],
	        [UnitPrice],
	        [UnitCost],
	        [Weight],
	        [Quantity],
	        [eBayItemID],
	        [eBayTransID],
	        eBaySellingManagerProductName,
	        eBaySellingManagerProductPart,
	        eBaySellingManagerRecord,
	        [MivaLineID],
	        [MivaProductCode],
	        [Status],
	        [YahooProductID],
	        Location,
          	ISBN, 
			UPC,
	        ChannelAdvisorSiteName,
	        ChannelAdvisorBuyerID,
	        ChannelAdvisorAuctionID,
	        AmazonOrderItemCode,
	        AmazonASIN,
	        ChannelAdvisorClassification,
	        AmazonConditionNote
		)
        VALUES
        (
	        @OrderID,
	        @Ordinal,
	        @Name,
	        @Code,
	        @SKU,
	        @Thumbnail,
	        @Image,
	        @UnitPrice,
	        @UnitCost,
	        @Weight,
	        @Quantity,
	        @eBayItemID,
	        @eBayTransID,
	        @eBaySellingManagerProductName,
	        @eBaySellingManagerProductPart,
	        @eBaySellingManagerRecord,
	        @MivaLineID,
	        @MivaProductCode,
	        @Status,
	        @YahooProductID,
	        @Location,
           	@ISBN, 
			@UPC,
	        @ChannelAdvisorSiteName,
	        @ChannelAdvisorBuyerID,
	        @ChannelAdvisorAuctionID,
	        @AmazonOrderItemCode,
	        @AmazonASIN,
	        @ChannelAdvisorClassification,
	        @AmazonConditionNote
       )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderItemID, [RowVersion]
        FROM OrderItems
        WHERE OrderItemID = SCOPE_IDENTITY()

        return 1
    end
GO

-----------------------------
--- Procedure SynchMivaOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaOrderItem]
GO

CREATE PROCEDURE dbo.SynchMivaOrderItem
(
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@SKU nvarchar (100),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@eBaySellingManagerProductName nvarchar (80),
	@eBaySellingManagerProductPart nvarchar (80),
	@eBaySellingManagerRecord int,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@Status nvarchar (50),
	@YahooProductID nvarchar (255),
	@Location nvarchar (100),
	@ISBN nvarchar(30), 
	@UPC nvarchar(30),
	@ChannelAdvisorSiteName varchar(50),
	@ChannelAdvisorBuyerID varchar(80),
	@ChannelAdvisorAuctionID varchar(50),
	@AmazonOrderItemCode bigint,
	@AmazonASIN varchar(32),
	@ChannelAdvisorClassification nvarchar(30),
	@AmazonConditionNote nvarchar(255)
)
WITH ENCRYPTION
AS
   
    -- If this Miva item already exists, we dont do anything
    if exists (
        SELECT * 
        FROM OrderItems i
        WHERE i.MivaLineID = @MivaLineID AND
              i.OrderID = @OrderID)
    begin
    
        -- Select the current row back into .net
        SELECT *
        FROM OrderItems i
        WHERE i.MivaLineID = @MivaLineID AND
              i.OrderID = @OrderID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItems]
        (
	        [OrderID],
	        [Ordinal],
	        [Name],
	        [Code],
	        SKU,
	        [Thumbnail],
	        [Image],
	        [UnitPrice],
	        [UnitCost],
	        [Weight],
	        [Quantity],
	        [eBayItemID],
	        [eBayTransID],
	        eBaySellingManagerProductName,
	        eBaySellingManagerProductPart,
	        eBaySellingManagerRecord,
	        [MivaLineID],
	        [MivaProductCode],
	        [Status],
	        [YahooProductID],
	        Location,
          	ISBN, 
			UPC,
	        ChannelAdvisorSiteName,
	        ChannelAdvisorBuyerID,
	        ChannelAdvisorAuctionID,
	        AmazonOrderItemCode,
	        AmazonASIN,
	        ChannelAdvisorClassification,
	        AmazonConditionNote
        )
        VALUES
        (
	        @OrderID,
	        @Ordinal,
	        @Name,
	        @Code,
	        @SKU,
	        @Thumbnail,
	        @Image,
	        @UnitPrice,
	        @UnitCost,
	        @Weight,
	        @Quantity,
	        @eBayItemID,
	        @eBayTransID,
	        @eBaySellingManagerProductName,
	        @eBaySellingManagerProductPart,
	        @eBaySellingManagerRecord,
	        @MivaLineID,
	        @MivaProductCode,
	        @Status,
	        @YahooProductID,
	        @Location,
          	@ISBN, 
			@UPC,
	        @ChannelAdvisorSiteName,
	        @ChannelAdvisorBuyerID,
	        @ChannelAdvisorAuctionID,
	        @AmazonOrderItemCode,
	        @AmazonASIN,
	        @ChannelAdvisorClassification,
	        @AmazonConditionNote
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderItemID, [RowVersion]
        FROM OrderItems
        WHERE OrderItemID = SCOPE_IDENTITY()

        return 1
    end
GO
