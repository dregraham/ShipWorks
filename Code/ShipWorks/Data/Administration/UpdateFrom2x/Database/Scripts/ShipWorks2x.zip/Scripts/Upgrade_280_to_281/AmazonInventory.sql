CREATE UNIQUE NONCLUSTERED INDEX IX_AmazonInventory_Sku ON dbo.AmazonInventory
	(
	SKU,
	StoreID
	) 
GO