-----------------------------
--- Procedure GetDhlPackageRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetDhlPackageRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetDhlPackageRange]
GO

CREATE PROCEDURE dbo.GetDhlPackageRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
     FROM DhlPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
           o.OrderID > @MinOrderID
     
GO