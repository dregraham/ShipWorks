-----------------------------
--- TRIGGER TG_Orders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Orders]'))
   drop trigger dbo.[TG_Orders]
GO

CREATE TRIGGER dbo.TG_Orders ON Orders FOR UPDATE
AS
    DECLARE @StoreID int
    DECLARE @OldCustomerID int
    DECLARE @NewCustomerID int
    
    SELECT TOP 1 @StoreID = StoreID, @NewCustomerID = CustomerID FROM inserted
    SELECT TOP 1 @OldCustomerID = CustomerID FROM deleted
    
    if (@StoreID IS NULL)
        return;
    
    EXEC SetTableLastDbts 'Orders', @StoreID, @@DBTS
    
    IF (@OldCustomerID != @NewCustomerID)
    begin
        -- If the customerID is updated, we just need to touch the customer of each order
        -- so that SW knows the customer calculated columns need looked at.
        UPDATE Customers
          SET ShipFirstName = ShipFirstName
          WHERE CustomerID in (SELECT CustomerID FROM inserted)
          
        -- Update all the old customers too
        UPDATE Customers
          SET ShipFirstName = ShipFirstName
          WHERE CustomerID in (SELECT CustomerID FROM deleted)
          
        print('TG_Orders - CustomerID Changed')
    end
    
GO