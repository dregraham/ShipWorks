ALTER TABLE OrderItems
   ALTER COLUMN [Name] nvarchar (300) NOT NULL
GO

ALTER TABLE OrderItems
   ALTER COLUMN [Code] nvarchar (300) NOT NULL
GO

ALTER TABLE OrderItems
   ALTER COLUMN [MivaProductCode] nvarchar (300) NOT NULL
GO

ALTER TABLE OrderItems
    ALTER COLUMN [Image] ntext NOT NULL
GO

-----------------------------
--- Procedure GetChangedItems
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedItems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedItems]
GO

CREATE PROCEDURE GetChangedItems
(
   @LastDBTS rowversion,
   @StoreID int
)
AS

   SELECT i.*
      FROM Orders o, OrderItems i
      WHERE (i.RowVersion > @LastDBTS AND o.StoreID = @StoreID AND o.OrderID = i.OrderID)

GO

-----------------------------
--- Procedure UpdateOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateOrderItem]
GO

CREATE PROCEDURE UpdateOrderItem
(
	@OrderItemID int,
	@RowVersion timestamp,
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@MivaCustomStatus nvarchar (50)
)
AS
    -- Update the item
    UPDATE OrderItems
    SET [OrderID] = @OrderID,
        [Name] = @Name,
        [Code] = @Code,
        [Thumbnail] = @Thumbnail,
        [Image] = @Image,
        [UnitPrice] = @UnitPrice,
        [UnitCost] = @UnitCost,
        [Weight] = @Weight,
        [Quantity] = @Quantity,
        [eBayItemID] = @eBayItemID,
        [eBayTransID] = @eBayTransID,
        [MivaLineID] = @MivaLineID,
        [MivaProductCode] = @MivaProductCode,
        [MivaCustomStatus] = @MivaCustomStatus
    WHERE OrderItemID = @OrderItemID AND RowVersion = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT [RowVersion]
    FROM OrderItems
    WHERE OrderItemID = @OrderItemID

    return 1
GO

-----------------------------
--- Procedure AddOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddOrderItem]
GO

CREATE PROCEDURE AddOrderItem
(
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@MivaCustomStatus nvarchar (50)
)
AS
    -- Add the item
    INSERT INTO [OrderItems]
    (
	    [OrderID],
	    [Ordinal],
	    [Name],
	    [Code],
	    [Thumbnail],
	    [Image],
	    [UnitPrice],
	    [UnitCost],
	    [Weight],
	    [Quantity],
	    [eBayItemID],
	    [eBayTransID],
	    [MivaLineID],
	    [MivaProductCode],
	    [MivaCustomStatus]
    )
    VALUES
    (
	    @OrderID,
	    @Ordinal,
	    @Name,
	    @Code,
	    @Thumbnail,
	    @Image,
	    @UnitPrice,
	    @UnitCost,
	    @Weight,
	    @Quantity,
	    @eBayItemID,
	    @eBayTransID,
	    @MivaLineID,
	    @MivaProductCode,
	    @MivaCustomStatus
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT OrderItemID, [RowVersion]
    FROM OrderItems
    WHERE OrderItemID = SCOPE_IDENTITY()
        
    return 1
GO

-----------------------------
--- Procedure SynchEBayOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchEBayOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchEBayOrderItem]
GO

CREATE PROCEDURE SynchEBayOrderItem
(
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@MivaCustomStatus nvarchar (50)
)
AS
   
    -- If this eBay item already exists, we update it
    if exists (
        SELECT * 
        FROM OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              i.OrderID = @OrderID)
    begin
    
        -- Update the item
        UPDATE OrderItems
        SET [Ordinal] = @Ordinal,
            [Name] = @Name,
            [Code] = @Code,
            [Thumbnail] = @Thumbnail,
            [Image] = @Image,
            [UnitPrice] = @UnitPrice,
            [UnitCost] = @UnitCost,
            [Weight] = @Weight,
            [Quantity] = @Quantity,
            [eBayItemID] = @eBayItemID,
            [eBayTransID] = @eBayTransID,
            [MivaLineID] = @MivaLineID,
            [MivaProductCode] = @MivaProductCode,
            [MivaCustomStatus] = @MivaCustomStatus
        WHERE eBayItemID = @eBayItemID AND
              eBayTransID = @eBayTransID AND
              OrderID = @OrderID
              
        -- This just lets the .NET data provider know everything is OK
        SELECT OrderItemID, [RowVersion]
        FROM OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              i.OrderID = @OrderID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItems]
        (
	        [OrderID],
	        [Ordinal],
	        [Name],
	        [Code],
	        [Thumbnail],
	        [Image],
	        [UnitPrice],
	        [UnitCost],
	        [Weight],
	        [Quantity],
	        [eBayItemID],
	        [eBayTransID],
	        [MivaLineID],
	        [MivaProductCode],
	        [MivaCustomStatus]
        )
        VALUES
        (
	        @OrderID,
	        @Ordinal,
	        @Name,
	        @Code,
	        @Thumbnail,
	        @Image,
	        @UnitPrice,
	        @UnitCost,
	        @Weight,
	        @Quantity,
	        @eBayItemID,
	        @eBayTransID,
	        @MivaLineID,
	        @MivaProductCode,
	        @MivaCustomStatus
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderItemID, [RowVersion]
        FROM OrderItems
        WHERE OrderItemID = SCOPE_IDENTITY()

        return 1
    end
GO

-----------------------------
--- Procedure SynchMivaOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaOrderItem]
GO

CREATE PROCEDURE SynchMivaOrderItem
(
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@MivaCustomStatus nvarchar (50)
)
AS
   
    -- If this Miva item already exists, we dont do anything
    if exists (
        SELECT * 
        FROM OrderItems i
        WHERE i.MivaLineID = @MivaLineID AND
              i.OrderID = @OrderID)
    begin
    
        -- Select the current row back into .net
        SELECT *
        FROM OrderItems i
        WHERE i.MivaLineID = @MivaLineID AND
              i.OrderID = @OrderID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItems]
        (
	        [OrderID],
	        [Ordinal],
	        [Name],
	        [Code],
	        [Thumbnail],
	        [Image],
	        [UnitPrice],
	        [UnitCost],
	        [Weight],
	        [Quantity],
	        [eBayItemID],
	        [eBayTransID],
	        [MivaLineID],
	        [MivaProductCode],
	        [MivaCustomStatus]
        )
        VALUES
        (
	        @OrderID,
	        @Ordinal,
	        @Name,
	        @Code,
	        @Thumbnail,
	        @Image,
	        @UnitPrice,
	        @UnitCost,
	        @Weight,
	        @Quantity,
	        @eBayItemID,
	        @eBayTransID,
	        @MivaLineID,
	        @MivaProductCode,
	        @MivaCustomStatus
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderItemID, [RowVersion]
        FROM OrderItems
        WHERE OrderItemID = SCOPE_IDENTITY()

        return 1
    end
GO