ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Clients
GO

ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Stores
GO

CREATE TABLE dbo.Tmp_ClientStoreSettings
	(
	ClientID int NOT NULL,
	StoreID int NOT NULL,
	RowVersion timestamp NOT NULL,
	LicenseKey nvarchar(150) NOT NULL,
	PerfDateRangeType int NOT NULL,
	PerfDateRangeDays int NOT NULL,
	PerfDateRangeMax datetime NOT NULL,
	PerfDateRangeMin datetime NOT NULL,
	PerfShowFilterCounts bit NOT NULL,
	WolrdShipCsvFilename nvarchar(350) NOT NULL,
	WorldShipOutputType int NOT NULL,
	WorldShipLaunchAfterExport bit NOT NULL,
	WorldShipReferenceNumber1 varchar(50) NOT NULL,
	WorldShipReferenceNumber2 varchar(50) NOT NULL,
	WorldShipQvnFromName nvarchar(30) NOT NULL,
	WorldShipQvnSubject int NOT NULL,
	WorldShipQvnMemo nvarchar(150) NOT NULL,
	WorldShipQvnFailedAddress nvarchar(50) NOT NULL,
	WorldShipQvnShipNotify bit NOT NULL,
	WorldShipQvnDeliveryNotify bit NOT NULL,
	WorldShipQvnExceptionNotify bit NOT NULL,
	StampsDefaultService int NOT NULL,
	StampsDefaultConfirmation int NOT NULL,
	StampsMailpiece int NOT NULL,
	StampsLabelSheet int NOT NULL,
	StampsHidePostage bit NOT NULL,
	StampsMemo nvarchar(50) NOT NULL,
	EndiciaSetService bit NOT NULL,
	EndiciaSetConfirmation bit NOT NULL,
	EndiciaSetWeight bit NOT NULL,
	EndiciaSetDate bit NOT NULL,
	EndiciaSetInsurance bit NOT NULL,
	EndiciaDefaultDomesticService int NOT NULL,
	EndiciaDefaultInternationalService int NOT NULL,
	EndiciaDefaultConfirmation int NOT NULL,
	EndiciaDefaultDateAdvance int NOT NULL,
	EndiciaDefaultInsuranceType int NOT NULL,
	EndiciaDefaultLayouts ntext NOT NULL,
	EndiciaDefaultStealthMode bit NOT NULL,
	EndiciaDefaultOversize bit NOT NULL,
	EndiciaDefaultCustomsForm int NOT NULL,
	EndiciaDefaultCustomsDescription varchar(200) NOT NULL,
	EndiciaDefaultCustomsContentType int NOT NULL,
	EndiciaRubberStamp1 varchar(200) NOT NULL,
	EndiciaRubberStamp2 varchar(200) NOT NULL,
	EndiciaRubberStamp3 varchar(200) NOT NULL,
	EndiciaRubberStamp4 varchar(200) NOT NULL,
	EndiciaTestMode bit NOT NULL,
	EndiciaCloseOnComplete bit NOT NULL,
	EndiciaAutoPrintCustoms bit NOT NULL,
	EndiciaUnattendedPrinting bit NOT NULL,
	UspsDefaultService int NOT NULL,
	UspsDefaultConfirmation int NOT NULL,
	UspsDefaultRequestAddressService bit NOT NULL,
	UspsDefaultSendConfirmationEmail bit NOT NULL,
	UspsUseLiveServer bit NOT NULL,
	UspsDefaultTemplate nvarchar(50) NOT NULL,
	DownloadAllowed bit NOT NULL,
	DownloadAutoEnable bit NOT NULL,
	DownloadAutoInterval int NOT NULL,
	DisplayShipmentOwnerOrder varchar(200) NOT NULL,
	DisplayShipmentOwnerCustomer varchar(200) NOT NULL
	)
GO

IF EXISTS(SELECT * FROM dbo.ClientStoreSettings)
	 EXEC('INSERT INTO dbo.Tmp_ClientStoreSettings 
	          (ClientID, StoreID, LicenseKey, PerfDateRangeType, PerfDateRangeDays, PerfDateRangeMax, PerfDateRangeMin, PerfShowFilterCounts, WolrdShipCsvFilename, WorldShipOutputType, WorldShipLaunchAfterExport, WorldShipReferenceNumber1, WorldShipReferenceNumber2, WorldShipQvnFromName, WorldShipQvnSubject, WorldShipQvnMemo, WorldShipQvnFailedAddress, WorldShipQvnShipNotify, WorldShipQvnDeliveryNotify, WorldShipQvnExceptionNotify, StampsDefaultService, StampsDefaultConfirmation, StampsMailpiece, StampsLabelSheet, StampsHidePostage, StampsMemo, EndiciaSetService, EndiciaSetConfirmation, EndiciaSetWeight, EndiciaSetDate, EndiciaSetInsurance, EndiciaDefaultDomesticService, EndiciaDefaultInternationalService, EndiciaDefaultConfirmation, EndiciaDefaultDateAdvance, EndiciaDefaultInsuranceType, EndiciaDefaultLayouts, EndiciaDefaultStealthMode, EndiciaDefaultOversize, EndiciaDefaultCustomsForm, EndiciaDefaultCustomsDescription, EndiciaDefaultCustomsContentType, EndiciaRubberStamp1, EndiciaRubberStamp2, EndiciaRubberStamp3, EndiciaRubberStamp4, EndiciaTestMode, EndiciaCloseOnComplete, EndiciaAutoPrintCustoms, EndiciaUnattendedPrinting, UspsDefaultService, UspsDefaultConfirmation, UspsDefaultRequestAddressService, UspsDefaultSendConfirmationEmail, UspsUseLiveServer, UspsDefaultTemplate, DownloadAllowed, DownloadAutoEnable, DownloadAutoInterval, DisplayShipmentOwnerOrder, DisplayShipmentOwnerCustomer)
		SELECT ClientID, StoreID, LicenseKey, PerfDateRangeType, PerfDateRangeDays, PerfDateRangeMax, PerfDateRangeMin, PerfShowFilterCounts, WolrdShipCsvFilename, WorldShipOutputType, WorldShipLaunchAfterExport, WorldShipReferenceNumber1, WorldShipReferenceNumber2, WorldShipQvnFromName, WorldShipQvnSubject, WorldShipQvnMemo, WorldShipQvnFailedAddress, WorldShipQvnShipNotify, WorldShipQvnDeliveryNotify, WorldShipQvnExceptionNotify, StampsDefaultService, StampsDefaultConfirmation, StampsMailpiece, StampsLabelSheet, StampsHidePostage, StampsMemo, EndiciaSetService, EndiciaSetConfirmation, EndiciaSetWeight, EndiciaSetDate, 0,                   EndiciaDefaultDomesticService, EndiciaDefaultInternationalService, EndiciaDefaultConfirmation, EndiciaDefaultDateAdvance, 0,                           '''',                  EndiciaStealthMode,        0,                      0,                         '''',                             3,                                EndiciaRubberStamp1, EndiciaRubberStamp2, EndiciaRubberStamp3, EndiciaRubberStamp4, EndiciaTestMode, EndiciaCloseOnComplete, 0,                       EndiciaUnattendedPrinting, UspsDefaultService, UspsDefaultConfirmation, UspsDefaultRequestAddressService, UspsDefaultSendConfirmationEmail, UspsUseLiveServer, UspsDefaultTemplate, DownloadAllowed, DownloadAutoEnable, DownloadAutoInterval, DisplayShipmentOwnerOrder, DisplayShipmentOwnerCustomer FROM dbo.ClientStoreSettings TABLOCKX')
GO

DROP TABLE dbo.ClientStoreSettings
GO

EXECUTE sp_rename N'dbo.Tmp_ClientStoreSettings', N'ClientStoreSettings', 'OBJECT'
GO

ALTER TABLE dbo.ClientStoreSettings ADD CONSTRAINT
	PK_ClientStoreSettings PRIMARY KEY CLUSTERED 
	(
	ClientID,
	StoreID
	)
GO

ALTER TABLE dbo.ClientStoreSettings WITH NOCHECK ADD CONSTRAINT
	FK_ClientStoreSettings_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.ClientStoreSettings WITH NOCHECK ADD CONSTRAINT
	FK_ClientStoreSettings_Clients FOREIGN KEY
	(
	ClientID
	) REFERENCES dbo.Clients
	(
	ClientID
	)
GO

----------------------------
--- PROCEDURE GetAllClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetAllClientStoreSettings]
GO

CREATE PROCEDURE GetAllClientStoreSettings
AS
   SELECT *
   FROM [ClientStoreSettings]
GO

----------------------------
--- PROCEDURE DeleteClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteClientStoreSettings]
GO

CREATE PROCEDURE DeleteClientStoreSettings
(
   @ClientID int,
   @StoreID int
)
AS
   DELETE FROM [ClientStoreSettings]
   WHERE 
      [ClientID] = @ClientID AND
      [StoreID] = @StoreID
GO

----------------------------
--- PROCEDURE AddClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddClientStoreSettings]
GO

CREATE PROCEDURE AddClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 varchar (50),
   @WorldShipReferenceNumber2 varchar (50),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaSetInsurance bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaDefaultInsuranceType int,
   @EndiciaDefaultLayouts ntext,
   @EndiciaDefaultStealthMode bit,
   @EndiciaDefaultOversize bit,
   @EndiciaDefaultCustomsForm int,
   @EndiciaDefaultCustomsDescription varchar (200),
   @EndiciaDefaultCustomsContentType int,
   @EndiciaRubberStamp1 varchar(200),
   @EndiciaRubberStamp2 varchar(200),
   @EndiciaRubberStamp3 varchar(200),
   @EndiciaRubberStamp4 varchar(200),
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @EndiciaAutoPrintCustoms bit,
   @EndiciaUnattendedPrinting bit,
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DisplayShipmentOwnerOrder varchar (200),
   @DisplayShipmentOwnerCustomer varchar (200)
)
AS
   INSERT INTO [ClientStoreSettings]
   (
        [ClientID], 
        [StoreID], 
        [LicenseKey], 
        [PerfDateRangeType],
        [PerfDateRangeDays], 
        [PerfDateRangeMax], 
        [PerfDateRangeMin], 
        [PerfShowFilterCounts],
        [WolrdShipCsvFilename], 
        [WorldShipOutputType], 
        [WorldShipLaunchAfterExport], 
        [WorldShipReferenceNumber1],
        [WorldShipReferenceNumber2],
        [WorldShipQvnFromName],
        [WorldShipQvnSubject],
        [WorldShipQvnMemo],
        [WorldShipQvnFailedAddress],
        [WorldShipQvnShipNotify],
        [WorldShipQvnDeliveryNotify],
        [WorldShipQvnExceptionNotify],
        [StampsDefaultService],
        [StampsDefaultConfirmation],
        [StampsMailpiece],
        [StampsLabelSheet],
        [StampsHidePostage],
        [StampsMemo],
		[EndiciaSetService],
		[EndiciaSetConfirmation],
		[EndiciaSetWeight],
		[EndiciaSetDate],
		[EndiciaSetInsurance],
		[EndiciaDefaultDomesticService],
		[EndiciaDefaultInternationalService],
		[EndiciaDefaultConfirmation],
		[EndiciaDefaultDateAdvance],
		[EndiciaDefaultInsuranceType],
		[EndiciaDefaultLayouts],
		[EndiciaDefaultStealthMode],
		[EndiciaDefaultOversize],
		[EndiciaDefaultCustomsForm],
		[EndiciaDefaultCustomsDescription],
		[EndiciaDefaultCustomsContentType],
		[EndiciaRubberStamp1],
		[EndiciaRubberStamp2],
		[EndiciaRubberStamp3],
		[EndiciaRubberStamp4],
		[EndiciaTestMode],
		[EndiciaCloseOnComplete],
		[EndiciaAutoPrintCustoms],
		[EndiciaUnattendedPrinting],
        [UspsDefaultService], 
        [UspsDefaultConfirmation], 
        [UspsDefaultRequestAddressService], 
        [UspsDefaultSendConfirmationEmail], 
        [UspsUseLiveServer], 
        [UspsDefaultTemplate], 
        [DownloadAllowed],
	    [DownloadAutoEnable],
	    [DownloadAutoInterval],
	    DisplayShipmentOwnerOrder,
	    DisplayShipmentOwnerCustomer
   )
   VALUES 
   (
        @ClientID, 
        @StoreID, 
        @LicenseKey, 
        @PerfDateRangeType,
        @PerfDateRangeDays, 
        @PerfDateRangeMax, 
        @PerfDateRangeMin, 
        @PerfShowFilterCounts,
        @WolrdShipCsvFilename, 
        @WorldShipOutputType, 
        @WorldShipLaunchAfterExport, 
        @WorldShipReferenceNumber1,
        @WorldShipReferenceNumber2,
        @WorldShipQvnFromName,
        @WorldShipQvnSubject,
        @WorldShipQvnMemo,
        @WorldShipQvnFailedAddress,
        @WorldShipQvnShipNotify,
        @WorldShipQvnDeliveryNotify,
        @WorldShipQvnExceptionNotify,
        @StampsDefaultService,
        @StampsDefaultConfirmation,
        @StampsMailpiece,
        @StampsLabelSheet,
        @StampsHidePostage,
        @StampsMemo,
		@EndiciaSetService,
		@EndiciaSetConfirmation,
		@EndiciaSetWeight,
		@EndiciaSetDate,
		@EndiciaSetInsurance,
		@EndiciaDefaultDomesticService,
		@EndiciaDefaultInternationalService,
		@EndiciaDefaultConfirmation,
		@EndiciaDefaultDateAdvance,
		@EndiciaDefaultInsuranceType,
		@EndiciaDefaultLayouts,
		@EndiciaDefaultStealthMode,
		@EndiciaDefaultOversize,
		@EndiciaDefaultCustomsForm,
		@EndiciaDefaultCustomsDescription,
		@EndiciaDefaultCustomsContentType,
		@EndiciaRubberStamp1,
		@EndiciaRubberStamp2,
		@EndiciaRubberStamp3,
		@EndiciaRubberStamp4,
		@EndiciaTestMode,
		@EndiciaCloseOnComplete,
		@EndiciaAutoPrintCustoms,
		@EndiciaUnattendedPrinting,
        @UspsDefaultService, 
        @UspsDefaultConfirmation, 
        @UspsDefaultRequestAddressService, 
        @UspsDefaultSendConfirmationEmail, 
        @UspsUseLiveServer, 
        @UspsDefaultTemplate, 
        @DownloadAllowed,
	    @DownloadAutoEnable,
	    @DownloadAutoInterval,
	    @DisplayShipmentOwnerOrder,
	    @DisplayShipmentOwnerCustomer
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT RowVersion
   FROM ClientStoreSettings
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateClientStoreSettings]
GO

CREATE PROCEDURE UpdateClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 varchar (50),
   @WorldShipReferenceNumber2 varchar (50),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaSetInsurance bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaDefaultInsuranceType int,
   @EndiciaDefaultLayouts ntext,
   @EndiciaDefaultStealthMode bit,
   @EndiciaDefaultOversize bit,
   @EndiciaDefaultCustomsForm int,
   @EndiciaDefaultCustomsDescription varchar (200),
   @EndiciaDefaultCustomsContentType int,
   @EndiciaRubberStamp1 varchar(200),
   @EndiciaRubberStamp2 varchar(200),
   @EndiciaRubberStamp3 varchar(200),
   @EndiciaRubberStamp4 varchar(200),
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @EndiciaAutoPrintCustoms bit,
   @EndiciaUnattendedPrinting bit,
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DisplayShipmentOwnerOrder varchar (200),
   @DisplayShipmentOwnerCustomer varchar (200)
)
AS
   UPDATE [ClientStoreSettings]
   SET 
    [LicenseKey] = @LicenseKey, 
    [PerfDateRangeType] = @PerfDateRangeType,
    [PerfDateRangeDays] = @PerfDateRangeDays, 
    [PerfDateRangeMax] = @PerfDateRangeMax, 
    [PerfDateRangeMin] = @PerfDateRangeMin, 
    [PerfShowFilterCounts] = @PerfShowFilterCounts,
    [WolrdShipCsvFilename] = @WolrdShipCsvFilename, 
    [WorldShipOutputType] = @WorldShipOutputType, 
    [WorldShipLaunchAfterExport] = @WorldShipLaunchAfterExport, 
    [WorldShipReferenceNumber1] = @WorldShipReferenceNumber1,
    [WorldShipReferenceNumber2] = @WorldShipReferenceNumber2,
    [WorldShipQvnFromName] = @WorldShipQvnFromName,
    [WorldShipQvnSubject] = @WorldShipQvnSubject,
    [WorldShipQvnMemo] = @WorldShipQvnMemo,
    [WorldShipQvnFailedAddress] = @WorldShipQvnFailedAddress,
    [WorldShipQvnShipNotify] = @WorldShipQvnShipNotify,
    [WorldShipQvnDeliveryNotify] = @WorldShipQvnDeliveryNotify,
    [WorldShipQvnExceptionNotify] = @WorldShipQvnExceptionNotify,
    [StampsDefaultService] = @StampsDefaultService,
    [StampsDefaultConfirmation] = @StampsDefaultConfirmation,
    [StampsMailpiece] = @StampsMailpiece,
    [StampsLabelSheet] = @StampsLabelSheet,
    [StampsHidePostage] = @StampsHidePostage,
    [StampsMemo] = @StampsMemo,
	[EndiciaSetService] = @EndiciaSetService,
	[EndiciaSetConfirmation] = @EndiciaSetConfirmation,
	[EndiciaSetWeight] = @EndiciaSetWeight,
	[EndiciaSetDate] = @EndiciaSetDate,
	[EndiciaSetInsurance] = @EndiciaSetInsurance,
	[EndiciaDefaultDomesticService] = @EndiciaDefaultDomesticService,
	[EndiciaDefaultInternationalService] = @EndiciaDefaultInternationalService,
	[EndiciaDefaultConfirmation] = @EndiciaDefaultConfirmation,
	[EndiciaDefaultDateAdvance] = @EndiciaDefaultDateAdvance,
	[EndiciaDefaultInsuranceType] = @EndiciaDefaultInsuranceType,
	[EndiciaDefaultLayouts] = @EndiciaDefaultLayouts,
	[EndiciaDefaultStealthMode] = @EndiciaDefaultStealthMode,
	[EndiciaDefaultOversize] = @EndiciaDefaultOversize,
	[EndiciaDefaultCustomsForm] = @EndiciaDefaultCustomsForm,
	[EndiciaDefaultCustomsDescription] = @EndiciaDefaultCustomsDescription,
	[EndiciaDefaultCustomsContentType] = @EndiciaDefaultCustomsContentType,
	[EndiciaRubberStamp1] = @EndiciaRubberStamp1,
	[EndiciaRubberStamp2] = @EndiciaRubberStamp2,
	[EndiciaRubberStamp3] = @EndiciaRubberStamp3,
	[EndiciaRubberStamp4] = @EndiciaRubberStamp4,
	[EndiciaTestMode] = @EndiciaTestMode,
	[EndiciaCloseOnComplete] = @EndiciaCloseOnComplete,
	[EndiciaAutoPrintCustoms] = @EndiciaAutoPrintCustoms,
	[EndiciaUnattendedPrinting] = @EndiciaUnattendedPrinting,
    [UspsDefaultService] = @UspsDefaultService, 
    [UspsDefaultConfirmation] = @UspsDefaultConfirmation, 
    [UspsDefaultRequestAddressService] = @UspsDefaultRequestAddressService, 
    [UspsDefaultSendConfirmationEmail] = @UspsDefaultSendConfirmationEmail, 
    [UspsUseLiveServer] = @UspsUseLiveServer, 
    [UspsDefaultTemplate] = @UspsDefaultTemplate, 
    [DownloadAllowed] = @DownloadAllowed,
    [DownloadAutoEnable] = @DownloadAutoEnable,
    [DownloadAutoInterval] = @DownloadAutoInterval,
    DisplayShipmentOwnerOrder = @DisplayShipmentOwnerOrder,
    DisplayShipmentOwnerCustomer = @DisplayShipmentOwnerCustomer
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM [ClientStoreSettings]
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID

   return 1
GO
