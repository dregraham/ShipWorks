-----------------------------
--- Procedure DeleteShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteShipment]
GO

CREATE PROCEDURE dbo.DeleteShipment
(
   @ShipmentID int
)
WITH ENCRYPTION
AS
    DELETE UpsPackages
      FROM UpsPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID

    DELETE UpsShipments
      FROM UpsShipments u, Shipments s
      WHERE u.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID

    DELETE FedexPackages
      FROM FedexPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID

    DELETE FedexShipments
      FROM FedexShipments u, Shipments s
      WHERE u.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID
    
    DELETE DhlShipments
      FROM DhlShipments u, Shipments s
      WHERE u.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID
      
    DELETE UspsPackages
	  FROM UspsPackages p, Shipments s
	  WHERE p.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID

    DELETE UspsShipments
      FROM UspsShipments u, Shipments s
      WHERE u.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID
      
    DELETE ShipmentCommodities
      FROM ShipmentCommodities c, Shipments s
      WHERE c.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID
      
    DELETE FROM Shipments
      WHERE ShipmentID = @ShipmentID
GO