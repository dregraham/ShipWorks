-----------------------------
--- Procedure DeleteAllBatches
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteAllBatches]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[DeleteAllBatches]
GO

CREATE PROCEDURE DeleteAllBatches
(
   @StoreID int
)
AS
   DELETE FROM [MivaBatches]
      WHERE StoreID = @StoreID
GO

-----------------------------
--- Procedure UpdateBatch
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateBatch]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateBatch]
GO

CREATE PROCEDURE UpdateBatch
(
   @MivaBatchID int,
   @StoreID int,
   @Name nvarchar (75),
   @BatchDate datetime
)
AS
    -- If the batch already exists, just update it
    if exists (SELECT * FROM MivaBatches WHERE StoreID = @StoreID AND MivaBatchID = @MivaBatchID)
        begin
            UPDATE [MivaBatches]
            SET [Name] = @Name, 
                [BatchDate] = @BatchDate
            WHERE StoreID = @StoreID AND 
                  MivaBatchID = @MivaBatchID
        end
    else
        begin
            INSERT INTO [MivaBatches] ([MivaBatchID], [StoreID], [Name], [BatchDate])
            VALUES (@MivaBatchID, @StoreID, @Name, @BatchDate)
        end

GO