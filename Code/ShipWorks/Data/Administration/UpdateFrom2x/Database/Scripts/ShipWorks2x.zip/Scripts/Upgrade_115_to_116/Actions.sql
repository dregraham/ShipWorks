-----------------------------
--- TABLE Actions
-----------------------------
CREATE TABLE Actions 
(
	[ActionID] [int] IDENTITY (1, 1) NOT NULL ,
	[StoreID] [int] NOT NULL,
	[ActionName] [nvarchar] (50) NOT NULL,
	[TriggerType] smallint NOT NULL,
	[TriggerSettings] [text] NOT NULL,
	[TasksXml] [text] NOT NULL,
	[Enabled] bit NOT NULL,
	CONSTRAINT [PK_Actions] PRIMARY KEY  CLUSTERED ([ActionID]),
	CONSTRAINT [FK_Actions_Stores] FOREIGN KEY ([StoreID]) REFERENCES [Stores] ([StoreID]),
	CONSTRAINT [IX_ActionsName] UNIQUE NONCLUSTERED ([StoreID], [ActionName])
)
GO

DECLARE settingsCursor CURSOR
  FOR SELECT  
    ClientID,
    StoreID, 
    DownloadNewPlaySound, 
    DownloadNewPlaySoundFile, 
    DownloadNewSendEmail, 
    DownloadNewSendEmailTemplate,
    DownloadNewPrint,
    DownloadNewPrintTemplate,
    DownloadErrorPlaySound,
    DownloadErrorPlaySoundFile 
  FROM ClientStoreSettings
  FOR UPDATE
  
OPEN settingsCursor

DECLARE @ClientID int
DECLARE @StoreID int
DECLARE @DownloadNewPlaySound bit
DECLARE @DownloadNewPlaySoundFile nvarchar(350)
DECLARE @DownloadNewSendEmail bit
DECLARE @DownloadNewSendEmailTemplate nvarchar(50)
DECLARE @DownloadNewPrint bit
DECLARE @DownloadNewPrintTemplate nvarchar(50)
DECLARE @DownloadErrorPlaySound bit
DECLARE @DownloadErrorPlaySoundFile nvarchar(350)

FETCH NEXT FROM settingsCursor INTO 
    @ClientID,
    @StoreID, 
    @DownloadNewPlaySound, 
    @DownloadNewPlaySoundFile, 
    @DownloadNewSendEmail, 
    @DownloadNewSendEmailTemplate,
    @DownloadNewPrint,
    @DownloadNewPrintTemplate,
    @DownloadErrorPlaySound,
    @DownloadErrorPlaySoundFile

WHILE @@FETCH_STATUS = 0
BEGIN

    -- Play sound on successsful download
    if (@DownloadNewPlaySound = 1)
    begin

	if (not exists(select * from actions where storeid = @storeid and ActionName = 'Play sound after new orders downloaded'))
    
	        insert into Actions (StoreID, ActionName, TriggerType, TriggerSettings, TasksXml, Enabled)
	                    VALUES  (@StoreID, 'Play sound after new orders downloaded', 2, '<Trigger><NewOrders>True</NewOrders><DownloadResult>-1</DownloadResult></Trigger>', '<Tasks><Task type="PlaySoundTask"><SoundFile>' + @DownloadNewPlaySoundFile + '</SoundFile></Task></Tasks>', 1)
        
    end

    -- send email on successsful download
    if (@DownloadNewSendEmail = 1)
    begin
    
	if (not exists(select * from actions where storeid = @storeid and ActionName = 'Send email when new order downloaded'))

	        insert into Actions (StoreID, ActionName, TriggerType, TriggerSettings, TasksXml, Enabled)
	                    VALUES  (@StoreID, 'Send email when new order downloaded', 0, '<Trigger><Filter /></Trigger>', '<Tasks><Task type="EmailTask"><Template>' + @DownloadNewSendEmailTemplate + '</Template></Task></Tasks>', 1)
                                    
    end

    -- print on successsful download
    if (@DownloadNewPrint = 1)
    begin
    
	if (not exists(select * from actions where storeid = @storeid and ActionName = 'Print when new order downloaded'))

	        insert into Actions (StoreID, ActionName, TriggerType, TriggerSettings, TasksXml, Enabled)
	                    VALUES  (@StoreID, 'Print when new order downloaded', 0, '<Trigger><Filter /></Trigger>', '<Tasks><Task type="PrintTask"><Template>' + @DownloadNewPrintTemplate + '</Template><Copies>1</Copies></Task></Tasks>', 1)
        
    end

    -- play error sound
    if (@DownloadErrorPlaySound = 1)
    BEGIN
    
	if (not exists(select * from actions where storeid = @storeid and ActionName = 'Play sound after download error'))

	        insert into Actions (StoreID, ActionName, TriggerType, TriggerSettings, TasksXml, Enabled)
	                    VALUES  (@StoreID, 'Play sound after download error', 2, '<Trigger><NewOrders>False</NewOrders><DownloadResult>2</DownloadResult></Trigger>', '<Tasks><Task type="PlaySoundTask"><SoundFile>' + @DownloadErrorPlaySoundFile + '</SoundFile></Task></Tasks>', 1)
        
    end

    FETCH NEXT FROM settingsCursor INTO 
        @ClientID,
        @StoreID, 
        @DownloadNewPlaySound, 
        @DownloadNewPlaySoundFile, 
        @DownloadNewSendEmail, 
        @DownloadNewSendEmailTemplate,
        @DownloadNewPrint,
        @DownloadNewPrintTemplate,
        @DownloadErrorPlaySound,
        @DownloadErrorPlaySoundFile

END

CLOSE settingsCursor
DEALLOCATE settingsCursor

GO


----------------------------
--- PROCEDURE AddAction
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddAction]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddAction]
GO

CREATE PROCEDURE AddAction
(
   @StoreID int,
   @ActionName nvarchar(50),
   @TriggerType smallint,
   @TriggerSettings text,
   @TasksXml text,
   @Enabled bit
)
AS
   INSERT INTO Actions 
   (
      StoreID,
      ActionName,
      TriggerType,
      TriggerSettings,
      TasksXml,
      Enabled
   )
   VALUES 
   (
      @StoreID,
      @ActionName,
      @TriggerType,
      @TriggerSettings,
      @TasksXml,
      @Enabled
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT ActionID
     FROM Actions
     WHERE ActionID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateAction
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateAction]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateAction]
GO

CREATE PROCEDURE UpdateAction
(
   @ActionID int,
   @StoreID int,
   @ActionName nvarchar(50),
   @TriggerSettings text,
   @TriggerType smallint,
   @TasksXml text,
   @Enabled bit
)
AS
   UPDATE Actions
      SET StoreID = @StoreID,
          ActionName = @ActionName,
          TriggerType = @TriggerType,
          TriggerSettings = @TriggerSettings,
          TasksXml = @TasksXml,
          Enabled = @Enabled
      WHERE ActionID = @ActionID
      
   if (@@ROWCOUNT != 1)
      return 0

   return 1
GO

-----------------------------
--- Procedure DeleteAction
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteAction]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteAction]
GO

CREATE PROCEDURE DeleteAction
(
   @ActionID int
)
AS
    DELETE FROM Actions
    WHERE ActionID = @ActionID
GO

----------------------------
--- PROCEDURE GetAllActions
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllActions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllActions]
GO

CREATE PROCEDURE GetAllActions 
(
   @StoreID int
)
AS
   SELECT *
   FROM Actions
   WHERE StoreID = @StoreID
GO
