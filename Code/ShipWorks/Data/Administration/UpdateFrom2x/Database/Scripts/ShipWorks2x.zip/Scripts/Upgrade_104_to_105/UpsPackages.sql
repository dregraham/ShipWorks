-----------------------------
--- Procedure GetUpsPackageRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsPackageRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUpsPackageRange]
GO

CREATE PROCEDURE GetUpsPackageRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT p.*
     FROM UpsPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO