----------------------------
--- PROCEDURE EnsureTableChangesExists
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnsureTableChangesExists]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[EnsureTableChangesExists]
GO

CREATE PROCEDURE EnsureTableChangesExists
AS
    if not exists (select * from tempdb..sysobjects where id = object_id(N'tempdb..##TableChanges'))
    begin
    
        CREATE TABLE ##TableChanges 
        (
	        [TableName] varchar (50) NOT NULL ,
	        [StoreID] int NOT NULL ,
	        [ClientID] int NOT NULL ,
	        [LastDbts] int NOT NULL ,
	        CONSTRAINT [PK_TableChanges] PRIMARY KEY CLUSTERED (TableName, StoreID, ClientID) 
        )
        
        INSERT INTO ##TableChanges 
           SELECT 'Orders', StoreID, ClientID, @@DBTS 
           FROM Stores, Clients
        
        INSERT INTO ##TableChanges 
           SELECT 'OrderItems', StoreID, ClientID, @@DBTS 
           FROM Stores, Clients

        INSERT INTO ##TableChanges 
           SELECT 'Shipments', StoreID, ClientID, @@DBTS 
           FROM Stores, Clients
           
        INSERT INTO ##TableChanges 
           SELECT 'Customers', StoreID, ClientID, @@DBTS 
           FROM Stores, Clients
    end
GO

----------------------------
--- PROCEDURE GetTableLastDbts
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetTableLastDbts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetTableLastDbts]
GO

CREATE PROCEDURE GetTableLastDbts
(
   @TableName varchar (50),
   @StoreID int,
   @AllClients bit
)
AS

    EXEC EnsureTableChangesExists
    
    DECLARE @LastDbts int
    DECLARE @ClientID int
    
    SELECT @ClientID = CAST(context_info AS int)
       FROM master.dbo.sysprocesses
       WHERE spid = @@spid

    SELECT @LastDbts = MAX(LastDbts)
       FROM ##TableChanges
       WHERE TableName = @TableName AND 
             StoreID = @StoreID AND 
             (@AllClients = 1 OR ClientID != @ClientID)
       
    if (@LastDbts IS NULL)
       SELECT 0 AS LastDbts
    else
       SELECT @LastDbts AS LastDbts
GO
