-----------------------------
--- TABLE DhlPreferences
-----------------------------
CREATE TABLE dbo.DhlPreferences
(
	ClientID int NOT NULL,
	StoreID int NOT NULL,
	DefaultShipperID int NOT NULL,
	DefaultDomesticService int NOT NULL,
	DefaultPackage int NOT NULL,
	ReferenceText nvarchar(25) NOT NULL,
	Description nvarchar(50) NOT NULL,
	Length int NOT NULL,
	Width int NOT NULL,
	Height int NOT NULL,
	EmailNotify bit NOT NULL,
	EmailNotifyMessage nvarchar(255) NOT NULL,
	HoldForPickup bit NOT NULL,
	HazardousMaterials bit NOT NULL,
	LeaveAtDoor bit NOT NULL,
	ReturnService bit NOT NULL,
	CODCode int NOT NULL,
	CODValue money NOT NULL,
	InsuranceCode int NOT NULL,
	BlankRecipientPhone nvarchar(25) NOT NULL,
	DefaultTemplate nvarchar(50) NOT NULL,
	CommercialInvoiceCopies int NOT NULL,
	CommercialInvoiceTemplate nvarchar(50),
	CONSTRAINT [PK_DhlPreferences] PRIMARY KEY CLUSTERED ([ClientID], [StoreID]),
	CONSTRAINT [FK_DhlPreferences_Clients] FOREIGN KEY ([ClientID]) REFERENCES [Clients]([ClientID]),
	CONSTRAINT [FK_DhlPreferences_Stores] FOREIGN KEY ([StoreID]) REFERENCES [Stores]([StoreID])
)
GO

----------------------------
--- PROCEDURE GetDhlPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetDhlPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetDhlPreferences]
GO

CREATE PROCEDURE dbo.GetDhlPreferences
(
	@StoreID int,
	@ClientID int
)
WITH ENCRYPTION
AS 
	-- See if there are any prefs for this store\client
	IF (0 = (SELECT COUNT(*)
				FROM DhlPreferences
				WHERE StoreID = @StoreID AND ClientID = @ClientID))
	BEGIN
		-- There are not.  See if there are any for the store to use as a starting point	
		INSERT INTO DhlPreferences
		(
			ClientID,
			StoreID,
			DefaultShipperID,
			DefaultDomesticService,
			DefaultPackage,
			ReferenceText,
			Description,
			Length,
			Width,
			Height,
			EmailNotify,
			EmailNotifyMessage,
			HoldForPickup,
			HazardousMaterials,
			LeaveAtDoor,
			ReturnService,
			CODCode,
			CODValue,
			InsuranceCode,
			BlankRecipientPhone,
			DefaultTemplate,
			CommercialInvoiceCopies,
			CommercialInvoiceTemplate
		)
		SELECT TOP 1
			@ClientID,
			StoreID,
			DefaultShipperID,
			DefaultDomesticService,
			DefaultPackage,
			ReferenceText,
			Description,
			Length,
			Width,
			Height,
			EmailNotify,
			EmailNotifyMessage,
			HoldForPickup,
			HazardousMaterials,
			LeaveAtDoor,
			ReturnService,
			CODCode,
			CODValue,
			InsuranceCode,
			BlankRecipientPhone,
			DefaultTemplate,
			CommercialInvoiceCopies,
			CommercialInvoiceTemplate
		FROM DhlPreferences WHERE StoreID = @StoreID
	END
	
	SELECT * 
		FROM DhlPreferences
		WHERE StoreID = @StoreID AND ClientID = @ClientID
GO

----------------------------
--- PROCEDURE AddDhlPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDhlPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddDhlPreferences]
GO

CREATE PROCEDURE dbo.AddDhlPreferences
(
	@ClientID int,
	@StoreID int,
	@DefaultShipperID int,
	@DefaultDomesticService int,
	@DefaultPackage int,
	@ReferenceText nvarchar(25),
	@Description nvarchar(50),
	@Length int,
	@Width int,
	@Height int,
	@EmailNotify bit,
	@EmailNotifyMessage nvarchar(255),
	@HoldForPickup bit,
	@HazardousMaterials bit,
	@LeaveAtDoor bit,
	@ReturnService bit,
	@CODCode int,
	@CODValue money, 
	@InsuranceCode int,
	@BlankRecipientPhone nvarchar(25),
	@DefaultTemplate nvarchar(50),
	@CommercialInvoiceCopies int,
	@CommercialInvoiceTemplate nvarchar(50)
)
WITH ENCRYPTION
AS 
	INSERT INTO DhlPreferences
	(
		ClientID,
		StoreID,
		DefaultShipperID,
		DefaultDomesticService,
		DefaultPackage,
		ReferenceText,
		Description,
		Length,
		Width,
		Height,
		EmailNotify,
		EmailNotifyMessage,
		HoldForPickup,
		HazardousMaterials,
		LeaveAtDoor,
		ReturnService,
		CODCode,
		CODValue,
		InsuranceCode,
		BlankRecipientPhone,
		DefaultTemplate,
		CommercialInvoiceCopies,
		CommercialInvoiceTemplate
	)
	VALUES
	(
		@ClientID,
		@StoreID,
		@DefaultShipperID,
		@DefaultDomesticService,
		@DefaultPackage,
		@ReferenceText,
		@Description,
		@Length,
		@Width,
		@Height,
		@EmailNotify,
		@EmailNotifyMessage,
		@HoldForPickup,
		@HazardousMaterials,
		@LeaveAtDoor,
		@ReturnService,
		@CODCode,
		@CODValue,
		@InsuranceCode,
		@BlankRecipientPhone,
		@DefaultTemplate,
		@CommercialInvoiceCopies,
		@CommercialInvoiceTemplate
	)
	
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT StoreID, ClientID
		FROM DhlPreferences
		WHERE StoreID = @StoreID AND ClientID = @ClientID
		
	RETURN 1
GO

----------------------------
--- PROCEDURE UpdateDhlPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateDhlPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateDhlPreferences]
GO

CREATE PROCEDURE dbo.UpdateDhlPreferences
(
	@ClientID int,
	@StoreID int,
	@DefaultShipperID int,
	@DefaultDomesticService int,
	@DefaultPackage int,
	@ReferenceText nvarchar(25),
	@Description nvarchar(50),
	@Length int,
	@Width int,
	@Height int,
	@EmailNotify bit,
	@EmailNotifyMessage nvarchar(255),
	@HoldForPickup bit,
	@HazardousMaterials bit,
	@LeaveAtDoor bit,
	@ReturnService bit,
	@CODCode int,
	@CODValue money, 
	@InsuranceCode int,
	@BlankRecipientPhone nvarchar(25),
	@DefaultTemplate nvarchar(50),
	@CommercialInvoiceCopies int,
	@CommercialInvoiceTemplate nvarchar(50)
)
WITH ENCRYPTION 
AS
	UPDATE DhlPreferences
	SET 
		ClientID = @ClientID,
		StoreID = @StoreID,
		DefaultShipperID = @DefaultShipperID,
		DefaultDomesticService = @DefaultDomesticService,
		DefaultPackage = @DefaultPackage,
		ReferenceText = @ReferenceText,
		Description = @Description,
		Length = @Length,
		Width = @Width,
		Height = @Height,
		EmailNotify = @EmailNotify,
		EmailNotifyMessage = @EmailNotifyMessage,
		HoldForPickup = @HoldForPickup,
		HazardousMaterials = @HazardousMaterials,
		LeaveAtDoor = @LeaveAtDoor,
		ReturnService = @ReturnService,
		CODCode = @CODCode,
		CODValue = @CODValue,
		InsuranceCode = @InsuranceCode,
		BlankRecipientPhone = @BlankRecipientPhone,
		DefaultTemplate = @DefaultTemplate,
		CommercialInvoiceCopies = @CommercialInvoiceCopies,
		CommercialInvoiceTemplate = @CommercialInvoiceTemplate
	WHERE StoreID = @StoreID AND ClientID = @ClientID
	
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT StoreID, ClientID
	FROM DhlPreferences
	WHERE ClientID = @ClientID AND StoreID = @StoreID
	
	RETURN 1
GO
		

	