-----------------------------
--- Procedure AddPaymentDetail
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddPaymentDetail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddPaymentDetail]
GO

CREATE PROCEDURE AddPaymentDetail
(
	@OrderID int,
	@Type nvarchar (50) ,
	@Label nvarchar (100) ,
	@Value nvarchar (100)
)
AS
    INSERT INTO [PaymentDetails]
    (
        [OrderID], 
        [Type], 
        [Label],
        [Value]
    )
    VALUES
    (
        @OrderID, 
        @Type, 
        @Label,
        @Value
    )
    
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT PaymentDetailID
     FROM PaymentDetails
     WHERE PaymentDetailID = SCOPE_IDENTITY()

   return 1
GO

-----------------------------
--- Procedure UpdatePaymentDetail
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdatePaymentDetail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdatePaymentDetail]
GO

CREATE PROCEDURE UpdatePaymentDetail
(
    @PaymentDetailID int,
	@OrderID int,
	@Type nvarchar (50) ,
	@Label nvarchar (100) ,
	@Value nvarchar (100)
)
AS
    UPDATE [PaymentDetails]
    SET [OrderID] = @OrderID,
        [Type] = @Type, 
        [Label] = @Label,
        [Value] = @Value
    WHERE [PaymentDetailID] = @PaymentDetailID
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

   SELECT PaymentDetailID
     FROM PaymentDetails
     WHERE PaymentDetailID = @PaymentDetailID

    return 1
GO