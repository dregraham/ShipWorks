-----------------------------
--- Procedure GetShipmentsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetShipmentsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetShipmentsRange]
GO

CREATE PROCEDURE GetShipmentsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT s.*
   FROM Shipments s, Orders o
   WHERE s.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
         o.OrderID > @MinOrderID
GO
