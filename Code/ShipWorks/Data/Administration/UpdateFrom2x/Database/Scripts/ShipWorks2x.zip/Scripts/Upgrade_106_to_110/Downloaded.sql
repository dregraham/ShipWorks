EXECUTE sp_rename N'MivaDownloaded', N'Downloaded', 'OBJECT'
GO

----------------------------
--- PROCEDURE DeleteDownloaded
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteDownloaded]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteDownloaded]
GO

CREATE PROCEDURE DeleteDownloaded
(
   @StoreID int
)
AS
   DELETE FROM [Downloaded]
   WHERE [StoreID] = @StoreID
GO

----------------------------
--- PROCEDURE AddDownloaded
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDownloaded]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [AddDownloaded]
GO

CREATE PROCEDURE AddDownloaded
(
    @StoreID int,
    @OrderNumber int
)
AS
    INSERT INTO [Downloaded]
    (
        [StoreID], 
        [OrderNumber]
    )
    VALUES
    (
        @StoreID, 
        @OrderNumber
    )
GO

----------------------------
--- PROCEDURE IsDownloaded
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IsDownloaded]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [IsDownloaded]
GO

CREATE PROCEDURE IsDownloaded
(
    @StoreID int,
    @OrderNumber int
)
AS
    SELECT Count(*)
    FROM Downloaded
    WHERE StoreID = @StoreID AND OrderNumber = @OrderNumber
GO