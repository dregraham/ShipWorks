-----------------------------
--- TRIGGER TG_Orders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Orders]'))
   drop trigger [TG_Orders]
GO

CREATE TRIGGER TG_Orders ON Orders FOR UPDATE
AS
    if ( (SELECT COUNT(*) FROM inserted) = 0)
       return;

    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID FROM inserted
    
    EXEC SetTableLastDbts 'Orders', @StoreID, @@DBTS
    
    IF UPDATE(CustomerID)
    begin
        -- If the customerID is updated, we just need to touch the customer of each order
        -- so that SW knows the customer calculated columns need looked at.
        UPDATE Customers
          SET ShipFirstName = ShipFirstName
          WHERE CustomerID in (SELECT CustomerID FROM inserted)
          
        -- Update all the old customers too
        UPDATE Customers
          SET ShipFirstName = ShipFirstName
          WHERE CustomerID in (SELECT CustomerID FROM deleted)
    end
    
GO

-----------------------------
--- Procedure DeleteOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteOrder]
GO

CREATE PROCEDURE DeleteOrder
(
    @OrderID int
)
AS
   DELETE OrderItemAttributes
     FROM OrderItemAttributes a, OrderItems i
     WHERE a.OrderItemID = i.OrderItemID AND i.OrderID = @OrderID
     
   DELETE FROM OrderItems
     WHERE OrderID = @OrderID
     
   DELETE FROM OrderCharges
     WHERE OrderID = @OrderID
     
   DELETE FROM PaymentDetails
     WHERE OrderID = @OrderID
     
   DELETE FROM MivaSebenzaMsgs
     WHERE OrderID = @OrderID
     
    DELETE UpsPackages
      FROM UpsPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE UpsShipments
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE FROM Shipments
     WHERE OrderID = @OrderID

   DELETE FROM [Orders]
     WHERE OrderID = @OrderID
GO
