-----------------------------
--- TABLE EndiciaScanForms
-----------------------------
CREATE TABLE dbo.EndiciaScanForms
(
	EndiciaScanFormID int IDENTITY (1, 1) NOT NULL,
	[RowVersion] timestamp NOT NULL,
	EndiciaShipperID int NOT NULL,
	ShipmentCount int NOT NULL,
	SubmissionDate datetime NOT NULL,
	SubmissionID nvarchar(30) NOT NULL,
	LabelPath nvarchar(350) NOT NULL,
	CONSTRAINT PK_EndiciaScanForms PRIMARY KEY CLUSTERED ( EndiciaScanFormID )
)
GO

----------------------------
--- PROCEDURE AddEndiciaScanForm
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddEndiciaScanForm]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddEndiciaScanForm]
GO

CREATE PROCEDURE dbo.AddEndiciaScanForm
(
	@EndiciaShipperID int,
	@ShipmentCount int,
	@SubmissionDate datetime,
	@SubmissionID nvarchar(30),
	@LabelPath nvarchar(350)
)
WITH ENCRYPTION
AS
	INSERT INTO EndiciaScanForms
	(
		EndiciaShipperID,
		ShipmentCount,
		SubmissionDate,
		SubmissionID,
		LabelPath
	)
	VALUES
	(
		@EndiciaShipperID,
		@ShipmentCount,
		@SubmissionDate,
		@SubmissionID,
		@LabelPath
	)
	
	if (@@ROWCOUNT != 1)
		return 0
		
	SET NOCOUNT ON
	
	SELECT EndiciaScanFormID, [RowVersion]
		FROM EndiciaScanForms
		WHERE EndiciaScanFormID = SCOPE_IDENTITY()
		
	RETURN 1
GO
		
----------------------------
--- PROCEDURE UpdateEndiciaScanForm
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateEndiciaScanForm]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateEndiciaScanForm]
GO

CREATE PROCEDURE dbo.UpdateEndiciaScanForm
(
	@EndiciaScanFormID int,
	@RowVersion timestamp,
	@EndiciaShipperID int,
	@ShipmentCount int,
	@SubmissionDate datetime,
	@SubmissionID nvarchar(30),
	@LabelPath nvarchar(350)
)
WITH ENCRYPTION
AS 
	UPDATE EndiciaScanForms
		SET
			EndiciaShipperID = @EndiciaShipperID,
			ShipmentCount = @ShipmentCount,
			SubmissionDate = @SubmissionDate,
			SubmissionID = @SubmissionID,
			LabelPath = @LabelPath
		WHERE EndiciaScanFormID = @EndiciaScanFormID AND [RowVersion] = @RowVersion
		
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT EndiciaScanFormID, [RowVersion]
		FROM EndiciaScanForms
		WHERE EndiciaScanFormID = @EndiciaScanFormID
	RETURN 1
GO

-----------------------------
--- Procedure DeleteEndiciaScanForm
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteEndiciaScanForm]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteEndiciaScanForm]
GO

CREATE PROCEDURE dbo.DeleteEndiciaScanForm
(
	@EndiciaScanFormID int
)
WITH ENCRYPTION
AS
	DELETE FROM EndiciaScanForms
	WHERE EndiciaScanFormID = @EndiciaScanFormID
GO


----------------------------
--- PROCEDURE GetAllEndiciaScanForms
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllEndiciaScanForms]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllEndiciaScanForms]
GO

CREATE PROCEDURE dbo.GetAllEndiciaScanForms 
WITH ENCRYPTION
AS
   SELECT *
   FROM EndiciaScanForms
GO