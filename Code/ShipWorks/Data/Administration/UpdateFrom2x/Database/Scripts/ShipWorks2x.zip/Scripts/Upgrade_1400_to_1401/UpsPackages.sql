-----------------------------
--- Procedure GetOrderUpsPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUpsPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUpsPackages]
GO

CREATE PROCEDURE dbo.GetOrderUpsPackages
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
   FROM UpsPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUpsPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUpsPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUpsPackages]
GO

CREATE PROCEDURE dbo.GetCustomerUpsPackages
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT p.*
   FROM UpsPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetUpsPackageRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsPackageRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUpsPackageRange]
GO

CREATE PROCEDURE dbo.GetUpsPackageRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
     FROM UpsPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure DeleteUpsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteUpsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteUpsPackage]
GO

CREATE PROCEDURE dbo.DeleteUpsPackage
(
    @UpsPackageID int
)
WITH ENCRYPTION
AS
   DELETE FROM UpsPackages
     WHERE UpsPackageID = @UpsPackageID
GO

-----------------------------
--- Procedure AddUpsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUpsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUpsPackage]
GO

CREATE PROCEDURE dbo.AddUpsPackage
(
    @ShipmentID int,
    @PackagingTypeCode nvarchar (10),
    @Length int,
    @Width int,
    @Height int,
    @Weight float,
    @AdditionalHandling bit,
    @DeliveryConfirmation bit,
    @DeliveryConfirmationType nvarchar (15),
    @Insurance bit,
    @InsuredValue money,
    @COD bit,
    @CODFundsCode nvarchar (10),
    @CODAmount money,
    @TrackingNumber nvarchar (50),
    @LabelImageFull nvarchar (350) ,
    @LabelImageLabel nvarchar (350) ,
    @LabelImageEpl nvarchar (350) ,
    @LabelWarsawPath nvarchar (350) ,
    @LabelHtmlPath nvarchar (350)
)
WITH ENCRYPTION
AS
    INSERT INTO UpsPackages
    (
        ShipmentID,
        PackagingTypeCode,
        Length,
        Width,
        Height,
        Weight,
        AdditionalHandling,
        DeliveryConfirmation,
        DeliveryConfirmationType,
        Insurance,
        InsuredValue,
        COD,
        CODFundsCode,
        CODAmount,
        TrackingNumber,
        LabelImageFull,
        LabelImageLabel,
        LabelImageEpl,
        LabelWarsawPath,
        LabelHtmlPath
    )
    VALUES
    (
        @ShipmentID,
        @PackagingTypeCode,
        @Length,
        @Width,
        @Height,
        @Weight,
        @AdditionalHandling,
        @DeliveryConfirmation,
        @DeliveryConfirmationType,
        @Insurance,
        @InsuredValue,
        @COD,
        @CODFundsCode,
        @CODAmount,
        @TrackingNumber,
        @LabelImageFull,
        @LabelImageLabel,
        @LabelImageEpl,
        @LabelWarsawPath,
        @LabelHtmlPath
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT UpsPackageID, [RowVersion]
      FROM UpsPackages
      WHERE UpsPackageID = SCOPE_IDENTITY()

    return 1
GO

-----------------------------
--- Procedure UpdateUpsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUpsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUpsPackage]
GO

CREATE PROCEDURE dbo.UpdateUpsPackage
(
    @UpsPackageID int,
    @RowVersion timestamp,
    @ShipmentID int,
    @PackagingTypeCode nvarchar (10),
    @Length int,
    @Width int,
    @Height int,
    @Weight float,
    @AdditionalHandling bit,
    @DeliveryConfirmation bit,
    @DeliveryConfirmationType nvarchar (15),
    @Insurance bit,
    @InsuredValue money,
    @COD bit,
    @CODFundsCode nvarchar (10),
    @CODAmount money,
    @TrackingNumber nvarchar (50),
    @LabelImageFull nvarchar (350) ,
    @LabelImageLabel nvarchar (350) ,
    @LabelImageEpl nvarchar (350) ,
    @LabelWarsawPath nvarchar (350) ,
    @LabelHtmlPath nvarchar (350)
)
WITH ENCRYPTION
AS
    UPDATE UpsPackages
    SET ShipmentID = @ShipmentID,
        PackagingTypeCode = @PackagingTypeCode,
        Length = @Length,
        Width = @Width,
        Height = @Height,
        Weight = @Weight,
        AdditionalHandling = @AdditionalHandling,
        DeliveryConfirmation = @DeliveryConfirmation,
        DeliveryConfirmationType = @DeliveryConfirmationType,
        Insurance = @Insurance,
        InsuredValue = @InsuredValue,
        COD = @COD,
        CODFundsCode = @CODFundsCode,
        CODAmount = @CODAmount,
        TrackingNumber = @TrackingNumber,
        LabelImageFull = @LabelImageFull,
        LabelImageLabel = @LabelImageLabel,
        LabelImageEpl = @LabelImageEpl,
        LabelWarsawPath = @LabelWarsawPath,
        LabelHtmlPath = @LabelHtmlPath
    WHERE UpsPackageID = @UpsPackageID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT UpsPackageID, [RowVersion]
      FROM UpsPackages
      WHERE UpsPackageID = @UpsPackageID

    return 1
GO

 
