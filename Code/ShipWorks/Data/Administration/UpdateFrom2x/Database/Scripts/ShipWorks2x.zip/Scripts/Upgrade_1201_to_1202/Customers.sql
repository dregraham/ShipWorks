-----------------------------
--- Procedure GetChangedCustomers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedCustomers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedCustomers]
GO

CREATE PROCEDURE dbo.GetChangedCustomers
(
   @LastDBTS rowversion,
   @StoreID int,
   @MaxCustomerID int
)
AS
   SELECT   
        CustomerID,
        [RowVersion],  
        StoreID, 
        ShipEmail,
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1,
        ShipAddress2,
        ShipAddress3,
        ShipCity,
        ShipStateProvinceCode,
        ShipPostalCode,
        ShipCountryCode,
        ShipPhone,
        ShipFax,
        BillEmail,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1,
        BillAddress2,
        BillAddress3,
        BillCity,
        BillStateProvinceCode,
        BillPostalCode,
        BillCountryCode,
        BillPhone, 
        BillFax,
        Notes, 
        eBayBuyerID,
        MarketWorksBuyerNumber,
        osCommerceCustomerID,
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = c.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = c.CustomerID), 0.00) AS TotalAmount
      FROM Customers c
      WHERE (c.RowVersion > @LastDBTS AND c.StoreID = @StoreID) AND
            (@MaxCustomerID < 0 OR c.CustomerID <= @MaxCustomerID)

GO