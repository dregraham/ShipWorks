-----------------------------
--- TABLE YahooInventory
-----------------------------
CREATE TABLE dbo.YahooInventory 
(
	YahooInventoryID int IDENTITY (1, 1) NOT NULL ,
	StoreID int NOT NULL,
	itemID varchar(255) NOT NULL,
	weight float NOT NULL,
	CONSTRAINT [PK_YahooInventory] PRIMARY KEY  CLUSTERED (YahooInventoryID),
	CONSTRAINT [FK_YahooInventory_Stores] FOREIGN KEY ([StoreID]) REFERENCES [Stores] ([StoreID])
)
GO

CREATE UNIQUE NONCLUSTERED INDEX IX_YahooInventory_Item ON dbo.YahooInventory
	(
	itemID,
	StoreID
	) 
