----------------------------
--- PROCEDURE GetEndiciaPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetEndiciaPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetEndiciaPreferences]
GO

CREATE PROCEDURE dbo.GetEndiciaPreferences
(
    @StoreID int,
    @ClientID int
)
WITH ENCRYPTION
AS
   -- See if there are any prefs for this store\client
   if (0 = (SELECT COUNT(*)
                FROM EndiciaPreferences
                WHERE StoreID = @StoreID AND ClientID = @ClientID) )
   begin
   
      -- There are not.  See if there are any for the store to use as a starting point
        INSERT INTO EndiciaPreferences 
        (
            ClientID,
            StoreID,
		    SetService,
		    SetConfirmation,
		    SetWeight,
		    SetDate,
		    SetInsurance,
		    DefaultDomesticService,
		    DefaultInternationalService,
		    DefaultConfirmation,
		    DefaultDateAdvance,
		    DefaultInsuranceType,
		    DefaultLayouts,
		    DefaultStealthMode,
		    DefaultOversize,
		    DefaultCustomsForm,
		    DefaultCustomsDescription,
		    DefaultCustomsContentType,
		    RubberStamp1,
		    RubberStamp2,
		    RubberStamp3,
		    RubberStamp4,
		    TestMode,
		    CloseOnComplete,
		    AutoPrintCustoms,
		    UnattendedPrinting
		)
		SELECT TOP 1
            @ClientID,
            StoreID,
		    SetService,
		    SetConfirmation,
		    SetWeight,
		    SetDate,
		    SetInsurance,
		    DefaultDomesticService,
		    DefaultInternationalService,
		    DefaultConfirmation,
		    DefaultDateAdvance,
		    DefaultInsuranceType,
		    DefaultLayouts,
		    DefaultStealthMode,
		    DefaultOversize,
		    DefaultCustomsForm,
		    DefaultCustomsDescription,
		    DefaultCustomsContentType,
		    RubberStamp1,
		    RubberStamp2,
		    RubberStamp3,
		    RubberStamp4,
		    TestMode,
		    CloseOnComplete,
		    AutoPrintCustoms,
		    UnattendedPrinting
		FROM EndiciaPreferences WHERE StoreID = @StoreID
	end
	
    SELECT *
        FROM EndiciaPreferences
        WHERE StoreID = @StoreID AND ClientID = @ClientID
                
GO

----------------------------
--- PROCEDURE AddEndiciaPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddEndiciaPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddEndiciaPreferences]
GO

CREATE PROCEDURE dbo.AddEndiciaPreferences
(
    @ClientID int ,
    @StoreID int ,
    @SetService bit,
    @SetConfirmation bit,
    @SetWeight bit,
    @SetDate bit,
    @SetInsurance bit,
    @DefaultDomesticService int,
    @DefaultInternationalService int,
    @DefaultConfirmation int,
    @DefaultDateAdvance int,
    @DefaultInsuranceType int,
    @DefaultLayouts ntext,
    @DefaultStealthMode bit,
    @DefaultOversize bit,
    @DefaultCustomsForm int,
    @DefaultCustomsDescription varchar (200),
    @DefaultCustomsContentType int,
    @RubberStamp1 varchar(200),
    @RubberStamp2 varchar(200),
    @RubberStamp3 varchar(200),
    @RubberStamp4 varchar(200),
    @TestMode bit,
    @CloseOnComplete bit,
    @AutoPrintCustoms bit,
    @UnattendedPrinting bit
)
WITH ENCRYPTION
AS
   INSERT INTO EndiciaPreferences
   (
        ClientID,
        StoreID,
	    SetService,
	    SetConfirmation,
	    SetWeight,
	    SetDate,
	    SetInsurance,
	    DefaultDomesticService,
	    DefaultInternationalService,
	    DefaultConfirmation,
	    DefaultDateAdvance,
	    DefaultInsuranceType,
	    DefaultLayouts,
	    DefaultStealthMode,
	    DefaultOversize,
	    DefaultCustomsForm,
	    DefaultCustomsDescription,
	    DefaultCustomsContentType,
	    RubberStamp1,
	    RubberStamp2,
	    RubberStamp3,
	    RubberStamp4,
	    TestMode,
	    CloseOnComplete,
	    AutoPrintCustoms,
	    UnattendedPrinting
   )
   VALUES
   (
        @ClientID,
        @StoreID,
		@SetService,
		@SetConfirmation,
		@SetWeight,
		@SetDate,
		@SetInsurance,
		@DefaultDomesticService,
		@DefaultInternationalService,
		@DefaultConfirmation,
		@DefaultDateAdvance,
		@DefaultInsuranceType,
		@DefaultLayouts,
		@DefaultStealthMode,
		@DefaultOversize,
		@DefaultCustomsForm,
		@DefaultCustomsDescription,
		@DefaultCustomsContentType,
		@RubberStamp1,
		@RubberStamp2,
		@RubberStamp3,
		@RubberStamp4,
		@TestMode,
		@CloseOnComplete,
		@AutoPrintCustoms,
		@UnattendedPrinting
   )
   
    if (@@ROWCOUNT != 1)
        return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
     FROM EndiciaPreferences
     WHERE StoreID = @StoreID AND ClientID = @ClientID

   return 1
GO

----------------------------
--- PROCEDURE UpdateEndiciaPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateEndiciaPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateEndiciaPreferences]
GO

CREATE PROCEDURE dbo.UpdateEndiciaPreferences
(
    @ClientID int ,
    @StoreID int ,
    @SetService bit,
    @SetConfirmation bit,
    @SetWeight bit,
    @SetDate bit,
    @SetInsurance bit,
    @DefaultDomesticService int,
    @DefaultInternationalService int,
    @DefaultConfirmation int,
    @DefaultDateAdvance int,
    @DefaultInsuranceType int,
    @DefaultLayouts ntext,
    @DefaultStealthMode bit,
    @DefaultOversize bit,
    @DefaultCustomsForm int,
    @DefaultCustomsDescription varchar (200),
    @DefaultCustomsContentType int,
    @RubberStamp1 varchar(200),
    @RubberStamp2 varchar(200),
    @RubberStamp3 varchar(200),
    @RubberStamp4 varchar(200),
    @TestMode bit,
    @CloseOnComplete bit,
    @AutoPrintCustoms bit,
    @UnattendedPrinting bit
)
WITH ENCRYPTION
AS
   UPDATE EndiciaPreferences
   SET  ClientID = @ClientID,
        StoreID = @StoreID,
	    SetService = @SetService,
	    SetConfirmation = @SetConfirmation,
	    SetWeight = @SetWeight,
	    SetDate = @SetDate,
	    SetInsurance = @SetInsurance,
	    DefaultDomesticService = @DefaultDomesticService,
	    DefaultInternationalService = @DefaultInternationalService,
	    DefaultConfirmation = @DefaultConfirmation,
	    DefaultDateAdvance = @DefaultDateAdvance,
	    DefaultInsuranceType = @DefaultInsuranceType,
	    DefaultLayouts = @DefaultLayouts,
	    DefaultStealthMode = @DefaultStealthMode,
	    DefaultOversize = @DefaultOversize,
	    DefaultCustomsForm = @DefaultCustomsForm,
	    DefaultCustomsDescription = @DefaultCustomsDescription,
	    DefaultCustomsContentType = @DefaultCustomsContentType,
	    RubberStamp1 = @RubberStamp1,
	    RubberStamp2 = @RubberStamp2,
	    RubberStamp3 = @RubberStamp3,
	    RubberStamp4 = @RubberStamp4,
	    TestMode = @TestMode,
	    CloseOnComplete = @CloseOnComplete,
	    AutoPrintCustoms = @AutoPrintCustoms,
	    UnattendedPrinting = @UnattendedPrinting
   WHERE StoreID = @StoreID AND ClientID = @ClientID
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
   FROM EndiciaPreferences
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO