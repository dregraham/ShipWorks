-----------------------------
--- Procedure DeleteOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteOrder]
GO

CREATE PROCEDURE dbo.DeleteOrder
(
    @OrderID int
)
WITH ENCRYPTION
AS
   DELETE OrderItemAttributes
     FROM OrderItemAttributes a, OrderItems i
     WHERE a.OrderItemID = i.OrderItemID AND i.OrderID = @OrderID
     
   DELETE FROM OrderItems
     WHERE OrderID = @OrderID
     
   DELETE FROM OrderCharges
     WHERE OrderID = @OrderID
     
   DELETE FROM PaymentDetails
     WHERE OrderID = @OrderID
     
   DELETE FROM MivaSebenzaMsgs
     WHERE OrderID = @OrderID
     
   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE UpsPackages
      FROM UpsPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID

   DELETE UpsShipments
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
          
   DELETE FedexPackages
      FROM FedexPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE FedexShipments
     FROM FedexShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE DhlShipments
     FROM DhlShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID   

    DELETE ShipmentCommodities
      FROM ShipmentCommodities c, Shipments s
      WHERE c.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE FROM Shipments
     WHERE OrderID = @OrderID

   DELETE FROM [Orders]
     WHERE OrderID = @OrderID
GO