-----------------------------
--- Procedure GetChangedShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedShipments]
GO

CREATE PROCEDURE GetChangedShipments
(
   @LastDBTS rowversion,
   @MaxOrderID int,
   @StoreID int
)
AS

   SELECT s.*
      FROM Orders o, Shipments s
      WHERE (s.RowVersion > @LastDBTS AND o.StoreID = @StoreID AND o.OrderID = s.OrderID) AND
            (o.OrderID <= @MaxOrderID OR @MaxOrderID < 0)

GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_Shipments]'))
    drop trigger [dbo].[TG_Shipments]
GO

-- Create trigger to track changes to shipments
CREATE TRIGGER TG_Shipments ON Shipments FOR UPDATE
AS
    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = o.StoreID 
        FROM inserted s, Orders o
        WHERE s.OrderID = o.OrderID
       
    EXEC SetTableLastDbts 'Shipments', @StoreID, @@DBTS
GO