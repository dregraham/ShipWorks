-----------------------------
--- Procedure GetOrderFedexPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderFedexPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderFedexPackages]
GO

CREATE PROCEDURE dbo.GetOrderFedexPackages
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
   FROM FedexPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerFedexPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerFedexPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerFedexPackages]
GO

CREATE PROCEDURE dbo.GetCustomerFedexPackages
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT p.*
   FROM FedexPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetFedexPackageRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetFedexPackageRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetFedexPackageRange]
GO

CREATE PROCEDURE dbo.GetFedexPackageRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
     FROM FedexPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure DeleteFedexPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteFedexPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteFedexPackage]
GO

CREATE PROCEDURE dbo.DeleteFedexPackage
(
    @FedexPackageID int
)
WITH ENCRYPTION
AS
   DELETE FROM FedexPackages
     WHERE FedexPackageID = @FedexPackageID
GO

-----------------------------
--- Procedure AddFedexPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFedexPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddFedexPackage]
GO

CREATE PROCEDURE dbo.AddFedexPackage
(
    @ShipmentID int,
    @Length int,
    @Width int,
    @Height int,
    @Weight float,
    @SkidPieces smallint,
    @DeclaredValue money,
    @TrackingNumber nvarchar (20),
    @LabelImagePath nvarchar (350)
)
WITH ENCRYPTION
AS
    INSERT INTO FedexPackages
    (
        ShipmentID,
        Length,
        Width,
        Height,
        Weight,
        SkidPieces,
        DeclaredValue,
        TrackingNumber,
        LabelImagePath
    )
    VALUES
    (
        @ShipmentID,
        @Length,
        @Width,
        @Height,
        @Weight,
        @SkidPieces,
        @DeclaredValue,
        @TrackingNumber,
        @LabelImagePath
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT FedexPackageID, [RowVersion]
      FROM FedexPackages
      WHERE FedexPackageID = SCOPE_IDENTITY()

    return 1
GO

-----------------------------
--- Procedure UpdateFedexPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFedexPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFedexPackage]
GO

CREATE PROCEDURE dbo.UpdateFedexPackage
(
    @FedexPackageID int,
    @RowVersion timestamp,
    @ShipmentID int,
    @Length int,
    @Width int,
    @Height int,
    @Weight float,
    @SkidPieces smallint,
    @DeclaredValue money,
    @TrackingNumber nvarchar (20),
    @LabelImagePath nvarchar (350)
)
WITH ENCRYPTION
AS
    UPDATE FedexPackages
    SET ShipmentID = @ShipmentID,
        Length = @Length,
        Width = @Width,
        Height = @Height,
        Weight = @Weight,
        SkidPieces = @SkidPieces,
        DeclaredValue = @DeclaredValue,
        TrackingNumber = @TrackingNumber,
        LabelImagePath = @LabelImagePath
    WHERE FedexPackageID = @FedexPackageID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT FedexPackageID, [RowVersion]
      FROM FedexPackages
      WHERE FedexPackageID = @FedexPackageID

    return 1
GO

 
