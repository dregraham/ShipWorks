-----------------------------
--- Procedure GetChangedItems
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedItems]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedItems]
GO

CREATE PROCEDURE GetChangedItems
(
   @LastDBTS rowversion,
   @MaxOrderID int,
   @StoreID int
)
AS

   SELECT i.*
      FROM Orders o, OrderItems i
      WHERE (i.RowVersion > @LastDBTS AND o.StoreID = @StoreID AND o.OrderID = i.OrderID) AND
            (o.OrderID <= @MaxOrderID OR @MaxOrderID < 0)

GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_OrderItems]'))
    drop trigger [dbo].[TG_OrderItems]
GO

-- Create trigger to track changes to orderitems
CREATE TRIGGER TG_OrderItems ON OrderItems FOR UPDATE
AS
    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = o.StoreID 
        FROM inserted i, Orders o
        WHERE i.OrderID = o.OrderID
       
    EXEC SetTableLastDbts 'OrderItems', @StoreID, @@DBTS
GO