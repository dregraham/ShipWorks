-----------------------------
--- Procedure GetPaymentDetailsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetPaymentDetailsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetPaymentDetailsRange]
GO

CREATE PROCEDURE dbo.GetPaymentDetailsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
   FROM PaymentDetails p, Orders o
   WHERE p.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
         o.OrderID > @MinOrderID
GO