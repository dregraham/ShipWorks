----------------------------
--- PROCEDURE AddLabelSheet
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddLabelSheet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddLabelSheet]
GO

CREATE PROCEDURE dbo.AddLabelSheet
(
    @Name nvarchar (50),
	@PaperSizeDescription nvarchar (100)  ,
	@PaperSizeHeight float ,
	@PaperSizeWidth float ,
	@MarginTop float ,
	@MarginLeft float ,
	@LabelHeight float ,
	@LabelWidth float ,
	@VerticalSpacing float ,
	@HorizontalSpacing float ,
	@Rows int ,
	@Columns int
)
WITH ENCRYPTION
AS
   INSERT INTO CustomLabelSheets 
   (
        [Name],
	    PaperSizeDescription,
	    PaperSizeHeight,
	    PaperSizeWidth,
	    MarginTop,
	    MarginLeft,
	    LabelHeight,
	    LabelWidth,
	    VerticalSpacing,
	    HorizontalSpacing,
	    [Rows],
	    Columns
   )
   VALUES 
   (
        @Name,
	    @PaperSizeDescription,
	    @PaperSizeHeight,
	    @PaperSizeWidth,
	    @MarginTop,
	    @MarginLeft,
	    @LabelHeight,
	    @LabelWidth,
	    @VerticalSpacing,
	    @HorizontalSpacing,
	    @Rows,
	    @Columns
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT SheetID
     FROM CustomLabelSheets
     WHERE SheetID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateLabelSheet
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateLabelSheet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateLabelSheet]
GO

CREATE PROCEDURE dbo.UpdateLabelSheet
(
    @SheetID int,
    @Name nvarchar (50),
    @PaperSizeDescription nvarchar (100)  ,
    @PaperSizeHeight float ,
    @PaperSizeWidth float ,
    @MarginTop float ,
    @MarginLeft float ,
    @LabelHeight float ,
    @LabelWidth float ,
    @VerticalSpacing float ,
    @HorizontalSpacing float ,
    @Rows int ,
    @Columns int
)
WITH ENCRYPTION
AS
   UPDATE CustomLabelSheets
      SET   [Name] = @Name,
            PaperSizeDescription = @PaperSizeDescription,
	        PaperSizeHeight = @PaperSizeHeight,
	        PaperSizeWidth = @PaperSizeWidth,
	        MarginTop = @MarginTop,
	        MarginLeft = @MarginLeft,
	        LabelHeight = @LabelHeight,
	        LabelWidth = @LabelWidth,
	        VerticalSpacing = @VerticalSpacing,
	        HorizontalSpacing = @HorizontalSpacing,
	        [Rows] = @Rows,
	        Columns = @Columns
      WHERE SheetID = @SheetID
      
   if (@@ROWCOUNT != 1)
      return 0

   return 1
GO

-----------------------------
--- Procedure DeleteLabelSheet
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteLabelSheet]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteLabelSheet]
GO

CREATE PROCEDURE dbo.DeleteLabelSheet
(
   @SheetID int
)
WITH ENCRYPTION
AS
    DELETE FROM CustomLabelSheets
    WHERE SheetID = @SheetID
GO

----------------------------
--- PROCEDURE GetAllLabelSheets
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllLabelSheets]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllLabelSheets]
GO

CREATE PROCEDURE GetAllLabelSheets 
WITH ENCRYPTION
AS
   SELECT *, 'Custom' AS BrandName
   FROM CustomLabelSheets
GO
