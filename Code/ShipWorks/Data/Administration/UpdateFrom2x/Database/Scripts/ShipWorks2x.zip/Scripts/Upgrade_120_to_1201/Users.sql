----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IsAdminUser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[IsAdminUser]
GO

CREATE PROCEDURE dbo.IsAdminUser
(
	@Username nvarchar (50),
	@Password varchar (32)
)
AS
    select count(*) as 'IsAdmin' from users where Username = @Username and Password = @Password and IsAdmin = 1 and Deleted = 0
    
    return 0
GO
