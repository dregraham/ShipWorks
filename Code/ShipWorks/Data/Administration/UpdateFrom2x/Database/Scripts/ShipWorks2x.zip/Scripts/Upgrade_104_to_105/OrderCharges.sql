-----------------------------
--- Procedure GetChargesRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChargesRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChargesRange]
GO

CREATE PROCEDURE GetChargesRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT c.*
   FROM OrderCharges c, Orders o
   WHERE c.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
         o.OrderID > @MinOrderID
GO
