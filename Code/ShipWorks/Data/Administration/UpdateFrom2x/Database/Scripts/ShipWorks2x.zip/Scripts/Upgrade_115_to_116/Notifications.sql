-----------------------------
--- TABLE Notifications
-----------------------------
CREATE TABLE Notifications
(
    NotificationID int IDENTITY (1, 1) NOT NULL ,
    ClientID int NOT NULL,
    StoreID int NOT NULL,
    Occurred datetime NOT NULL,
    Type smallint NOT NULL,
    Source nvarchar(512) NOT NULL,
    Context nvarchar(512) NOT NULL,
    Details ntext NOT NULL,
	CONSTRAINT [PK_Notifications] PRIMARY KEY CLUSTERED (NotificationID) ,
	CONSTRAINT [FK_Notifications_Clients] FOREIGN KEY ([ClientID]) REFERENCES [Clients] ([ClientID]),
	CONSTRAINT [FK_Notifications_Stores] FOREIGN KEY ([StoreID]) REFERENCES [Stores] ([StoreID])
)
GO

----------------------------
--- PROCEDURE GetNotifications
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetNotifications]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetNotifications]
GO

CREATE PROCEDURE GetNotifications
(
    @StoreID int,
    @ClientID int
)
AS
   SELECT *
     FROM Notifications
     WHERE StoreID = @StoreID AND ClientID = @ClientID
GO

----------------------------
--- PROCEDURE AddNotification
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddNotification]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddNotification]
GO

CREATE PROCEDURE AddNotification
(
    @ClientID int ,
    @StoreID int ,
    @Occurred datetime,
    @Type smallint,
    @Source nvarchar(512),
    @Context nvarchar(512),
    @Details ntext
)
AS
   INSERT INTO Notifications
   (
        ClientID,
        StoreID,
        Occurred,
        Type,
        Source,
        Context,
        Details
   )
   VALUES
   (
        @ClientID,
        @StoreID,
        @Occurred,
        @Type,
        @Source,
        @Context,
        @Details
   )
   
    if (@@ROWCOUNT != 1)
        return 0

   SET NOCOUNT ON

   SELECT NotificationID
     FROM Notifications
     WHERE NotificationID = SCOPE_IDENTITY()

   return 1
GO

-----------------------------
--- Procedure DeleteNotification
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteNotification]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteNotification]
GO

CREATE PROCEDURE DeleteNotification
(
   @NotificationID int
)
AS
    DELETE FROM Notifications
    WHERE NotificationID = @NotificationID
GO
