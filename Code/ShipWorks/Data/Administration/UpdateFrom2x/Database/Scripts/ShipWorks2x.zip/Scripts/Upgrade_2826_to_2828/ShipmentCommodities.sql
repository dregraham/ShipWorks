ALTER TABLE dbo.ShipmentCommodities DROP COLUMN ECCN
GO
ALTER TABLE dbo.ShipmentCommodities DROP COLUMN ScheduleBNumber
GO
ALTER TABLE dbo.ShipmentCommodities DROP COLUMN ExportInformationCode
GO
ALTER TABLE dbo.ShipmentCommodities DROP COLUMN ExportLicenseType
GO

-----------------------------
--- Procedure GetOrderShipmentCommodities
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentCommodities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentCommodities]
GO

CREATE PROCEDURE dbo.GetOrderShipmentCommodities
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT c.*
   FROM ShipmentCommodities c, Shipments s
   WHERE c.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerShipmentCommodities
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentCommodities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentCommodities]
GO

CREATE PROCEDURE dbo.GetCustomerShipmentCommodities
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT c.*
   FROM ShipmentCommodities c, Shipments s
   WHERE c.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderShipmentCommodityRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentCommodityRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentCommodityRange]
GO

CREATE PROCEDURE dbo.GetOrderShipmentCommodityRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT c.*
     FROM ShipmentCommodities c, Shipments s, Orders o
     WHERE c.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerShipmentCommodityRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentCommodityRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentCommodityRange]
GO

CREATE PROCEDURE dbo.GetCustomerShipmentCommodityRange
(
    @StoreID int,
    @MinCustomerID int
)
WITH ENCRYPTION
AS
   SELECT c.*
     FROM ShipmentCommodities c, Shipments s
     WHERE c.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure DeleteShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteShipmentCommodity]
GO

CREATE PROCEDURE dbo.DeleteShipmentCommodity
(
    @CommodityID int
)
WITH ENCRYPTION
AS
   DELETE FROM ShipmentCommodities
     WHERE CommodityID = @CommodityID
GO

-----------------------------
--- Procedure UpdateShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateShipmentCommodity]
GO

CREATE PROCEDURE dbo.UpdateShipmentCommodity
(
	@CommodityID int,
	@RowVersion timestamp,
	@ShipmentID int,
	@Description nvarchar (200),
	@Quantity float,
	@Weight float,
	@UnitValue money,
	@UnitOfMeasure int,
	@OriginCountry varchar (20),
	@HarmonizedCode varchar (14),
	@ExportLicenseNumber varchar (12),
	@ExportLicenseExpiration datetime
)
WITH ENCRYPTION
AS
    UPDATE [ShipmentCommodities]
    SET 	
		ShipmentID = @ShipmentID,
		Description = @Description,
		Quantity = @Quantity,
		Weight = @Weight,
		UnitValue = @UnitValue,
		UnitOfMeasure = @UnitOfMeasure,
		OriginCountry = @OriginCountry,
		HarmonizedCode = @HarmonizedCode,
		ExportLicenseNumber = @ExportLicenseNumber,
		ExportLicenseExpiration = @ExportLicenseExpiration
		
    WHERE CommodityID = @CommodityID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT CommodityID, [RowVersion]
    FROM ShipmentCommodities
    WHERE CommodityID = @CommodityID

    return 1
GO

-----------------------------
--- Procedure AddShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddShipmentCommodity]
GO

CREATE PROCEDURE dbo.AddShipmentCommodity
(
	@ShipmentID int,
	@Description nvarchar (200),
	@Quantity float,
	@Weight float,
	@UnitValue money,
	@UnitOfMeasure int,
	@OriginCountry varchar (20),
	@HarmonizedCode varchar (14),
	@ExportLicenseNumber varchar (12),
	@ExportLicenseExpiration datetime
)
WITH ENCRYPTION
AS
    
    INSERT INTO [ShipmentCommodities]
    (
		ShipmentID,
		Description,
		Quantity,
		Weight,
		UnitValue,
		UnitOfMeasure,
		OriginCountry,
		HarmonizedCode,
		ExportLicenseNumber,
		ExportLicenseExpiration
    )
    VALUES
    (
		@ShipmentID,
		@Description,
		@Quantity,
		@Weight,
		@UnitValue,
		@UnitOfMeasure,
		@OriginCountry,
		@HarmonizedCode,
		@ExportLicenseNumber,
		@ExportLicenseExpiration
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT CommodityID, [RowVersion]
    FROM ShipmentCommodities
    WHERE CommodityID = SCOPE_IDENTITY()

    return 1

GO