-----------------------------
--- TRIGGER TG_Customers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Customers]'))
   drop trigger dbo.[TG_Customers]
GO

-- Create trigger to track changes to customers, and insures email address uniqueness
CREATE TRIGGER dbo.TG_Customers ON Customers WITH ENCRYPTION FOR UPDATE, INSERT
AS      
    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID FROM inserted
    if (@StoreID is NULL)
       return;
        
    IF UPDATE(BillEmail)
    begin
    
        DECLARE @uniqueCount int
        DECLARE @totalCount int
        
        SELECT @uniqueCount = Count(DISTINCT BillEmail), @totalCount = Count(BillEmail)
        FROM Customers
        WHERE BillEmail != '' AND StoreID = @StoreID
                
        if (@uniqueCount != @totalCount)
        BEGIN
            RAISERROR ('Non-blank customer email addresses must be unique.', 16, 1)
            ROLLBACK TRANSACTION
            return
        END 
        
    end
    
    EXEC SetTableLastDbts 'Customers', @StoreID, @@DBTS
GO

-----------------------------
--- Procedure AddCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddCustomer]
GO

CREATE PROCEDURE dbo.AddCustomer
(
    @StoreID int,
    @ShipEmail nvarchar (50),
    @ShipFirstName nvarchar (30),
    @ShipLastName nvarchar (30),
    @ShipCompany nvarchar (30),
    @ShipAddress1 nvarchar (60),
    @ShipAddress2 nvarchar (60),
    @ShipAddress3 nvarchar (60),
    @ShipCity nvarchar (50),
    @ShipStateProvinceCode nvarchar (25),
    @ShipPostalCode nvarchar (10),
    @ShipCountryCode nvarchar (5),
    @ShipPhone nvarchar (25),
    @ShipFax nvarchar (25),
    @BillEmail nvarchar (50),
    @BillFirstName nvarchar (30),
    @BillLastName nvarchar (30),
    @BillCompany nvarchar (30),
    @BillAddress1 nvarchar (60),
    @BillAddress2 nvarchar (60),
    @BillAddress3 nvarchar (60),
    @BillCity nvarchar (50),
    @BillStateProvinceCode nvarchar (25),
    @BillPostalCode nvarchar (10),
    @BillCountryCode nvarchar (5),
    @BillPhone nvarchar (25),
    @BillFax nvarchar (25),
    @Notes ntext,
    @eBayBuyerID nvarchar (50),
    @MarketWorksBuyerNumber int,
    @osCommerceCustomerID int,
    @ProStoresCustomerNumber varchar(20)
)
WITH ENCRYPTION
AS
    -- Add each order as a customer
    INSERT INTO Customers 
    (
        StoreID, 
        ShipEmail,     
        ShipFirstName,     
        ShipLastName,     
        ShipCompany,     
        ShipAddress1,     
        ShipAddress2,     
        ShipAddress3,     
        ShipCity,     
        ShipStateProvinceCode,     
        ShipPostalCode,     
        ShipCountryCode,     
        ShipPhone,     
        ShipFax,     
        BillEmail,     
        BillFirstName,     
        BillLastName,     
        BillCompany,     
        BillAddress1,     
        BillAddress2,     
        BillAddress3,     
        BillCity,     
        BillStateProvinceCode,     
        BillPostalCode,     
        BillCountryCode,     
        BillPhone,     
        BillFax,     
        Notes, 
        eBayBuyerID,
        MarketWorksBuyerNumber,
        osCommerceCustomerID,
        ProStoresCustomerNumber
    )
    VALUES
    ( 
        @StoreID, 
        @ShipEmail,     
        @ShipFirstName,     
        @ShipLastName,     
        @ShipCompany,     
        @ShipAddress1,     
        @ShipAddress2,     
        @ShipAddress3,     
        @ShipCity,     
        @ShipStateProvinceCode,     
        @ShipPostalCode,     
        @ShipCountryCode,     
        @ShipPhone,     
        @ShipFax,     
        @BillEmail,     
        @BillFirstName,     
        @BillLastName,     
        @BillCompany,     
        @BillAddress1,     
        @BillAddress2,     
        @BillAddress3,     
        @BillCity,     
        @BillStateProvinceCode,     
        @BillPostalCode,     
        @BillCountryCode,     
        @BillPhone,     
        @BillFax,     
        @Notes, 
        @eBayBuyerID,
        @MarketWorksBuyerNumber,
        @osCommerceCustomerID,
        @ProStoresCustomerNumber
    )
    
    SELECT 
        CustomerID, 
        [RowVersion],         
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = Customers.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = Customers.CustomerID), 0.00) AS TotalAmount
    FROM Customers
    WHERE CustomerID = SCOPE_IDENTITY()

GO

-----------------------------
--- Procedure UpdateCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateCustomer]
GO

CREATE PROCEDURE dbo.UpdateCustomer
(
    @CustomerID int,
    @RowVersion timestamp,
    @StoreID int,
    @ShipEmail nvarchar (50),
    @ShipFirstName nvarchar (30),
    @ShipLastName nvarchar (30),
    @ShipCompany nvarchar (30),
    @ShipAddress1 nvarchar (60),
    @ShipAddress2 nvarchar (60),
    @ShipAddress3 nvarchar (60),
    @ShipCity nvarchar (50),
    @ShipStateProvinceCode nvarchar (25),
    @ShipPostalCode nvarchar (10),
    @ShipCountryCode nvarchar (5),
    @ShipPhone nvarchar (25),
    @ShipFax nvarchar (25),
    @BillEmail nvarchar (50),
    @BillFirstName nvarchar (30),
    @BillLastName nvarchar (30),
    @BillCompany nvarchar (30),
    @BillAddress1 nvarchar (60),
    @BillAddress2 nvarchar (60),
    @BillAddress3 nvarchar (60),
    @BillCity nvarchar (50),
    @BillStateProvinceCode nvarchar (25),
    @BillPostalCode nvarchar (10),
    @BillCountryCode nvarchar (5),
    @BillPhone nvarchar (25),
    @BillFax nvarchar (25),
    @Notes ntext,
    @eBayBuyerID nvarchar (50),
    @MarketWorksBuyerNumber int,
    @osCommerceCustomerID int,
    @ProStoresCustomerNumber varchar(20)
)
WITH ENCRYPTION
AS
    UPDATE Customers
    SET
        StoreID = @StoreID, 
        ShipEmail = @ShipEmail,     
        ShipFirstName = @ShipFirstName,
        ShipLastName = @ShipLastName,
        ShipCompany = @ShipCompany,
        ShipAddress1 = @ShipAddress1,
        ShipAddress2 = @ShipAddress2,
        ShipAddress3 = @ShipAddress3,
        ShipCity = @ShipCity,
        ShipStateProvinceCode = @ShipStateProvinceCode,
        ShipPostalCode = @ShipPostalCode,
        ShipCountryCode = @ShipCountryCode,
        ShipPhone = @ShipPhone,
        ShipFax = @ShipFax,
        BillEmail = @BillEmail,
        BillFirstName = @BillFirstName,
        BillLastName = @BillLastName,
        BillCompany = @BillCompany,
        BillAddress1 = @BillAddress1,
        BillAddress2 = @BillAddress2,
        BillAddress3 = @BillAddress3,
        BillCity = @BillCity,
        BillStateProvinceCode = @BillStateProvinceCode,
        BillPostalCode = @BillPostalCode,
        BillCountryCode = @BillCountryCode,
        BillPhone = @BillPhone,
        BillFax = @BillFax,
        Notes = @Notes, 
        eBayBuyerID = @eBayBuyerID,
        MarketWorksBuyerNumber = @MarketWorksBuyerNumber,
        osCommerceCustomerID = @osCommerceCustomerID,
        ProStoresCustomerNumber = @ProStoresCustomerNumber
    WHERE CustomerID = @CustomerID AND [RowVersion] = @RowVersion
    
    SELECT 
        CustomerID, 
        [RowVersion],         
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = Customers.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = Customers.CustomerID), 0.00) AS TotalAmount
    FROM Customers
    WHERE CustomerID = @CustomerID
    
GO
    
-----------------------------
--- Procedure DoesCustomerExist
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DoesCustomerExist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DoesCustomerExist]
GO

CREATE PROCEDURE dbo.DoesCustomerExist
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   if exists (SELECT * FROM [Customers] WHERE CustomerID = @CustomerID)
      SELECT 1
   else
      SELECT 0
GO

-----------------------------
--- Procedure GetLatestCustomers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLatestCustomers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetLatestCustomers]
GO

CREATE PROCEDURE dbo.GetLatestCustomers
(
    @StoreID int,
    @MinCustomerID int
)
WITH ENCRYPTION
AS
   SELECT   
        CustomerID,
        [RowVersion],  
        StoreID, 
        ShipEmail,
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1,
        ShipAddress2,
        ShipAddress3,
        ShipCity,
        ShipStateProvinceCode,
        ShipPostalCode,
        ShipCountryCode,
        ShipPhone,
        ShipFax,
        BillEmail,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1,
        BillAddress2,
        BillAddress3,
        BillCity,
        BillStateProvinceCode,
        BillPostalCode,
        BillCountryCode,
        BillPhone, 
        BillFax,
        Notes, 
        eBayBuyerID,
        MarketWorksBuyerNumber,
        osCommerceCustomerID,
        ProStoresCustomerNumber,
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = Customers.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = Customers.CustomerID), 0.00) AS TotalAmount
     FROM Customers
     WHERE 
       StoreID = @StoreID AND 
       CustomerID > @MinCustomerID
GO

-----------------------------
--- Procedure GetLatestCustomersCount
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLatestCustomersCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetLatestCustomersCount]
GO

CREATE PROCEDURE dbo.GetLatestCustomersCount
(
    @StoreID int,
    @MinCustomerID int
)
WITH ENCRYPTION
AS
   SELECT Count(*)
     FROM Customers
     WHERE 
       StoreID = @StoreID AND 
       CustomerID > @MinCustomerID
GO

-----------------------------
--- Procedure GetCustomerOrders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerOrders]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerOrders]
GO

CREATE PROCEDURE dbo.GetCustomerOrders
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM [Orders]
   WHERE CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetChangedCustomers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedCustomers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedCustomers]
GO

CREATE PROCEDURE dbo.GetChangedCustomers
(
   @LastDBTS rowversion,
   @StoreID int,
   @MaxCustomerID int
)
WITH ENCRYPTION
AS
   SELECT   
        CustomerID,
        [RowVersion],  
        StoreID, 
        ShipEmail,
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1,
        ShipAddress2,
        ShipAddress3,
        ShipCity,
        ShipStateProvinceCode,
        ShipPostalCode,
        ShipCountryCode,
        ShipPhone,
        ShipFax,
        BillEmail,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1,
        BillAddress2,
        BillAddress3,
        BillCity,
        BillStateProvinceCode,
        BillPostalCode,
        BillCountryCode,
        BillPhone, 
        BillFax,
        Notes, 
        eBayBuyerID,
        MarketWorksBuyerNumber,
        osCommerceCustomerID,
        ProStoresCustomerNumber,
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = c.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = c.CustomerID), 0.00) AS TotalAmount
      FROM Customers c
      WHERE (c.RowVersion > @LastDBTS AND c.StoreID = @StoreID) AND
            (@MaxCustomerID < 0 OR c.CustomerID <= @MaxCustomerID)

GO

-----------------------------
--- Procedure GetCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomer]
GO

CREATE PROCEDURE dbo.GetCustomer
(
   @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT   
        CustomerID,
        [RowVersion],  
        StoreID, 
        ShipEmail,
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1,
        ShipAddress2,
        ShipAddress3,
        ShipCity,
        ShipStateProvinceCode,
        ShipPostalCode,
        ShipCountryCode,
        ShipPhone,
        ShipFax,
        BillEmail,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1,
        BillAddress2,
        BillAddress3,
        BillCity,
        BillStateProvinceCode,
        BillPostalCode,
        BillCountryCode,
        BillPhone, 
        BillFax,
        Notes, 
        eBayBuyerID,
        MarketWorksBuyerNumber,
        osCommerceCustomerID,
        ProStoresCustomerNumber,
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = c.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = c.CustomerID), 0.00) AS TotalAmount
      FROM Customers c
      WHERE c.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure DeleteCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteCustomer]
GO

CREATE PROCEDURE dbo.DeleteCustomer
(
   @CustomerID int
)
WITH ENCRYPTION
AS
    DELETE UpsPackages
      FROM UpsPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID
     
   DELETE UpsShipments
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID
     
    DELETE FedexPackages
      FROM FedexPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID
     
   DELETE FedexShipments
     FROM FedexShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID

    DELETE ShipmentCommodities
      FROM ShipmentCommodities c, Shipments s
      WHERE c.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID

   DELETE FROM Shipments
     WHERE CustomerID = @CustomerID

    DELETE FROM Customers
       WHERE CustomerID = @CustomerID
GO
