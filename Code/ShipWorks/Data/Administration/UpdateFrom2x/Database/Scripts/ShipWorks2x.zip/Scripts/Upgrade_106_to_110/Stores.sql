CREATE TABLE dbo.Tmp_Stores
(
	StoreID int NOT NULL IDENTITY (1, 1),
	RowVersion timestamp NOT NULL,
	StoreType int NOT NULL,
	StoreName nvarchar(75) NOT NULL,
	CompanyName nvarchar(60) NOT NULL,
	CompanyAddress1 nvarchar(60) NOT NULL,
	CompanyAddress2 nvarchar(60) NOT NULL,
	CompanyAddress3 nvarchar(60) NOT NULL,
	CompanyCity nvarchar(50) NOT NULL,
	CompanyStateProvCode nvarchar(5) NOT NULL,
	CompanyPostalCode nvarchar(10) NOT NULL,
	CompanyCountryCode nvarchar(5) NOT NULL,
	CompanyUrl nvarchar(150) NOT NULL,
	CompanyFax nvarchar(50) NOT NULL,
	CompanyPhone nvarchar(50) NOT NULL,
	CompanyEmail nvarchar(50) NOT NULL,
	CompanyLogo nvarchar(300) NOT NULL,
	LastUpdateTime datetime NOT NULL,
	EmailDefaultAccountID int NOT NULL,
	EmailLogSaveMessage bit NOT NULL,
	EmailLogSaveMessageImages bit NOT NULL,
	OrderStatusStrings nvarchar(500) NOT NULL,
	ItemStatusStrings nvarchar(500) NOT NULL,
	OrderNumberPrefix nvarchar(10) NOT NULL,
	OrderNumberPostfix nvarchar(10) NOT NULL,
	MivaUsername nvarchar(50) NOT NULL,
	MivaPassword nvarchar(50) NOT NULL,
	MivaRememberPassword bit NOT NULL,
	MivaPassphrase nvarchar(50) NOT NULL,
	MivaSiteID nchar(8) NOT NULL,
	MivaModuleUrl nvarchar(300) NOT NULL,
	MivaStoreCode nvarchar(50) NOT NULL,
	MivaConnectSecure bit NOT NULL,
	MivaRemovedDeletedBatches bit NOT NULL,
	MivaSebenzaExtraMsg bit NOT NULL,
	MivaLiveManualOrderNumbers bit NOT NULL,
	eBayUserID nvarchar(50) NOT NULL,
	eBayToken text NOT NULL,
	eBayTokenExpire datetime NOT NULL,
	eBayDownloadItemDetails bit NOT NULL,
	YahooAccountName nvarchar (50) NOT NULL,
	YahooPassword nvarchar (50) NOT NULL,
	YahooRememberPassword bit NOT NULL,
	YahooPopServer nvarchar (150) NOT NULL 
)
GO

SET IDENTITY_INSERT dbo.Tmp_Stores ON
GO

IF EXISTS(SELECT * FROM dbo.Stores)
	 EXEC('INSERT INTO dbo.Tmp_Stores (StoreID, StoreType, StoreName, CompanyName, CompanyAddress1, CompanyAddress2, CompanyAddress3, CompanyCity, CompanyStateProvCode, CompanyPostalCode, CompanyCountryCode, CompanyUrl, CompanyFax, CompanyPhone, CompanyEmail, CompanyLogo, LastUpdateTime, EmailDefaultAccountID, EmailLogSaveMessage, EmailLogSaveMessageImages, OrderStatusStrings,     ItemStatusStrings,     OrderNumberPrefix, OrderNumberPostfix, MivaUsername, MivaPassword, MivaRememberPassword, MivaPassphrase, MivaSiteID, MivaModuleUrl, MivaStoreCode, MivaConnectSecure, MivaRemovedDeletedBatches, MivaSebenzaExtraMsg, MivaLiveManualOrderNumbers, eBayUserID, eBayToken, eBayTokenExpire, eBayDownloadItemDetails, YahooAccountName, YahooPassword,	YahooRememberPassword, YahooPopServer)
		                        SELECT StoreID, StoreType, StoreName, CompanyName, CompanyAddress1, CompanyAddress2, CompanyAddress3, CompanyCity, CompanyStateProvCode, CompanyPostalCode, CompanyCountryCode, CompanyUrl, CompanyFax, CompanyPhone, CompanyEmail, CompanyLogo, LastUpdateTime, EmailDefaultAccountID, EmailLogSaveMessage, EmailLogSaveMessageImages, OrderStatusStrings,     ItemStatusStrings,     "",                "-M",               MivaUsername, MivaPassword, MivaRememberPassword, MivaPassphrase, MivaSiteID, MivaModuleUrl, MivaStoreCode, MivaConnectSecure, MivaRemovedDeletedBatches, MivaSebenzaExtraMsg, 1,                          eBayUserID, eBayToken, eBayTokenExpire, eBayDownloadItemDetails, "",               "",            0,                     ""             
		   FROM dbo.Stores TABLOCKX')
GO

SET IDENTITY_INSERT dbo.Tmp_Stores OFF
GO

ALTER TABLE dbo.EmailAccounts
	DROP CONSTRAINT FK_EmailAccounts_Stores
GO

ALTER TABLE dbo.Downloaded
	DROP CONSTRAINT FK_MivaDownloaded_Stores
GO

ALTER TABLE dbo.DownloadLog
	DROP CONSTRAINT FK_DownloadLog_Stores
GO

ALTER TABLE dbo.UpsPreferences
	DROP CONSTRAINT FK_UpsPreferences_Stores
GO

ALTER TABLE dbo.MivaBatches
	DROP CONSTRAINT FK_MivaBatches_Stores
GO

ALTER TABLE dbo.EmailLog
	DROP CONSTRAINT FK_EmailLog_Stores
GO

ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Stores
GO

ALTER TABLE dbo.Orders
	DROP CONSTRAINT FK_Orders_Stores
GO

DROP TABLE dbo.Stores
GO

EXECUTE sp_rename N'dbo.Tmp_Stores', N'Stores', 'OBJECT'
GO

ALTER TABLE dbo.Stores ADD CONSTRAINT
	PK_Stores PRIMARY KEY CLUSTERED 
	(
	StoreID
	) ON [PRIMARY]

GO

ALTER TABLE dbo.Stores ADD CONSTRAINT
	UQ_Stores_StoreName UNIQUE NONCLUSTERED 
	(
	StoreName
	)

GO

ALTER TABLE dbo.Stores WITH NOCHECK ADD CONSTRAINT
	CK_ValidStoreType CHECK (([StoreType] = 0 or [StoreType] = 1 or [StoreType] = 2))
GO

ALTER TABLE dbo.Orders WITH NOCHECK ADD CONSTRAINT
	FK_Orders_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.ClientStoreSettings WITH NOCHECK ADD CONSTRAINT
	FK_ClientStoreSettings_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.EmailLog WITH NOCHECK ADD CONSTRAINT
	FK_EmailLog_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.MivaBatches WITH NOCHECK ADD CONSTRAINT
	FK_MivaBatches_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.UpsPreferences WITH NOCHECK ADD CONSTRAINT
	FK_UpsPreferences_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.DownloadLog WITH NOCHECK ADD CONSTRAINT
	FK_DownloadLog_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.Downloaded WITH NOCHECK ADD CONSTRAINT
	FK_Downloaded_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.EmailAccounts WITH NOCHECK ADD CONSTRAINT
	FK_EmailAccounts_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

----------------------------
--- PROCEDURE AddStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddStore]
GO

CREATE PROCEDURE AddStore
(
   @StoreType int,  
   @StoreName nvarchar(75),  
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @EmailDefaultAccountID int,  
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit,
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @MivaUsername nvarchar(50),  
   @MivaPassword nvarchar(50),  
   @MivaRememberPassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit, 
   @MivaLiveManualOrderNumbers bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @YahooAccountName nvarchar (50),
   @YahooPassword nvarchar (50),
   @YahooRememberPassword bit,
   @YahooPopServer nvarchar (150)
)
AS
   INSERT INTO [Stores]
   (
        [StoreType], 
        [StoreName], 
        [CompanyName], 
        [CompanyAddress1], 
        [CompanyAddress2], 
        [CompanyAddress3], 
        [CompanyCity], 
        [CompanyStateProvCode], 
        [CompanyPostalCode], 
        [CompanyCountryCode], 
        [CompanyUrl], 
        [CompanyFax], 
        [CompanyPhone], 
        [CompanyEmail], 
        [CompanyLogo],
        [LastUpdateTime], 
        [EmailDefaultAccountID], 
        [EmailLogSaveMessage],
        [EmailLogSaveMessageImages],
        [OrderStatusStrings], 
        [ItemStatusStrings], 
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [MivaUsername], 
        [MivaPassword], 
        [MivaRememberPassword], 
        [MivaPassphrase], 
        [MivaSiteID], 
        [MivaModuleUrl], 
        [MivaStoreCode], 
        [MivaConnectSecure], 
        [MivaRemovedDeletedBatches], 
        [MivaSebenzaExtraMsg], 
        [MivaLiveManualOrderNumbers],
        [eBayUserID], 
        [eBayToken], 
        [eBayTokenExpire],
        [eBayDownloadItemDetails],
        [YahooAccountName],
        [YahooPassword],
        [YahooRememberPassword],
        [YahooPopServer]
   )
   VALUES 
   (
        @StoreType, 
        @StoreName, 
        @CompanyName, 
        @CompanyAddress1,
        @CompanyAddress2, 
        @CompanyAddress3, 
        @CompanyCity, 
        @CompanyStateProvCode, 
        @CompanyPostalCode, 
        @CompanyCountryCode, 
        @CompanyUrl, 
        @CompanyFax, 
        @CompanyPhone, 
        @CompanyEmail, 
        @CompanyLogo,
        @LastUpdateTime, 
        @EmailDefaultAccountID, 
        @EmailLogSaveMessage,
        @EmailLogSaveMessageImages,
        @OrderStatusStrings,
        @ItemStatusStrings, 
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @MivaUsername, 
        @MivaPassword, 
        @MivaRememberPassword, 
        @MivaPassphrase, 
        @MivaSiteID, 
        @MivaModuleUrl, 
        @MivaStoreCode, 
        @MivaConnectSecure, 
        @MivaRemovedDeletedBatches, 
        @MivaSebenzaExtraMsg, 
        @MivaLiveManualOrderNumbers,
        @eBayUserID, 
        @eBayToken, 
        @eBayTokenExpire,
        @eBayDownloadItemDetails,
        @YahooAccountName,
        @YahooPassword,
        @YahooRememberPassword,
        @YahooPopServer
)
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, RowVersion
   FROM Stores
   WHERE StoreID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE SaveLastUpdateTime
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveLastUpdateTime]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveLastUpdateTime]
GO

CREATE PROCEDURE SaveLastUpdateTime
(
   @StoreID int,
   @LastUpdateTime datetime
)
AS
    UPDATE [Stores]
    SET [LastUpdateTime]=@LastUpdateTime
    WHERE [StoreID] = @StoreID

   SET NOCOUNT ON

   SELECT *
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE SaveEmailSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveEmailSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveEmailSettings]
GO

CREATE PROCEDURE SaveEmailSettings
(
   @StoreID int,
   @EmailDefaultAccountID int,
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit
)
AS
    UPDATE Stores
      SET EmailDefaultAccountID = @EmailDefaultAccountID,
          EmailLogSaveMessage = @EmailLogSaveMessage,
          EmailLogSaveMessageImages = @EmailLogSaveMessageImages
      WHERE StoreID = @StoreID

   SET NOCOUNT ON

   SELECT *
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO


----------------------------
--- PROCEDURE UpdateStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateStore]
GO

CREATE PROCEDURE UpdateStore
(
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @StoreType int,  
   @StoreName nvarchar(75),  
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @EmailDefaultAccountID int, 
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit, 
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @MivaUsername nvarchar(50),  
   @MivaPassword nvarchar(50),  
   @MivaRememberPassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit,  
   @MivaLiveManualOrderNumbers bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @YahooAccountName nvarchar (50),
   @YahooPassword nvarchar (50),
   @YahooRememberPassword bit,
   @YahooPopServer nvarchar (150)
)
AS
   UPDATE [Stores]
   SET [StoreType]=@StoreType, 
       [StoreName]=@StoreName, 
       [CompanyName]=@CompanyName, 
       [CompanyAddress1]=@CompanyAddress1, 
       [CompanyAddress2]=@CompanyAddress2, 
       [CompanyAddress3]=@CompanyAddress3, 
       [CompanyCity]=@CompanyCity, 
       [CompanyStateProvCode]=@CompanyStateProvCode, 
       [CompanyPostalCode]=@CompanyPostalCode, 
       [CompanyCountryCode]=@CompanyCountryCode, 
       [CompanyUrl]=@CompanyUrl, 
       [CompanyFax]=@CompanyFax, 
       [CompanyPhone]=@CompanyPhone, 
       [CompanyEmail]=@CompanyEmail, 
       [CompanyLogo]=@CompanyLogo,
       [LastUpdateTime]=@LastUpdateTime, 
       [EmailDefaultAccountID]=@EmailDefaultAccountID, 
       [EmailLogSaveMessage]=@EmailLogSaveMessage,
       [EmailLogSaveMessageImages]=@EmailLogSaveMessageImages,
       [OrderStatusStrings]=@OrderStatusStrings, 
       [ItemStatusStrings]=@ItemStatusStrings, 
       [OrderNumberPrefix]=@OrderNumberPrefix,
       [OrderNumberPostfix]=@OrderNumberPostfix,
       [MivaUsername]=@MivaUsername, 
       [MivaPassword]=@MivaPassword, 
       [MivaRememberPassword]=@MivaRememberPassword, 
       [MivaPassphrase]=@MivaPassphrase, 
       [MivaSiteID]=@MivaSiteID,
       [MivaModuleUrl]=@MivaModuleUrl, 
       [MivaStoreCode]=@MivaStoreCode, 
       [MivaConnectSecure]=@MivaConnectSecure, 
       [MivaRemovedDeletedBatches]=@MivaRemovedDeletedBatches, 
       [MivaSebenzaExtraMsg]=@MivaSebenzaExtraMsg, 
       [MivaLiveManualOrderNumbers]=@MivaLiveManualOrderNumbers,
       [eBayUserID]=@eBayUserID, 
       [eBayToken]=@eBayToken, 
       [eBayTokenExpire]=@eBayTokenExpire,
       [eBayDownloadItemDetails]=@eBayDownloadItemDetails,
       [YahooAccountName]=@YahooAccountName,
       [YahooPassword]=@YahooPassword,
       [YahooRememberPassword]=@YahooRememberPassword,
       [YahooPopServer]=@YahooPopServer
    WHERE [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO