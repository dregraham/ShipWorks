-----------------------------
--- Procedure GetOrderUspsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsShipments]
GO

CREATE PROCEDURE dbo.GetOrderUspsShipments
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT u.*
   FROM UspsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUspsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsShipments]
GO

CREATE PROCEDURE dbo.GetCustomerUspsShipments
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT u.*
   FROM UspsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsShipmentRange]
GO

CREATE PROCEDURE dbo.GetOrderUspsShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsShipmentRange]
GO

CREATE PROCEDURE dbo.GetCustomerUspsShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
WITH ENCRYPTION
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure UpdateUspsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUspsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUspsShipment]
GO

CREATE PROCEDURE dbo.UpdateUspsShipment
(
    @ShipmentID int,
    @RowVersion timestamp,
	@ServiceType int ,
	@ConfirmationType int ,
	@AddressService bit  ,
	@SendEmail bit ,
	@LabelImageFull nvarchar (350) ,
	@LabelImageLabel nvarchar (350),
	@LabelImageBarcode nvarchar (350) ,
    @Stealth bit ,
    @SpecifyLayout bit,
    @Layout nvarchar (350) ,
    @DeclaredValue money ,
    @InsuranceType int,
    @Oversize bit,
	@RubberStamp1 varchar (200) ,
	@RubberStamp2 varchar (200) ,
	@RubberStamp3 varchar (200) ,
	@RubberStamp4 varchar (200) ,
	@CustomsForm int ,
	@CustomsDescription nvarchar (200) ,
	@CustomsContentType int
)
WITH ENCRYPTION
AS
    UPDATE [UspsShipments]
    SET ServiceType = @ServiceType,
	    ConfirmationType = @ConfirmationType,
	    AddressService = @AddressService,
	    SendEmail = @SendEmail,
	    LabelImageFull = @LabelImageFull,
	    LabelImageLabel = @LabelImageLabel,
	    LabelImageBarcode = @LabelImageBarcode,
		Stealth = @Stealth,
		SpecifyLayout = @SpecifyLayout,
		Layout = @Layout,
		DeclaredValue = @DeclaredValue,
		InsuranceType = @InsuranceType,
		Oversize = @Oversize,
		RubberStamp1 = @RubberStamp1,
		RubberStamp2 = @RubberStamp2,
		RubberStamp3 = @RubberStamp3,
		RubberStamp4 = @RubberStamp4,
		CustomsForm = @CustomsForm,
		CustomsDescription = @CustomsDescription,
		CustomsContentType = @CustomsContentType
    WHERE ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM UspsShipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

-----------------------------
--- Procedure AddUspsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUspsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUspsShipment]
GO

CREATE PROCEDURE dbo.AddUspsShipment
(
    @ShipmentID int,
	@ServiceType int ,
	@ConfirmationType int ,
	@AddressService bit  ,
	@SendEmail bit ,
	@LabelImageFull nvarchar (350) ,
	@LabelImageLabel nvarchar (350),
	@LabelImageBarcode nvarchar (350) ,
    @Stealth bit ,
    @SpecifyLayout bit,
    @Layout nvarchar (350) ,
    @DeclaredValue money ,
    @InsuranceType int,
    @Oversize bit,
	@RubberStamp1 varchar (200) ,
	@RubberStamp2 varchar (200) ,
	@RubberStamp3 varchar (200) ,
	@RubberStamp4 varchar (200) ,
	@CustomsForm int ,
	@CustomsDescription nvarchar (200) ,
	@CustomsContentType int
)
WITH ENCRYPTION
AS
    if (exists(SELECT * FROM UspsShipments WHERE ShipmentID = @ShipmentID))
    begin
    
        select * from UspsShipments WHERE ShipmentID = @ShipmentID
        
    end
    else
    begin
    
        INSERT INTO [UspsShipments]
        (
            ShipmentID,
            ServiceType,
	        ConfirmationType,
	        AddressService,
	        SendEmail,
	        LabelImageFull,
	        LabelImageLabel,
	        LabelImageBarcode,
			Stealth,
			SpecifyLayout,
			Layout,
			DeclaredValue,
			InsuranceType,
			Oversize,
			RubberStamp1,
			RubberStamp2,
			RubberStamp3,
			RubberStamp4,
			CustomsForm,
			CustomsDescription,
			CustomsContentType
        )
        VALUES
        (
            @ShipmentID,
            @ServiceType,
	        @ConfirmationType,
	        @AddressService,
	        @SendEmail,
	        @LabelImageFull,
	        @LabelImageLabel,
	        @LabelImageBarcode,
			@Stealth,
			@SpecifyLayout,
			@Layout,
			@DeclaredValue,
			@InsuranceType,
			@Oversize,
			@RubberStamp1,
			@RubberStamp2,
			@RubberStamp3,
			@RubberStamp4,
			@CustomsForm,
			@CustomsDescription,
			@CustomsContentType
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ShipmentID, [RowVersion]
        FROM UspsShipments
        WHERE ShipmentID = @ShipmentID

        return 1
                
  end
    
GO
