-----------------------------
--- Procedure GetOrderItemCounts
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderItemCounts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderItemCounts]
GO

CREATE PROCEDURE dbo.GetOrderItemCounts
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT o.OrderID, count(*) as ItemCount
   FROM OrderItems i, Orders o
   WHERE i.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
         o.OrderID > @MinOrderID
   GROUP BY o.OrderID
GO
