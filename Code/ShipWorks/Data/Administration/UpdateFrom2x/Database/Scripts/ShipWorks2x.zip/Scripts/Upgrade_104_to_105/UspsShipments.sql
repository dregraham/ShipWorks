-----------------------------
--- Procedure GetUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUspsShipmentRange]
GO

CREATE PROCEDURE GetUspsShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO