if exists (select * from tempdb..sysobjects where id = object_id(N'tempdb..##ClientStatus'))
    drop table ##ClientStatus
    
----------------------------
--- PROCEDURE EnsureClientStatusExists
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnsureClientStatusExists]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[EnsureClientStatusExists]
GO

CREATE PROCEDURE dbo.EnsureClientStatusExists
WITH ENCRYPTION
AS
    if not exists (select * from tempdb..sysobjects where id = object_id(N'tempdb..##ClientStatus'))
    begin
    
        CREATE TABLE ##ClientStatus 
        (
	        [spid] int NOT NULL ,
	        [Refreshing] bit NOT NULL ,
	        [Downloading] bit NOT NULL ,
	        [Saving] bit NOT NULL ,
	        CONSTRAINT [PK_ClientStatus] PRIMARY KEY CLUSTERED (spid) 
        )
        
    end
    
    -- Remove any dropped processes
    DELETE ##ClientStatus
      WHERE spid NOT IN (SELECT spid FROM master.dbo.sysprocesses)
    
    -- See if our client exists
    if (0 = (SELECT COUNT(*) FROM ##ClientStatus WHERE spid = @@spid))
    begin
        INSERT INTO ##ClientStatus
        (
            spid,
            Refreshing,
            Downloading,
            Saving
        )
        VALUES
        (
            @@spid,
            0,
            0,
            0
        )
    end
GO

----------------------------
--- PROCEDURE DownloadStart
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DownloadStart]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DownloadStart]
GO

CREATE PROCEDURE dbo.DownloadStart
WITH ENCRYPTION
AS

    EXEC EnsureClientStatusExists
    
    DECLARE @Result int
    
    BEGIN TRAN
    
    -- See if no one else is downloading
    if (0 = (select count(*) from ##ClientStatus where Downloading = 1 and spid != @@spid))
    begin
    
        -- Mark that we are downloading
        UPDATE ##ClientStatus
          SET Downloading = 1
          WHERE spid = @@spid
        
        SET @Result = 1
        
    end
    else
    begin

       SET @Result = 0
       
    end
    
    COMMIT
    
    SELECT @Result as Result
GO

----------------------------
--- PROCEDURE DownloadStop
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DownloadStop]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DownloadStop]
GO

CREATE PROCEDURE dbo.DownloadStop
WITH ENCRYPTION
AS

    EXEC EnsureClientStatusExists
    
    -- Mark that we are no longer downloading
    UPDATE ##ClientStatus
        SET Downloading = 0
        WHERE spid = @@spid

GO

----------------------------
--- PROCEDURE RefreshingStart
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RefreshingStart]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RefreshingStart]
GO

CREATE PROCEDURE dbo.RefreshingStart
WITH ENCRYPTION
AS

    EXEC EnsureClientStatusExists
    
    DECLARE @Result int
    
    BEGIN TRAN
    
    -- See if anyone else is saving
    if (0 = (select count(*) from ##ClientStatus where Saving = 1 and spid != @@spid))
    begin
    
        -- Mark that we are downloading
        UPDATE ##ClientStatus
          SET Refreshing = 1
          WHERE spid = @@spid
        
        SET @Result = 1

    end
    else
    begin

       SET @Result = 0
       
    end
    
    COMMIT
    
    SELECT @Result as Result
GO

----------------------------
--- PROCEDURE RefreshingStop
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RefreshingStop]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RefreshingStop]
GO

CREATE PROCEDURE dbo.RefreshingStop
WITH ENCRYPTION
AS

    EXEC EnsureClientStatusExists
    
    -- Mark that we are no longer downloading
    UPDATE ##ClientStatus
        SET Refreshing = 0
        WHERE spid = @@spid

GO

----------------------------
--- PROCEDURE SavingStart
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SavingStart]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SavingStart]
GO

CREATE PROCEDURE dbo.SavingStart
WITH ENCRYPTION
AS

    EXEC EnsureClientStatusExists
    
    DECLARE @Result int
    
    BEGIN TRAN
    
    -- See if anyone else is refreshing
    if (0 = (select count(*) from ##ClientStatus where Refreshing = 1 and spid != @@spid))
    begin
    
        -- Mark that we are downloading
        UPDATE ##ClientStatus
          SET Saving = 1
          WHERE spid = @@spid
        
        SET @Result = 1
    
    end    
    else
    begin

       SET @Result = 0
       
    end
    
    COMMIT
    
    SELECT @Result as Result
GO

----------------------------
--- PROCEDURE SavingStop
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SavingStop]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SavingStop]
GO

CREATE PROCEDURE dbo.SavingStop
WITH ENCRYPTION
AS

    EXEC EnsureClientStatusExists
    
    -- Mark that we are no longer downloading
    UPDATE ##ClientStatus
        SET Saving = 0
        WHERE spid = @@spid

GO