ALTER TABLE dbo.DhlShipments DROP COLUMN EmployerIDType
GO
ALTER TABLE dbo.DhlShipments DROP COLUMN PartiesRelated
GO
ALTER TABLE dbo.DhlShipments DROP COLUMN ExportTransactionNumber
GO
ALTER TABLE dbo.DhlShipments DROP COLUMN SEDRequired
GO


ALTER TABLE dbo.DhlShipments ADD CommerceLicensed bit NOT NULL CONSTRAINT DF_DhlShipments_CommerceLicensed DEFAULT 0
GO
ALTER TABLE dbo.DhlShipments ADD DOSFlag bit NOT NULL CONSTRAINT DF_DhlShipments_DOSFlag DEFAULT 0
GO
ALTER TABLE dbo.DhlShipments ADD FilingType smallint NOT NULL CONSTRAINT DF_DhlShipments_FilingType DEFAULT 0
GO
ALTER TABLE dbo.DhlShipments ADD ITN nvarchar(15) NOT NULL CONSTRAINT DF_DhlShipments_ITN DEFAULT ''
GO
ALTER TABLE dbo.DhlShipments ADD FTSRCode nvarchar(15) NOT NULL CONSTRAINT DF_DhlShipments_FTSRCode DEFAULT ''
GO

ALTER TABLE dbo.DhlShipments DROP CONSTRAINT DF_DhlShipments_CommerceLicensed
GO
ALTER TABLE dbo.DhlShipments DROP CONSTRAINT DF_DhlShipments_DOSFlag
GO
ALTER TABLE dbo.DhlShipments DROP CONSTRAINT DF_DhlShipments_FilingType
GO
ALTER TABLE dbo.DhlShipments DROP CONSTRAINT DF_DhlShipments_ITN
GO
ALTER TABLE dbo.DhlShipments DROP CONSTRAINT DF_DhlShipments_FTSRCode
GO

-----------------------------
--- Procedure GetOrderDhlShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderDhlShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderDhlShipments]
GO

CREATE PROCEDURE dbo.GetOrderDhlShipments
(
	@OrderID int
)
WITH ENCRYPTION
AS
	SELECT u.*
	FROM DhlShipments u, Shipments s
	WHERE u.ShipmentID = s.ShipmentID AND
		s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerDhlShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerDhlShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerDhlShipments]
GO

CREATE PROCEDURE dbo.GetCustomerDhlShipments
(
	@CustomerID int
)
WITH ENCRYPTION
AS
	SELECT u.*
	FROM DhlShipments u, Shipments s
	WHERE u.ShipmentID = s.ShipmentID AND
		s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderDhlShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderDhlShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderDhlShipmentRange]
GO

CREATE PROCEDURE dbo.GetOrderDhlShipmentRange
(
	@StoreID int,
	@DateRangeMax datetime,
	@DateRangeMin datetime,
	@MinOrderID int
)
WITH ENCRYPTION
AS 
	SELECT u.*
		FROM DhlShipments u, Shipments s, Orders o
		WHERE u.ShipmentID = s.ShipmentID AND
			s.StoreID = @StoreID AND
			s.OrderID = o.OrderID AND
			o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
			o.OrderID > @MinOrderID
GO


-----------------------------
--- Procedure GetCustomerDhlShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerDhlShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerDhlShipmentRange]
GO

CREATE PROCEDURE dbo.GetCustomerDhlShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
WITH ENCRYPTION
AS
   SELECT u.*
     FROM DhlShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO


-----------------------------
--- Procedure UpdateDhlShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateDhlShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateDhlShipment]
GO

CREATE PROCEDURE dbo.UpdateDhlShipment
(
	@ShipmentID int,
	@RowVersion timestamp,
	@ServiceType smallint, 
	@HoldForPickup bit,
	@HazardousMaterial bit,
	@LeaveAtDoor bit,
	@ReturnService bit,
	@CodType	smallint,
	@CodAmount money, 
	@ProtectionType smallint,
	@DhlEmailRecipient bit,
	@DhlEmailOtherEnable bit,
	@DhlEmailOtherAddress nvarchar(35),
	@DhlEmailMessage nvarchar(255),
	@ShipToResidential bit,
	@ShipFromShipperID int,
	@ShipFromContactName nvarchar(30),
	@ShipFromContactCompany	nvarchar(30),
	@ShipFromAddress1 nvarchar(60),
	@ShipFromAddress2 nvarchar(60),
	@ShipFromCity nvarchar(50),
	@ShipFromStateProvinceCode nvarchar(5),
	@ShipFromPostalCode nvarchar(10),
	@ShipFromCountryCode nvarchar(5),
	@ShipFromContactEmail nvarchar(35),
	@ShipFromContactPhone nvarchar(25),
	@ShipFromContactFax nvarchar(25),
	@PackageType smallint,
	@Length int,
	@Width int,
	@Height int,
	@Weight float,
	@LabelImagePath nvarchar(350),
	@ReferenceText nvarchar(25),
	@Description nvarchar(50),
	@EmployerIDNumber nvarchar(9),
	@BillingCode smallint,
	@BillingAccountNumber nvarchar(11),
	@DutyPaymentCode smallint,
	@DutyPaymentAccountNumber nvarchar(11),
	@OverrideZ1 bit,
	@OverrideZ2 bit,
	@OverrideES bit,
	@OverrideRP bit,
	@Dutiable bit,
	@DeclaredValue money,
	@OverrideZ5 bit,
	@CommerceLicensed bit,
	@DOSFlag bit,
	@FilingType smallint,
	@ITN nvarchar(15),
	@FTSRCode nvarchar(15)
	)
WITH ENCRYPTION 
AS 
	UPDATE DhlShipments
	SET
		ServiceType = @ServiceType, 
		HoldForPickup = @HoldForPickup,
		HazardousMaterial = @HazardousMaterial,
		LeaveAtDoor = @LeaveAtDoor,
		ReturnService = @ReturnService,
		CodType	= @CodType,
		CodAmount = @CodAmount,
		ProtectionType = @ProtectionType,
		DhlEmailRecipient = @DhlEmailRecipient,
		DhlEmailOtherEnable = @DhlEmailOtherEnable,
		DhlEmailOtherAddress = @DhlEmailOtherAddress,
		DhlEmailMessage = @DhlEmailMessage,
		ShipToResidential = @ShipToResidential,
		ShipFromShipperID = @ShipFromShipperID,
		ShipFromContactName = @ShipFromContactName,
		ShipFromContactCompany	= @ShipFromContactCompany,
		ShipFromAddress1 = @ShipFromAddress1, 
		ShipFromAddress2 = @ShipFromAddress2,
		ShipFromCity = @ShipFromCity,
		ShipFromStateProvinceCode = @ShipFromStateProvinceCode,
		ShipFromPostalCode = @ShipFromPostalCode,
		ShipFromCountryCode = @ShipFromCountryCode,
		ShipFromContactEmail = @ShipFromContactEmail,
		ShipFromContactPhone = @ShipFromContactPhone,
		ShipFromContactFax = @ShipFromContactFax,
		PackageType = @PackageType,
		Length = @Length,
		Width = @Width,
		Height = @Height,
		Weight = @Weight,
		LabelImagePath = @LabelImagePath,
		ReferenceTExt = @ReferenceText,
		Description = @Description,
		EmployerIDNumber = @EmployerIDNumber,
		BillingCode = @BillingCode, 
		BillingAccountNumber = @BillingAccountNumber, 
		DutyPaymentCode = @DutyPaymentCode, 
		DutyPaymentAccountNumber = @DutyPaymentAccountNumber,
		OverrideZ1 = @OverrideZ1,
		OverrideZ2 = @OverrideZ2,
		OverrideES = @OverrideES,
		OverrideRP = @OverrideRP,
		Dutiable = @Dutiable,
		DeclaredValue = @DeclaredValue,
		OverrideZ5 = @OverrideZ5,
		CommerceLicensed = @CommerceLicensed,
		DOSFlag = @DOSFlag,
		FilingType = @FilingType,
		ITN = @ITN,
		FTSRCode = @FTSRCode
			
	WHERE
		ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
		
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT ShipmentID, [RowVersion]
	FROM DhlShipments
	WHERE ShipmentID = @ShipmentID
	
	RETURN 1
GO

-----------------------------
--- Procedure AddDhlShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDhlShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddDhlShipment]
GO

CREATE PROCEDURE dbo.AddDhlShipment
(
	@ShipmentID int,
	@ServiceType smallint, 
	@HoldForPickup bit,
	@HazardousMaterial bit,
	@LeaveAtDoor bit,
	@ReturnService bit,
	@CodType	smallint,
	@CodAmount money, 
	@ProtectionType smallint,
	@DhlEmailRecipient bit,
	@DhlEmailOtherEnable bit,
	@DhlEmailOtherAddress nvarchar(35),
	@DhlEmailMessage nvarchar(255),
	@ShipToResidential bit,
	@ShipFromShipperID int,
	@ShipFromContactName nvarchar(30),
	@ShipFromContactCompany	nvarchar(30),
	@ShipFromAddress1 nvarchar(60),
	@ShipFromAddress2 nvarchar(60),
	@ShipFromCity nvarchar(50),
	@ShipFromStateProvinceCode nvarchar(5),
	@ShipFromPostalCode nvarchar(10),
	@ShipFromCountryCode nvarchar(5),
	@ShipFromContactEmail nvarchar(35),
	@ShipFromContactPhone nvarchar(25),
	@ShipFromContactFax nvarchar(25),
	@PackageType smallint,
	@Length int,
	@Width int,
	@Height int,
	@Weight float,
	@LabelImagePath nvarchar(350),
	@ReferenceText nvarchar(25),
	@Description nvarchar(50),
	@EmployerIDNumber nvarchar(9),
	@BillingCode smallint,
	@BillingAccountNumber nvarchar(11),
	@DutyPaymentCode smallint,
	@DutyPaymentAccountNumber nvarchar(11),
	@OverrideZ1 bit,
	@OverrideZ2 bit,
	@OverrideES bit,
	@OverrideRP bit,
	@Dutiable bit,
	@DeclaredValue money,
	@OverrideZ5 bit,
	@CommerceLicensed bit,
	@DOSFlag bit,
	@FilingType smallint,
	@ITN nvarchar(15),
	@FTSRCode nvarchar(15)
)
WITH ENCRYPTION
AS 
	IF (EXISTS(SELECT * FROM DhlShipments WHERE ShipmentID = @ShipmentID))
	BEGIN
		SELECT * FROM DhlShipments WHERE ShipmentID = @ShipmentID
	END
	ELSE
	BEGIN
		INSERT INTO [DhlShipments]
		(
			ShipmentID,
			ServiceType, 
			HoldForPickup,
			HazardousMaterial,
			LeaveAtDoor,
			ReturnService,
			CodType,
			CodAmount, 
			ProtectionType,
			DhlEmailRecipient,
			DhlEmailOtherEnable,
			DhlEmailOtherAddress,
			DhlEmailMessage,
			ShipToResidential,
			ShipFromShipperID,
			ShipFromContactName,
			ShipFromContactCompany,
			ShipFromAddress1,
			ShipFromAddress2,
			ShipFromCity,
			ShipFromStateProvinceCode,
			ShipFromPostalCode,
			ShipFromCountryCode,
			ShipFromContactEmail,
			ShipFromContactPhone,
			ShipFromContactFax,
			PackageType,
			Length,
			Width,
			Height,
			Weight,
			LabelImagePath,
			ReferenceText,
			Description,
			EmployerIDNumber,
			BillingCode,
			BillingAccountNumber,
			DutyPaymentCode,
			DutyPaymentAccountNumber,
			OverrideZ1,
			OverrideZ2,
			OverrideES,
			OverrideRP,
			Dutiable,
			DeclaredValue,
			OverrideZ5,
			CommerceLicensed,
			DOSFlag,
			FilingType,
			ITN,
			FTSRCode
					)
		VALUES
		(
			@ShipmentID,
			@ServiceType, 
			@HoldForPickup,
			@HazardousMaterial,
			@LeaveAtDoor,
			@ReturnService,
			@CodType,
			@CodAmount, 
			@ProtectionType,
			@DhlEmailRecipient,
			@DhlEmailOtherEnable,
			@DhlEmailOtherAddress,
			@DhlEmailMessage,
			@ShipToResidential,
			@ShipFromShipperID,
			@ShipFromContactName,
			@ShipFromContactCompany,
			@ShipFromAddress1,
			@ShipFromAddress2,
			@ShipFromCity,
			@ShipFromStateProvinceCode,
			@ShipFromPostalCode,
			@ShipFromCountryCode,
			@ShipFromContactEmail,
			@ShipFromContactPhone,
			@ShipFromContactFax,
			@PackageType,
			@Length,
			@Width,
			@Height,
			@Weight,
			@LabelImagePath,
			@ReferenceText,
			@Description,
			@EmployerIDNumber,
			@BillingCode,
			@BillingAccountNumber,
			@DutyPaymentCode,
			@DutyPaymentAccountNumber,
			@OverrideZ1,
			@OverrideZ2,
			@OverrideES,
			@OverrideRP,
			@Dutiable,
			@DeclaredValue,
			@OverrideZ5,
			@CommerceLicensed,
			@DOSFlag,
			@FilingType,
			@ITN,
			@FTSRCode
					)
		
		IF (@@ROWCOUNT != 1)
			RETURN 0
			
		SET NOCOUNT ON
		
		SELECT ShipmentID, RowVersion
		FROM DhlShipments
		WHERE ShipmentID = @ShipmentID
		
		RETURN 1
	END
GO

