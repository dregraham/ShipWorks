ALTER TABLE dbo.Stores
	DROP CONSTRAINT CK_ValidStoreType
GO

ALTER TABLE dbo.Stores ADD CONSTRAINT
	CK_ValidStoreType CHECK (([StoreType]>=(0) AND [StoreType]<=(8)))
GO

ALTER TABLE dbo.Stores ADD
	InfopiaToken varchar(128) NOT NULL CONSTRAINT DF_Stores_InfopiaToken DEFAULT ''
GO
ALTER TABLE dbo.Stores DROP CONSTRAINT DF_Stores_InfopiaToken
GO


----------------------------
--- PROCEDURE GetAllStores
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllStores]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure dbo.[GetAllStores]
GO

CREATE PROCEDURE dbo.GetAllStores
WITH ENCRYPTION
AS
   SELECT *
   FROM [Stores]
GO

----------------------------
--- PROCEDURE DeleteStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure dbo.[DeleteStore]
GO

CREATE PROCEDURE dbo.DeleteStore
(
   @StoreID int
)
WITH ENCRYPTION
AS
   DELETE OrderItemAttributes
     FROM OrderItemAttributes a, OrderItems i, Orders o
     WHERE a.OrderItemID = i.OrderItemID AND i.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE OrderItems
     FROM OrderItems i, Orders o
     WHERE i.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE OrderCharges
     FROM OrderCharges c, Orders o
     WHERE c.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE PaymentDetails
     FROM PaymentDetails p, Orders o
     WHERE p.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE MivaSebenzaMsgs
     FROM MivaSebenzaMsgs m, Orders o
     WHERE m.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE UpsPackages
     FROM UpsPackages p, Shipments s
     WHERE p.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE UpsShipments
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE FedexPackages
     FROM FedexPackages p, Shipments s
     WHERE p.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE FedexShipments
     FROM FedexShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE ShipmentCommodities
     FROM ShipmentCommodities c, Shipments s
     WHERE c.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE Shipments
     FROM Shipments s
     WHERE s.StoreID = @StoreID
     
   DELETE FROM UpsPreferences
     WHERE [StoreID] = @StoreID
     
   DELETE From FedexPreferences
     WHERE [StoreID] = @StoreID
   
   DELETE From EndiciaPreferences
     WHERE [StoreID] = @StoreID

   DELETE FROM EmailAccounts
     WHERE [StoreID] = @StoreID
  
   DELETE FROM Orders
     WHERE [StoreID] = @StoreID

   DELETE FROM Downloaded
     WHERE [StoreID] = @StoreID
     
   DELETE FROM MivaBatches
     WHERE [StoreID] = @StoreID
     
   DELETE FROM DownloadLog
     WHERE [StoreID] = @StoreID
     
   DELETE FROM EmailLog
     WHERE [StoreID] = @StoreID
    
    DELETE FROM Actions
     WHERE [StoreID] = @StoreID
 
    DELETE FROM Notifications
     WHERE [StoreID] = @StoreID

   DELETE FROM Customers
     WHERE [StoreID] = @StoreID   
     
   DELETE FROM [Stores]
     WHERE [StoreID] = @StoreID
     
GO

----------------------------
--- PROCEDURE AddStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddStore]
GO

CREATE PROCEDURE dbo.AddStore
(
   @StoreType int,  
   @StoreName nvarchar(75),
   @LicenseKey nvarchar (150),  
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int,  
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit,
   @FilterLayout text,
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(50),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit, 
   @MivaLiveManualOrderNumbers bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @eBayDownloadPayPalDetails bit,
   @PayPalApiUsername nvarchar (80),
   @PayPalApiPassword nvarchar (80),
   @PayPalApiSignature nvarchar (80),
   @PayPalApiCredentialType smallint,	
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @YahooTrackingEmailAccountID int,
   @YahooTrackingEmailPassword varchar(30),
   @MarketWorksAccountType smallint,
   @MarketWorksDownloadFlags int,
   @osCommerceModuleUrl nvarchar (300),
   @osCommerceStatusCodes text,
   @ProStoresStoreName varchar(30),
   @ProStoresAdminUrl varchar(100),
   @ProStoresXteUrl varchar(75),
   @ProStoresPrefix varchar(30),
   @ChannelAdvisorProfileID int,
   @ChannelAdvisorTimeZone int,
   @ChannelAdvisorTimeZoneDst bit,
   @ChannelAdvisorLastReportTime datetime,
   @ChannelAdvisorXmlApiUsername varchar(50),
   @ChannelAdvisorXmlApiPassword varchar(50),
   @ChannelAdvisorDateFormat varchar(20),
   @ChannelAdvisorWeightUnit smallint,
   @InfopiaToken varchar(128)
)
WITH ENCRYPTION
AS
   INSERT INTO [Stores]
   (
        [StoreType], 
        [StoreName], 
        [LicenseKey],
        [CompanyName], 
        [CompanyAddress1], 
        [CompanyAddress2], 
        [CompanyAddress3], 
        [CompanyCity], 
        [CompanyStateProvCode], 
        [CompanyPostalCode], 
        [CompanyCountryCode], 
        [CompanyUrl], 
        [CompanyFax], 
        [CompanyPhone], 
        [CompanyEmail], 
        [CompanyLogo],
        [LastUpdateTime], 
        [DownloadAddressCasing],
        [EmailDefaultAccountID], 
        [EmailLogSaveMessage],
        [EmailLogSaveMessageImages],
        FilterLayout,
        [OrderStatusStrings], 
        [ItemStatusStrings], 
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [StoreUsername], 
        [StorePassword], 
        [StoreSavePassword], 
        [MivaPassphrase], 
        [MivaSiteID], 
        [MivaModuleUrl], 
        [MivaStoreCode], 
        [MivaConnectSecure], 
        [MivaRemovedDeletedBatches], 
        [MivaSebenzaExtraMsg], 
        [MivaLiveManualOrderNumbers],
        [eBayUserID], 
        [eBayToken], 
        [eBayTokenExpire],
        [eBayDownloadItemDetails],
        eBayDownloadPayPalDetails,
        PayPalApiUsername,
        PayPalApiPassword,
        PayPalApiSignature,
		PayPalApiCredentialType,	
		[ShopSiteCgiUrl],
		[ShopSiteConnectSecure],
		[ShopSiteTimeZoneID],
        [YahooPopServer],
        YahooTrackingEmailAccountID,
        YahooTrackingEmailPassword,
        [MarketWorksAccountType],
        MarketWorksDownloadFlags,
        osCommerceModuleUrl,
        osCommerceStatusCodes,
        ProStoresStoreName,
        ProStoresAdminUrl,
        ProStoresXteUrl,
        ProStoresPrefix,
        ChannelAdvisorProfileID,
        ChannelAdvisorTimeZone,
        ChannelAdvisorTimeZoneDst,
        ChannelAdvisorLastReportTime,
        ChannelAdvisorXmlApiUsername,
        ChannelAdvisorXmlApiPassword,
        ChannelAdvisorDateFormat,
        ChannelAdvisorWeightUnit,
        InfopiaToken
   )
   VALUES 
   (
        @StoreType, 
        @StoreName, 
        @LicenseKey,
        @CompanyName, 
        @CompanyAddress1,
        @CompanyAddress2, 
        @CompanyAddress3, 
        @CompanyCity, 
        @CompanyStateProvCode, 
        @CompanyPostalCode, 
        @CompanyCountryCode, 
        @CompanyUrl, 
        @CompanyFax, 
        @CompanyPhone, 
        @CompanyEmail, 
        @CompanyLogo,
        @LastUpdateTime, 
        @DownloadAddressCasing,
        @EmailDefaultAccountID, 
        @EmailLogSaveMessage,
        @EmailLogSaveMessageImages,
        @FilterLayout,
        @OrderStatusStrings,
        @ItemStatusStrings, 
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @StoreUsername, 
        @StorePassword, 
        @StoreSavePassword, 
        @MivaPassphrase, 
        @MivaSiteID, 
        @MivaModuleUrl, 
        @MivaStoreCode, 
        @MivaConnectSecure, 
        @MivaRemovedDeletedBatches, 
        @MivaSebenzaExtraMsg, 
        @MivaLiveManualOrderNumbers,
        @eBayUserID, 
        @eBayToken, 
        @eBayTokenExpire,
        @eBayDownloadItemDetails,
        @eBayDownloadPayPalDetails,
        @PayPalApiUsername,
        @PayPalApiPassword,
        @PayPalApiSignature,
		@PayPalApiCredentialType,	
		@ShopSiteCgiUrl,
		@ShopSiteConnectSecure,
		@ShopSiteTimeZoneID,
        @YahooPopServer,
        @YahooTrackingEmailAccountID,
        @YahooTrackingEmailPassword,
        @MarketWorksAccountType,
        @MarketWorksDownloadFlags,
        @osCommerceModuleUrl,
        @osCommerceStatusCodes,
        @ProStoresStoreName,
        @ProStoresAdminUrl,
        @ProStoresXteUrl,
        @ProStoresPrefix,
        @ChannelAdvisorProfileID,
        @ChannelAdvisorTimeZone,
        @ChannelAdvisorTimeZoneDst,
        @ChannelAdvisorLastReportTime,
        @ChannelAdvisorXmlApiUsername,
        @ChannelAdvisorXmlApiPassword,
        @ChannelAdvisorDateFormat,
        @ChannelAdvisorWeightUnit,
        @InfopiaToken
)
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, RowVersion
   FROM Stores
   WHERE StoreID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE SaveLastUpdateTime
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveLastUpdateTime]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveLastUpdateTime]
GO

CREATE PROCEDURE dbo.SaveLastUpdateTime
(
   @StoreID int,
   @LastUpdateTime datetime
)
WITH ENCRYPTION
AS
    UPDATE [Stores]
    SET [LastUpdateTime]=@LastUpdateTime
    WHERE [StoreID] = @StoreID

   SET NOCOUNT ON

   SELECT *
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE SaveEmailSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveEmailSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveEmailSettings]
GO

CREATE PROCEDURE dbo.SaveEmailSettings
(
   @StoreID int,
   @EmailDefaultAccountID int,
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit
)
WITH ENCRYPTION
AS
    UPDATE Stores
      SET EmailDefaultAccountID = @EmailDefaultAccountID,
          EmailLogSaveMessage = @EmailLogSaveMessage,
          EmailLogSaveMessageImages = @EmailLogSaveMessageImages
      WHERE StoreID = @StoreID

   SET NOCOUNT ON

   SELECT *
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO


----------------------------
--- PROCEDURE UpdateStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateStore]
GO

CREATE PROCEDURE dbo.UpdateStore
(
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @StoreType int,  
   @StoreName nvarchar(75),  
   @LicenseKey nvarchar (150),
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int, 
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit, 
   @FilterLayout text,
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(50),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit,  
   @MivaLiveManualOrderNumbers bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @eBayDownloadPayPalDetails bit,
   @PayPalApiUsername nvarchar (80),
   @PayPalApiPassword nvarchar (80),
   @PayPalApiSignature nvarchar (80),
   @PayPalApiCredentialType smallint,	
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @YahooTrackingEmailAccountID int,
   @YahooTrackingEmailPassword varchar(30),
   @MarketWorksAccountType smallint,
   @MarketWorksDownloadFlags int,
   @osCommerceModuleUrl nvarchar (300),
   @osCommerceStatusCodes text,
   @ProStoresStoreName varchar(30),
   @ProStoresAdminUrl varchar(100),
   @ProStoresXteUrl varchar(75),
   @ProStoresPrefix varchar(30),
   @ChannelAdvisorProfileID int,
   @ChannelAdvisorTimeZone int,
   @ChannelAdvisorTimeZoneDst bit,
   @ChannelAdvisorLastReportTime datetime,
   @ChannelAdvisorXmlApiUsername varchar(50),
   @ChannelAdvisorXmlApiPassword varchar(50),
   @ChannelAdvisorDateFormat varchar(20),
   @ChannelAdvisorWeightUnit smallint,
   @InfopiaToken varchar(128)
)
WITH ENCRYPTION
AS
   UPDATE [Stores]
   SET [StoreType]=@StoreType, 
       [StoreName]=@StoreName, 
       [LicenseKey]=@LicenseKey,
       [CompanyName]=@CompanyName, 
       [CompanyAddress1]=@CompanyAddress1, 
       [CompanyAddress2]=@CompanyAddress2, 
       [CompanyAddress3]=@CompanyAddress3, 
       [CompanyCity]=@CompanyCity, 
       [CompanyStateProvCode]=@CompanyStateProvCode, 
       [CompanyPostalCode]=@CompanyPostalCode, 
       [CompanyCountryCode]=@CompanyCountryCode, 
       [CompanyUrl]=@CompanyUrl, 
       [CompanyFax]=@CompanyFax, 
       [CompanyPhone]=@CompanyPhone, 
       [CompanyEmail]=@CompanyEmail, 
       [CompanyLogo]=@CompanyLogo,
       [LastUpdateTime]=@LastUpdateTime, 
       [DownloadAddressCasing]=@DownloadAddressCasing,
       [EmailDefaultAccountID]=@EmailDefaultAccountID, 
       [EmailLogSaveMessage]=@EmailLogSaveMessage,
       [EmailLogSaveMessageImages]=@EmailLogSaveMessageImages,
       FilterLayout = @FilterLayout,
       [OrderStatusStrings]=@OrderStatusStrings, 
       [ItemStatusStrings]=@ItemStatusStrings, 
       [OrderNumberPrefix]=@OrderNumberPrefix,
       [OrderNumberPostfix]=@OrderNumberPostfix,
       [StoreUsername]=@StoreUsername, 
       [StorePassword]=@StorePassword, 
       [StoreSavePassword]=@StoreSavePassword, 
       [MivaPassphrase]=@MivaPassphrase, 
       [MivaSiteID]=@MivaSiteID,
       [MivaModuleUrl]=@MivaModuleUrl, 
       [MivaStoreCode]=@MivaStoreCode, 
       [MivaConnectSecure]=@MivaConnectSecure, 
       [MivaRemovedDeletedBatches]=@MivaRemovedDeletedBatches, 
       [MivaSebenzaExtraMsg]=@MivaSebenzaExtraMsg, 
       [MivaLiveManualOrderNumbers]=@MivaLiveManualOrderNumbers,
       [eBayUserID]=@eBayUserID, 
       [eBayToken]=@eBayToken, 
       [eBayTokenExpire]=@eBayTokenExpire,
       [eBayDownloadItemDetails]=@eBayDownloadItemDetails,
       eBayDownloadPayPalDetails = @eBayDownloadPayPalDetails,
       PayPalApiUsername = @PayPalApiUsername,
       PayPalApiPassword = @PayPalApiPassword,
       PayPalApiSignature = @PayPalApiSignature,
	   PayPalApiCredentialType = @PayPalApiCredentialType,	
	   [ShopSiteCgiUrl]=@ShopSiteCgiUrl,
	   [ShopSiteConnectSecure]=@ShopSiteConnectSecure,
	   [ShopSiteTimeZoneID] = @ShopSiteTimeZoneID,
       [YahooPopServer]=@YahooPopServer,
       YahooTrackingEmailAccountID = @YahooTrackingEmailAccountID,
       YahooTrackingEmailPassword = @YahooTrackingEmailPassword,
       [MarketWorksAccountType] = @MarketWorksAccountType,
       MarketWorksDownloadFlags = @MarketWorksDownloadFlags,
       osCommerceModuleUrl = @osCommerceModuleUrl,
       osCommerceStatusCodes = @osCommerceStatusCodes,
       ProStoresStoreName = @ProStoresStoreName,
	   ProStoresAdminUrl = @ProStoresAdminUrl,
	   ProStoresXteUrl = @ProStoresXteUrl,
	   ProStoresPrefix = @ProStoresPrefix,
	   ChannelAdvisorProfileID = @ChannelAdvisorProfileID,
	   ChannelAdvisorTimeZone = @ChannelAdvisorTimeZone,
	   ChannelAdvisorTimeZoneDst = @ChannelAdvisorTimeZoneDst,
	   ChannelAdvisorLastReportTime = @ChannelAdvisorLastReportTime,
       ChannelAdvisorXmlApiUsername = @ChannelAdvisorXmlApiUsername,
       ChannelAdvisorXmlApiPassword = @ChannelAdvisorXmlApiPassword,
       ChannelAdvisorDateFormat = @ChannelAdvisorDateFormat,
       ChannelAdvisorWeightUnit = @ChannelAdvisorWeightUnit,
       InfopiaToken = @InfopiaToken
    WHERE [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateFilterLayout
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFilterLayout]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFilterLayout]
GO

CREATE PROCEDURE dbo.UpdateFilterLayout
(
   @StoreID int,
   @FilterLayout text
)
WITH ENCRYPTION
AS

   -- We purposely leave out the StoreID test here so that the settings act as global, not per-store.
   UPDATE Stores
      SET FilterLayout = @FilterLayout
      WHERE -- StoreID = @StoreID and 
            not (FilterLayout LIKE @FilterLayout)
      
    if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO
   