ALTER TABLE dbo.UspsShipments
	DROP CONSTRAINT FK_UspsShipments_Shipments
GO

CREATE TABLE dbo.Tmp_UspsShipments
	(
	ShipmentID int NOT NULL,
	RowVersion timestamp NOT NULL,
	ServiceType int NOT NULL,
	ConfirmationType int NOT NULL,
	AddressService bit NOT NULL,
	SendEmail bit NOT NULL,
	LabelImageFull nvarchar(350) NOT NULL,
	LabelImageLabel nvarchar(350) NOT NULL,
	LabelImageBarcode nvarchar(350) NOT NULL,
    Stealth bit NOT NULL,
    SpecifyLayout bit NOT NULL,
    Layout nvarchar (350) NOT NULL,
    DeclaredValue money NOT NULL,
    InsuranceType int NOT NULL,
    Oversize bit NOT NULL,
	RubberStamp1 varchar (200) NOT NULL,
	RubberStamp2 varchar (200) NOT NULL,
	RubberStamp3 varchar (200) NOT NULL,
	RubberStamp4 varchar (200) NOT NULL,
	CustomsForm int NOT NULL,
	CustomsDescription nvarchar (200) NOT NULL,
	CustomsContentType int
	)
GO

IF EXISTS(SELECT * FROM dbo.UspsShipments)
	 EXEC('INSERT INTO dbo.Tmp_UspsShipments 
	          (ShipmentID, ServiceType, ConfirmationType, AddressService, SendEmail, LabelImageFull, LabelImageLabel, LabelImageBarcode, Stealth, SpecifyLayout, Layout, DeclaredValue, InsuranceType, Oversize, RubberStamp1, RubberStamp2, RubberStamp3, RubberStamp4, CustomsForm, CustomsDescription,  CustomsContentType)
		SELECT ShipmentID, ServiceType, ConfirmationType, AddressService, SendEmail, LabelImageFull, LabelImageLabel, LabelImageBarcode, 0,       0,             '''',   0,             0,             0,        '''',         '''',         '''',         '''',         0,           '''',                3 FROM dbo.UspsShipments TABLOCKX')
GO

DROP TABLE dbo.UspsShipments
GO

EXECUTE sp_rename N'dbo.Tmp_UspsShipments', N'UspsShipments', 'OBJECT'
GO

ALTER TABLE dbo.UspsShipments ADD CONSTRAINT
	IX_UspsShipments_ShipmentID UNIQUE NONCLUSTERED 
	(
	ShipmentID
	)
GO

ALTER TABLE dbo.UspsShipments WITH NOCHECK ADD CONSTRAINT
	FK_UspsShipments_Shipments FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO



-----------------------------
--- Procedure GetOrderUspsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsShipments]
GO

CREATE PROCEDURE GetOrderUspsShipments
(
    @OrderID int
)
AS
   SELECT u.*
   FROM UspsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUspsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsShipments]
GO

CREATE PROCEDURE GetCustomerUspsShipments
(
    @CustomerID int
)
AS
   SELECT u.*
   FROM UspsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsShipmentRange]
GO

CREATE PROCEDURE GetOrderUspsShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsShipmentRange]
GO

CREATE PROCEDURE GetCustomerUspsShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure UpdateUspsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUspsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUspsShipment]
GO

CREATE PROCEDURE UpdateUspsShipment
(
    @ShipmentID int,
    @RowVersion timestamp,
	@ServiceType int ,
	@ConfirmationType int ,
	@AddressService bit  ,
	@SendEmail bit ,
	@LabelImageFull nvarchar (350) ,
	@LabelImageLabel nvarchar (350),
	@LabelImageBarcode nvarchar (350) ,
    @Stealth bit ,
    @SpecifyLayout bit,
    @Layout nvarchar (350) ,
    @DeclaredValue money ,
    @InsuranceType int,
    @Oversize bit,
	@RubberStamp1 varchar (200) ,
	@RubberStamp2 varchar (200) ,
	@RubberStamp3 varchar (200) ,
	@RubberStamp4 varchar (200) ,
	@CustomsForm int ,
	@CustomsDescription nvarchar (200) ,
	@CustomsContentType int
)
AS
    UPDATE [UspsShipments]
    SET ServiceType = @ServiceType,
	    ConfirmationType = @ConfirmationType,
	    AddressService = @AddressService,
	    SendEmail = @SendEmail,
	    LabelImageFull = @LabelImageFull,
	    LabelImageLabel = @LabelImageLabel,
	    LabelImageBarcode = @LabelImageBarcode,
		Stealth = @Stealth,
		SpecifyLayout = @SpecifyLayout,
		Layout = @Layout,
		DeclaredValue = @DeclaredValue,
		InsuranceType = @InsuranceType,
		Oversize = @Oversize,
		RubberStamp1 = @RubberStamp1,
		RubberStamp2 = @RubberStamp2,
		RubberStamp3 = @RubberStamp3,
		RubberStamp4 = @RubberStamp4,
		CustomsForm = @CustomsForm,
		CustomsDescription = @CustomsDescription,
		CustomsContentType = @CustomsContentType
    WHERE ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM UspsShipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

-----------------------------
--- Procedure AddUspsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUspsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUspsShipment]
GO

CREATE PROCEDURE AddUspsShipment
(
    @ShipmentID int,
	@ServiceType int ,
	@ConfirmationType int ,
	@AddressService bit  ,
	@SendEmail bit ,
	@LabelImageFull nvarchar (350) ,
	@LabelImageLabel nvarchar (350),
	@LabelImageBarcode nvarchar (350) ,
    @Stealth bit ,
    @SpecifyLayout bit,
    @Layout nvarchar (350) ,
    @DeclaredValue money ,
    @InsuranceType int,
    @Oversize bit,
	@RubberStamp1 varchar (200) ,
	@RubberStamp2 varchar (200) ,
	@RubberStamp3 varchar (200) ,
	@RubberStamp4 varchar (200) ,
	@CustomsForm int ,
	@CustomsDescription nvarchar (200) ,
	@CustomsContentType int
)
AS
    if (exists(SELECT * FROM UspsShipments WHERE ShipmentID = @ShipmentID))
    begin
    
        select * from UspsShipments WHERE ShipmentID = @ShipmentID
        
    end
    else
    begin
    
        INSERT INTO [UspsShipments]
        (
            ShipmentID,
            ServiceType,
	        ConfirmationType,
	        AddressService,
	        SendEmail,
	        LabelImageFull,
	        LabelImageLabel,
	        LabelImageBarcode,
			Stealth,
			SpecifyLayout,
			Layout,
			DeclaredValue,
			InsuranceType,
			Oversize,
			RubberStamp1,
			RubberStamp2,
			RubberStamp3,
			RubberStamp4,
			CustomsForm,
			CustomsDescription,
			CustomsContentType
        )
        VALUES
        (
            @ShipmentID,
            @ServiceType,
	        @ConfirmationType,
	        @AddressService,
	        @SendEmail,
	        @LabelImageFull,
	        @LabelImageLabel,
	        @LabelImageBarcode,
			@Stealth,
			@SpecifyLayout,
			@Layout,
			@DeclaredValue,
			@InsuranceType,
			@Oversize,
			@RubberStamp1,
			@RubberStamp2,
			@RubberStamp3,
			@RubberStamp4,
			@CustomsForm,
			@CustomsDescription,
			@CustomsContentType
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ShipmentID, [RowVersion]
        FROM UspsShipments
        WHERE ShipmentID = @ShipmentID

        return 1
                
  end
    
GO
