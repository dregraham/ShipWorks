if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUpsShipments]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsShipmentsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUpsShipmentsRange]
GO

-----------------------------
--- Procedure GetOrderUpsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUpsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUpsShipments]
GO

CREATE PROCEDURE GetOrderUpsShipments
(
    @OrderID int
)
AS
   SELECT u.*
   FROM UpsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUpsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUpsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUpsShipments]
GO

CREATE PROCEDURE GetCustomerUpsShipments
(
    @CustomerID int
)
AS
   SELECT u.*
   FROM UpsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderUpsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUpsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUpsShipmentRange]
GO

CREATE PROCEDURE GetOrderUpsShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT u.*
     FROM UpsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerUpsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUpsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUpsShipmentRange]
GO

CREATE PROCEDURE GetCustomerUpsShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT u.*
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO
