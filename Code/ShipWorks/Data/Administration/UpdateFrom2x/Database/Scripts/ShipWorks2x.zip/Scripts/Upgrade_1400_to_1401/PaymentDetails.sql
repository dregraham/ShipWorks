-----------------------------
--- Procedure AddPaymentDetail
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddPaymentDetail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddPaymentDetail]
GO

CREATE PROCEDURE dbo.AddPaymentDetail
(
	@OrderID int,
	@Type nvarchar (50) ,
	@Label nvarchar (100) ,
	@Value nvarchar (100)
)
WITH ENCRYPTION
AS
    INSERT INTO [PaymentDetails]
    (
        [OrderID], 
        [Type], 
        [Label],
        [Value]
    )
    VALUES
    (
        @OrderID, 
        @Type, 
        @Label,
        @Value
    )
    
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT PaymentDetailID
     FROM PaymentDetails
     WHERE PaymentDetailID = SCOPE_IDENTITY()

   return 1
GO

-----------------------------
--- Procedure UpdatePaymentDetail
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdatePaymentDetail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdatePaymentDetail]
GO

CREATE PROCEDURE dbo.UpdatePaymentDetail
(
    @PaymentDetailID int,
	@OrderID int,
	@Type nvarchar (50) ,
	@Label nvarchar (100) ,
	@Value nvarchar (100)
)
WITH ENCRYPTION
AS
    UPDATE [PaymentDetails]
    SET [OrderID] = @OrderID,
        [Type] = @Type, 
        [Label] = @Label,
        [Value] = @Value
    WHERE [PaymentDetailID] = @PaymentDetailID
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

   SELECT PaymentDetailID
     FROM PaymentDetails
     WHERE PaymentDetailID = @PaymentDetailID

    return 1
GO

-----------------------------
--- Procedure DeletePaymentDetail
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeletePaymentDetail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeletePaymentDetail]
GO

CREATE PROCEDURE dbo.DeletePaymentDetail
(
   @PaymentDetailID int
)
WITH ENCRYPTION
AS
    DELETE FROM PaymentDetails
    WHERE PaymentDetailID = @PaymentDetailID
GO

-----------------------------
--- Procedure GetPaymentDetailsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetPaymentDetailsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetPaymentDetailsRange]
GO

CREATE PROCEDURE dbo.GetPaymentDetailsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
   FROM PaymentDetails p, Orders o
   WHERE p.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
         o.OrderID > @MinOrderID
GO

-----------------------------
--- Procedure GetPaymentDetails
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetPaymentDetails]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetPaymentDetails]
GO

CREATE PROCEDURE dbo.GetPaymentDetails
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM PaymentDetails
   WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure SynchMivaPaymentDetail
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaPaymentDetail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaPaymentDetail]
GO

CREATE PROCEDURE dbo.SynchMivaPaymentDetail
(
	@OrderID int,
	@Type nvarchar (50) ,
	@Label nvarchar (100) ,
	@Value nvarchar (100)
)
WITH ENCRYPTION
AS
   
    -- If this payment detail already exists, we dont do anything
    if exists (
        SELECT * 
        FROM PaymentDetails
        WHERE Type = @Type AND OrderID = @OrderID
        )
    begin
    
        -- This just lets the .NET data provider know everything is OK
        SELECT PaymentDetailID
          FROM PaymentDetails
          WHERE Type = @Type AND OrderID = @OrderID
              
        return 1

    end
    
    -- This charge number does not already exist, we need to create it
    else 
    begin
        INSERT INTO [PaymentDetails]
        (
            [OrderID], 
            [Type], 
            [Label],
            [Value]
        )
        VALUES
        (
            @OrderID, 
            @Type, 
            @Label,
            @Value
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT PaymentDetailID
        FROM PaymentDetails
        WHERE PaymentDetailID = SCOPE_IDENTITY()

        return 1
    end
GO
