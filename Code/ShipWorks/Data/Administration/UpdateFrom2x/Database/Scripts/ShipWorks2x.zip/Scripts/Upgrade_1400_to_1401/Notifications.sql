----------------------------
--- PROCEDURE GetNotifications
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetNotifications]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetNotifications]
GO

CREATE PROCEDURE dbo.GetNotifications
(
    @StoreID int,
    @ClientID int
)
WITH ENCRYPTION
AS
   SELECT *
     FROM Notifications
     WHERE StoreID = @StoreID AND ClientID = @ClientID
GO

----------------------------
--- PROCEDURE AddNotification
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddNotification]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddNotification]
GO

CREATE PROCEDURE dbo.AddNotification
(
    @ClientID int ,
    @StoreID int ,
    @Occurred datetime,
    @Type smallint,
    @Source nvarchar(512),
    @Context nvarchar(512),
    @Details ntext
)
WITH ENCRYPTION
AS
   INSERT INTO Notifications
   (
        ClientID,
        StoreID,
        Occurred,
        Type,
        Source,
        Context,
        Details
   )
   VALUES
   (
        @ClientID,
        @StoreID,
        @Occurred,
        @Type,
        @Source,
        @Context,
        @Details
   )
   
    if (@@ROWCOUNT != 1)
        return 0

   SET NOCOUNT ON

   SELECT NotificationID
     FROM Notifications
     WHERE NotificationID = SCOPE_IDENTITY()

   return 1
GO

-----------------------------
--- Procedure DeleteNotification
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteNotification]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteNotification]
GO

CREATE PROCEDURE dbo.DeleteNotification
(
   @NotificationID int
)
WITH ENCRYPTION
AS
    DELETE FROM Notifications
    WHERE NotificationID = @NotificationID
GO
