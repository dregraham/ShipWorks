----------------------------
--- Database Schema Version 
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetSchemaVersion]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetSchemaVersion]
GO

CREATE PROCEDURE dbo.GetSchemaVersion 
AS 
SELECT '1.0.6.0' AS 'SchemaVersion'
GO

----------------------------
--- SetSessionClientID
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SetSessionClientID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SetSessionClientID]
GO

CREATE PROCEDURE SetSessionClientID
(
    @ClientID int
)
AS
    DECLARE @BinVar binary(128)
    SET @BinVar = CAST( @ClientID AS binary(128) )
    SET CONTEXT_INFO @BinVar
GO

----------------------------
--- GetSessionClientID
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetSessionClientID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetSessionClientID]
GO

CREATE PROCEDURE GetSessionClientID
AS
    SELECT CAST(context_info AS int) AS ClientID
       FROM master.dbo.sysprocesses
       WHERE spid = @@spid
GO
