--------------------------------------------------------------------
-- NOTE: There are other changes to the Orders table in this update,
--       that are in the Customers.sql file for the update.
--------------------------------------------------------------------

-----------------------------
--- TRIGGER TG_Orders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Orders]'))
   drop trigger [TG_Orders]
GO

CREATE TRIGGER TG_Orders ON Orders FOR UPDATE
AS
    if ( (SELECT COUNT(*) FROM inserted) = 0)
       return;

    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID FROM inserted
    
    IF UPDATE(CustomerID)
    begin
        -- If the customerID is updated, we just need to touch the customer of each order
        -- so that SW knows the customer calculated columns need looked at.
        UPDATE Customers
          SET ShipFirstName = ShipFirstName
          WHERE CustomerID in (SELECT CustomerID FROM inserted)
          
        -- Update all the old customers too
        UPDATE Customers
          SET ShipFirstName = ShipFirstName
          WHERE CustomerID in (SELECT CustomerID FROM deleted)
    end
       
    EXEC SetTableLastDbts 'Orders', @StoreID, @@DBTS
GO

-----------------------------
--- TRIGGER TG_Orders_Deleted
-----------------------------
CREATE TRIGGER TG_Orders_Deleted ON Orders FOR DELETE
AS
    -- We just need to touch the customer of each deleted order
    -- so that SW knows the customer calculated columns need looked at.
    UPDATE Customers
      SET ShipFirstName = ShipFirstName
      WHERE CustomerID in (SELECT CustomerID FROM deleted)
GO

-----------------------------
--- TRIGGER TG_Orders_Customers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Orders_Customers]'))
   drop trigger [TG_Orders_Customers]
GO

CREATE TRIGGER TG_Orders_Customers ON Orders INSTEAD OF INSERT
AS

    if ( (SELECT Count(*) FROM inserted) > 1 )
    begin
         RAISERROR ('Only one order can be added at a time.', 16, 1)
         ROLLBACK TRANSACTION
         return
    end

    DECLARE @customerID int
    SELECT @customerID = NULL
    
    -- See if a valid customer is already specified
    SELECT @customerID = i.CustomerID
      FROM inserted i, Customers c
      WHERE i.StoreID = c.StoreID AND i.CustomerID = c.CustomerID AND i.CustomerID > 0

    if (@customerID IS NULL)
    begin
    
        -- Match up customers based on bill email address
        SELECT @customerID = c.CustomerID
        FROM inserted i, Customers c
        WHERE
            i.StoreID = c.StoreID AND
            (i.BillEmail != '' AND i.BillEmail = c.BillEmail)
          
        -- If it didnt work based on email, try based on addresss
        if (@customerID IS NULL)
        begin

        -- Match up customers based on shipping address
        SELECT @customerID = c.CustomerID
            FROM inserted i, Customers c
            WHERE
                i.StoreID = c.StoreID AND
                c.AddressHash != '' AND
                c.AddressHash = (i.BillFirstName + i.BillLastName + i.BillAddress1 + i.BillAddress2 + i.BillPostalCode)
        end
        
    end
    
    -- If we still have not found a correct customer, add an entry to the customers table
    if (@customerID IS NULL)
    begin

            -- Create a customer for each order that does not yet have a customer
            INSERT INTO Customers 
            (
                StoreID, 
                ShipEmail,     
                ShipFirstName,     
                ShipLastName,     
                ShipCompany,     
                ShipAddress1,     
                ShipAddress2,     
                ShipAddress3,     
                ShipCity,     
                ShipStateProvinceCode,     
                ShipPostalCode,     
                ShipCountryCode,     
                ShipPhone,     
                ShipFax,     
                BillEmail,     
                BillFirstName,     
                BillLastName,     
                BillCompany,     
                BillAddress1,     
                BillAddress2,     
                BillAddress3,     
                BillCity,     
                BillStateProvinceCode,     
                BillPostalCode,     
                BillCountryCode,     
                BillPhone,     
                BillFax,     
                Notes, 
                eBayBuyerID
            )
            SELECT 
                StoreID, 
                ShipEmail,     
                ShipFirstName,     
                ShipLastName,     
                ShipCompany,     
                ShipAddress1,     
                ShipAddress2,     
                ShipAddress3,     
                ShipCity,     
                ShipStateProvinceCode,     
                ShipPostalCode,     
                ShipCountryCode,     
                ShipPhone,     
                ShipFax,    
                BillEmail, 
                BillFirstName, 
                BillLastName, 
                BillCompany, 
                BillAddress1, 
                BillAddress2, 
                BillAddress3, 
                BillCity, 
                BillStateProvinceCode, 
                BillPostalCode, 
                BillCountryCode, 
                BillPhone, 
                BillFax, 
                '',    
                eBayBuyerID
            FROM inserted i

          -- Now we know the customer ID
          SET @customerID = SCOPE_IDENTITY()
    end

    -- We do know the customer, update the existing customer record
    else
    begin

            UPDATE c 
            SET
                c.ShipEmail = i.ShipEmail,     
                c.ShipFirstName = i.ShipFirstName,     
                c.ShipLastName = i.ShipLastName,     
                c.ShipCompany = i.ShipCompany,     
                c.ShipAddress1 = i.ShipAddress1,     
                c.ShipAddress2 = i.ShipAddress2,     
                c.ShipAddress3 = i.ShipAddress3,     
                c.ShipCity = i.ShipCity,     
                c.ShipStateProvinceCode = i.ShipStateProvinceCode,     
                c.ShipPostalCode = i.ShipPostalCode,     
                c.ShipCountryCode = i.ShipCountryCode,     
                c.ShipPhone = i.ShipPhone,     
                c.ShipFax = i.ShipFax,     
                c.BillEmail = i.BillEmail,     
                c.BillFirstName = i.BillFirstName,     
                c.BillLastName = i.BillLastName,     
                c.BillCompany = i.BillCompany,     
                c.BillAddress1 = i.BillAddress1,     
                c.BillAddress2 = i.BillAddress2,     
                c.BillAddress3 = i.BillAddress3,     
                c.BillCity = i.BillCity,     
                c.BillStateProvinceCode = i.BillStateProvinceCode,     
                c.BillPostalCode = i.BillPostalCode,     
                c.BillCountryCode = i.BillCountryCode,     
                c.BillPhone = i.BillPhone,     
                c.BillFax = i.BillFax,
                c.eBayBuyerID = i.eBayBuyerID
            FROM Customers c, inserted i
            WHERE c.CustomerID = @customerID
    end
         
    -- Now, we can insert the rows into the real customers table
    INSERT INTO Orders 
    (
        OrderNumber, 
        StoreID, 
        CustomerID, 
        OrderDate, 
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1, 
        ShipAddress2, 
        ShipAddress3, 
        ShipCity, 
        ShipStateProvinceCode, 
        ShipPostalCode, 
        ShipCountryCode, 
        ShipEmail, 
        ShipPhone,
        ShipFax,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1, 
        BillAddress2, 
        BillAddress3, 
        BillCity, 
        BillStateProvinceCode, 
        BillPostalCode, 
        BillCountryCode, 
        BillEmail, 
        BillPhone,
        BillFax,
        CustomerComments,
        RequestedShipping,
        Total, 
        Notes, 
        Status,
        IsManual,
        OrderNumberPrefix,
        OrderNumberPostfix,
        eBayOrderID, 
        eBayBuyerID, 
        eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate,
        eBayLastModified, 
        eBayPaymentStatus, 
        eBayPaymentMethod, 
        eBayIncompleteState, 
        eBayStatusIs, 
        eBayLeftFeedback, 
        eBayLeftFeedbackType, 
        eBayLeftFeedbackComments, 
        eBayReceivedFeedbackType, 
        eBayReceivedFeedbackComments, 
        eBayMarkedPaymentMethod, 
        eBayAllowEdit, 
        MivaBatchID
    )
       SELECT         
        OrderNumber, 
        StoreID, 
        @CustomerID, 
        OrderDate, 
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1, 
        ShipAddress2, 
        ShipAddress3, 
        ShipCity, 
        ShipStateProvinceCode, 
        ShipPostalCode, 
        ShipCountryCode, 
        ShipEmail, 
        ShipPhone,
        ShipFax,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1, 
        BillAddress2, 
        BillAddress3, 
        BillCity, 
        BillStateProvinceCode, 
        BillPostalCode, 
        BillCountryCode, 
        BillEmail, 
        BillPhone,
        BillFax,
        CustomerComments,
        RequestedShipping,
        Total, 
        Notes, 
        Status,
        IsManual,
        OrderNumberPrefix,
        OrderNumberPostfix,
        eBayOrderID, 
        eBayBuyerID, 
        eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate,
        eBayLastModified, 
        eBayPaymentStatus, 
        eBayPaymentMethod, 
        eBayIncompleteState, 
        eBayStatusIs, 
        eBayLeftFeedback, 
        eBayLeftFeedbackType, 
        eBayLeftFeedbackComments, 
        eBayReceivedFeedbackType, 
        eBayReceivedFeedbackComments, 
        eBayMarkedPaymentMethod, 
        eBayAllowEdit, 
        MivaBatchID
     FROM inserted i
GO

-----------------------------
--- Procedure AddOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddOrder]
GO

CREATE PROCEDURE AddOrder
(
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @IsManual bit,
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int]
)
AS
    if (@OrderNumber <= 0)
    begin
      
        -- Determine the next OrderNumber to use
        SELECT @OrderNumber = MAX(OrderNumber) + 1
          FROM Orders
          WHERE StoreID = @StoreID
        
        if (@OrderNumber IS NULL)
           SELECT @OrderNumber = 1
           
    end

    INSERT INTO [Orders](
        [OrderNumber], 
        [StoreID], 
        [CustomerID], 
        [OrderDate], 
        [ShipFirstName],
        [ShipLastName],
        [ShipCompany],
        [ShipAddress1], 
        [ShipAddress2], 
        [ShipAddress3], 
        [ShipCity], 
        [ShipStateProvinceCode], 
        [ShipPostalCode], 
        [ShipCountryCode], 
        [ShipEmail], 
        [ShipPhone],
        [ShipFax],
        [BillFirstName],
        [BillLastName],
        [BillCompany],
        [BillAddress1], 
        [BillAddress2], 
        [BillAddress3], 
        [BillCity], 
        [BillStateProvinceCode], 
        [BillPostalCode], 
        [BillCountryCode], 
        [BillEmail], 
        [BillPhone],
        [BillFax],
        [CustomerComments],
        [RequestedShipping],
        [Total], 
        [Notes], 
        [Status],
        [IsManual],
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [eBayOrderID], 
        [eBayBuyerID], 
        [eBayBuyerFeedbackScore],
        [eBayBuyerFeedbackPrivate],
        [eBayLastModified], 
        [eBayPaymentStatus], 
        [eBayPaymentMethod], 
        [eBayIncompleteState], 
        [eBayStatusIs], 
        [eBayLeftFeedback], 
        [eBayLeftFeedbackType], 
        [eBayLeftFeedbackComments], 
        [eBayReceivedFeedbackType], 
        [eBayReceivedFeedbackComments], 
        [eBayMarkedPaymentMethod], 
        [eBayAllowEdit], 
        [MivaBatchID]
    )
    VALUES
    (
        @OrderNumber, 
        @StoreID, 
        @CustomerID, 
        @OrderDate, 
        @ShipFirstName,
        @ShipLastName,
        @ShipCompany,
        @ShipAddress1, 
        @ShipAddress2, 
        @ShipAddress3, 
        @ShipCity, 
        @ShipStateProvinceCode, 
        @ShipPostalCode, 
        @ShipCountryCode, 
        @ShipEmail, 
        @ShipPhone,
        @ShipFax,
        @BillFirstName,
        @BillLastName,
        @BillCompany,
        @BillAddress1, 
        @BillAddress2, 
        @BillAddress3, 
        @BillCity, 
        @BillStateProvinceCode, 
        @BillPostalCode, 
        @BillCountryCode, 
        @BillEmail, 
        @BillPhone,
        @BillFax,
        @CustomerComments,
        @RequestedShipping,
        @Total, 
        @Notes, 
        @Status,
        @IsManual,
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @eBayOrderID, 
        @eBayBuyerID, 
        @eBayBuyerFeedbackScore,
        @eBayBuyerFeedbackPrivate,
        @eBayLastModified, 
        @eBayPaymentStatus, 
        @eBayPaymentMethod, 
        @eBayIncompleteState, 
        @eBayStatusIs, 
        @eBayLeftFeedback, 
        @eBayLeftFeedbackType, 
        @eBayLeftFeedbackComments, 
        @eBayReceivedFeedbackType, 
        @eBayReceivedFeedbackComments, 
        @eBayMarkedPaymentMethod, 
        @eBayAllowEdit, 
        @MivaBatchID
    )

    SELECT OrderID, CustomerID, OrderNumber, [RowVersion], OrderNumberDisplay
      FROM Orders
      WHERE OrderNumber = @OrderNumber AND StoreID = @StoreID AND IsManual = @IsManual
    
    return @@ROWCOUNT
GO

-----------------------------
--- Procedure SynchEBayOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchEBayOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchEBayOrder]
GO

CREATE PROCEDURE SynchEBayOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int],
	@eBayItemID bigint,
	@eBayTransID bigint,
    @WasNew [bit] OUTPUT
)
AS 
    -- Assume its new by default
    SELECT @WasNew = 1

    -- If this eBay order already exists as a combined order
    if exists (
        SELECT * 
        FROM Orders
        WHERE @eBayOrderID != 0 AND 
              eBayOrderID = @eBayOrderID AND
              StoreID = @StoreID
    )
    begin
        
        SELECT @OrderID = MAX(OrderID), @OrderNumber = MAX(OrderNumber)
        FROM Orders
        WHERE eBayOrderID = @eBayOrderID AND
              StoreID = @StoreID
        
        -- Its not new
        SELECT @WasNew = 0
        
    end
    
    -- See if this eBay order exists as a single item, which we will find in the items table
    else if exists (
        SELECT * 
        FROM Orders o, OrderItems i
        WHERE @eBayItemID != 0 AND 
              i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              o.OrderID = i.OrderID AND 
              o.StoreID = @StoreID
    )
    begin
    
        SELECT @OrderID = MAX(o.OrderID), @OrderNumber = MAX(o.OrderNumber)
        FROM Orders o, OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              o.OrderID = i.OrderID AND 
              o.StoreID = @StoreID
              
        -- Its not new
        SELECT @WasNew = 0

    end
    
    -- If its new, then create the order
    if (@WasNew != 0)
    begin       
        -- Determine the next OrderNumber to use
        SELECT @OrderNumber = MAX(OrderNumber) + 1
          FROM Orders
          WHERE StoreID = @StoreID
        
        if (@OrderNumber IS NULL)
           SELECT @OrderNumber = 1
    
        INSERT INTO [Orders](
            [OrderNumber], 
            [StoreID], 
            [CustomerID], 
            [OrderDate], 
            [ShipFirstName],
            [ShipLastName],
            [ShipCompany],
            [ShipAddress1], 
            [ShipAddress2], 
            [ShipAddress3], 
            [ShipCity], 
            [ShipStateProvinceCode], 
            [ShipPostalCode], 
            [ShipCountryCode], 
            [ShipEmail], 
            [ShipPhone],
            [ShipFax],
            [BillFirstName],
            [BillLastName],
            [BillCompany],
            [BillAddress1], 
            [BillAddress2], 
            [BillAddress3], 
            [BillCity], 
            [BillStateProvinceCode], 
            [BillPostalCode], 
            [BillCountryCode], 
            [BillEmail], 
            [BillPhone],
            [BillFax],
            [CustomerComments],
            [RequestedShipping],
            [Total], 
            [Notes], 
            [Status],
            [IsManual],
            [OrderNumberPrefix],
            [OrderNumberPostfix],
            [eBayOrderID], 
            [eBayBuyerID], 
            [eBayBuyerFeedbackScore],
            [eBayBuyerFeedbackPrivate],
            [eBayLastModified], 
            [eBayPaymentStatus], 
            [eBayPaymentMethod], 
            [eBayIncompleteState], 
            [eBayStatusIs], 
            [eBayLeftFeedback], 
            [eBayLeftFeedbackType], 
            [eBayLeftFeedbackComments], 
            [eBayReceivedFeedbackType], 
            [eBayReceivedFeedbackComments], 
            [eBayMarkedPaymentMethod], 
            [eBayAllowEdit], 
            [MivaBatchID] 
        )
        VALUES
        (
            @OrderNumber, 
            @StoreID, 
            @CustomerID, 
            @OrderDate, 
            @ShipFirstName,
            @ShipLastName,
            @ShipCompany,
            @ShipAddress1, 
            @ShipAddress2, 
            @ShipAddress3, 
            @ShipCity, 
            @ShipStateProvinceCode, 
            @ShipPostalCode, 
            @ShipCountryCode, 
            @ShipEmail, 
            @ShipPhone,
            @ShipFax,
            @BillFirstName,
            @BillLastName,
            @BillCompany,
            @BillAddress1, 
            @BillAddress2, 
            @BillAddress3, 
            @BillCity, 
            @BillStateProvinceCode, 
            @BillPostalCode, 
            @BillCountryCode, 
            @BillEmail, 
            @BillPhone,
            @BillFax,
            @CustomerComments,
            @RequestedShipping,
            @Total, 
            @Notes, 
            @Status,
            0, -- IsManual
            @OrderNumberPrefix,
            @OrderNumberPostfix,
            @eBayOrderID, 
            @eBayBuyerID, 
            @eBayBuyerFeedbackScore,
            @eBayBuyerFeedbackPrivate,
            @eBayLastModified, 
            @eBayPaymentStatus, 
            @eBayPaymentMethod, 
            @eBayIncompleteState, 
            @eBayStatusIs, 
            @eBayLeftFeedback, 
            @eBayLeftFeedbackType, 
            @eBayLeftFeedbackComments, 
            @eBayReceivedFeedbackType, 
            @eBayReceivedFeedbackComments, 
            @eBayMarkedPaymentMethod, 
            @eBayAllowEdit, 
            @MivaBatchID 
        )
        
        SELECT OrderID, CustomerID, OrderNumber, [RowVersion], IsManual, OrderNumberDisplay
           FROM Orders
           WHERE OrderNumber = @OrderNumber AND StoreID = @StoreID AND IsManual = 0
        
        return @@ROWCOUNT
        
    end
    
    -- Its not new, we have to update it
    else
    begin
    
        UPDATE Orders
        SET OrderNumber = @OrderNumber,
            StoreID = @StoreID,
            CustomerID = @CustomerID,
            OrderDate = @OrderDate,
	        ShipFirstName = @ShipFirstName,
	        ShipLastName = @ShipLastName,
	        ShipCompany = @ShipCompany,
            ShipAddress1 = @ShipAddress1,
            ShipAddress2 = @ShipAddress2,
            ShipAddress3 = @ShipAddress3,
            ShipCity = @ShipCity,
            ShipStateProvinceCode = @ShipStateProvinceCode,
            ShipPostalCode = @ShipPostalCode,
            ShipCountryCode = @ShipCountryCode,
            ShipEmail = @ShipEmail,
            ShipPhone = @ShipPhone,
            ShipFax = @ShipFax,
	        BillFirstName = @BillFirstName,
	        BillLastName = @BillLastName,
	        BillCompany = @BillCompany,
            BillAddress1 = @BillAddress1,
            BillAddress2 = @BillAddress2,
            BillAddress3 = @BillAddress3,
            BillCity = @BillCity,
            BillStateProvinceCode = @BillStateProvinceCode,
            BillPostalCode = @BillPostalCode,
            BillCountryCode = @BillCountryCode,
            BillEmail = @BillEmail,
            BillPhone = @BillPhone,
            BillFax = @BillFax,
            CustomerComments = @CustomerComments,
            RequestedShipping = @RequestedShipping,
            Total = @Total,
            Notes = @Notes,
            Status = @Status,
            OrderNumberPrefix = @OrderNumberPrefix,
            OrderNumberPostfix = @OrderNumberPostfix,
            eBayOrderID = @eBayOrderID,
            eBayBuyerID = @eBayBuyerID,
            eBayBuyerFeedbackScore = @eBayBuyerFeedbackScore,
            eBayBuyerFeedbackPrivate = @eBayBuyerFeedbackPrivate,
            eBayLastModified = @eBayLastModified,
            eBayPaymentStatus = @eBayPaymentStatus,
            eBayPaymentMethod = @eBayPaymentMethod,
            eBayIncompleteState = @eBayIncompleteState,
            eBayStatusIs = @eBayStatusIs,
            eBayLeftFeedback = @eBayLeftFeedback,
            eBayLeftFeedbackType = @eBayLeftFeedbackType,
            eBayLeftFeedbackComments = @eBayLeftFeedbackComments,
            eBayReceivedFeedbackType = @eBayReceivedFeedbackType,
            eBayReceivedFeedbackComments = @eBayReceivedFeedbackComments,
            eBayMarkedPaymentMethod = @eBayMarkedPaymentMethod,
            eBayAllowEdit = @eBayAllowEdit,
            MivaBatchID = @MivaBatchID
        WHERE OrderID = @OrderID
    
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderID, CustomerID, OrderNumber, [RowVersion], OrderNumberDisplay
        FROM Orders
        WHERE OrderID = @OrderID
        
        return 1
    end
GO

-----------------------------
--- Procedure SynchMivaOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaOrder]
GO

CREATE PROCEDURE SynchMivaOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int]
)
AS       
    -- If this Miva order number already exists, just update its batch
    if exists (
        SELECT * FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND
              IsManual = 0 )
    begin
        -- Update the batch id.  Dont worry about RowVersion mismatch - just do it.
        UPDATE Orders
        SET MivaBatchID = @MivaBatchID 
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND 
              IsManual = 0
              
        SET NOCOUNT ON

        -- Select the updated row back into .NET
        SELECT *
        FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND
              IsManual = 0
              
        return 1
    end
    
    -- This order number does not already exist, we need to create it
    else 
    begin
        INSERT INTO [Orders](
            [OrderNumber], 
            [StoreID], 
            [CustomerID], 
            [OrderDate], 
            [ShipFirstName],
            [ShipLastName],
            [ShipCompany],
            [ShipAddress1], 
            [ShipAddress2], 
            [ShipAddress3], 
            [ShipCity], 
            [ShipStateProvinceCode], 
            [ShipPostalCode], 
            [ShipCountryCode], 
            [ShipEmail], 
            [ShipPhone],
            [ShipFax],
            [BillFirstName],
            [BillLastName],
            [BillCompany],
            [BillAddress1], 
            [BillAddress2], 
            [BillAddress3], 
            [BillCity], 
            [BillStateProvinceCode], 
            [BillPostalCode], 
            [BillCountryCode], 
            [BillEmail], 
            [BillPhone],
            [BillFax],
            [CustomerComments],
            [RequestedShipping],
            [Total], 
            [Notes], 
            [Status],
            [IsManual],
            [OrderNumberPrefix],
            [OrderNumberPostfix],
            [eBayOrderID], 
            [eBayBuyerID], 
            [eBayBuyerFeedbackScore],
            [eBayBuyerFeedbackPrivate],
            [eBayLastModified], 
            [eBayPaymentStatus], 
            [eBayPaymentMethod], 
            [eBayIncompleteState], 
            [eBayStatusIs], 
            [eBayLeftFeedback], 
            [eBayLeftFeedbackType], 
            [eBayLeftFeedbackComments], 
            [eBayReceivedFeedbackType], 
            [eBayReceivedFeedbackComments], 
            [eBayMarkedPaymentMethod], 
            [eBayAllowEdit], 
            [MivaBatchID]
        )
        VALUES
        (
            @OrderNumber, 
            @StoreID, 
            @CustomerID, 
            @OrderDate, 
            @ShipFirstName,
            @ShipLastName,
            @ShipCompany,
            @ShipAddress1, 
            @ShipAddress2, 
            @ShipAddress3, 
            @ShipCity, 
            @ShipStateProvinceCode, 
            @ShipPostalCode, 
            @ShipCountryCode, 
            @ShipEmail, 
            @ShipPhone,
            @ShipFax,
            @BillFirstName,
            @BillLastName,
            @BillCompany,
            @BillAddress1, 
            @BillAddress2, 
            @BillAddress3, 
            @BillCity, 
            @BillStateProvinceCode, 
            @BillPostalCode, 
            @BillCountryCode, 
            @BillEmail, 
            @BillPhone,
            @BillFax,
            @CustomerComments,
            @RequestedShipping,
            @Total, 
            @Notes, 
            @Status,
            0, -- IsManual
            @OrderNumberPrefix,
            @OrderNumberPostfix,
            @eBayOrderID, 
            @eBayBuyerID, 
            @eBayBuyerFeedbackScore,
            @eBayBuyerFeedbackPrivate,
            @eBayLastModified, 
            @eBayPaymentStatus, 
            @eBayPaymentMethod, 
            @eBayIncompleteState, 
            @eBayStatusIs, 
            @eBayLeftFeedback, 
            @eBayLeftFeedbackType, 
            @eBayLeftFeedbackComments, 
            @eBayReceivedFeedbackType, 
            @eBayReceivedFeedbackComments, 
            @eBayMarkedPaymentMethod, 
            @eBayAllowEdit, 
            @MivaBatchID
        )
        
        SELECT OrderID, CustomerID, OrderNumber, [RowVersion], IsManual, OrderNumberDisplay
           FROM Orders
           WHERE OrderNumber = @OrderNumber AND StoreID = @StoreID AND IsManual = 0
        
        return @@ROWCOUNT

    end
GO