if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUspsShipments]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUspsShipmentRange]
GO

-----------------------------
--- Procedure GetOrderUspsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsShipments]
GO

CREATE PROCEDURE GetOrderUspsShipments
(
    @OrderID int
)
AS
   SELECT u.*
   FROM UspsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUspsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsShipments]
GO

CREATE PROCEDURE GetCustomerUspsShipments
(
    @CustomerID int
)
AS
   SELECT u.*
   FROM UspsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsShipmentRange]
GO

CREATE PROCEDURE GetOrderUspsShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsShipmentRange]
GO

CREATE PROCEDURE GetCustomerUspsShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO