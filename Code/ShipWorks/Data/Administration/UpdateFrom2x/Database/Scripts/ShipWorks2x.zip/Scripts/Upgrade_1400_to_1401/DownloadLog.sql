----------------------------
--- PROCEDURE GetLatestDownloadLogs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLatestDownloadLogs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [GetLatestDownloadLogs]
GO

CREATE PROCEDURE dbo.GetLatestDownloadLogs
(
   @StoreID int,
   @TopCount int,
   @ExcludeStart int,
   @ExcludeEnd int
)
WITH ENCRYPTION
AS
    DECLARE @RowCount int
    DECLARE @ExcludeCount int
    
    SELECT @ExcludeCount = Count(*)
      FROM DownloadLog
      WHERE (DownloadLogID >= @ExcludeStart AND DownloadLogID <= @ExcludeEnd) AND
            StoreID = @StoreID
      
    SELECT @RowCount = @TopCount - @ExcludeCount
    
    if (@RowCount <= 0)
    begin
        SELECT *
        FROM DownloadLog
        WHERE DownloadLogID < 0
        
        return
    end
    
    SET ROWCOUNT @RowCount
    
    SELECT *
      FROM DownloadLog
      WHERE (DownloadLogID < @ExcludeStart OR DownloadLogID > @ExcludeEnd) AND
            StoreID = @StoreID
      ORDER BY StartTime DESC

    SET ROWCOUNT 0
GO

----------------------------
--- PROCEDURE AddDownloadLog
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDownloadLog]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [AddDownloadLog]
GO

CREATE PROCEDURE dbo.AddDownloadLog
(
	@StoreID int,
	@ClientID int,
	@StartTime datetime,
	@EndTime datetime,
	@QuantityDownloaded int,
	@QuantityNew int,
	@AutoDownload bit,
	@Result int,
	@ErrorMessage nvarchar(150)
)
WITH ENCRYPTION
AS
    INSERT INTO DownloadLog
    (
	    [StoreID],
	    [ClientID],
	    [StartTime],
	    [EndTime],
	    [QuantityDownloaded],
	    [QuantityNew],
	    [AutoDownload],
	    [Result],
	    [ErrorMessage]
	)
	VALUES
	(
		@StoreID,
	    @ClientID,
	    @StartTime,
	    @EndTime,
	    @QuantityDownloaded,
	    @QuantityNew,
	    @AutoDownload,
	    @Result,
	    @ErrorMessage
	)
	
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT SCOPE_IDENTITY() AS DownloadLogID

   return 1
GO

