-----------------------------
--- Procedure GetOrderDhlShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderDhlShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderDhlShipmentRange]
GO

CREATE PROCEDURE dbo.GetOrderDhlShipmentRange
(
	@StoreID int,
	@DateRangeMax datetime,
	@DateRangeMin datetime,
	@MinOrderID int
)
WITH ENCRYPTION
AS 
	SELECT u.*
		FROM DhlShipments u, Shipments s, Orders o
		WHERE u.ShipmentID = s.ShipmentID AND
			s.StoreID = @StoreID AND
			s.OrderID = o.OrderID AND
			((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
			o.OrderID > @MinOrderID
GO