----------------------------
--- Database Schema Version 
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetSchemaVersion]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetSchemaVersion]
GO

CREATE PROCEDURE dbo.GetSchemaVersion 
AS 
SELECT '1.3.0.4' AS 'SchemaVersion'
GO
