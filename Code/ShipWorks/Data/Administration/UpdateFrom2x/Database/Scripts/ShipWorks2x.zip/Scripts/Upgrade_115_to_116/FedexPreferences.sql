-----------------------------
--- TABLE FedexPreferences
-----------------------------
CREATE TABLE FedexPreferences
(
    ClientID int NOT NULL,
    StoreID int NOT NULL,
    DefaultShipperID int NOT NULL ,
    DefaultTemplate nvarchar (50) NOT NULL,
    ThermalPrinterName nvarchar (350) NOT NULL,
	CONSTRAINT [PK_FedexPreferences] PRIMARY KEY CLUSTERED ([ClientID], [StoreID]) ,
	CONSTRAINT [FK_FedexPreferences_Clients] FOREIGN KEY ([ClientID]) REFERENCES [Clients] ([ClientID]),
	CONSTRAINT [FK_FedexPreferences_Stores] FOREIGN KEY ([StoreID]) REFERENCES [Stores] ([StoreID])
)
GO

----------------------------
--- PROCEDURE GetFedexPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetFedexPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetFedexPreferences]
GO

CREATE PROCEDURE GetFedexPreferences
(
    @StoreID int,
    @ClientID int
)
AS
   SELECT *
     FROM FedexPreferences
     WHERE StoreID = @StoreID AND ClientID = @ClientID
GO

----------------------------
--- PROCEDURE AddFedexPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFedexPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddFedexPreferences]
GO

CREATE PROCEDURE AddFedexPreferences
(
    @ClientID int ,
    @StoreID int ,
    @DefaultShipperID int  ,
    @DefaultTemplate nvarchar (50) ,
    @ThermalPrinterName nvarchar (350)
)
AS
   INSERT INTO FedexPreferences
   (
        ClientID,
        StoreID,
        DefaultShipperID,
        DefaultTemplate,
        ThermalPrinterName
   )
   VALUES
   (
        @ClientID,
        @StoreID,
        @DefaultShipperID,
        @DefaultTemplate,
        @ThermalPrinterName
   )
   
    if (@@ROWCOUNT != 1)
        return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
     FROM FedexPreferences
     WHERE StoreID = @StoreID AND ClientID = @ClientID

   return 1
GO

----------------------------
--- PROCEDURE UpdateFedexPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFedexPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateFedexPreferences]
GO

CREATE PROCEDURE UpdateFedexPreferences
(
    @ClientID int ,
    @StoreID int ,
    @DefaultShipperID int  ,
    @DefaultTemplate nvarchar (50) ,
    @ThermalPrinterName nvarchar (350)
)
AS
   UPDATE FedexPreferences
   SET  ClientID = @ClientID,
        StoreID = @StoreID,
        DefaultShipperID = @DefaultShipperID,
        DefaultTemplate = @DefaultTemplate,
        ThermalPrinterName = @ThermalPrinterName
   WHERE StoreID = @StoreID AND ClientID = @ClientID
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
   FROM FedexPreferences
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO