ALTER TABLE Orders
   ALTER COLUMN Notes nvarchar (1500) NOT NULL
GO

ALTER TABLE Orders
   ALTER COLUMN ShipStateProvinceCode nvarchar (25) NOT NULL
GO

ALTER TABLE Orders
   ALTER COLUMN BillStateProvinceCode nvarchar (25) NOT NULL
GO

-----------------------------
--- Procedure GetChangedOrders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedOrders]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedOrders]
GO

CREATE PROCEDURE GetChangedOrders
(
   @LastDBTS rowversion,
   @StoreID int
)
AS

   SELECT o.*
      FROM Orders o
      WHERE (o.RowVersion > @LastDBTS AND o.StoreID = @StoreID)

GO
