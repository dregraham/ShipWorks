ALTER TABLE dbo.Orders
	DROP CONSTRAINT FK_Orders_Stores
GO

CREATE TABLE dbo.Tmp_Orders
	(
	OrderID int NOT NULL IDENTITY (1, 1),
	RowVersion timestamp NOT NULL,
	OrderNumber int NOT NULL,
	StoreID int NOT NULL,
	CustomerID int NOT NULL,
	OrderDate datetime NOT NULL,
	ShipFirstName nvarchar(30) NOT NULL,
	ShipLastName nvarchar(30) NOT NULL,
	ShipCompany nvarchar(30) NOT NULL,
	ShipAddress1 nvarchar(60) NOT NULL,
	ShipAddress2 nvarchar(60) NOT NULL,
	ShipAddress3 nvarchar(60) NOT NULL,
	ShipCity nvarchar(50) NOT NULL,
	ShipStateProvinceCode nvarchar(25) NOT NULL,
	ShipPostalCode nvarchar(10) NOT NULL,
	ShipCountryCode nvarchar(5) NOT NULL,
	ShipEmail nvarchar(50) NOT NULL,
	ShipPhone nvarchar(25) NOT NULL,
	ShipFax nvarchar(25) NOT NULL,
	BillFirstName nvarchar(30) NOT NULL,
	BillLastName nvarchar(30) NOT NULL,
	BillCompany nvarchar(30) NOT NULL,
	BillAddress1 nvarchar(60) NOT NULL,
	BillAddress2 nvarchar(60) NOT NULL,
	BillAddress3 nvarchar(60) NOT NULL,
	BillCity nvarchar(50) NOT NULL,
	BillStateProvinceCode nvarchar(25) NOT NULL,
	BillPostalCode nvarchar(10) NOT NULL,
	BillCountryCode nvarchar(5) NOT NULL,
	BillEmail nvarchar(50) NOT NULL,
	BillPhone nvarchar(25) NOT NULL,
	BillFax nvarchar(25) NOT NULL,
	CustomerComments ntext NOT NULL,
	RequestedShipping nvarchar(50) NOT NULL,
	Total money NOT NULL,
	Notes ntext NOT NULL,
	Status nvarchar(50) NOT NULL,
	IsManual bit NOT NULL,
	OrderNumberPrefix nvarchar (10),
	OrderNumberPostfix nvarchar (10),
    OrderNumberDisplay AS (OrderNumberPrefix + convert(nvarchar(30),OrderNumber) + OrderNumberPostfix),
	eBayOrderID int NOT NULL,
	eBayBuyerID nvarchar(50) NOT NULL,
	eBayBuyerFeedbackScore int NOT NULL,
	eBayBuyerFeedbackPrivate bit NOT NULL,
	eBayLastModified datetime NOT NULL,
	eBayPaymentStatus int NOT NULL,
	eBayPaymentMethod int NOT NULL,
	eBayIncompleteState int NOT NULL,
	eBayStatusIs int NOT NULL,
	eBayLeftFeedback bit NOT NULL,
	eBayLeftFeedbackType int NOT NULL,
	eBayLeftFeedbackComments nvarchar(80) NOT NULL,
	eBayReceivedFeedbackType int NOT NULL,
	eBayReceivedFeedbackComments nvarchar(80) NOT NULL,
	eBayMarkedPaymentMethod int NOT NULL,
	eBayAllowEdit bit NOT NULL,
	MivaBatchID int NOT NULL
	)
GO

SET IDENTITY_INSERT dbo.Tmp_Orders ON
GO

IF EXISTS(SELECT * FROM dbo.Orders)
	 EXEC('INSERT INTO dbo.Tmp_Orders (OrderID, OrderNumber, StoreID, CustomerID, OrderDate, ShipFirstName, ShipLastName, ShipCompany, ShipAddress1, ShipAddress2, ShipAddress3, ShipCity, ShipStateProvinceCode, ShipPostalCode, ShipCountryCode, ShipEmail, ShipPhone, ShipFax, BillFirstName, BillLastName, BillCompany, BillAddress1, BillAddress2, BillAddress3, BillCity, BillStateProvinceCode, BillPostalCode, BillCountryCode, BillEmail, BillPhone, BillFax, CustomerComments, RequestedShipping,     Total, Notes, Status, IsManual, OrderNumberPrefix, OrderNumberPostfix, eBayOrderID, eBayBuyerID, eBayBuyerFeedbackScore, eBayBuyerFeedbackPrivate, eBayLastModified, eBayPaymentStatus, eBayPaymentMethod, eBayIncompleteState, eBayStatusIs, eBayLeftFeedback, eBayLeftFeedbackType, eBayLeftFeedbackComments, eBayReceivedFeedbackType, eBayReceivedFeedbackComments, eBayMarkedPaymentMethod, eBayAllowEdit, MivaBatchID)
		                        SELECT OrderID, OrderNumber, StoreID, CustomerID, OrderDate, ShipFirstName, ShipLastName, ShipCompany, ShipAddress1, ShipAddress2, ShipAddress3, ShipCity, ShipStateProvinceCode, ShipPostalCode, ShipCountryCode, ShipEmail, ShipPhone, ShipFax, BillFirstName, BillLastName, BillCompany, BillAddress1, BillAddress2, BillAddress3, BillCity, BillStateProvinceCode, BillPostalCode, BillCountryCode, BillEmail, BillPhone, BillFax, "",               MivaRequestedShipping, Total, Notes, Status, IsManual, "",                "",                 eBayOrderID, eBayBuyerID, eBayBuyerFeedbackScore, eBayBuyerFeedbackPrivate, eBayLastModified, eBayPaymentStatus, eBayPaymentMethod, eBayIncompleteState, eBayStatusIs, eBayLeftFeedback, eBayLeftFeedbackType, eBayLeftFeedbackComments, eBayReceivedFeedbackType, eBayReceivedFeedbackComments, eBayMarkedPaymentMethod, eBayAllowEdit, MivaBatchID 
		   FROM dbo.Orders TABLOCKX')
GO

SET IDENTITY_INSERT dbo.Tmp_Orders OFF
GO

ALTER TABLE dbo.Shipments
	DROP CONSTRAINT FK_Shipments_Orders
GO

ALTER TABLE dbo.OrderCharges
	DROP CONSTRAINT FK_OrderCharges_Orders
GO

ALTER TABLE dbo.PaymentDetails
	DROP CONSTRAINT FK_PaymentDetails_Orders
GO

ALTER TABLE dbo.OrderItems
	DROP CONSTRAINT FK_OrderItems_Orders
GO

ALTER TABLE dbo.MivaSebenzaMsgs
	DROP CONSTRAINT FK_MivaSebenzaMsgs_Orders
GO

DROP TABLE dbo.Orders
GO

EXECUTE sp_rename N'dbo.Tmp_Orders', N'Orders', 'OBJECT'
GO

ALTER TABLE dbo.Orders ADD CONSTRAINT
	PK_Orders PRIMARY KEY CLUSTERED 
	(
	OrderID
	)

GO

ALTER TABLE dbo.Orders ADD CONSTRAINT
	IX_OrdersStores UNIQUE NONCLUSTERED 
	(
	OrderNumber,
	StoreID,
	IsManual
	)

GO

CREATE NONCLUSTERED INDEX IX_Orders_OrderDate ON dbo.Orders
	(
	OrderDate
	)
GO

-- Create an index on the order number.
CREATE INDEX IX_Orders_OrderNumber
    ON Orders (OrderNumber)
GO

ALTER TABLE dbo.Orders WITH NOCHECK ADD CONSTRAINT
	FK_Orders_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

CREATE TRIGGER TG_Orders ON dbo.Orders FOR UPDATE
AS
    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID FROM inserted
       
    EXEC SetTableLastDbts 'Orders', @StoreID, @@DBTS
GO

ALTER TABLE dbo.MivaSebenzaMsgs WITH NOCHECK ADD CONSTRAINT
	FK_MivaSebenzaMsgs_Orders FOREIGN KEY
	(
	OrderID
	) REFERENCES dbo.Orders
	(
	OrderID
	)
GO

ALTER TABLE dbo.OrderItems WITH NOCHECK ADD CONSTRAINT
	FK_OrderItems_Orders FOREIGN KEY
	(
	OrderID
	) REFERENCES dbo.Orders
	(
	OrderID
	)
GO

ALTER TABLE dbo.PaymentDetails WITH NOCHECK ADD CONSTRAINT
	FK_PaymentDetails_Orders FOREIGN KEY
	(
	OrderID
	) REFERENCES dbo.Orders
	(
	OrderID
	)
GO

ALTER TABLE dbo.OrderCharges WITH NOCHECK ADD CONSTRAINT
	FK_OrderCharges_Orders FOREIGN KEY
	(
	OrderID
	) REFERENCES dbo.Orders
	(
	OrderID
	)
GO

ALTER TABLE dbo.Shipments WITH NOCHECK ADD CONSTRAINT
	FK_Shipments_Orders FOREIGN KEY
	(
	OrderID
	) REFERENCES dbo.Orders
	(
	OrderID
	)
GO

-----------------------------
--- Procedure GetOrderRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderRange]
GO

CREATE PROCEDURE GetOrderRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT *
   FROM [Orders]
   WHERE StoreID = @StoreID AND 
         OrderDate >= @DateRangeMin AND OrderDate <= @DateRangeMax AND
         OrderID > @MinOrderID
GO

-----------------------------
--- Procedure GetOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrder]
GO

CREATE PROCEDURE GetOrder
(
    @OrderID int
)
AS
   SELECT *
   FROM [Orders]
   WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure DoesOrderExist
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DoesOrderExist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DoesOrderExist]
GO

CREATE PROCEDURE DoesOrderExist
(
    @OrderID int
)
AS
   if exists (SELECT * FROM [Orders] WHERE OrderID = @OrderID)
      SELECT 1
   else
      SELECT 0
GO

-----------------------------
--- Procedure DoesOrderNumberExist
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DoesOrderNumberExist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DoesOrderNumberExist]
GO

CREATE PROCEDURE DoesOrderNumberExist
(
    @StoreID int,
    @OrderNumber int,
    @IsManual bit
)
AS
   if exists (SELECT * FROM [Orders] WHERE StoreID = @StoreID AND OrderNumber = @OrderNumber AND IsManual = @IsManual)
      SELECT 1
   else
      SELECT 0
GO

-----------------------------
--- Procedure DeleteOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteOrder]
GO

CREATE PROCEDURE DeleteOrder
(
    @OrderID int
)
AS
   DELETE OrderItemAttributes
     FROM OrderItemAttributes a, OrderItems i, Orders o
     WHERE a.OrderItemID = i.OrderItemID AND i.OrderID = o.OrderID AND o.OrderID = @OrderID
     
   DELETE FROM OrderItems
     WHERE OrderID = @OrderID
     
   DELETE FROM OrderCharges
     WHERE OrderID = @OrderID
     
   DELETE FROM PaymentDetails
     WHERE OrderID = @OrderID
     
   DELETE FROM MivaSebenzaMsgs
     WHERE OrderID = @OrderID
     
    DELETE UpsPackages
      FROM UpsPackages p, Shipments s, Orders o
      WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.OrderID = @OrderID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.OrderID = @OrderID
     
   DELETE UpsShipments
     FROM UpsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.OrderID = @OrderID
     
   DELETE FROM Shipments
     WHERE OrderID = @OrderID

   DELETE FROM [Orders]
     WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure GetOrderCount
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderCount]
GO

CREATE PROCEDURE GetOrderCount
(
    @StoreID int
)
AS
   SELECT Count(*) AS OrderCount
      FROM Orders
      WHERE StoreID = @StoreID
GO

-----------------------------
--- Procedure GetChangedOrders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedOrders]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedOrders]
GO

CREATE PROCEDURE GetChangedOrders
(
   @LastDBTS rowversion,
   @MaxOrderID int,
   @StoreID int
)
AS

   SELECT o.*
      FROM Orders o
      WHERE (o.RowVersion > @LastDBTS AND o.StoreID = @StoreID) AND
            (o.OrderID <= @MaxOrderID OR @MaxOrderID < 0)

GO

-----------------------------
--- Procedure AddOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddOrder]
GO

CREATE PROCEDURE AddOrder
(
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @IsManual bit,
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int]
)
AS
    if (@OrderNumber <= 0)
    begin
      
        -- Determine the next OrderNumber to use
        SELECT @OrderNumber = MAX(OrderNumber) + 1
          FROM Orders
          WHERE StoreID = @StoreID
        
        if (@OrderNumber IS NULL)
           SELECT @OrderNumber = 1
           
    end

    INSERT INTO [Orders](
        [OrderNumber], 
        [StoreID], 
        [CustomerID], 
        [OrderDate], 
        [ShipFirstName],
        [ShipLastName],
        [ShipCompany],
        [ShipAddress1], 
        [ShipAddress2], 
        [ShipAddress3], 
        [ShipCity], 
        [ShipStateProvinceCode], 
        [ShipPostalCode], 
        [ShipCountryCode], 
        [ShipEmail], 
        [ShipPhone],
        [ShipFax],
        [BillFirstName],
        [BillLastName],
        [BillCompany],
        [BillAddress1], 
        [BillAddress2], 
        [BillAddress3], 
        [BillCity], 
        [BillStateProvinceCode], 
        [BillPostalCode], 
        [BillCountryCode], 
        [BillEmail], 
        [BillPhone],
        [BillFax],
        [CustomerComments],
        [RequestedShipping],
        [Total], 
        [Notes], 
        [Status],
        [IsManual],
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [eBayOrderID], 
        [eBayBuyerID], 
        [eBayBuyerFeedbackScore],
        [eBayBuyerFeedbackPrivate],
        [eBayLastModified], 
        [eBayPaymentStatus], 
        [eBayPaymentMethod], 
        [eBayIncompleteState], 
        [eBayStatusIs], 
        [eBayLeftFeedback], 
        [eBayLeftFeedbackType], 
        [eBayLeftFeedbackComments], 
        [eBayReceivedFeedbackType], 
        [eBayReceivedFeedbackComments], 
        [eBayMarkedPaymentMethod], 
        [eBayAllowEdit], 
        [MivaBatchID]
    )
    VALUES
    (
        @OrderNumber, 
        @StoreID, 
        @CustomerID, 
        @OrderDate, 
        @ShipFirstName,
        @ShipLastName,
        @ShipCompany,
        @ShipAddress1, 
        @ShipAddress2, 
        @ShipAddress3, 
        @ShipCity, 
        @ShipStateProvinceCode, 
        @ShipPostalCode, 
        @ShipCountryCode, 
        @ShipEmail, 
        @ShipPhone,
        @ShipFax,
        @BillFirstName,
        @BillLastName,
        @BillCompany,
        @BillAddress1, 
        @BillAddress2, 
        @BillAddress3, 
        @BillCity, 
        @BillStateProvinceCode, 
        @BillPostalCode, 
        @BillCountryCode, 
        @BillEmail, 
        @BillPhone,
        @BillFax,
        @CustomerComments,
        @RequestedShipping,
        @Total, 
        @Notes, 
        @Status,
        @IsManual,
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @eBayOrderID, 
        @eBayBuyerID, 
        @eBayBuyerFeedbackScore,
        @eBayBuyerFeedbackPrivate,
        @eBayLastModified, 
        @eBayPaymentStatus, 
        @eBayPaymentMethod, 
        @eBayIncompleteState, 
        @eBayStatusIs, 
        @eBayLeftFeedback, 
        @eBayLeftFeedbackType, 
        @eBayLeftFeedbackComments, 
        @eBayReceivedFeedbackType, 
        @eBayReceivedFeedbackComments, 
        @eBayMarkedPaymentMethod, 
        @eBayAllowEdit, 
        @MivaBatchID
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT OrderID, OrderNumber, [RowVersion], IsManual, OrderNumberDisplay
    FROM Orders
    WHERE OrderID = SCOPE_IDENTITY()
    
    return 1
GO

-----------------------------
--- Procedure UpdateOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateOrder]
GO

CREATE PROCEDURE UpdateOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int]
)
AS       
    UPDATE Orders
    SET OrderNumber = @OrderNumber,
        StoreID = @StoreID,
        CustomerID = @CustomerID,
        OrderDate = @OrderDate,
	    ShipFirstName = @ShipFirstName,
	    ShipLastName = @ShipLastName,
	    ShipCompany = @ShipCompany,
        ShipAddress1 = @ShipAddress1,
        ShipAddress2 = @ShipAddress2,
        ShipAddress3 = @ShipAddress3,
        ShipCity = @ShipCity,
        ShipStateProvinceCode = @ShipStateProvinceCode,
        ShipPostalCode = @ShipPostalCode,
        ShipCountryCode = @ShipCountryCode,
        ShipEmail = @ShipEmail,
        ShipPhone = @ShipPhone,
        ShipFax = @ShipFax,
	    BillFirstName = @BillFirstName,
	    BillLastName = @BillLastName,
	    BillCompany = @BillCompany,
        BillAddress1 = @BillAddress1,
        BillAddress2 = @BillAddress2,
        BillAddress3 = @BillAddress3,
        BillCity = @BillCity,
        BillStateProvinceCode = @BillStateProvinceCode,
        BillPostalCode = @BillPostalCode,
        BillCountryCode = @BillCountryCode,
        BillEmail = @BillEmail,
        BillPhone = @BillPhone,
        BillFax = @BillFax,
        CustomerComments = @CustomerComments,
        RequestedShipping = @RequestedShipping,
        Total = @Total,
        Notes = @Notes,
        Status = @Status,
        OrderNumberPrefix = @OrderNumberPrefix,
        OrderNumberPostfix = @OrderNumberPostfix,
        eBayOrderID = @eBayOrderID,
        eBayBuyerID = @eBayBuyerID,
        eBayBuyerFeedbackScore = @eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate = @eBayBuyerFeedbackPrivate,
        eBayLastModified = @eBayLastModified,
        eBayPaymentStatus = @eBayPaymentStatus,
        eBayPaymentMethod = @eBayPaymentMethod,
        eBayIncompleteState = @eBayIncompleteState,
        eBayStatusIs = @eBayStatusIs,
        eBayLeftFeedback = @eBayLeftFeedback,
        eBayLeftFeedbackType = @eBayLeftFeedbackType,
        eBayLeftFeedbackComments = @eBayLeftFeedbackComments,
        eBayReceivedFeedbackType = @eBayReceivedFeedbackType,
        eBayReceivedFeedbackComments = @eBayReceivedFeedbackComments,
        eBayMarkedPaymentMethod = @eBayMarkedPaymentMethod,
        eBayAllowEdit = @eBayAllowEdit,
        MivaBatchID = @MivaBatchID
    WHERE OrderID = @OrderID AND [RowVersion] = @RowVersion

    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT [RowVersion], OrderNumberDisplay
    FROM Orders
    WHERE [OrderID] = @OrderID
            
    return 1
GO

-----------------------------
--- Procedure IsEBayOrderEditAllowed
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IsEBayOrderEditAllowed]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[IsEBayOrderEditAllowed]
GO

CREATE PROCEDURE IsEBayOrderEditAllowed
(
    @OrderID [int],
    @EditAllowed bit OUTPUT
)
AS
    SELECT @EditAllowed = eBayAllowEdit
      FROM Orders
      WHERE OrderID = @OrderID
      
    if (@EditAllowed IS NULL)
      SELECT @EditAllowed = 0
GO

-----------------------------
--- Procedure SynchEBayOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchEBayOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchEBayOrder]
GO

CREATE PROCEDURE SynchEBayOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int],
	@eBayItemID bigint,
	@eBayTransID bigint,
    @WasNew [bit] OUTPUT
)
AS 
    -- Assume its new by default
    SELECT @WasNew = 1

    -- If this eBay order already exists as a combined order
    if exists (
        SELECT * 
        FROM Orders
        WHERE @eBayOrderID != 0 AND 
              eBayOrderID = @eBayOrderID AND
              StoreID = @StoreID
    )
    begin
        
        SELECT @OrderID = MAX(OrderID), @OrderNumber = MAX(OrderNumber)
        FROM Orders
        WHERE eBayOrderID = @eBayOrderID AND
              StoreID = @StoreID
        
        -- Its not new
        SELECT @WasNew = 0
        
    end
    
    -- See if this eBay order exists as a single item, which we will find in the items table
    else if exists (
        SELECT * 
        FROM Orders o, OrderItems i
        WHERE @eBayItemID != 0 AND 
              i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              o.OrderID = i.OrderID AND 
              o.StoreID = @StoreID
    )
    begin
    
        SELECT @OrderID = MAX(o.OrderID), @OrderNumber = MAX(o.OrderNumber)
        FROM Orders o, OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              o.OrderID = i.OrderID AND 
              o.StoreID = @StoreID
              
        -- Its not new
        SELECT @WasNew = 0

    end
    
    -- If its new, then create the order
    if (@WasNew != 0)
    begin       
        -- Determine the next OrderNumber to use
        SELECT @OrderNumber = MAX(OrderNumber) + 1
          FROM Orders
          WHERE StoreID = @StoreID
        
        if (@OrderNumber IS NULL)
           SELECT @OrderNumber = 1
    
        INSERT INTO [Orders](
            [OrderNumber], 
            [StoreID], 
            [CustomerID], 
            [OrderDate], 
            [ShipFirstName],
            [ShipLastName],
            [ShipCompany],
            [ShipAddress1], 
            [ShipAddress2], 
            [ShipAddress3], 
            [ShipCity], 
            [ShipStateProvinceCode], 
            [ShipPostalCode], 
            [ShipCountryCode], 
            [ShipEmail], 
            [ShipPhone],
            [ShipFax],
            [BillFirstName],
            [BillLastName],
            [BillCompany],
            [BillAddress1], 
            [BillAddress2], 
            [BillAddress3], 
            [BillCity], 
            [BillStateProvinceCode], 
            [BillPostalCode], 
            [BillCountryCode], 
            [BillEmail], 
            [BillPhone],
            [BillFax],
            [CustomerComments],
            [RequestedShipping],
            [Total], 
            [Notes], 
            [Status],
            [IsManual],
            [OrderNumberPrefix],
            [OrderNumberPostfix],
            [eBayOrderID], 
            [eBayBuyerID], 
            [eBayBuyerFeedbackScore],
            [eBayBuyerFeedbackPrivate],
            [eBayLastModified], 
            [eBayPaymentStatus], 
            [eBayPaymentMethod], 
            [eBayIncompleteState], 
            [eBayStatusIs], 
            [eBayLeftFeedback], 
            [eBayLeftFeedbackType], 
            [eBayLeftFeedbackComments], 
            [eBayReceivedFeedbackType], 
            [eBayReceivedFeedbackComments], 
            [eBayMarkedPaymentMethod], 
            [eBayAllowEdit], 
            [MivaBatchID] 
        )
        VALUES
        (
            @OrderNumber, 
            @StoreID, 
            @CustomerID, 
            @OrderDate, 
            @ShipFirstName,
            @ShipLastName,
            @ShipCompany,
            @ShipAddress1, 
            @ShipAddress2, 
            @ShipAddress3, 
            @ShipCity, 
            @ShipStateProvinceCode, 
            @ShipPostalCode, 
            @ShipCountryCode, 
            @ShipEmail, 
            @ShipPhone,
            @ShipFax,
            @BillFirstName,
            @BillLastName,
            @BillCompany,
            @BillAddress1, 
            @BillAddress2, 
            @BillAddress3, 
            @BillCity, 
            @BillStateProvinceCode, 
            @BillPostalCode, 
            @BillCountryCode, 
            @BillEmail, 
            @BillPhone,
            @BillFax,
            @CustomerComments,
            @RequestedShipping,
            @Total, 
            @Notes, 
            @Status,
            0, -- IsManual
            @OrderNumberPrefix,
            @OrderNumberPostfix,
            @eBayOrderID, 
            @eBayBuyerID, 
            @eBayBuyerFeedbackScore,
            @eBayBuyerFeedbackPrivate,
            @eBayLastModified, 
            @eBayPaymentStatus, 
            @eBayPaymentMethod, 
            @eBayIncompleteState, 
            @eBayStatusIs, 
            @eBayLeftFeedback, 
            @eBayLeftFeedbackType, 
            @eBayLeftFeedbackComments, 
            @eBayReceivedFeedbackType, 
            @eBayReceivedFeedbackComments, 
            @eBayMarkedPaymentMethod, 
            @eBayAllowEdit, 
            @MivaBatchID 
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderID, OrderNumber, [RowVersion], IsManual, OrderNumberDisplay
        FROM Orders
        WHERE OrderID = SCOPE_IDENTITY()
        
        return 1
    end
    
    -- Its not new, we have to update it
    else
    begin
    
        UPDATE Orders
        SET OrderNumber = @OrderNumber,
            StoreID = @StoreID,
            CustomerID = @CustomerID,
            OrderDate = @OrderDate,
	        ShipFirstName = @ShipFirstName,
	        ShipLastName = @ShipLastName,
	        ShipCompany = @ShipCompany,
            ShipAddress1 = @ShipAddress1,
            ShipAddress2 = @ShipAddress2,
            ShipAddress3 = @ShipAddress3,
            ShipCity = @ShipCity,
            ShipStateProvinceCode = @ShipStateProvinceCode,
            ShipPostalCode = @ShipPostalCode,
            ShipCountryCode = @ShipCountryCode,
            ShipEmail = @ShipEmail,
            ShipPhone = @ShipPhone,
            ShipFax = @ShipFax,
	        BillFirstName = @BillFirstName,
	        BillLastName = @BillLastName,
	        BillCompany = @BillCompany,
            BillAddress1 = @BillAddress1,
            BillAddress2 = @BillAddress2,
            BillAddress3 = @BillAddress3,
            BillCity = @BillCity,
            BillStateProvinceCode = @BillStateProvinceCode,
            BillPostalCode = @BillPostalCode,
            BillCountryCode = @BillCountryCode,
            BillEmail = @BillEmail,
            BillPhone = @BillPhone,
            BillFax = @BillFax,
            CustomerComments = @CustomerComments,
            RequestedShipping = @RequestedShipping,
            Total = @Total,
            Notes = @Notes,
            Status = @Status,
            OrderNumberPrefix = @OrderNumberPrefix,
            OrderNumberPostfix = @OrderNumberPostfix,
            eBayOrderID = @eBayOrderID,
            eBayBuyerID = @eBayBuyerID,
            eBayBuyerFeedbackScore = @eBayBuyerFeedbackScore,
            eBayBuyerFeedbackPrivate = @eBayBuyerFeedbackPrivate,
            eBayLastModified = @eBayLastModified,
            eBayPaymentStatus = @eBayPaymentStatus,
            eBayPaymentMethod = @eBayPaymentMethod,
            eBayIncompleteState = @eBayIncompleteState,
            eBayStatusIs = @eBayStatusIs,
            eBayLeftFeedback = @eBayLeftFeedback,
            eBayLeftFeedbackType = @eBayLeftFeedbackType,
            eBayLeftFeedbackComments = @eBayLeftFeedbackComments,
            eBayReceivedFeedbackType = @eBayReceivedFeedbackType,
            eBayReceivedFeedbackComments = @eBayReceivedFeedbackComments,
            eBayMarkedPaymentMethod = @eBayMarkedPaymentMethod,
            eBayAllowEdit = @eBayAllowEdit,
            MivaBatchID = @MivaBatchID
        WHERE OrderID = @OrderID
    
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderID, OrderNumber, [RowVersion], OrderNumberDisplay
        FROM Orders
        WHERE OrderID = @OrderID
        
        return 1
    end
GO

-----------------------------
--- Procedure SaveEBayFeedback
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveEBayFeedback]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveEBayFeedback]
GO

CREATE PROCEDURE SaveEBayFeedback
(
   @OrderID [int],
   @eBayLeftFeedback [bit],
   @eBayLeftFeedbackType [int],
   @eBayLeftFeedbackComments [nvarchar] (80),
   @eBayReceivedFeedbackType [int],
   @eBayReceivedFeedbackComments [nvarchar] (80)
)
AS
   -- We can safely update the received feedback
   UPDATE Orders
     SET [eBayReceivedFeedbackType] = @eBayReceivedFeedbackType,
         [eBayReceivedFeedbackComments] = @eBayReceivedFeedbackComments
     WHERE OrderID = @OrderID
   
   -- Determine if we know feedback has already been left
   DECLARE @feedbackLeft bit
   SELECT @feedbackLeft = eBayLeftFeedback
     FROM Orders
     WHERE OrderID = @OrderID
     
    if (@@ROWCOUNT != 1)
       return 0
       
   -- Only update the left feedback if it hadnt already been left
   if (@feedbackLeft = 0)
   begin
   
      UPDATE Orders
         SET [eBayLeftFeedback] = @eBayLeftFeedback,
             [eBayLeftFeedbackType] = @eBayLeftFeedbackType,
             [eBayReceivedFeedbackComments] = @eBayReceivedFeedbackComments
         WHERE OrderID = @OrderID
   end
  
    if (@@ROWCOUNT != 1)
       return 0

    SET NOCOUNT ON

    SELECT *
    FROM Orders
    WHERE OrderID = @OrderID

    return 1
GO

-----------------------------
--- Procedure SynchMivaOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaOrder]
GO

CREATE PROCEDURE SynchMivaOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int]
)
AS       
    -- If this Miva order number already exists, just update its batch
    if exists (
        SELECT * FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND
              IsManual = 0 )
    begin
        -- Update the batch id.  Dont worry about RowVersion mismatch - just do it.
        UPDATE Orders
        SET MivaBatchID = @MivaBatchID 
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND 
              IsManual = 0
              
        SET NOCOUNT ON

        -- Select the updated row back into .NET
        SELECT *
        FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND
              IsManual = 0
              
        return 1
    end
    
    -- This order number does not already exist, we need to create it
    else 
    begin
        INSERT INTO [Orders](
            [OrderNumber], 
            [StoreID], 
            [CustomerID], 
            [OrderDate], 
            [ShipFirstName],
            [ShipLastName],
            [ShipCompany],
            [ShipAddress1], 
            [ShipAddress2], 
            [ShipAddress3], 
            [ShipCity], 
            [ShipStateProvinceCode], 
            [ShipPostalCode], 
            [ShipCountryCode], 
            [ShipEmail], 
            [ShipPhone],
            [ShipFax],
            [BillFirstName],
            [BillLastName],
            [BillCompany],
            [BillAddress1], 
            [BillAddress2], 
            [BillAddress3], 
            [BillCity], 
            [BillStateProvinceCode], 
            [BillPostalCode], 
            [BillCountryCode], 
            [BillEmail], 
            [BillPhone],
            [BillFax],
            [CustomerComments],
            [RequestedShipping],
            [Total], 
            [Notes], 
            [Status],
            [IsManual],
            [OrderNumberPrefix],
            [OrderNumberPostfix],
            [eBayOrderID], 
            [eBayBuyerID], 
            [eBayBuyerFeedbackScore],
            [eBayBuyerFeedbackPrivate],
            [eBayLastModified], 
            [eBayPaymentStatus], 
            [eBayPaymentMethod], 
            [eBayIncompleteState], 
            [eBayStatusIs], 
            [eBayLeftFeedback], 
            [eBayLeftFeedbackType], 
            [eBayLeftFeedbackComments], 
            [eBayReceivedFeedbackType], 
            [eBayReceivedFeedbackComments], 
            [eBayMarkedPaymentMethod], 
            [eBayAllowEdit], 
            [MivaBatchID]
        )
        VALUES
        (
            @OrderNumber, 
            @StoreID, 
            @CustomerID, 
            @OrderDate, 
            @ShipFirstName,
            @ShipLastName,
            @ShipCompany,
            @ShipAddress1, 
            @ShipAddress2, 
            @ShipAddress3, 
            @ShipCity, 
            @ShipStateProvinceCode, 
            @ShipPostalCode, 
            @ShipCountryCode, 
            @ShipEmail, 
            @ShipPhone,
            @ShipFax,
            @BillFirstName,
            @BillLastName,
            @BillCompany,
            @BillAddress1, 
            @BillAddress2, 
            @BillAddress3, 
            @BillCity, 
            @BillStateProvinceCode, 
            @BillPostalCode, 
            @BillCountryCode, 
            @BillEmail, 
            @BillPhone,
            @BillFax,
            @CustomerComments,
            @RequestedShipping,
            @Total, 
            @Notes, 
            @Status,
            0, -- IsManual
            @OrderNumberPrefix,
            @OrderNumberPostfix,
            @eBayOrderID, 
            @eBayBuyerID, 
            @eBayBuyerFeedbackScore,
            @eBayBuyerFeedbackPrivate,
            @eBayLastModified, 
            @eBayPaymentStatus, 
            @eBayPaymentMethod, 
            @eBayIncompleteState, 
            @eBayStatusIs, 
            @eBayLeftFeedback, 
            @eBayLeftFeedbackType, 
            @eBayLeftFeedbackComments, 
            @eBayReceivedFeedbackType, 
            @eBayReceivedFeedbackComments, 
            @eBayMarkedPaymentMethod, 
            @eBayAllowEdit, 
            @MivaBatchID
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderID, [RowVersion], IsManual, OrderNumberDisplay
        FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber

        return 1
    end
GO