ALTER TABLE dbo.FedexPreferences ADD
	BlankRecipientPhone nvarchar(25) NOT NULL CONSTRAINT DF_FedexPreferences_BlankRecipientPhone DEFAULT '999-999-9999'
GO
ALTER TABLE dbo.FedexPreferences DROP CONSTRAINT DF_FedexPreferences_BlankRecipientPhone
GO

----------------------------
--- PROCEDURE GetFedexPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetFedexPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetFedexPreferences]
GO

CREATE PROCEDURE dbo.GetFedexPreferences
(
    @StoreID int,
    @ClientID int
)
WITH ENCRYPTION
AS
   -- See if there are any prefs for this store\client
   if (0 = (SELECT COUNT(*)
                FROM FedexPreferences
                WHERE StoreID = @StoreID AND ClientID = @ClientID) )
   begin
   
      -- There are not.  See if there are any for the store to use as a starting point
        INSERT INTO FedexPreferences 
        (
            ClientID,
            StoreID,
            DefaultShipperID,
            DefaultDomesticService,
            DefaultInternationalService,
            DefaultTemplate,
            ThermalPrinterName,
            UseThermalLabels,
            ThermalLabelDocTabType,
		    ReferenceNumber,
		    PackagingType,
		    PackagingLength,
		    PackagingWidth,
		    PackagingHeight ,
		    SignatureOption,
		    PayorType,
		    PayorAccountNumber,
		    DutiesPayorType,
		    DutiesPayorAccountNumber,
		    ShipAlertRecipientAddressUseBill,
		    ShipAlertRecipientShip,
		    ShipAlertRecipientDelivery,
		    ShipAlertSenderShip,
		    ShipAlertSenderDelivery,
		    ShipAlertOther1Address,
		    ShipAlertOther1Ship,
		    ShipAlertOther1Delivery,
		    ShipAlertExpressMessage,
		    ShipAlertGroundEnable,
		    ShipAlertGroundAddressUseBill,
		    ShipAlertGroundMessage,
		    CodEnable,
		    CodType,
		    CodAddFreight,
		    CodUseShipperAddress,
		    CodReturnContactName,
		    CodReturnCompany,
		    CodReturnAddress1,
		    CodReturnAddress2,
		    CodReturnCity,
		    CodReturnStateProvinceCode,
		    CodReturnPostalCode,
		    CodReturnPhone,
		    BrokerEnable,
		    BrokerAccount,
		    BrokerContactName,
		    BrokerCompany,
		    BrokerAddress1,
		    BrokerAddress2,
		    BrokerCity,
		    BrokerStateProvinceCode,
		    BrokerPostalCode,
		    BrokerPhone,
		    MaskAccountNumber,
		    BlankRecipientPhone
		)
		SELECT TOP 1
            @ClientID,
            StoreID,
            DefaultShipperID,
            DefaultDomesticService,
            DefaultInternationalService,
            DefaultTemplate,
            ThermalPrinterName,
            UseThermalLabels,
            ThermalLabelDocTabType,
		    ReferenceNumber,
		    PackagingType,
		    PackagingLength,
		    PackagingWidth,
		    PackagingHeight ,
		    SignatureOption,
		    PayorType,
		    PayorAccountNumber,
		    DutiesPayorType,
		    DutiesPayorAccountNumber,
		    ShipAlertRecipientAddressUseBill,
		    ShipAlertRecipientShip,
		    ShipAlertRecipientDelivery,
		    ShipAlertSenderShip,
		    ShipAlertSenderDelivery,
		    ShipAlertOther1Address,
		    ShipAlertOther1Ship,
		    ShipAlertOther1Delivery,
		    ShipAlertExpressMessage,
		    ShipAlertGroundEnable,
		    ShipAlertGroundAddressUseBill,
		    ShipAlertGroundMessage,
		    CodEnable,
		    CodType,
		    CodAddFreight,
		    CodUseShipperAddress,
		    CodReturnContactName,
		    CodReturnCompany,
		    CodReturnAddress1,
		    CodReturnAddress2,
		    CodReturnCity,
		    CodReturnStateProvinceCode,
		    CodReturnPostalCode,
		    CodReturnPhone,
		    BrokerEnable,
		    BrokerAccount,
		    BrokerContactName,
		    BrokerCompany,
		    BrokerAddress1,
		    BrokerAddress2,
		    BrokerCity,
		    BrokerStateProvinceCode,
		    BrokerPostalCode,
		    BrokerPhone,
		    MaskAccountNumber,
		    BlankRecipientPhone
		FROM FedexPreferences WHERE StoreID = @StoreID
	end
	
    SELECT *
        FROM FedexPreferences
        WHERE StoreID = @StoreID AND ClientID = @ClientID
                
GO

----------------------------
--- PROCEDURE AddFedexPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFedexPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddFedexPreferences]
GO

CREATE PROCEDURE dbo.AddFedexPreferences
(
    @ClientID int ,
    @StoreID int ,
    @DefaultShipperID int  ,
    @DefaultDomesticService smallint,
    @DefaultInternationalService smallint,
    @DefaultTemplate nvarchar (50) ,
    @ThermalPrinterName nvarchar (350),
    @UseThermalLabels bit,
    @ThermalLabelDocTabType smallint,
    @ReferenceNumber nvarchar (200) ,
	@PackagingType smallint,
    @PackagingLength int,
    @PackagingWidth int,
    @PackagingHeight int,
    @SignatureOption int,
    @PayorType smallint,
    @PayorAccountNumber nvarchar (12),
    @DutiesPayorType smallint,
    @DutiesPayorAccountNumber nvarchar (12),
    @ShipAlertRecipientAddressUseBill bit,
    @ShipAlertRecipientShip bit,
    @ShipAlertRecipientDelivery bit,
    @ShipAlertSenderShip bit,
    @ShipAlertSenderDelivery bit,
    @ShipAlertOther1Address nvarchar (120),
    @ShipAlertOther1Ship bit,
    @ShipAlertOther1Delivery bit,
    @ShipAlertExpressMessage nvarchar (75),
    @ShipAlertGroundEnable bit,
    @ShipAlertGroundAddressUseBill bit,
    @ShipAlertGroundMessage nvarchar (75),
    @CodEnable bit,
    @CodType int,
    @CodAddFreight bit,
    @CodUseShipperAddress bit,
    @CodReturnContactName nvarchar (35),
    @CodReturnCompany nvarchar (35),
    @CodReturnAddress1 nvarchar (35),
    @CodReturnAddress2 nvarchar (35),
    @CodReturnCity nvarchar (35),
    @CodReturnStateProvinceCode nvarchar (2),
    @CodReturnPostalCode nvarchar (16),
    @CodReturnPhone nvarchar (16),
	@BrokerEnable bit,
    @BrokerAccount nvarchar (12),
    @BrokerContactName nvarchar (35),
    @BrokerCompany nvarchar (35),
    @BrokerAddress1 nvarchar (35),
    @BrokerAddress2 nvarchar (35),
    @BrokerCity nvarchar (35),
    @BrokerStateProvinceCode nvarchar (2),
    @BrokerPostalCode nvarchar (16),
    @BrokerPhone nvarchar (16),
    @MaskAccountNumber bit,
    @BlankRecipientPhone nvarchar (25)
)
WITH ENCRYPTION
AS
   INSERT INTO FedexPreferences
   (
        ClientID,
        StoreID,
        DefaultShipperID,
        DefaultDomesticService,
        DefaultInternationalService,
        DefaultTemplate,
        ThermalPrinterName,
        UseThermalLabels,
        ThermalLabelDocTabType,
		ReferenceNumber,
		PackagingType,
		PackagingLength,
		PackagingWidth,
		PackagingHeight ,
		SignatureOption,
		PayorType,
		PayorAccountNumber,
		DutiesPayorType,
		DutiesPayorAccountNumber,
		ShipAlertRecipientAddressUseBill,
		ShipAlertRecipientShip,
		ShipAlertRecipientDelivery,
		ShipAlertSenderShip,
		ShipAlertSenderDelivery,
		ShipAlertOther1Address,
		ShipAlertOther1Ship,
		ShipAlertOther1Delivery,
		ShipAlertExpressMessage,
		ShipAlertGroundEnable,
		ShipAlertGroundAddressUseBill,
		ShipAlertGroundMessage,
		CodEnable,
		CodType,
		CodAddFreight,
		CodUseShipperAddress,
		CodReturnContactName,
		CodReturnCompany,
		CodReturnAddress1,
		CodReturnAddress2,
		CodReturnCity,
		CodReturnStateProvinceCode,
		CodReturnPostalCode,
		CodReturnPhone,
		BrokerEnable,
		BrokerAccount,
		BrokerContactName,
		BrokerCompany,
		BrokerAddress1,
		BrokerAddress2,
		BrokerCity,
		BrokerStateProvinceCode,
		BrokerPostalCode,
		BrokerPhone,
		MaskAccountNumber,
		BlankRecipientPhone
   )
   VALUES
   (
        @ClientID,
        @StoreID,
        @DefaultShipperID,
        @DefaultDomesticService,
        @DefaultInternationalService,
        @DefaultTemplate,
        @ThermalPrinterName,
        @UseThermalLabels,
        @ThermalLabelDocTabType,
		@ReferenceNumber,
		@PackagingType,
		@PackagingLength,
		@PackagingWidth,
		@PackagingHeight ,
		@SignatureOption,
		@PayorType,
		@PayorAccountNumber,
		@DutiesPayorType,
		@DutiesPayorAccountNumber,
		@ShipAlertRecipientAddressUseBill,
		@ShipAlertRecipientShip,
		@ShipAlertRecipientDelivery,
		@ShipAlertSenderShip,
		@ShipAlertSenderDelivery,
		@ShipAlertOther1Address,
		@ShipAlertOther1Ship,
		@ShipAlertOther1Delivery,
		@ShipAlertExpressMessage,
		@ShipAlertGroundEnable,
		@ShipAlertGroundAddressUseBill,
		@ShipAlertGroundMessage,
		@CodEnable,
		@CodType,
		@CodAddFreight,
		@CodUseShipperAddress,
		@CodReturnContactName,
		@CodReturnCompany,
		@CodReturnAddress1,
		@CodReturnAddress2,
		@CodReturnCity,
		@CodReturnStateProvinceCode,
		@CodReturnPostalCode,
		@CodReturnPhone,
		@BrokerEnable,
		@BrokerAccount,
		@BrokerContactName,
		@BrokerCompany,
		@BrokerAddress1,
		@BrokerAddress2,
		@BrokerCity,
		@BrokerStateProvinceCode,
		@BrokerPostalCode,
		@BrokerPhone,
		@MaskAccountNumber,
		@BlankRecipientPhone
   )
   
    if (@@ROWCOUNT != 1)
        return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
     FROM FedexPreferences
     WHERE StoreID = @StoreID AND ClientID = @ClientID

   return 1
GO

----------------------------
--- PROCEDURE UpdateFedexPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFedexPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateFedexPreferences]
GO

CREATE PROCEDURE dbo.UpdateFedexPreferences
(
    @ClientID int ,
    @StoreID int ,
    @DefaultShipperID int  ,
    @DefaultDomesticService smallint,
    @DefaultInternationalService smallint,
    @DefaultTemplate nvarchar (50) ,
    @ThermalPrinterName nvarchar (350),
    @UseThermalLabels bit,
    @ThermalLabelDocTabType smallint,
    @ReferenceNumber nvarchar (200) ,
	@PackagingType smallint,
    @PackagingLength int,
    @PackagingWidth int,
    @PackagingHeight int,
    @SignatureOption int,
    @PayorType smallint,
    @PayorAccountNumber nvarchar (12),
    @DutiesPayorType smallint,
    @DutiesPayorAccountNumber nvarchar (12),
    @ShipAlertRecipientAddressUseBill bit,
    @ShipAlertRecipientShip bit,
    @ShipAlertRecipientDelivery bit,
    @ShipAlertSenderShip bit,
    @ShipAlertSenderDelivery bit,
    @ShipAlertOther1Address nvarchar (120),
    @ShipAlertOther1Ship bit,
    @ShipAlertOther1Delivery bit,
    @ShipAlertExpressMessage nvarchar (75),
    @ShipAlertGroundEnable bit,
    @ShipAlertGroundAddressUseBill bit,
    @ShipAlertGroundMessage nvarchar (75),
    @CodEnable bit,
    @CodType int,
    @CodAddFreight bit,
    @CodUseShipperAddress bit,
    @CodReturnContactName nvarchar (35),
    @CodReturnCompany nvarchar (35),
    @CodReturnAddress1 nvarchar (35),
    @CodReturnAddress2 nvarchar (35),
    @CodReturnCity nvarchar (35),
    @CodReturnStateProvinceCode nvarchar (2),
    @CodReturnPostalCode nvarchar (16),
    @CodReturnPhone nvarchar (16),
	@BrokerEnable bit,
    @BrokerAccount nvarchar (12),
    @BrokerContactName nvarchar (35),
    @BrokerCompany nvarchar (35),
    @BrokerAddress1 nvarchar (35),
    @BrokerAddress2 nvarchar (35),
    @BrokerCity nvarchar (35),
    @BrokerStateProvinceCode nvarchar (2),
    @BrokerPostalCode nvarchar (16),
    @BrokerPhone nvarchar (16),
    @MaskAccountNumber bit,
    @BlankRecipientPhone nvarchar (25)
)
WITH ENCRYPTION
AS
   UPDATE FedexPreferences
   SET  ClientID = @ClientID,
        StoreID = @StoreID,
        DefaultShipperID = @DefaultShipperID,
        DefaultDomesticService = @DefaultDomesticService,
        DefaultInternationalService = @DefaultInternationalService,
        DefaultTemplate = @DefaultTemplate,
        ThermalPrinterName = @ThermalPrinterName,
        UseThermalLabels = @UseThermalLabels,
        ThermalLabelDocTabType = @ThermalLabelDocTabType,
		ReferenceNumber = @ReferenceNumber,
		PackagingType = @PackagingType,
		PackagingLength = @PackagingLength,
		PackagingWidth = @PackagingWidth,
		PackagingHeight  = @PackagingHeight,
		SignatureOption = @SignatureOption,
		PayorType = @PayorType,
		PayorAccountNumber = @PayorAccountNumber,
		DutiesPayorType = @DutiesPayorType,
		DutiesPayorAccountNumber = @DutiesPayorAccountNumber,
		ShipAlertRecipientAddressUseBill = @ShipAlertRecipientAddressUseBill,
		ShipAlertRecipientShip = @ShipAlertRecipientShip,
		ShipAlertRecipientDelivery = @ShipAlertRecipientDelivery,
		ShipAlertSenderShip = @ShipAlertSenderShip,
		ShipAlertSenderDelivery = @ShipAlertSenderDelivery,
		ShipAlertOther1Address = @ShipAlertOther1Address,
		ShipAlertOther1Ship = @ShipAlertOther1Ship,
		ShipAlertOther1Delivery = @ShipAlertOther1Delivery,
		ShipAlertExpressMessage = @ShipAlertExpressMessage,
		ShipAlertGroundEnable = @ShipAlertGroundEnable,
		ShipAlertGroundAddressUseBill = @ShipAlertGroundAddressUseBill,
		ShipAlertGroundMessage = @ShipAlertGroundMessage,
		CodEnable = @CodEnable,
		CodType = @CodType,
		CodAddFreight = @CodAddFreight,
		CodUseShipperAddress = @CodUseShipperAddress,
		CodReturnContactName = @CodReturnContactName,
		CodReturnCompany = @CodReturnCompany,
		CodReturnAddress1 = @CodReturnAddress1,
		CodReturnAddress2 = @CodReturnAddress2,
		CodReturnCity = @CodReturnCity,
		CodReturnStateProvinceCode = @CodReturnStateProvinceCode,
		CodReturnPostalCode = @CodReturnPostalCode,
		CodReturnPhone = @CodReturnPhone,
		BrokerEnable = @BrokerEnable,
		BrokerAccount = @BrokerAccount,
		BrokerContactName = @BrokerContactName,
		BrokerCompany = @BrokerCompany,
		BrokerAddress1 = @BrokerAddress1,
		BrokerAddress2 = @BrokerAddress2,
		BrokerCity = @BrokerCity,
		BrokerStateProvinceCode = @BrokerStateProvinceCode,
		BrokerPostalCode = @BrokerPostalCode,
		BrokerPhone = @BrokerPhone,
		MaskAccountNumber = @MaskAccountNumber,
		BlankRecipientPhone = @BlankRecipientPhone
   WHERE StoreID = @StoreID AND ClientID = @ClientID
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
   FROM FedexPreferences
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO