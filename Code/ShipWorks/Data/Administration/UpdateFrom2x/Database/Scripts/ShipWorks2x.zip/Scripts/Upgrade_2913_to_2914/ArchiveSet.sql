----------------------------
--- PROCEDURE GetAllArchiveSets
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllArchiveSets]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllArchiveSets]
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[GetAllArchiveSets]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [GetAllArchiveSets]
GO

CREATE PROCEDURE dbo.GetAllArchiveSets
WITH ENCRYPTION
AS 
	SELECT
		ArchiveSetID,
		RowVersion,
		ArchiveSetName,
		DbName,
		Description,
		CreateDate
	FROM [ArchiveSets]
GO
