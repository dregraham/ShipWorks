ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Clients
GO

ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Stores
GO

CREATE TABLE dbo.Tmp_ClientStoreSettings
	(
	ClientID int NOT NULL,
	StoreID int NOT NULL,
	RowVersion timestamp NOT NULL,
	LicenseKey nvarchar(150) NOT NULL,
	ActiveTemplate nvarchar(50) NOT NULL,
	ActiveFilter nvarchar(50) NOT NULL,
	PerfDateRangeType int NOT NULL,
	PerfDateRangeDays int NOT NULL,
	PerfDateRangeMax datetime NOT NULL,
	PerfDateRangeMin datetime NOT NULL,
	PerfShowFilterCounts bit NOT NULL,
	FileSaveWebImages bit NOT NULL,
	FileSavePromptEach bit NOT NULL,
	FileSaveNameTemplate nvarchar(50) NOT NULL,
	WolrdShipCsvFilename nvarchar(350) NOT NULL,
	WorldShipOutputType int NOT NULL,
	WorldShipLaunchAfterExport bit NOT NULL,
	WorldShipReferenceNumber nvarchar(50) NOT NULL,
	StampsCsvFilename nvarchar(350) NOT NULL,
	StampsLaunchAfterExport bit NOT NULL,
	EndiciaSetService bit NOT NULL,
	EndiciaSetConfirmation bit NOT NULL,
	EndiciaSetWeight bit NOT NULL,
	EndiciaSetDate bit NOT NULL,
	EndiciaDefaultDomesticService int NOT NULL,
	EndiciaDefaultInternationalService int NOT NULL,
	EndiciaDefaultConfirmation int NOT NULL,
	EndiciaDefaultDateAdvance int NOT NULL,
	EndiciaUnattendedPrinting bit NOT NULL,
	EndiciaSpecifyLayout bit NOT NULL,
	EndiciaDefaultLayoutFile nvarchar(350) NOT NULL,
	EndiciaStealthMode bit NOT NULL,
	EndiciaTestMode bit NOT NULL,
	EndiciaCloseOnComplete bit NOT NULL,
	UspsDefaultService int NOT NULL,
	UspsDefaultConfirmation int NOT NULL,
	UspsDefaultRequestAddressService bit NOT NULL,
	UspsDefaultSendConfirmationEmail bit NOT NULL,
	UspsUseLiveServer bit NOT NULL,
	UspsDefaultTemplate nvarchar(50) NOT NULL,
	DownloadAllowed bit NOT NULL,
	DownloadAutoEnable bit NOT NULL,
	DownloadAutoInterval int NOT NULL,
	DownloadNewPlaySound bit NOT NULL,
	DownloadNewPlaySoundFile nvarchar(350) NOT NULL,
	DownloadNewSendEmail bit NOT NULL,
	DownloadNewSendEmailTemplate nvarchar(50) NOT NULL,
	DownloadNewSendEmailTestMode bit NOT NULL,
	DownloadNewSendEmailTestAddress nvarchar(50) NOT NULL,
	DownloadNewPrint bit NOT NULL,
	DownloadNewPrintTemplate nvarchar(50) NOT NULL,
	DownloadErrorPlaySound bit NOT NULL,
	DownloadErrorPlaySoundFile nvarchar(350) NOT NULL
	)  ON [PRIMARY]
GO

ALTER TABLE dbo.Tmp_ClientStoreSettings ADD CONSTRAINT
	DF_ClientStoreSettings_EndiciaDefaultInternationalService DEFAULT 11 FOR EndiciaDefaultInternationalService
GO

ALTER TABLE dbo.Tmp_ClientStoreSettings ADD CONSTRAINT
	DF_ClientStoreSettings_EndiciaStealthMode DEFAULT 0 FOR EndiciaStealthMode
GO

IF EXISTS(SELECT * FROM dbo.ClientStoreSettings)
	 EXEC('INSERT INTO dbo.Tmp_ClientStoreSettings (ClientID, StoreID, LicenseKey, ActiveTemplate, ActiveFilter, PerfDateRangeType, PerfDateRangeDays, PerfDateRangeMax, PerfDateRangeMin, PerfShowFilterCounts, FileSaveWebImages, FileSavePromptEach, FileSaveNameTemplate, WolrdShipCsvFilename, WorldShipOutputType, WorldShipLaunchAfterExport, WorldShipReferenceNumber, StampsCsvFilename, StampsLaunchAfterExport, EndiciaSetService, EndiciaSetConfirmation, EndiciaSetWeight, EndiciaSetDate, EndiciaDefaultDomesticService, EndiciaDefaultConfirmation, EndiciaDefaultDateAdvance, EndiciaUnattendedPrinting, EndiciaSpecifyLayout, EndiciaDefaultLayoutFile, EndiciaTestMode, EndiciaCloseOnComplete, UspsDefaultService, UspsDefaultConfirmation, UspsDefaultRequestAddressService, UspsDefaultSendConfirmationEmail, UspsUseLiveServer, UspsDefaultTemplate, DownloadAllowed, DownloadAutoEnable, DownloadAutoInterval, DownloadNewPlaySound, DownloadNewPlaySoundFile, DownloadNewSendEmail, DownloadNewSendEmailTemplate, DownloadNewSendEmailTestMode, DownloadNewSendEmailTestAddress, DownloadNewPrint, DownloadNewPrintTemplate, DownloadErrorPlaySound, DownloadErrorPlaySoundFile)
		                                     SELECT ClientID, StoreID, LicenseKey, ActiveTemplate, ActiveFilter, PerfDateRangeType, PerfDateRangeDays, PerfDateRangeMax, PerfDateRangeMin, PerfShowFilterCounts, FileSaveWebImages, FileSavePromptEach, FileSaveNameTemplate, WolrdShipCsvFilename, WorldShipOutputType, WorldShipLaunchAfterExport, ''Order Sw_OrderNumber'' AS WorldShipReferenceNumber, StampsCsvFilename, StampsLaunchAfterExport, EndiciaSetService, EndiciaSetConfirmation, EndiciaSetWeight, EndiciaSetDate, EndiciaDefaultService, EndiciaDefaultConfirmation, EndiciaDefaultDateAdvance, EndiciaUnattendedPrinting, EndiciaSpecifyLayout, EndiciaDefaultLayoutFile, EndiciaTestMode, EndiciaCloseOnComplete, UspsDefaultService, UspsDefaultConfirmation, UspsDefaultRequestAddressService, UspsDefaultSendConfirmationEmail, UspsUseLiveServer, UspsDefaultTemplate, DownloadAllowed, DownloadAutoEnable, DownloadAutoInterval, DownloadNewPlaySound, DownloadNewPlaySoundFile, DownloadNewSendEmail, DownloadNewSendEmailTemplate, DownloadNewSendEmailTestMode, DownloadNewSendEmailTestAddress, DownloadNewPrint, DownloadNewPrintTemplate, DownloadErrorPlaySound, DownloadErrorPlaySoundFile FROM dbo.ClientStoreSettings TABLOCKX')
GO

DROP TABLE dbo.ClientStoreSettings
GO

EXECUTE sp_rename N'dbo.Tmp_ClientStoreSettings', N'ClientStoreSettings', 'OBJECT'
GO

ALTER TABLE dbo.ClientStoreSettings ADD CONSTRAINT
	PK_ClientStoreSettings PRIMARY KEY CLUSTERED 
	(
	ClientID,
	StoreID
	) ON [PRIMARY]

GO

ALTER TABLE dbo.ClientStoreSettings WITH NOCHECK ADD CONSTRAINT
	FK_ClientStoreSettings_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

ALTER TABLE dbo.ClientStoreSettings WITH NOCHECK ADD CONSTRAINT
	FK_ClientStoreSettings_Clients FOREIGN KEY
	(
	ClientID
	) REFERENCES dbo.Clients
	(
	ClientID
	)
GO

ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT DF_ClientStoreSettings_EndiciaDefaultInternationalService
GO

ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT DF_ClientStoreSettings_EndiciaStealthMode
GO

----------------------------
--- PROCEDURE GetAllClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetAllClientStoreSettings]
GO

CREATE PROCEDURE GetAllClientStoreSettings
AS
   SELECT *
   FROM [ClientStoreSettings]
GO

----------------------------
--- PROCEDURE DeleteClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteClientStoreSettings]
GO

CREATE PROCEDURE DeleteClientStoreSettings
(
   @ClientID int,
   @StoreID int
)
AS
   DELETE FROM [ClientStoreSettings]
   WHERE 
      [ClientID] = @ClientID AND
      [StoreID] = @StoreID
GO

----------------------------
--- PROCEDURE AddClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddClientStoreSettings]
GO

CREATE PROCEDURE AddClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @LicenseKey nvarchar(150),
   @ActiveTemplate nvarchar(50),
   @ActiveFilter nvarchar(50),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @FileSaveWebImages bit,
   @FileSavePromptEach bit,
   @FileSaveNameTemplate nvarchar(50),
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber nvarchar (50),
   @StampsCsvFilename nvarchar(350),
   @StampsLaunchAfterExport bit,
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaUnattendedPrinting bit,
   @EndiciaSpecifyLayout bit,
   @EndiciaDefaultLayoutFile nvarchar(350),
   @EndiciaStealthMode bit,
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DownloadNewPlaySound bit,
   @DownloadNewPlaySoundFile nvarchar(350),
   @DownloadNewSendEmail bit,
   @DownloadNewSendEmailTemplate nvarchar(50),
   @DownloadNewSendEmailTestMode bit,
   @DownloadNewSendEmailTestAddress nvarchar(50),
   @DownloadNewPrint bit,
   @DownloadNewPrintTemplate nvarchar(50),
   @DownloadErrorPlaySound bit,
   @DownloadErrorPlaySoundFile nvarchar(350)
)
AS
   INSERT INTO [ClientStoreSettings]
   (
        [ClientID], 
        [StoreID], 
        [LicenseKey], 
	    [ActiveTemplate],
	    [ActiveFilter],
        [PerfDateRangeType],
        [PerfDateRangeDays], 
        [PerfDateRangeMax], 
        [PerfDateRangeMin], 
        [PerfShowFilterCounts],
	    [FileSaveWebImages],
	    [FileSavePromptEach],
	    [FileSaveNameTemplate],
        [WolrdShipCsvFilename], 
        [WorldShipOutputType], 
        [WorldShipLaunchAfterExport], 
        [WorldShipReferenceNumber],
        [StampsCsvFilename], 
        [StampsLaunchAfterExport], 
        [EndiciaSetService], 
        [EndiciaSetConfirmation], 
        [EndiciaSetWeight], 
        [EndiciaSetDate], 
        [EndiciaDefaultDomesticService], 
        [EndiciaDefaultInternationalService],
        [EndiciaDefaultConfirmation], 
        [EndiciaDefaultDateAdvance], 
        [EndiciaUnattendedPrinting], 
        [EndiciaSpecifyLayout], 
        [EndiciaDefaultLayoutFile], 
        [EndiciaStealthMode],
        [EndiciaTestMode], 
        [EndiciaCloseOnComplete], 
        [UspsDefaultService], 
        [UspsDefaultConfirmation], 
        [UspsDefaultRequestAddressService], 
        [UspsDefaultSendConfirmationEmail], 
        [UspsUseLiveServer], 
        [UspsDefaultTemplate], 
        [DownloadAllowed],
	    [DownloadAutoEnable],
	    [DownloadAutoInterval],
	    [DownloadNewPlaySound],
	    [DownloadNewPlaySoundFile],
	    [DownloadNewSendEmail],
	    [DownloadNewSendEmailTemplate],
	    [DownloadNewSendEmailTestMode],
	    [DownloadNewSendEmailTestAddress],
	    [DownloadNewPrint],
	    [DownloadNewPrintTemplate],
	    [DownloadErrorPlaySound],
	    [DownloadErrorPlaySoundFile]
   )
   VALUES 
   (
        @ClientID, 
        @StoreID, 
        @LicenseKey, 
	    @ActiveTemplate,
	    @ActiveFilter,
        @PerfDateRangeType,
        @PerfDateRangeDays, 
        @PerfDateRangeMax, 
        @PerfDateRangeMin, 
        @PerfShowFilterCounts,
	    @FileSaveWebImages,
	    @FileSavePromptEach,
	    @FileSaveNameTemplate,
        @WolrdShipCsvFilename, 
        @WorldShipOutputType, 
        @WorldShipLaunchAfterExport, 
        @WorldShipReferenceNumber,
        @StampsCsvFilename, 
        @StampsLaunchAfterExport, 
        @EndiciaSetService, 
        @EndiciaSetConfirmation, 
        @EndiciaSetWeight, 
        @EndiciaSetDate, 
        @EndiciaDefaultDomesticService, 
        @EndiciaDefaultInternationalService,
        @EndiciaDefaultConfirmation, 
        @EndiciaDefaultDateAdvance, 
        @EndiciaUnattendedPrinting, 
        @EndiciaSpecifyLayout, 
        @EndiciaDefaultLayoutFile, 
        @EndiciaStealthMode,
        @EndiciaTestMode, 
        @EndiciaCloseOnComplete, 
        @UspsDefaultService, 
        @UspsDefaultConfirmation, 
        @UspsDefaultRequestAddressService, 
        @UspsDefaultSendConfirmationEmail, 
        @UspsUseLiveServer, 
        @UspsDefaultTemplate, 
        @DownloadAllowed,
	    @DownloadAutoEnable,
	    @DownloadAutoInterval,
	    @DownloadNewPlaySound,
	    @DownloadNewPlaySoundFile,
	    @DownloadNewSendEmail,
	    @DownloadNewSendEmailTemplate,
	    @DownloadNewSendEmailTestMode,
	    @DownloadNewSendEmailTestAddress,
	    @DownloadNewPrint,
	    @DownloadNewPrintTemplate,
	    @DownloadErrorPlaySound,
	    @DownloadErrorPlaySoundFile
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT RowVersion
   FROM ClientStoreSettings
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateClientStoreSettings]
GO

CREATE PROCEDURE UpdateClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @LicenseKey nvarchar(150),
   @ActiveTemplate nvarchar(50),
   @ActiveFilter nvarchar(50),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @FileSaveWebImages bit,
   @FileSavePromptEach bit,
   @FileSaveNameTemplate nvarchar(50),
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber nvarchar (50),
   @StampsCsvFilename nvarchar(350),
   @StampsLaunchAfterExport bit,
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaUnattendedPrinting bit,
   @EndiciaSpecifyLayout bit,
   @EndiciaDefaultLayoutFile nvarchar(350),
   @EndiciaStealthMode bit,
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DownloadNewPlaySound bit,
   @DownloadNewPlaySoundFile nvarchar(350),
   @DownloadNewSendEmail bit,
   @DownloadNewSendEmailTemplate nvarchar(50),
   @DownloadNewSendEmailTestMode bit,
   @DownloadNewSendEmailTestAddress nvarchar(50),
   @DownloadNewPrint bit,
   @DownloadNewPrintTemplate nvarchar(50),
   @DownloadErrorPlaySound bit,
   @DownloadErrorPlaySoundFile nvarchar(350)
)
AS
   UPDATE [ClientStoreSettings]
   SET 
    [LicenseKey] = @LicenseKey, 
    [ActiveTemplate] = @ActiveTemplate,
    [ActiveFilter] = @ActiveFilter,
    [PerfDateRangeType] = @PerfDateRangeType,
    [PerfDateRangeDays] = @PerfDateRangeDays, 
    [PerfDateRangeMax] = @PerfDateRangeMax, 
    [PerfDateRangeMin] = @PerfDateRangeMin, 
    [PerfShowFilterCounts] = @PerfShowFilterCounts,
    [FileSaveWebImages] = @FileSaveWebImages,
    [FileSavePromptEach] = @FileSavePromptEach,
    [FileSaveNameTemplate] = @FileSaveNameTemplate,
    [WolrdShipCsvFilename] = @WolrdShipCsvFilename, 
    [WorldShipOutputType] = @WorldShipOutputType, 
    [WorldShipLaunchAfterExport] = @WorldShipLaunchAfterExport, 
    [WorldShipReferenceNumber] = @WorldShipReferenceNumber,
    [StampsCsvFilename] = @StampsCsvFilename, 
    [StampsLaunchAfterExport] = @StampsLaunchAfterExport, 
    [EndiciaSetService] = @EndiciaSetService, 
    [EndiciaSetConfirmation] = @EndiciaSetConfirmation, 
    [EndiciaSetWeight] = @EndiciaSetWeight, 
    [EndiciaSetDate] = @EndiciaSetDate, 
    [EndiciaDefaultDomesticService] = @EndiciaDefaultDomesticService, 
    [EndiciaDefaultInternationalService] = @EndiciaDefaultInternationalService,
    [EndiciaDefaultConfirmation] = @EndiciaDefaultConfirmation, 
    [EndiciaDefaultDateAdvance] = @EndiciaDefaultDateAdvance, 
    [EndiciaUnattendedPrinting] = @EndiciaUnattendedPrinting, 
    [EndiciaSpecifyLayout] = @EndiciaSpecifyLayout, 
    [EndiciaDefaultLayoutFile] = @EndiciaDefaultLayoutFile,
    [EndiciaStealthMode] = @EndiciaStealthMode, 
    [EndiciaTestMode] = @EndiciaTestMode, 
    [EndiciaCloseOnComplete] = @EndiciaCloseOnComplete, 
    [UspsDefaultService] = @UspsDefaultService, 
    [UspsDefaultConfirmation] = @UspsDefaultConfirmation, 
    [UspsDefaultRequestAddressService] = @UspsDefaultRequestAddressService, 
    [UspsDefaultSendConfirmationEmail] = @UspsDefaultSendConfirmationEmail, 
    [UspsUseLiveServer] = @UspsUseLiveServer, 
    [UspsDefaultTemplate] = @UspsDefaultTemplate, 
    [DownloadAllowed] = @DownloadAllowed,
    [DownloadAutoEnable] = @DownloadAutoEnable,
    [DownloadAutoInterval] = @DownloadAutoInterval,
    [DownloadNewPlaySound] = @DownloadNewPlaySound,
    [DownloadNewPlaySoundFile] = @DownloadNewPlaySoundFile,
    [DownloadNewSendEmail] = @DownloadNewSendEmail,
    [DownloadNewSendEmailTemplate] = @DownloadNewSendEmailTemplate,
    [DownloadNewSendEmailTestMode] = @DownloadNewSendEmailTestMode,
    [DownloadNewSendEmailTestAddress] = @DownloadNewSendEmailTestAddress,
    [DownloadNewPrint] = @DownloadNewPrint,
    [DownloadNewPrintTemplate] = @DownloadNewPrintTemplate,
    [DownloadErrorPlaySound] = @DownloadErrorPlaySound,
    [DownloadErrorPlaySoundFile] = @DownloadErrorPlaySoundFile
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM [ClientStoreSettings]
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID

   return 1
GO
