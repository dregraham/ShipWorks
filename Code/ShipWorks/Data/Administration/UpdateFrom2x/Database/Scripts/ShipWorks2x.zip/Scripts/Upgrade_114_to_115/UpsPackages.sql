if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUpsPackages]
GO

-----------------------------
--- Procedure GetOrderUpsPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUpsPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUpsPackages]
GO

CREATE PROCEDURE GetOrderUpsPackages
(
    @OrderID int
)
AS
   SELECT p.*
   FROM UpsPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUpsPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUpsPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUpsPackages]
GO

CREATE PROCEDURE GetCustomerUpsPackages
(
    @CustomerID int
)
AS
   SELECT p.*
   FROM UpsPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO
