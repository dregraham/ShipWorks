ALTER TABLE dbo.Shipments
	DROP CONSTRAINT FK_Shipments_Stores
GO

CREATE TABLE dbo.Tmp_Shipments
	(
	ShipmentID int NOT NULL IDENTITY (1, 1),
	RowVersion timestamp NOT NULL,
	StoreID int NOT NULL,
	OrderID int NOT NULL,
	CustomerID int NOT NULL,
	ShipmentType int NOT NULL,
	Processed bit NOT NULL,
	ProcessedDate datetime NOT NULL,
	ShippedDate datetime NOT NULL,
	ServiceUsed nvarchar(50) NOT NULL,
	TrackingNumber nvarchar(50) NOT NULL,
	Notes ntext NOT NULL,
	CommoditiesCreated bit NOT NULL,
	TotalCharges money NOT NULL,
	TotalWeight float(53) NOT NULL,
	ToFirstName nvarchar(30) NOT NULL,
	ToLastName nvarchar(30) NOT NULL,
	ToCompany nvarchar(30) NOT NULL,
	ToAddress1 nvarchar(60) NOT NULL,
	ToAddress2 nvarchar(60) NOT NULL,
	ToAddress3 nvarchar(60) NOT NULL,
	ToCity nvarchar(50) NOT NULL,
	ToStateProvinceCode nvarchar(25) NOT NULL,
	ToPostalCode nvarchar(10) NOT NULL,
	ToCountryCode nvarchar(5) NOT NULL,
	ToPhone nvarchar(25) NOT NULL,
	ToFax nvarchar(25) NOT NULL,
	ToEmail nvarchar(50) NOT NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO

SET IDENTITY_INSERT dbo.Tmp_Shipments ON
GO

IF EXISTS(SELECT * FROM dbo.Shipments)
	 EXEC('INSERT INTO dbo.Tmp_Shipments 
	          (ShipmentID, StoreID, OrderID, CustomerID, ShipmentType, Processed, ProcessedDate, ShippedDate, ServiceUsed, TrackingNumber, Notes, CommoditiesCreated, TotalCharges, TotalWeight, ToFirstName, ToLastName, ToCompany, ToAddress1, ToAddress2, ToAddress3, ToCity, ToStateProvinceCode, ToPostalCode, ToCountryCode, ToPhone, ToFax, ToEmail)
		SELECT ShipmentID, StoreID, OrderID, CustomerID, ShipmentType, Processed, ProcessedDate, ShippedDate, ServiceUsed, TrackingNumber, Notes, 0,                  TotalCharges, TotalWeight, ToFirstName, ToLastName, ToCompany, ToAddress1, ToAddress2, ToAddress3, ToCity, ToStateProvinceCode, ToPostalCode, ToCountryCode, ToPhone, ToFax, ToEmail FROM dbo.Shipments TABLOCKX')
GO

SET IDENTITY_INSERT dbo.Tmp_Shipments OFF
GO

ALTER TABLE dbo.UspsShipments
	DROP CONSTRAINT FK_UspsShipments_Shipments
GO

ALTER TABLE dbo.UpsShipments
	DROP CONSTRAINT FK_UpsShipments_Shipments
GO

ALTER TABLE dbo.FedexShipments
	DROP CONSTRAINT FK_FedexShipments_Shipments
GO

DROP TABLE dbo.Shipments
GO

EXECUTE sp_rename N'dbo.Tmp_Shipments', N'Shipments', 'OBJECT'
GO

ALTER TABLE dbo.Shipments ADD CONSTRAINT
	PK_Shipments PRIMARY KEY CLUSTERED 
	(
	ShipmentID
	) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX IX_Shipments_OrderID ON dbo.Shipments
	(
	OrderID
	) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX IX_Shipments_CustomerID ON dbo.Shipments
	(
	CustomerID
	) ON [PRIMARY]
GO

ALTER TABLE dbo.Shipments WITH NOCHECK ADD CONSTRAINT
	FK_Shipments_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

CREATE TRIGGER TG_Shipments ON dbo.Shipments FOR UPDATE
AS
    if ( (SELECT COUNT(*) FROM inserted) = 0)
       return;

    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID
        FROM inserted

    EXEC SetTableLastDbts 'Shipments', @StoreID, @@DBTS
GO

ALTER TABLE dbo.FedexShipments WITH NOCHECK ADD CONSTRAINT
	FK_FedexShipments_Shipments FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO

ALTER TABLE dbo.UpsShipments WITH NOCHECK ADD CONSTRAINT
	FK_UpsShipments_Shipments FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO

ALTER TABLE dbo.UspsShipments WITH NOCHECK ADD CONSTRAINT
	FK_UspsShipments_Shipments FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO


-----------------------------
--- Procedure DeleteShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteShipment]
GO

CREATE PROCEDURE DeleteShipment
(
   @ShipmentID int
)
AS
    DELETE UpsPackages
      FROM UpsPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID

    DELETE UpsShipments
      FROM UpsShipments u, Shipments s
      WHERE u.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID
      
    DELETE UspsShipments
      FROM UspsShipments u, Shipments s
      WHERE u.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID
      
    DELETE ShipmentCommodities
      FROM ShipmentCommodities c, Shipments s
      WHERE c.ShipmentID = s.ShipmentID AND s.ShipmentID = @ShipmentID

    DELETE FROM Shipments
      WHERE ShipmentID = @ShipmentID
GO

-----------------------------
--- Procedure GetOrderShipmentsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentsRange]
GO

CREATE PROCEDURE GetOrderShipmentsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
    -- Get all shipments within the order range
    SELECT s.*
        FROM Shipments s, Orders o
        WHERE s.StoreID = @StoreID AND
              s.OrderID = o.OrderID AND
              o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
              o.OrderID > @MinOrderID
                  
GO

-----------------------------
--- Procedure GetCustomerShipmentsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentsRange]
GO

CREATE PROCEDURE GetCustomerShipmentsRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
    -- Get all shipments within the customer range
    SELECT s.*
        FROM Shipments s
        WHERE s.StoreID = @StoreID AND
              s.CustomerID > @MinCustomerID AND
              s.CustomerID <> -1
                  
GO

-----------------------------
--- Procedure GetChangedShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedShipments]
GO

CREATE PROCEDURE GetChangedShipments
(
   @LastDBTS rowversion,
   @MaxOrderID int,
   @StoreID int
)
AS
   if (@MaxOrderID < 0)
   begin
      SELECT s.*
         FROM Shipments s
         WHERE s.RowVersion > @LastDBTS AND s.StoreID = @StoreID
   end
   else
   begin
      SELECT s.*
        FROM Shipments s
        WHERE s.RowVersion > @LastDBTS AND s.StoreID = @StoreID AND s.OrderID <= @MaxOrderID
   end
GO

-----------------------------
--- Procedure GetOrderShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipments]
GO

CREATE PROCEDURE GetOrderShipments
(
    @OrderID int
)
AS
   SELECT *
     FROM Shipments
     WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipments]
GO

CREATE PROCEDURE GetCustomerShipments
(
    @CustomerID int
)
AS
   SELECT *
     FROM Shipments
     WHERE CustomerID = @CustomerID
GO

-----------------------------
--- Procedure UpdateShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateShipment]
GO

CREATE PROCEDURE UpdateShipment
(
    @ShipmentID int,
    @RowVersion timestamp,
    @OrderID int ,
    @CustomerID int,
    @ShipmentType int,
    @Processed bit ,
    @ProcessedDate datetime ,
    @ShippedDate datetime ,
    @ServiceUsed nvarchar(50) ,
    @TrackingNumber nvarchar(50) ,
    @Notes ntext,
    @CommoditiesCreated bit,
    @TotalCharges money ,
    @TotalWeight float , 
    @ToFirstName nvarchar (30)  ,
    @ToLastName nvarchar (30)  ,
    @ToCompany nvarchar (30)  ,
    @ToAddress1 nvarchar (60)  ,
    @ToAddress2 nvarchar (60)  ,
    @ToAddress3 nvarchar (60)  ,
    @ToCity nvarchar (50)  ,
    @ToStateProvinceCode nvarchar (25)  ,
    @ToPostalCode nvarchar (10)  ,
    @ToCountryCode nvarchar (5)  ,
    @ToPhone nvarchar (25)  ,
    @ToFax nvarchar (25) ,
    @ToEmail nvarchar (50)
)
AS
    -- Only one can be set
    if (@OrderID >= 0 AND @CustomerID >= 0)
    begin
       RAISERROR ('An shipment cannot be associated with more than one object.', 16, 1)
       return
    end

    UPDATE [Shipments]
    SET OrderID = @OrderID,
        CustomerID = @CustomerID,
        ShipmentType = @ShipmentType,
        Processed = @Processed,
        ProcessedDate = @ProcessedDate,
        ShippedDate = @ShippedDate,
        ServiceUsed = @ServiceUsed,
        TrackingNumber = @TrackingNumber,
        Notes = @Notes,
        CommoditiesCreated = @CommoditiesCreated,
        TotalCharges = @TotalCharges,
        TotalWeight = @TotalWeight, 
        ToFirstName = @ToFirstName,
        ToLastName = @ToLastName,
        ToCompany = @ToCompany,
        ToAddress1 = @ToAddress1,
        ToAddress2 = @ToAddress2,
        ToAddress3 = @ToAddress3,
        ToCity = @ToCity,
        ToStateProvinceCode = @ToStateProvinceCode,
        ToPostalCode = @ToPostalCode,
        ToCountryCode = @ToCountryCode,
        ToPhone = @ToPhone,
        ToFax = @ToFax,
        ToEmail = @ToEmail
    WHERE ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM Shipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

-----------------------------
--- Procedure UpdateWorldShipShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateWorldShipShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateWorldShipShipment]
GO

CREATE PROCEDURE UpdateWorldShipShipment
(
    @ShipmentID int,
    @ServiceUsed nvarchar(50) ,
    @TrackingNumber nvarchar(50) ,
    @TotalCharges money ,
    @TotalWeight float
)
AS
    UPDATE Shipments
       SET ServiceUsed = @ServiceUsed,
           TrackingNumber = @TrackingNumber,
           TotalCharges = @TotalCharges,
           TotalWeight = @TotalWeight
       WHERE ShipmentID = @ShipmentID

    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM Shipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

-----------------------------
--- Procedure AddShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddShipment]
GO

CREATE PROCEDURE AddShipment
(
    @StoreID int,
    @OrderID int,
    @CustomerID int,
    @ShipmentType int,
    @Processed bit ,
    @ProcessedDate datetime ,
    @ShippedDate datetime ,
    @ServiceUsed nvarchar(50) ,
    @TrackingNumber nvarchar(50) ,
    @Notes ntext,
    @CommoditiesCreated bit,
    @TotalCharges money ,
    @TotalWeight float , 
    @ToFirstName nvarchar (30)  ,
    @ToLastName nvarchar (30)  ,
    @ToCompany nvarchar (30)  ,
    @ToAddress1 nvarchar (60)  ,
    @ToAddress2 nvarchar (60)  ,
    @ToAddress3 nvarchar (60)  ,
    @ToCity nvarchar (50)  ,
    @ToStateProvinceCode nvarchar (25)  ,
    @ToPostalCode nvarchar (10)  ,
    @ToCountryCode nvarchar (5)  ,
    @ToPhone nvarchar (25)  ,
    @ToFax nvarchar (25) ,
    @ToEmail nvarchar (50)
)
AS
    -- Only one can be set
    if (@OrderID >= 0 AND @CustomerID >= 0)
    begin
       RAISERROR ('An shipment cannot be associated with more than one object.', 16, 1)
       return
    end

    INSERT INTO [Shipments]
    (
        StoreID,
        OrderID ,
        CustomerID,
        ShipmentType,
        Processed ,
        ProcessedDate  ,
        ShippedDate  ,
        ServiceUsed  ,
        TrackingNumber  ,
        Notes,
        CommoditiesCreated,
        TotalCharges  ,
        TotalWeight  , 
        ToFirstName ,
        ToLastName ,
        ToCompany  ,
        ToAddress1  ,
        ToAddress2  ,
        ToAddress3 ,
        ToCity ,
        ToStateProvinceCode ,
        ToPostalCode ,
        ToCountryCode ,
        ToPhone ,
        ToFax ,
        ToEmail
    )
    VALUES
    (
        @StoreID,
        @OrderID ,
        @CustomerID,
        @ShipmentType,
        @Processed ,
        @ProcessedDate  ,
        @ShippedDate  ,
        @ServiceUsed  ,
        @TrackingNumber  ,
        @Notes,
        @CommoditiesCreated,
        @TotalCharges  ,
        @TotalWeight  , 
        @ToFirstName ,
        @ToLastName ,
        @ToCompany  ,
        @ToAddress1  ,
        @ToAddress2  ,
        @ToAddress3 ,
        @ToCity ,
        @ToStateProvinceCode ,
        @ToPostalCode ,
        @ToCountryCode ,
        @ToPhone ,
        @ToFax ,
        @ToEmail
    )
    
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT ShipmentID, RowVersion
   FROM Shipments
   WHERE ShipmentID = SCOPE_IDENTITY()

   return 1
GO
