-----------------------------
--- TABLE FedexPackages
-----------------------------
CREATE TABLE dbo.FedexPackages
(
   	FedexPackageID int IDENTITY (1, 1) NOT NULL ,
   	[RowVersion] timestamp NOT NULL,
   	ShipmentID int NOT NULL,
    PackagingType smallint NOT NULL,
    Length int NOT NULL,
    Width int NOT NULL,
    Height int NOT NULL,
    Weight float NOT NULL,
    SkidPieces smallint NOT NULL,
    DeclaredValue money NOT NULL,
    TrackingNumber nvarchar (20) NOT NULL,
	LabelImagePath nvarchar (350) NOT NULL ,
	CONSTRAINT [PK_FedexPackages] PRIMARY KEY CLUSTERED ([FedexPackageID])  ,
	CONSTRAINT [FK_FedexPackages_Shipment] FOREIGN KEY ([ShipmentID]) REFERENCES [FedexShipments] ([ShipmentID])
)
GO

-----------------------------
--- Procedure GetOrderFedexPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderFedexPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderFedexPackages]
GO

CREATE PROCEDURE dbo.GetOrderFedexPackages
(
    @OrderID int
)
AS
   SELECT p.*
   FROM FedexPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerFedexPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerFedexPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerFedexPackages]
GO

CREATE PROCEDURE dbo.GetCustomerFedexPackages
(
    @CustomerID int
)
AS
   SELECT p.*
   FROM FedexPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetFedexPackageRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetFedexPackageRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetFedexPackageRange]
GO

CREATE PROCEDURE dbo.GetFedexPackageRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT p.*
     FROM FedexPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure DeleteFedexPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteFedexPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteFedexPackage]
GO

CREATE PROCEDURE dbo.DeleteFedexPackage
(
    @FedexPackageID int
)
AS
   DELETE FROM FedexPackages
     WHERE FedexPackageID = @FedexPackageID
GO

-----------------------------
--- Procedure AddFedexPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFedexPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddFedexPackage]
GO

CREATE PROCEDURE dbo.AddFedexPackage
(
    @ShipmentID int,
    @PackagingType smallint,
    @Length int,
    @Width int,
    @Height int,
    @Weight float,
    @SkidPieces smallint,
    @DeclaredValue money,
    @TrackingNumber nvarchar (20),
    @LabelImagePath nvarchar (350)
)
AS
    INSERT INTO FedexPackages
    (
        ShipmentID,
        PackagingType,
        Length,
        Width,
        Height,
        Weight,
        SkidPieces,
        DeclaredValue,
        TrackingNumber,
        LabelImagePath
    )
    VALUES
    (
        @ShipmentID,
        @PackagingType,
        @Length,
        @Width,
        @Height,
        @Weight,
        @SkidPieces,
        @DeclaredValue,
        @TrackingNumber,
        @LabelImagePath
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT FedexPackageID, [RowVersion]
      FROM FedexPackages
      WHERE FedexPackageID = SCOPE_IDENTITY()

    return 1
GO

-----------------------------
--- Procedure UpdateFedexPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFedexPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFedexPackage]
GO

CREATE PROCEDURE dbo.UpdateFedexPackage
(
    @FedexPackageID int,
    @RowVersion timestamp,
    @ShipmentID int,
    @PackagingType smallint,
    @Length int,
    @Width int,
    @Height int,
    @Weight float,
    @SkidPieces smallint,
    @DeclaredValue money,
    @TrackingNumber nvarchar (20),
    @LabelImagePath nvarchar (350)
)
AS
    UPDATE FedexPackages
    SET ShipmentID = @ShipmentID,
        PackagingType = @PackagingType,
        Length = @Length,
        Width = @Width,
        Height = @Height,
        Weight = @Weight,
        SkidPieces = @SkidPieces,
        DeclaredValue = @DeclaredValue,
        TrackingNumber = @TrackingNumber,
        LabelImagePath = @LabelImagePath
    WHERE FedexPackageID = @FedexPackageID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT FedexPackageID, [RowVersion]
      FROM FedexPackages
      WHERE FedexPackageID = @FedexPackageID

    return 1
GO

 
