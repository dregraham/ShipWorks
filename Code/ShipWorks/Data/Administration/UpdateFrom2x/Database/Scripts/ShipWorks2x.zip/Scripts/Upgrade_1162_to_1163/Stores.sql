ALTER TABLE dbo.Stores ADD
	MarketworksCorpServer bit NOT NULL CONSTRAINT DF_Stores_MarketworksCorpServer DEFAULT 0
GO

ALTER TABLE dbo.Stores
	DROP CONSTRAINT DF_Stores_MarketworksCorpServer
GO


----------------------------
--- PROCEDURE AddStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddStore]
GO

CREATE PROCEDURE AddStore
(
   @StoreType int,  
   @StoreName nvarchar(75),  
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int,  
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit,
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(50),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit, 
   @MivaLiveManualOrderNumbers bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @MarketworksCorpServer bit
)
AS
   INSERT INTO [Stores]
   (
        [StoreType], 
        [StoreName], 
        [CompanyName], 
        [CompanyAddress1], 
        [CompanyAddress2], 
        [CompanyAddress3], 
        [CompanyCity], 
        [CompanyStateProvCode], 
        [CompanyPostalCode], 
        [CompanyCountryCode], 
        [CompanyUrl], 
        [CompanyFax], 
        [CompanyPhone], 
        [CompanyEmail], 
        [CompanyLogo],
        [LastUpdateTime], 
        [DownloadAddressCasing],
        [EmailDefaultAccountID], 
        [EmailLogSaveMessage],
        [EmailLogSaveMessageImages],
        [OrderStatusStrings], 
        [ItemStatusStrings], 
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [StoreUsername], 
        [StorePassword], 
        [StoreSavePassword], 
        [MivaPassphrase], 
        [MivaSiteID], 
        [MivaModuleUrl], 
        [MivaStoreCode], 
        [MivaConnectSecure], 
        [MivaRemovedDeletedBatches], 
        [MivaSebenzaExtraMsg], 
        [MivaLiveManualOrderNumbers],
        [eBayUserID], 
        [eBayToken], 
        [eBayTokenExpire],
        [eBayDownloadItemDetails],
		[ShopSiteCgiUrl],
		[ShopSiteConnectSecure],
		[ShopSiteTimeZoneID],
        [YahooPopServer],
        [MarketworksCorpServer]
   )
   VALUES 
   (
        @StoreType, 
        @StoreName, 
        @CompanyName, 
        @CompanyAddress1,
        @CompanyAddress2, 
        @CompanyAddress3, 
        @CompanyCity, 
        @CompanyStateProvCode, 
        @CompanyPostalCode, 
        @CompanyCountryCode, 
        @CompanyUrl, 
        @CompanyFax, 
        @CompanyPhone, 
        @CompanyEmail, 
        @CompanyLogo,
        @LastUpdateTime, 
        @DownloadAddressCasing,
        @EmailDefaultAccountID, 
        @EmailLogSaveMessage,
        @EmailLogSaveMessageImages,
        @OrderStatusStrings,
        @ItemStatusStrings, 
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @StoreUsername, 
        @StorePassword, 
        @StoreSavePassword, 
        @MivaPassphrase, 
        @MivaSiteID, 
        @MivaModuleUrl, 
        @MivaStoreCode, 
        @MivaConnectSecure, 
        @MivaRemovedDeletedBatches, 
        @MivaSebenzaExtraMsg, 
        @MivaLiveManualOrderNumbers,
        @eBayUserID, 
        @eBayToken, 
        @eBayTokenExpire,
        @eBayDownloadItemDetails,
		@ShopSiteCgiUrl,
		@ShopSiteConnectSecure,
		@ShopSiteTimeZoneID,
        @YahooPopServer,
        @MarketworksCorpServer
)
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, RowVersion
   FROM Stores
   WHERE StoreID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE SaveLastUpdateTime
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveLastUpdateTime]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveLastUpdateTime]
GO

CREATE PROCEDURE SaveLastUpdateTime
(
   @StoreID int,
   @LastUpdateTime datetime
)
AS
    UPDATE [Stores]
    SET [LastUpdateTime]=@LastUpdateTime
    WHERE [StoreID] = @StoreID

   SET NOCOUNT ON

   SELECT *
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE SaveEmailSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveEmailSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveEmailSettings]
GO

CREATE PROCEDURE SaveEmailSettings
(
   @StoreID int,
   @EmailDefaultAccountID int,
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit
)
AS
    UPDATE Stores
      SET EmailDefaultAccountID = @EmailDefaultAccountID,
          EmailLogSaveMessage = @EmailLogSaveMessage,
          EmailLogSaveMessageImages = @EmailLogSaveMessageImages
      WHERE StoreID = @StoreID

   SET NOCOUNT ON

   SELECT *
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO


----------------------------
--- PROCEDURE UpdateStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateStore]
GO

CREATE PROCEDURE UpdateStore
(
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @StoreType int,  
   @StoreName nvarchar(75),  
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int, 
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit, 
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(50),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit,  
   @MivaLiveManualOrderNumbers bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @MarketworksCorpServer bit
)
AS
   UPDATE [Stores]
   SET [StoreType]=@StoreType, 
       [StoreName]=@StoreName, 
       [CompanyName]=@CompanyName, 
       [CompanyAddress1]=@CompanyAddress1, 
       [CompanyAddress2]=@CompanyAddress2, 
       [CompanyAddress3]=@CompanyAddress3, 
       [CompanyCity]=@CompanyCity, 
       [CompanyStateProvCode]=@CompanyStateProvCode, 
       [CompanyPostalCode]=@CompanyPostalCode, 
       [CompanyCountryCode]=@CompanyCountryCode, 
       [CompanyUrl]=@CompanyUrl, 
       [CompanyFax]=@CompanyFax, 
       [CompanyPhone]=@CompanyPhone, 
       [CompanyEmail]=@CompanyEmail, 
       [CompanyLogo]=@CompanyLogo,
       [LastUpdateTime]=@LastUpdateTime, 
       [DownloadAddressCasing]=@DownloadAddressCasing,
       [EmailDefaultAccountID]=@EmailDefaultAccountID, 
       [EmailLogSaveMessage]=@EmailLogSaveMessage,
       [EmailLogSaveMessageImages]=@EmailLogSaveMessageImages,
       [OrderStatusStrings]=@OrderStatusStrings, 
       [ItemStatusStrings]=@ItemStatusStrings, 
       [OrderNumberPrefix]=@OrderNumberPrefix,
       [OrderNumberPostfix]=@OrderNumberPostfix,
       [StoreUsername]=@StoreUsername, 
       [StorePassword]=@StorePassword, 
       [StoreSavePassword]=@StoreSavePassword, 
       [MivaPassphrase]=@MivaPassphrase, 
       [MivaSiteID]=@MivaSiteID,
       [MivaModuleUrl]=@MivaModuleUrl, 
       [MivaStoreCode]=@MivaStoreCode, 
       [MivaConnectSecure]=@MivaConnectSecure, 
       [MivaRemovedDeletedBatches]=@MivaRemovedDeletedBatches, 
       [MivaSebenzaExtraMsg]=@MivaSebenzaExtraMsg, 
       [MivaLiveManualOrderNumbers]=@MivaLiveManualOrderNumbers,
       [eBayUserID]=@eBayUserID, 
       [eBayToken]=@eBayToken, 
       [eBayTokenExpire]=@eBayTokenExpire,
       [eBayDownloadItemDetails]=@eBayDownloadItemDetails,
	   [ShopSiteCgiUrl]=@ShopSiteCgiUrl,
	   [ShopSiteConnectSecure]=@ShopSiteConnectSecure,
	   [ShopSiteTimeZoneID] = @ShopSiteTimeZoneID,
       [YahooPopServer]=@YahooPopServer,
       [MarketworksCorpServer] = @MarketworksCorpServer
    WHERE [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO
