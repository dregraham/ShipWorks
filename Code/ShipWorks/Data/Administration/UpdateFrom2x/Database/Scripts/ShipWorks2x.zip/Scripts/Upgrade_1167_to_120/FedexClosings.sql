-----------------------------
--- TABLE FedexClosings
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'FedexClosings') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
   drop table dbo.FedexClosings
GO

CREATE TABLE dbo.FedexClosings 
(
	ClosingID int IDENTITY (1, 1) NOT NULL,
	ShipperID int NOT NULL,
	ShipperAccountNumber int NOT NULL,
	CloseDate datetime NOT NULL,
	ReportPaths nvarchar (450) NOT NULL,
	CONSTRAINT PK_FedexClosings PRIMARY KEY CLUSTERED (ClosingID)
)
GO

-- Create the index on CloseDate
CREATE INDEX IX_FedexClosings_CloseDate
    ON FedexClosings (CloseDate)
GO

----------------------------
--- PROCEDURE AddFedexClosing
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.AddFedexClosing') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure dbo.AddFedexClosing
GO

CREATE PROCEDURE dbo.AddFedexClosing
(
	@ShipperID int,
	@ShipperAccountNumber int,
	@CloseDate datetime,
	@ReportPaths nvarchar (450)
)
AS
    INSERT INTO FedexClosings
    (
        ShipperID,
        ShipperAccountNumber,
        CloseDate,
        ReportPaths
    )
    VALUES
    (
        @ShipperID,
        @ShipperAccountNumber,
        @CloseDate,
        @ReportPaths
    )
    
    if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT ClosingID
   FROM FedexClosings
   WHERE ClosingID = SCOPE_IDENTITY()
   
   return 1
GO

----------------------------
--- PROCEDURE GetRecentClosings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetRecentClosings') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure dbo.GetRecentClosings
GO

CREATE PROCEDURE dbo.GetRecentClosings
(
	@ShipperID int,
	@MaxDays int
)
AS 
    if ( (SELECT Count(*) FROM FedexClosings) = 0)
        return 0
    
    SELECT fc.*
    FROM FedexClosings fc
    WHERE fc.CloseDate >= DATEADD(day, -@MaxDays, (SELECT MAX(fcInner.CloseDate) FROM FedexClosings fcInner)) AND
      fc.ShipperID = @ShipperID
    ORDER BY CloseDate ASC

GO