ALTER TABLE dbo.UpsShipments
	DROP COLUMN Voided
GO

-----------------------------
--- Procedure GetOrderUpsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUpsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUpsShipments]
GO

CREATE PROCEDURE dbo.GetOrderUpsShipments
(
    @OrderID int
)
AS
   SELECT u.*
   FROM UpsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUpsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUpsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUpsShipments]
GO

CREATE PROCEDURE dbo.GetCustomerUpsShipments
(
    @CustomerID int
)
AS
   SELECT u.*
   FROM UpsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderUpsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUpsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUpsShipmentRange]
GO

CREATE PROCEDURE dbo.GetOrderUpsShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT u.*
     FROM UpsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerUpsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUpsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUpsShipmentRange]
GO

CREATE PROCEDURE dbo.GetCustomerUpsShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT u.*
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure UpdateUpsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUpsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUpsShipment]
GO

CREATE PROCEDURE dbo.UpdateUpsShipment
(
    @ShipmentID int,
    @RowVersion timestamp ,
    @DescriptionOfGoods nvarchar (100)  ,
    @DocumentsOnly bit ,
    @CustomsValue money ,
    @ReferenceNumber nvarchar (50)  ,
    @ServiceCode nvarchar (10)  ,
    @LabelTypeCode  nvarchar (10)  ,
    @ArrivalDate datetime ,
    @NotificationEmailFromName nvarchar (50)  ,
    @NotificationEmailSubjectCode nvarchar (50)  ,
    @NotificationEmailFailedAddress nvarchar (50)  ,
    @NotificationEmailMemo nvarchar (150)  ,
    @NotificationEmailRecipients nvarchar (1500), 
    @ShipToResidential bit ,
    @ShipToShipperNumber nvarchar (10)  ,
    @ShipFromCompanyOrName nvarchar (30)  ,
    @ShipFromAttention nvarchar (30)  ,
    @ShipFromAddress1 nvarchar (60)  ,
    @ShipFromAddress2 nvarchar (60)  ,
    @ShipFromAddress3 nvarchar (60)  ,
    @ShipFromCity nvarchar (50)  ,
    @ShipFromStateProvinceCode nvarchar (5)  ,
    @ShipFromPostalCode nvarchar (10)  ,
    @ShipFromCountryCode nvarchar (5)  ,
    @ShipFromContactEmail nvarchar (25)  ,
    @ShipFromContactPhone nvarchar (25)  ,
    @ShipFromContactFax nvarchar (25)  ,
    @ShipFromShipperNumber nvarchar (10) 
)
AS
    UPDATE [UpsShipments]
    SET DescriptionOfGoods = @DescriptionOfGoods,
        DocumentsOnly = @DocumentsOnly,
        CustomsValue = @CustomsValue,
        ReferenceNumber = @ReferenceNumber,
        ServiceCode = @ServiceCode,
        LabelTypeCode = @LabelTypeCode,
        ArrivalDate = @ArrivalDate,
        NotificationEmailFromName = @NotificationEmailFromName,
        NotificationEmailSubjectCode = @NotificationEmailSubjectCode,
        NotificationEmailFailedAddress = @NotificationEmailFailedAddress,
        NotificationEmailMemo = @NotificationEmailMemo,
        NotificationEmailRecipients = @NotificationEmailRecipients,
        ShipToResidential = @ShipToResidential,
        ShipToShipperNumber = @ShipToShipperNumber,
	    ShipFromCompanyOrName = @ShipFromCompanyOrName,
	    ShipFromAttention = @ShipFromAttention,
	    ShipFromAddress1 = @ShipFromAddress1,
	    ShipFromAddress2 = @ShipFromAddress2,
	    ShipFromAddress3 = @ShipFromAddress3,
	    ShipFromCity = @ShipFromCity,
	    ShipFromStateProvinceCode = @ShipFromStateProvinceCode,
	    ShipFromPostalCode = @ShipFromPostalCode,
	    ShipFromCountryCode = @ShipFromCountryCode,
        ShipFromContactEmail = @ShipFromContactEmail,
	    ShipFromContactPhone = @ShipFromContactPhone,
	    ShipFromContactFax = @ShipFromContactFax,
        ShipFromShipperNumber = @ShipFromShipperNumber
    WHERE ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM UpsShipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

-----------------------------
--- Procedure AddUpsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUpsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUpsShipment]
GO

CREATE PROCEDURE dbo.AddUpsShipment
(
    @ShipmentID int,
    @DescriptionOfGoods nvarchar (100)  ,
    @DocumentsOnly bit ,
    @CustomsValue money ,
    @ReferenceNumber nvarchar (50)  ,
    @ServiceCode nvarchar (10)  ,
    @LabelTypeCode  nvarchar (10)  ,
    @ArrivalDate datetime ,
    @NotificationEmailFromName nvarchar (50)  ,
    @NotificationEmailSubjectCode nvarchar (50)  ,
    @NotificationEmailFailedAddress nvarchar (50)  ,
    @NotificationEmailMemo nvarchar (150)  ,
    @NotificationEmailRecipients nvarchar (1500),
    @ShipToResidential bit ,
    @ShipToShipperNumber nvarchar (10)  ,
    @ShipFromCompanyOrName nvarchar (30)  ,
    @ShipFromAttention nvarchar (30)  ,
    @ShipFromAddress1 nvarchar (60)  ,
    @ShipFromAddress2 nvarchar (60)  ,
    @ShipFromAddress3 nvarchar (60)  ,
    @ShipFromCity nvarchar (50)  ,
    @ShipFromStateProvinceCode nvarchar (5)  ,
    @ShipFromPostalCode nvarchar (10)  ,
    @ShipFromCountryCode nvarchar (5)  ,
    @ShipFromContactEmail nvarchar (25)  ,
    @ShipFromContactPhone nvarchar (25)  ,
    @ShipFromContactFax nvarchar (25)  ,
    @ShipFromShipperNumber nvarchar (10) 
)
AS
    if (exists(SELECT * FROM UpsShipments WHERE ShipmentID = @ShipmentID))
    begin
    
        select * from UpsShipments WHERE ShipmentID = @ShipmentID
        
    end
    else
    begin
        INSERT INTO [UpsShipments]
        (
	        ShipmentID,
            DescriptionOfGoods,
            DocumentsOnly,
            CustomsValue,
            ReferenceNumber,
            ServiceCode,
            LabelTypeCode,
            ArrivalDate,
            NotificationEmailFromName,
            NotificationEmailSubjectCode,
            NotificationEmailFailedAddress,
            NotificationEmailMemo,
            NotificationEmailRecipients,
            ShipToResidential,
            ShipToShipperNumber,
	        ShipFromCompanyOrName,
	        ShipFromAttention,
	        ShipFromAddress1,
	        ShipFromAddress2,
	        ShipFromAddress3,
	        ShipFromCity,
	        ShipFromStateProvinceCode,
	        ShipFromPostalCode,
	        ShipFromCountryCode,
            ShipFromContactEmail,
	        ShipFromContactPhone,
	        ShipFromContactFax,
            ShipFromShipperNumber
        )
        VALUES
        (
            @ShipmentID,
            @DescriptionOfGoods,
            @DocumentsOnly,
            @CustomsValue,
            @ReferenceNumber,
            @ServiceCode,
            @LabelTypeCode,
            @ArrivalDate,
            @NotificationEmailFromName,
            @NotificationEmailSubjectCode,
            @NotificationEmailFailedAddress,
            @NotificationEmailMemo,
            @NotificationEmailRecipients,
            @ShipToResidential,
            @ShipToShipperNumber,
            @ShipFromCompanyOrName,
            @ShipFromAttention,
            @ShipFromAddress1,
            @ShipFromAddress2,
            @ShipFromAddress3,
            @ShipFromCity,
            @ShipFromStateProvinceCode,
            @ShipFromPostalCode,
            @ShipFromCountryCode,
            @ShipFromContactEmail,
            @ShipFromContactPhone,
            @ShipFromContactFax,
            @ShipFromShipperNumber    
        )
            
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ShipmentID, RowVersion
        FROM UpsShipments
        WHERE ShipmentID = @ShipmentID

        return 1   
  end
  
GO