ALTER TABLE dbo.EndiciaShippers ADD
	ShipperType int NOT NULL	CONSTRAINT DF_EndiciaShippers_ShipperType DEFAULT 0,
	EndiciaAccountNumber nvarchar(30) NOT NULL CONSTRAINT DF_EndiciaShippers_EndiciaAccountNumber DEFAULT '',
	SignupConfirmation nvarchar(30) NOT NULL CONSTRAINT DF_EndiciaShippers_SignupConfirmation DEFAULT '',
	ApiInitialPassword nvarchar(250) NOT NULL CONSTRAINT DF_EndiciaShippers_ApiInitialPassword DEFAULT '',
	ApiUserPassword nvarchar(250) NOT NULL CONSTRAINT DF_EndiciaShippers_ApiUserPassword DEFAULT '',
	TestLabelServerAccount bit NOT NULL CONSTRAINT DF_EndiciaShippers_TestLabelServerAccount DEFAULT 0,
	CustomsSigner nvarchar(100) NOT NULL CONSTRAINT DF_EndiciaShippers_CustomsSigner DEFAULT '',
	CustomsCertify BIT NOT NULL CONSTRAINT DF_EndiciaShippers_CustomsCertify DEFAULT 0
GO

ALTER TABLE dbo.EndiciaShippers DROP CONSTRAINT DF_EndiciaShippers_ShipperType
GO

ALTER TABLE dbo.EndiciaShippers DROP CONSTRAINT DF_EndiciaShippers_EndiciaAccountNumber
GO

ALTER TABLE dbo.EndiciaShippers DROP CONSTRAINT DF_EndiciaShippers_SignupConfirmation
GO

ALTER TABLE dbo.EndiciaShippers DROP CONSTRAINT DF_EndiciaShippers_ApiInitialPassword
GO

ALTER TABLE dbo.EndiciaShippers DROP CONSTRAINT DF_EndiciaShippers_ApiUserPassword
GO

ALTER TABLE dbo.EndiciaShippers DROP CONSTRAINT DF_EndiciaShippers_TestLabelServerAccount
GO

ALTER TABLE dbo.EndiciaShippers DROP CONSTRAINT DF_EndiciaShippers_CustomsSigner
GO

ALTER TABLE dbo.EndiciaShippers DROP CONSTRAINT DF_EndiciaShippers_CustomsCertify
GO

----------------------------
--- PROCEDURE AddEndiciaShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddEndiciaShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddEndiciaShipper]
GO

CREATE PROCEDURE dbo.AddEndiciaShipper
(
	@Company nvarchar(35),
	@ContactName nvarchar(35),
	@Address1 nvarchar(60),
	@Address2 nvarchar(60),
	@Address3 nvarchar(60),
	@City nvarchar(50),
	@StateProvinceCode nvarchar(5),
	@PostalCode nvarchar(10),
	@ContactEmail nvarchar(35),
	@ContactPhone nvarchar(25),
	@ShipperType int,
	@EndiciaAccountNumber nvarchar(30),
	@SignupConfirmation nvarchar(30),
	@ApiInitialPassword nvarchar(250),
	@ApiUserPassword nvarchar(250),
	@TestLabelServerAccount bit,
	@CustomsSigner nvarchar(100),
	@CustomsCertify bit
)
WITH ENCRYPTION
AS
	INSERT INTO EndiciaShippers
	(
		Company,
		ContactName,
		Address1,
		Address2,
		Address3,
		City,
		StateProvinceCode,
		PostalCode,
		ContactEmail,
		ContactPhone,
		ShipperType,
		EndiciaAccountNumber,
		SignupConfirmation,
		ApiInitialPassword,
		ApiUserPassword,
		TestLabelServerAccount,
		CustomsSigner,
		CustomsCertify
	)
	VALUES
	(
		@Company,
		@ContactName,
		@Address1,
		@Address2,
		@Address3,
		@City,
		@StateProvinceCode,
		@PostalCode,
		@ContactEmail,
		@ContactPhone,
		@ShipperType,
		@EndiciaAccountNumber,
		@SignupConfirmation,
		@ApiInitialPassword,
		@ApiUserPassword,
		@TestLabelServerAccount,
		@CustomsSigner,
		@CustomsCertify
	)
	
	if (@@ROWCOUNT != 1)
		return 0
		
	SET NOCOUNT ON
	
	SELECT EndiciaShipperID, [RowVersion]
		FROM EndiciaShippers
		WHERE EndiciaShipperID = SCOPE_IDENTITY()
		
	RETURN 1
GO
		
----------------------------
--- PROCEDURE UpdateEndiciaShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateEndiciaShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateEndiciaShipper]
GO

CREATE PROCEDURE dbo.UpdateEndiciaShipper
(
	@EndiciaShipperID int,
	@RowVersion timestamp,
	@Company nvarchar(35),
	@ContactName nvarchar(35),
	@Address1 nvarchar(60),
	@Address2 nvarchar(60),
	@Address3 nvarchar(60),
	@City nvarchar(50),
	@StateProvinceCode nvarchar(5),
	@PostalCode nvarchar(10),
	@ContactEmail nvarchar(35),
	@ContactPhone nvarchar(25),
	@ShipperType int,
	@EndiciaAccountNumber nvarchar(30),
	@SignupConfirmation nvarchar(30),
	@ApiInitialPassword nvarchar(250),
	@ApiUserPassword nvarchar(250),
	@TestLabelServerAccount bit,
	@CustomsSigner nvarchar(100),
	@CustomsCertify bit
)
WITH ENCRYPTION
AS 
	UPDATE EndiciaShippers
		SET
			Company = @Company,
			ContactName = @ContactName,
			Address1 = @Address1,
			Address2 = @Address2,
			Address3 = @Address3,
			City = @City,
			StateProvinceCode = @StateProvinceCode,
			PostalCode = @PostalCode,
			ContactEmail = @ContactEmail,
			ContactPhone = @ContactPhone,
			ShipperType = @ShipperType,
			EndiciaAccountNumber = @EndiciaAccountNumber,
			SignupConfirmation = @SignupConfirmation,
			ApiInitialPassword = @ApiInitialPassword,
			ApiUserPassword = @ApiUserPassword,
			TestLabelServerAccount = @TestLabelServerAccount,
			CustomsSigner = @CustomsSigner,
			CustomsCertify = @CustomsCertify
		WHERE EndiciaShipperID = @EndiciaShipperID AND [RowVersion] = @RowVersion
		
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT EndiciaShipperID, [RowVersion]
		FROM EndiciaShippers
		WHERE EndiciaShipperID = @EndiciaShipperID
		
	RETURN 1
GO

-----------------------------
--- Procedure DeleteEndiciaShipper
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteEndiciaShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteEndiciaShipper]
GO

CREATE PROCEDURE dbo.DeleteEndiciaShipper
(
	@EndiciaShipperID int
)
WITH ENCRYPTION
AS
	DELETE FROM EndiciaShippers
	WHERE EndiciaShipperID = @EndiciaShipperID
GO


----------------------------
--- PROCEDURE GetAllEndiciaShippers
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllEndiciaShippers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllEndiciaShippers]
GO

CREATE PROCEDURE dbo.GetAllEndiciaShippers 
WITH ENCRYPTION
AS
   SELECT *
   FROM EndiciaShippers
GO
