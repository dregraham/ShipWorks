-----------------------------
--- Procedure DeleteOrderItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteOrderItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteOrderItemAttribute]
GO

CREATE PROCEDURE dbo.DeleteOrderItemAttribute
(
   @AttributeID int
)
WITH ENCRYPTION
AS
    DELETE FROM OrderItemAttributes
    WHERE AttributeID = @AttributeID
GO

-----------------------------
--- Procedure GetItemAttributesRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetItemAttributesRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetItemAttributesRange]
GO

CREATE PROCEDURE dbo.GetItemAttributesRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT a.*
   FROM OrderItemAttributes a, OrderItems i, Orders o
   WHERE a.OrderItemID = i.OrderItemID AND
         i.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
         o.OrderID > @MinOrderID
GO

-----------------------------
--- Procedure GetOrderItemAttributes
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderItemAttributes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderItemAttributes]
GO

CREATE PROCEDURE dbo.GetOrderItemAttributes
(
    @OrderItemID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM [OrderItemAttributes]
   WHERE OrderItemID = @OrderItemID
GO

-----------------------------
--- Procedure AddItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddItemAttribute]
GO

CREATE PROCEDURE dbo.AddItemAttribute
(
    @OrderItemID int,
	@Code [nvarchar] (300),
	@Name [nvarchar] (300),
    @Description [nvarchar] (1500),
	@UnitPrice money,
	@MivaAttributeID int,
	@MivaOptionCode [nvarchar] (300)
)
WITH ENCRYPTION
AS
    INSERT INTO [OrderItemAttributes]
    (
	    [OrderItemID],
	    [Code],
	    [Name],
	    [Description],
	    [UnitPrice],
	    [MivaAttributeID],
	    [MivaOptionCode]
    )
    VALUES
    (
	    @OrderItemID,
	    @Code,
	    @Name,
	    @Description,
	    @UnitPrice,
	    @MivaAttributeID,
	    @MivaOptionCode
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT AttributeID, [RowVersion]
    FROM OrderItemAttributes
    WHERE AttributeID = SCOPE_IDENTITY()

    return 1
GO

-----------------------------
--- Procedure UpdateItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateItemAttribute]
GO

CREATE PROCEDURE dbo.UpdateItemAttribute
(
	@AttributeID int,
	@RowVersion timestamp,
    @OrderItemID int,
    @Code nvarchar (300),
	@Name nvarchar (300),
	@Description nvarchar (1500),
	@UnitPrice money,
	@MivaAttributeID int,
	@MivaOptionCode nvarchar (300)
)
WITH ENCRYPTION
AS
    UPDATE [OrderItemAttributes]
    SET [OrderItemID] = @OrderItemID,
        [Code] = @Code,
	    [Name] = @Name,
	    [Description] = @Description,
	    [UnitPrice] = @UnitPrice,
	    [MivaAttributeID] = @MivaAttributeID,
	    [MivaOptionCode] = @MivaOptionCode
    WHERE AttributeID = @AttributeID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT [RowVersion]
    FROM OrderItemAttributes
    WHERE AttributeID = @AttributeID

    return 1
GO

-----------------------------
--- Procedure SynchMivaItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaItemAttribute]
GO

CREATE PROCEDURE dbo.SynchMivaItemAttribute
(
	@OrderItemID int,
	@Code nvarchar (300),
	@Name nvarchar (300),
	@Description nvarchar (1500),
	@UnitPrice money,
	@MivaAttributeID int,
	@MivaOptionCode nvarchar (300)
)
WITH ENCRYPTION
AS
   
    -- If this Miva item attribute already exists, we dont do anything
    if exists (
        SELECT * 
        FROM OrderItemAttributes a
        WHERE a.MivaAttributeID = @MivaAttributeID AND
              a.Code = @Code AND 
              a.OrderItemID = @OrderItemID)
    begin
    
        -- This just lets the .NET data provider know everything is OK
        SELECT AttributeID, [RowVersion]
        FROM OrderItemAttributes a
        WHERE a.MivaAttributeID = @MivaAttributeID AND
              a.Code = @Code AND
              a.OrderItemID = @OrderItemID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItemAttributes]
        (
	        [OrderItemID],
	        [Code],
	        [Name],
	        [Description],
	        [UnitPrice],
	        [MivaAttributeID],
	        [MivaOptionCode]
        )
        VALUES
        (
	        @OrderItemID,
	        @Code,
	        @Name,
	        @Description,
	        @UnitPrice,
	        @MivaAttributeID,
	        @MivaOptionCode
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT AttributeID, [RowVersion]
        FROM OrderItemAttributes
        WHERE AttributeID = SCOPE_IDENTITY()

        return 1
    end
GO
