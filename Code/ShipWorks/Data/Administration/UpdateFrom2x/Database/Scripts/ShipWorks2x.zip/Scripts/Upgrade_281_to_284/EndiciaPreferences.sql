ALTER TABLE dbo.EndiciaPreferences
	DROP CONSTRAINT FK_EndiciaPreferences_Stores
GO

GO
ALTER TABLE dbo.EndiciaPreferences
	DROP CONSTRAINT FK_EndiciaPreferences_Clients
GO

GO
CREATE TABLE dbo.Tmp_EndiciaPreferences
	(
	ClientID int NOT NULL,
	StoreID int NOT NULL,
	SetPackaging bit NOT NULL,
	SetService bit NOT NULL,
	SetConfirmation bit NOT NULL,
	SetWeight bit NOT NULL,
	SetDims bit NOT NULL,
	SetDate bit NOT NULL,
	SetInsurance bit NOT NULL,
	DefaultPackaging int NOT NULL,
	DefaultDomesticService int NOT NULL,
	DefaultInternationalService int NOT NULL,
	DefaultConfirmation int NOT NULL,
	DefaultDateAdvance int NOT NULL,
	DefaultInsuranceType int NOT NULL,
	DefaultLayouts ntext NOT NULL,
	DefaultStealthMode bit NOT NULL,
	DefaultOversize bit NOT NULL,
	DefaultNonMachinable bit NOT NULL,
	DefaultCustomsForm int NOT NULL,
	DefaultCustomsDescription varchar(200) NOT NULL,
	DefaultCustomsContentType int NOT NULL,
	DefaultWidth float(53) NOT NULL,
	DefaultLength float(53) NOT NULL,
	DefaultDepth float(53) NOT NULL,
	ReferenceID varchar(200) NOT NULL,
	RubberStamp1 varchar(200) NOT NULL,
	RubberStamp2 varchar(200) NOT NULL,
	RubberStamp3 varchar(200) NOT NULL,
	RubberStamp4 varchar(200) NOT NULL,
	TestMode bit NOT NULL,
	CloseOnComplete bit NOT NULL,
	AutoPrintCustoms bit NOT NULL,
	UnattendedPrinting bit NOT NULL,
	BlankRecipientPhone nvarchar(25) NOT NULL
	)
GO

IF EXISTS(SELECT * FROM dbo.EndiciaPreferences)
	 EXEC('INSERT INTO dbo.Tmp_EndiciaPreferences (ClientID, StoreID, SetPackaging, SetService, SetConfirmation, SetWeight, SetDims, SetDate, SetInsurance, DefaultPackaging, DefaultDomesticService, DefaultInternationalService, DefaultConfirmation, DefaultDateAdvance, DefaultInsuranceType, DefaultLayouts, DefaultStealthMode, DefaultOversize, DefaultNonMachinable, DefaultCustomsForm, DefaultCustomsDescription, DefaultCustomsContentType, DefaultWidth, DefaultLength, DefaultDepth, ReferenceID, RubberStamp1, RubberStamp2, RubberStamp3, RubberStamp4, TestMode, CloseOnComplete, AutoPrintCustoms, UnattendedPrinting, BlankRecipientPhone)
		                                    SELECT ClientID, StoreID, 0,            SetService, SetConfirmation, SetWeight, 0,       SetDate, SetInsurance, 4,                DefaultDomesticService, DefaultInternationalService, DefaultConfirmation, DefaultDateAdvance, DefaultInsuranceType, DefaultLayouts, DefaultStealthMode, DefaultOversize, 0,                    DefaultCustomsForm, DefaultCustomsDescription, DefaultCustomsContentType, 0,            0,             0,            ReferenceID, RubberStamp1, RubberStamp2, RubberStamp3, RubberStamp4, TestMode, CloseOnComplete, AutoPrintCustoms, UnattendedPrinting, BlankRecipientPhone FROM dbo.EndiciaPreferences')
GO

DROP TABLE dbo.EndiciaPreferences
GO

EXECUTE sp_rename N'dbo.Tmp_EndiciaPreferences', N'EndiciaPreferences', 'OBJECT' 
GO

ALTER TABLE dbo.EndiciaPreferences ADD CONSTRAINT
	PK_EndiciaPreferences PRIMARY KEY CLUSTERED 
	(
	ClientID,
	StoreID
	)

GO

ALTER TABLE dbo.EndiciaPreferences ADD CONSTRAINT
	FK_EndiciaPreferences_Clients FOREIGN KEY
	(
	ClientID
	) REFERENCES dbo.Clients
	(
	ClientID
	)
GO

ALTER TABLE dbo.EndiciaPreferences ADD CONSTRAINT
	FK_EndiciaPreferences_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

----------------------------
--- PROCEDURE GetEndiciaPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetEndiciaPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetEndiciaPreferences]
GO

CREATE PROCEDURE dbo.GetEndiciaPreferences
(
    @StoreID int,
    @ClientID int
)
WITH ENCRYPTION
AS
   -- See if there are any prefs for this store\client
   if (0 = (SELECT COUNT(*)
                FROM EndiciaPreferences
                WHERE StoreID = @StoreID AND ClientID = @ClientID) )
   begin
   
      -- There are not.  See if there are any for the store to use as a starting point
        INSERT INTO EndiciaPreferences 
        (
            ClientID,
            StoreID,
            SetPackaging,
		    SetService,
		    SetConfirmation,
		    SetWeight,
		    SetDims,
		    SetDate,
		    SetInsurance,
		    DefaultPackaging,
		    DefaultDomesticService,
		    DefaultInternationalService,
		    DefaultConfirmation,
		    DefaultDateAdvance,
		    DefaultInsuranceType,
		    DefaultLayouts,
		    DefaultStealthMode,
		    DefaultOversize,
		    DefaultNonMachinable,
		    DefaultCustomsForm,
		    DefaultCustomsDescription,
		    DefaultCustomsContentType,
		    DefaultWidth,
		    DefaultLength,
		    DefaultDepth,
		    ReferenceID,
		    RubberStamp1,
		    RubberStamp2,
		    RubberStamp3,
		    RubberStamp4,
		    TestMode,
		    CloseOnComplete,
		    AutoPrintCustoms,
		    UnattendedPrinting,
		    BlankRecipientPhone
		)
		SELECT TOP 1
            @ClientID,
            StoreID,
            SetPackaging,
		    SetService,
		    SetConfirmation,
		    SetWeight,
		    SetDims,
		    SetDate,
		    SetInsurance,
		    DefaultPackaging,
		    DefaultDomesticService,
		    DefaultInternationalService,
		    DefaultConfirmation,
		    DefaultDateAdvance,
		    DefaultInsuranceType,
		    DefaultLayouts,
		    DefaultStealthMode,
		    DefaultOversize,
		    DefaultNonMachinable,
		    DefaultCustomsForm,
		    DefaultCustomsDescription,
		    DefaultCustomsContentType,
		    DefaultWidth,
		    DefaultLength,
		    DefaultDepth,
		    ReferenceID,
		    RubberStamp1,
		    RubberStamp2,
		    RubberStamp3,
		    RubberStamp4,
		    TestMode,
		    CloseOnComplete,
		    AutoPrintCustoms,
		    UnattendedPrinting,
		    BlankRecipientPhone
		FROM EndiciaPreferences WHERE StoreID = @StoreID
	end
	
    SELECT *
        FROM EndiciaPreferences
        WHERE StoreID = @StoreID AND ClientID = @ClientID
                
GO

----------------------------
--- PROCEDURE AddEndiciaPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddEndiciaPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddEndiciaPreferences]
GO

CREATE PROCEDURE dbo.AddEndiciaPreferences
(
    @ClientID int ,
    @StoreID int ,
    @SetPackaging bit,
    @SetService bit,
    @SetConfirmation bit,
    @SetWeight bit,
    @SetDims bit,
    @SetDate bit,
    @SetInsurance bit,
    @DefaultPackaging int,
    @DefaultDomesticService int,
    @DefaultInternationalService int,
    @DefaultConfirmation int,
    @DefaultDateAdvance int,
    @DefaultInsuranceType int,
    @DefaultLayouts ntext,
    @DefaultStealthMode bit,
    @DefaultOversize bit,
    @DefaultNonMachinable bit,
    @DefaultCustomsForm int,
    @DefaultCustomsDescription varchar (200),
    @DefaultCustomsContentType int,
    @DefaultWidth float,
    @DefaultLength float,
    @DefaultDepth float,
    @ReferenceID varchar(200),
    @RubberStamp1 varchar(200),
    @RubberStamp2 varchar(200),
    @RubberStamp3 varchar(200),
    @RubberStamp4 varchar(200),
    @TestMode bit,
    @CloseOnComplete bit,
    @AutoPrintCustoms bit,
    @UnattendedPrinting bit,
    @BlankRecipientPhone nvarchar (25)
)
WITH ENCRYPTION
AS
   INSERT INTO EndiciaPreferences
   (
        ClientID,
        StoreID,
        SetPackaging,
	    SetService,
	    SetConfirmation,
	    SetWeight,
	    SetDims,
	    SetDate,
	    SetInsurance,
	    DefaultPackaging,
	    DefaultDomesticService,
	    DefaultInternationalService,
	    DefaultConfirmation,
	    DefaultDateAdvance,
	    DefaultInsuranceType,
	    DefaultLayouts,
	    DefaultStealthMode,
	    DefaultOversize,
	    DefaultNonMachinable,
	    DefaultCustomsForm,
	    DefaultCustomsDescription,
	    DefaultCustomsContentType,
	    DefaultWidth,
	    DefaultLength,
	    DefaultDepth,
	    ReferenceID,
	    RubberStamp1,
	    RubberStamp2,
	    RubberStamp3,
	    RubberStamp4,
	    TestMode,
	    CloseOnComplete,
	    AutoPrintCustoms,
	    UnattendedPrinting,
	    BlankRecipientPhone
   )
   VALUES
   (
        @ClientID,
        @StoreID,
        @SetPackaging,
		@SetService,
		@SetConfirmation,
		@SetWeight,
		@SetDims,
		@SetDate,
		@SetInsurance,
		@DefaultPackaging,
		@DefaultDomesticService,
		@DefaultInternationalService,
		@DefaultConfirmation,
		@DefaultDateAdvance,
		@DefaultInsuranceType,
		@DefaultLayouts,
		@DefaultStealthMode,
		@DefaultOversize,
		@DefaultNonMachinable,
		@DefaultCustomsForm,
		@DefaultCustomsDescription,
		@DefaultCustomsContentType,
		@DefaultWidth,
		@DefaultLength,
		@DefaultDepth,
		@ReferenceID,
		@RubberStamp1,
		@RubberStamp2,
		@RubberStamp3,
		@RubberStamp4,
		@TestMode,
		@CloseOnComplete,
		@AutoPrintCustoms,
		@UnattendedPrinting,
		@BlankRecipientPhone
   )
   
    if (@@ROWCOUNT != 1)
        return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
     FROM EndiciaPreferences
     WHERE StoreID = @StoreID AND ClientID = @ClientID

   return 1
GO

----------------------------
--- PROCEDURE UpdateEndiciaPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateEndiciaPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateEndiciaPreferences]
GO

CREATE PROCEDURE dbo.UpdateEndiciaPreferences
(
    @ClientID int ,
    @StoreID int ,
    @SetPackaging bit,
    @SetService bit,
    @SetConfirmation bit,
    @SetWeight bit,
    @SetDims bit,
    @SetDate bit,
    @SetInsurance bit,
    @DefaultPackaging int,
    @DefaultDomesticService int,
    @DefaultInternationalService int,
    @DefaultConfirmation int,
    @DefaultDateAdvance int,
    @DefaultInsuranceType int,
    @DefaultLayouts ntext,
    @DefaultStealthMode bit,
    @DefaultOversize bit,
    @DefaultNonMachinable bit,
    @DefaultCustomsForm int,
    @DefaultCustomsDescription varchar (200),
    @DefaultCustomsContentType int,
    @DefaultWidth float,
    @DefaultLength float,
    @DefaultDepth float,
    @ReferenceID varchar(200),
    @RubberStamp1 varchar(200),
    @RubberStamp2 varchar(200),
    @RubberStamp3 varchar(200),
    @RubberStamp4 varchar(200),
    @TestMode bit,
    @CloseOnComplete bit,
    @AutoPrintCustoms bit,
    @UnattendedPrinting bit,
    @BlankRecipientPhone nvarchar (25)
)
WITH ENCRYPTION
AS
   UPDATE EndiciaPreferences
   SET  ClientID = @ClientID,
        StoreID = @StoreID,
        SetPackaging = @SetPackaging,
	    SetService = @SetService,
	    SetConfirmation = @SetConfirmation,
	    SetWeight = @SetWeight,
	    SetDims = @SetDims,
	    SetDate = @SetDate,
	    SetInsurance = @SetInsurance,
	    DefaultPackaging = @DefaultPackaging,
	    DefaultDomesticService = @DefaultDomesticService,
	    DefaultInternationalService = @DefaultInternationalService,
	    DefaultConfirmation = @DefaultConfirmation,
	    DefaultDateAdvance = @DefaultDateAdvance,
	    DefaultInsuranceType = @DefaultInsuranceType,
	    DefaultLayouts = @DefaultLayouts,
	    DefaultStealthMode = @DefaultStealthMode,
	    DefaultOversize = @DefaultOversize,
	    DefaultNonMachinable = @DefaultNonMachinable,
	    DefaultCustomsForm = @DefaultCustomsForm,
	    DefaultCustomsDescription = @DefaultCustomsDescription,
	    DefaultCustomsContentType = @DefaultCustomsContentType,
	    DefaultWidth = @DefaultWidth,
	    DefaultLength = @DefaultLength,
	    DefaultDepth = @DefaultDepth,
	    ReferenceID = @ReferenceID,
	    RubberStamp1 = @RubberStamp1,
	    RubberStamp2 = @RubberStamp2,
	    RubberStamp3 = @RubberStamp3,
	    RubberStamp4 = @RubberStamp4,
	    TestMode = @TestMode,
	    CloseOnComplete = @CloseOnComplete,
	    AutoPrintCustoms = @AutoPrintCustoms,
	    UnattendedPrinting = @UnattendedPrinting,
	    BlankRecipientPhone = @BlankRecipientPhone
   WHERE StoreID = @StoreID AND ClientID = @ClientID
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
   FROM EndiciaPreferences
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO