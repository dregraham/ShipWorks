ALTER TABLE Orders
   ALTER COLUMN Notes nvarchar (1500)
GO

ALTER TABLE Orders
   ALTER COLUMN ShipStateProvinceCode nvarchar (25)
GO

ALTER TABLE Orders
   ALTER COLUMN BillStateProvinceCode nvarchar (25)
GO
-----------------------------
--- Procedure AddOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddOrder]
GO

CREATE PROCEDURE AddOrder
(
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @Total [money],
    @Notes [nvarchar] (1500),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedCheckoutStatus [int],
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int],
    @MivaRequestedShipping [nvarchar] (50),
    @MivaCustomStatus [nvarchar] (50)
)
AS
    if (@OrderNumber <= 0)
    begin
      
        -- Determine the next OrderNumber to use
        SELECT @OrderNumber = MAX(OrderNumber) + 1
          FROM Orders
          WHERE StoreID = @StoreID
        
        if (@OrderNumber IS NULL)
           SELECT @OrderNumber = 1
           
    end

    INSERT INTO [Orders](
        [OrderNumber], 
        [StoreID], 
        [CustomerID], 
        [OrderDate], 
        [ShipFirstName],
        [ShipLastName],
        [ShipCompany],
        [ShipAddress1], 
        [ShipAddress2], 
        [ShipAddress3], 
        [ShipCity], 
        [ShipStateProvinceCode], 
        [ShipPostalCode], 
        [ShipCountryCode], 
        [ShipEmail], 
        [ShipPhone],
        [ShipFax],
        [BillFirstName],
        [BillLastName],
        [BillCompany],
        [BillAddress1], 
        [BillAddress2], 
        [BillAddress3], 
        [BillCity], 
        [BillStateProvinceCode], 
        [BillPostalCode], 
        [BillCountryCode], 
        [BillEmail], 
        [BillPhone],
        [BillFax],
        [Total], 
        [Notes], 
        [IsManual],
        [eBayOrderID], 
        [eBayBuyerID], 
        [eBayBuyerFeedbackScore],
        [eBayBuyerFeedbackPrivate],
        [eBayLastModified], 
        [eBayPaymentStatus], 
        [eBayPaymentMethod], 
        [eBayIncompleteState], 
        [eBayStatusIs], 
        [eBayLeftFeedback], 
        [eBayLeftFeedbackType], 
        [eBayLeftFeedbackComments], 
        [eBayReceivedFeedbackType], 
        [eBayReceivedFeedbackComments], 
        [eBayMarkedCheckoutStatus], 
        [eBayMarkedPaymentMethod], 
        [eBayAllowEdit], 
        [MivaBatchID], 
        [MivaRequestedShipping], 
        [MivaCustomStatus]
    )
    VALUES
    (
        @OrderNumber, 
        @StoreID, 
        @CustomerID, 
        @OrderDate, 
        @ShipFirstName,
        @ShipLastName,
        @ShipCompany,
        @ShipAddress1, 
        @ShipAddress2, 
        @ShipAddress3, 
        @ShipCity, 
        @ShipStateProvinceCode, 
        @ShipPostalCode, 
        @ShipCountryCode, 
        @ShipEmail, 
        @ShipPhone,
        @ShipFax,
        @BillFirstName,
        @BillLastName,
        @BillCompany,
        @BillAddress1, 
        @BillAddress2, 
        @BillAddress3, 
        @BillCity, 
        @BillStateProvinceCode, 
        @BillPostalCode, 
        @BillCountryCode, 
        @BillEmail, 
        @BillPhone,
        @BillFax,
        @Total, 
        @Notes, 
        1, -- IsManual
        @eBayOrderID, 
        @eBayBuyerID, 
        @eBayBuyerFeedbackScore,
        @eBayBuyerFeedbackPrivate,
        @eBayLastModified, 
        @eBayPaymentStatus, 
        @eBayPaymentMethod, 
        @eBayIncompleteState, 
        @eBayStatusIs, 
        @eBayLeftFeedback, 
        @eBayLeftFeedbackType, 
        @eBayLeftFeedbackComments, 
        @eBayReceivedFeedbackType, 
        @eBayReceivedFeedbackComments, 
        @eBayMarkedCheckoutStatus, 
        @eBayMarkedPaymentMethod, 
        @eBayAllowEdit, 
        @MivaBatchID, 
        @MivaRequestedShipping, 
        @MivaCustomStatus
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT OrderID, OrderNumber, [RowVersion], IsManual
    FROM Orders
    WHERE OrderID = SCOPE_IDENTITY()
    
    return 1
GO

-----------------------------
--- Procedure UpdateOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateOrder]
GO

CREATE PROCEDURE UpdateOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @Total [money],
    @Notes [nvarchar] (1500),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedCheckoutStatus [int],
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int],
    @MivaRequestedShipping [nvarchar] (50),
    @MivaCustomStatus [nvarchar] (50)
)
AS       
    UPDATE Orders
    SET OrderNumber = @OrderNumber,
        StoreID = @StoreID,
        CustomerID = @CustomerID,
        OrderDate = @OrderDate,
	    ShipFirstName = @ShipFirstName,
	    ShipLastName = @ShipLastName,
	    ShipCompany = @ShipCompany,
        ShipAddress1 = @ShipAddress1,
        ShipAddress2 = @ShipAddress2,
        ShipAddress3 = @ShipAddress3,
        ShipCity = @ShipCity,
        ShipStateProvinceCode = @ShipStateProvinceCode,
        ShipPostalCode = @ShipPostalCode,
        ShipCountryCode = @ShipCountryCode,
        ShipEmail = @ShipEmail,
        ShipPhone = @ShipPhone,
        ShipFax = @ShipFax,
	    BillFirstName = @BillFirstName,
	    BillLastName = @BillLastName,
	    BillCompany = @BillCompany,
        BillAddress1 = @BillAddress1,
        BillAddress2 = @BillAddress2,
        BillAddress3 = @BillAddress3,
        BillCity = @BillCity,
        BillStateProvinceCode = @BillStateProvinceCode,
        BillPostalCode = @BillPostalCode,
        BillCountryCode = @BillCountryCode,
        BillEmail = @BillEmail,
        BillPhone = @BillPhone,
        BillFax = @BillFax,
        Total = @Total,
        Notes = @Notes,
        eBayOrderID = @eBayOrderID,
        eBayBuyerID = @eBayBuyerID,
        eBayBuyerFeedbackScore = @eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate = @eBayBuyerFeedbackPrivate,
        eBayLastModified = @eBayLastModified,
        eBayPaymentStatus = @eBayPaymentStatus,
        eBayPaymentMethod = @eBayPaymentMethod,
        eBayIncompleteState = @eBayIncompleteState,
        eBayStatusIs = @eBayStatusIs,
        eBayLeftFeedback = @eBayLeftFeedback,
        eBayLeftFeedbackType = @eBayLeftFeedbackType,
        eBayLeftFeedbackComments = @eBayLeftFeedbackComments,
        eBayReceivedFeedbackType = @eBayReceivedFeedbackType,
        eBayReceivedFeedbackComments = @eBayReceivedFeedbackComments,
        eBayMarkedCheckoutStatus = @eBayMarkedCheckoutStatus,
        eBayMarkedPaymentMethod = @eBayMarkedPaymentMethod,
        eBayAllowEdit = @eBayAllowEdit,
        MivaBatchID = @MivaBatchID,
        MivaRequestedShipping = @MivaRequestedShipping,
        MivaCustomStatus = @MivaCustomStatus
    WHERE OrderID = @OrderID AND [RowVersion] = @RowVersion

    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT [RowVersion]
    FROM Orders
    WHERE [OrderID] = @OrderID
            
    return 1
GO


-----------------------------
--- Procedure SynchEBayOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchEBayOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchEBayOrder]
GO

CREATE PROCEDURE SynchEBayOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @Total [money],
    @Notes [nvarchar] (1500),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedCheckoutStatus [int],
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int],
    @MivaRequestedShipping [nvarchar] (50),
    @MivaCustomStatus [nvarchar] (50),
	@eBayItemID bigint,
	@eBayTransID bigint,
    @WasNew [bit] OUTPUT
)
AS 
    -- Assume its new by default
    SELECT @WasNew = 1

    -- If this eBay order already exists as a combined order
    if exists (
        SELECT * 
        FROM Orders
        WHERE @eBayOrderID != 0 AND 
              eBayOrderID = @eBayOrderID AND
              StoreID = @StoreID
    )
    begin
        
        SELECT @OrderID = MAX(OrderID), @OrderNumber = MAX(OrderNumber)
        FROM Orders
        WHERE eBayOrderID = @eBayOrderID AND
              StoreID = @StoreID
        
        -- Its not new
        SELECT @WasNew = 0
        
    end
    
    -- See if this eBay order exists as a single item, which we will find in the items table
    else if exists (
        SELECT * 
        FROM Orders o, OrderItems i
        WHERE @eBayItemID != 0 AND 
              i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              o.OrderID = i.OrderID AND 
              o.StoreID = @StoreID
    )
    begin
    
        SELECT @OrderID = MAX(o.OrderID), @OrderNumber = MAX(o.OrderNumber)
        FROM Orders o, OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              o.OrderID = i.OrderID AND 
              o.StoreID = @StoreID
              
        -- Its not new
        SELECT @WasNew = 0

    end
    
    -- If its new, then create the order
    if (@WasNew != 0)
    begin       
        -- Determine the next OrderNumber to use
        SELECT @OrderNumber = MAX(OrderNumber) + 1
          FROM Orders
          WHERE StoreID = @StoreID
        
        if (@OrderNumber IS NULL)
           SELECT @OrderNumber = 1
    
        INSERT INTO [Orders](
            [OrderNumber], 
            [StoreID], 
            [CustomerID], 
            [OrderDate], 
            [ShipFirstName],
            [ShipLastName],
            [ShipCompany],
            [ShipAddress1], 
            [ShipAddress2], 
            [ShipAddress3], 
            [ShipCity], 
            [ShipStateProvinceCode], 
            [ShipPostalCode], 
            [ShipCountryCode], 
            [ShipEmail], 
            [ShipPhone],
            [ShipFax],
            [BillFirstName],
            [BillLastName],
            [BillCompany],
            [BillAddress1], 
            [BillAddress2], 
            [BillAddress3], 
            [BillCity], 
            [BillStateProvinceCode], 
            [BillPostalCode], 
            [BillCountryCode], 
            [BillEmail], 
            [BillPhone],
            [BillFax],
            [Total], 
            [Notes], 
            [IsManual],
            [eBayOrderID], 
            [eBayBuyerID], 
            [eBayBuyerFeedbackScore],
            [eBayBuyerFeedbackPrivate],
            [eBayLastModified], 
            [eBayPaymentStatus], 
            [eBayPaymentMethod], 
            [eBayIncompleteState], 
            [eBayStatusIs], 
            [eBayLeftFeedback], 
            [eBayLeftFeedbackType], 
            [eBayLeftFeedbackComments], 
            [eBayReceivedFeedbackType], 
            [eBayReceivedFeedbackComments], 
            [eBayMarkedCheckoutStatus], 
            [eBayMarkedPaymentMethod], 
            [eBayAllowEdit], 
            [MivaBatchID], 
            [MivaRequestedShipping], 
            [MivaCustomStatus]
        )
        VALUES
        (
            @OrderNumber, 
            @StoreID, 
            @CustomerID, 
            @OrderDate, 
            @ShipFirstName,
            @ShipLastName,
            @ShipCompany,
            @ShipAddress1, 
            @ShipAddress2, 
            @ShipAddress3, 
            @ShipCity, 
            @ShipStateProvinceCode, 
            @ShipPostalCode, 
            @ShipCountryCode, 
            @ShipEmail, 
            @ShipPhone,
            @ShipFax,
            @BillFirstName,
            @BillLastName,
            @BillCompany,
            @BillAddress1, 
            @BillAddress2, 
            @BillAddress3, 
            @BillCity, 
            @BillStateProvinceCode, 
            @BillPostalCode, 
            @BillCountryCode, 
            @BillEmail, 
            @BillPhone,
            @BillFax,
            @Total, 
            @Notes, 
            0, -- IsManual
            @eBayOrderID, 
            @eBayBuyerID, 
            @eBayBuyerFeedbackScore,
            @eBayBuyerFeedbackPrivate,
            @eBayLastModified, 
            @eBayPaymentStatus, 
            @eBayPaymentMethod, 
            @eBayIncompleteState, 
            @eBayStatusIs, 
            @eBayLeftFeedback, 
            @eBayLeftFeedbackType, 
            @eBayLeftFeedbackComments, 
            @eBayReceivedFeedbackType, 
            @eBayReceivedFeedbackComments, 
            @eBayMarkedCheckoutStatus, 
            @eBayMarkedPaymentMethod, 
            @eBayAllowEdit, 
            @MivaBatchID, 
            @MivaRequestedShipping, 
            @MivaCustomStatus
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderID, OrderNumber, [RowVersion], IsManual
        FROM Orders
        WHERE OrderID = SCOPE_IDENTITY()
        
        return 1
    end
    
    -- Its not new, we have to update it
    else
    begin
    
        UPDATE Orders
        SET OrderNumber = @OrderNumber,
            StoreID = @StoreID,
            CustomerID = @CustomerID,
            OrderDate = @OrderDate,
	        ShipFirstName = @ShipFirstName,
	        ShipLastName = @ShipLastName,
	        ShipCompany = @ShipCompany,
            ShipAddress1 = @ShipAddress1,
            ShipAddress2 = @ShipAddress2,
            ShipAddress3 = @ShipAddress3,
            ShipCity = @ShipCity,
            ShipStateProvinceCode = @ShipStateProvinceCode,
            ShipPostalCode = @ShipPostalCode,
            ShipCountryCode = @ShipCountryCode,
            ShipEmail = @ShipEmail,
            ShipPhone = @ShipPhone,
            ShipFax = @ShipFax,
	        BillFirstName = @BillFirstName,
	        BillLastName = @BillLastName,
	        BillCompany = @BillCompany,
            BillAddress1 = @BillAddress1,
            BillAddress2 = @BillAddress2,
            BillAddress3 = @BillAddress3,
            BillCity = @BillCity,
            BillStateProvinceCode = @BillStateProvinceCode,
            BillPostalCode = @BillPostalCode,
            BillCountryCode = @BillCountryCode,
            BillEmail = @BillEmail,
            BillPhone = @BillPhone,
            BillFax = @BillFax,
            Total = @Total,
            Notes = @Notes,
            eBayOrderID = @eBayOrderID,
            eBayBuyerID = @eBayBuyerID,
            eBayBuyerFeedbackScore = @eBayBuyerFeedbackScore,
            eBayBuyerFeedbackPrivate = @eBayBuyerFeedbackPrivate,
            eBayLastModified = @eBayLastModified,
            eBayPaymentStatus = @eBayPaymentStatus,
            eBayPaymentMethod = @eBayPaymentMethod,
            eBayIncompleteState = @eBayIncompleteState,
            eBayStatusIs = @eBayStatusIs,
            eBayLeftFeedback = @eBayLeftFeedback,
            eBayLeftFeedbackType = @eBayLeftFeedbackType,
            eBayLeftFeedbackComments = @eBayLeftFeedbackComments,
            eBayReceivedFeedbackType = @eBayReceivedFeedbackType,
            eBayReceivedFeedbackComments = @eBayReceivedFeedbackComments,
            eBayMarkedCheckoutStatus = @eBayMarkedCheckoutStatus,
            eBayMarkedPaymentMethod = @eBayMarkedPaymentMethod,
            eBayAllowEdit = @eBayAllowEdit,
            MivaBatchID = @MivaBatchID,
            MivaRequestedShipping = @MivaRequestedShipping,
            MivaCustomStatus = @MivaCustomStatus
        WHERE OrderID = @OrderID
    
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderID, OrderNumber, [RowVersion]
        FROM Orders
        WHERE OrderID = @OrderID
        
        return 1
    end
GO


-----------------------------
--- Procedure SynchMivaOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaOrder]
GO

CREATE PROCEDURE SynchMivaOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @Total [money],
    @Notes [nvarchar] (1500),
    @eBayOrderID [int],
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayLastModified [datetime],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayIncompleteState [int],
    @eBayStatusIs [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMarkedCheckoutStatus [int],
    @eBayMarkedPaymentMethod [int],
    @eBayAllowEdit [bit],
    @MivaBatchID [int],
    @MivaRequestedShipping [nvarchar] (50),
    @MivaCustomStatus [nvarchar] (50)
)
AS       
    -- If this Miva order number already exists, just update its batch
    if exists (
        SELECT * FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber)
    begin
        -- Update the batch id.  Dont worry about RowVersion mismatch - just do it.
        UPDATE Orders
        SET MivaBatchID = @MivaBatchID 
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber
              
        SET NOCOUNT ON

        -- Select the updated row back into .NET
        SELECT *
        FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber
              
        return 1
    end
    
    -- This order number does not already exist, we need to create it
    else 
    begin
        INSERT INTO [Orders](
            [OrderNumber], 
            [StoreID], 
            [CustomerID], 
            [OrderDate], 
            [ShipFirstName],
            [ShipLastName],
            [ShipCompany],
            [ShipAddress1], 
            [ShipAddress2], 
            [ShipAddress3], 
            [ShipCity], 
            [ShipStateProvinceCode], 
            [ShipPostalCode], 
            [ShipCountryCode], 
            [ShipEmail], 
            [ShipPhone],
            [ShipFax],
            [BillFirstName],
            [BillLastName],
            [BillCompany],
            [BillAddress1], 
            [BillAddress2], 
            [BillAddress3], 
            [BillCity], 
            [BillStateProvinceCode], 
            [BillPostalCode], 
            [BillCountryCode], 
            [BillEmail], 
            [BillPhone],
            [BillFax],
            [Total], 
            [Notes], 
            [IsManual],
            [eBayOrderID], 
            [eBayBuyerID], 
            [eBayBuyerFeedbackScore],
            [eBayBuyerFeedbackPrivate],
            [eBayLastModified], 
            [eBayPaymentStatus], 
            [eBayPaymentMethod], 
            [eBayIncompleteState], 
            [eBayStatusIs], 
            [eBayLeftFeedback], 
            [eBayLeftFeedbackType], 
            [eBayLeftFeedbackComments], 
            [eBayReceivedFeedbackType], 
            [eBayReceivedFeedbackComments], 
            [eBayMarkedCheckoutStatus], 
            [eBayMarkedPaymentMethod], 
            [eBayAllowEdit], 
            [MivaBatchID], 
            [MivaRequestedShipping], 
            [MivaCustomStatus]
        )
        VALUES
        (
            @OrderNumber, 
            @StoreID, 
            @CustomerID, 
            @OrderDate, 
            @ShipFirstName,
            @ShipLastName,
            @ShipCompany,
            @ShipAddress1, 
            @ShipAddress2, 
            @ShipAddress3, 
            @ShipCity, 
            @ShipStateProvinceCode, 
            @ShipPostalCode, 
            @ShipCountryCode, 
            @ShipEmail, 
            @ShipPhone,
            @ShipFax,
            @BillFirstName,
            @BillLastName,
            @BillCompany,
            @BillAddress1, 
            @BillAddress2, 
            @BillAddress3, 
            @BillCity, 
            @BillStateProvinceCode, 
            @BillPostalCode, 
            @BillCountryCode, 
            @BillEmail, 
            @BillPhone,
            @BillFax,
            @Total, 
            @Notes, 
            0, -- IsManual
            @eBayOrderID, 
            @eBayBuyerID, 
            @eBayBuyerFeedbackScore,
            @eBayBuyerFeedbackPrivate,
            @eBayLastModified, 
            @eBayPaymentStatus, 
            @eBayPaymentMethod, 
            @eBayIncompleteState, 
            @eBayStatusIs, 
            @eBayLeftFeedback, 
            @eBayLeftFeedbackType, 
            @eBayLeftFeedbackComments, 
            @eBayReceivedFeedbackType, 
            @eBayReceivedFeedbackComments, 
            @eBayMarkedCheckoutStatus, 
            @eBayMarkedPaymentMethod, 
            @eBayAllowEdit, 
            @MivaBatchID, 
            @MivaRequestedShipping, 
            @MivaCustomStatus
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderID, [RowVersion], IsManual
        FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber

        return 1
    end
GO