ALTER TABLE dbo.ClientStoreSettings ADD
	FilterGridSettings text NOT NULL CONSTRAINT DF_ClientStoreSettings_FilterGridSettings DEFAULT ''
GO
ALTER TABLE dbo.ClientStoreSettings DROP CONSTRAINT DF_ClientStoreSettings_FilterGridSettings
GO

----------------------------
--- PROCEDURE GetAllClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetAllClientStoreSettings]
GO

CREATE PROCEDURE dbo.GetAllClientStoreSettings
WITH ENCRYPTION
AS
   SELECT *
   FROM [ClientStoreSettings]
GO

----------------------------
--- PROCEDURE DeleteClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteClientStoreSettings]
GO

CREATE PROCEDURE dbo.DeleteClientStoreSettings
(
   @ClientID int,
   @StoreID int
)
WITH ENCRYPTION
AS
   DELETE FROM [ClientStoreSettings]
   WHERE 
      [ClientID] = @ClientID AND
      [StoreID] = @StoreID
GO

----------------------------
--- PROCEDURE AddClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddClientStoreSettings]
GO

CREATE PROCEDURE dbo.AddClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 varchar (200),
   @WorldShipReferenceNumber2 varchar (200),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @WorldShipProcessOnExport bit,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DisplayShipmentOwnerOrder varchar (200),
   @DisplayShipmentOwnerCustomer varchar (200),
   @FilterGridSettings text
)
WITH ENCRYPTION
AS
   INSERT INTO [ClientStoreSettings]
   (
        [ClientID], 
        [StoreID], 
        [LicenseKey], 
        [PerfDateRangeType],
        [PerfDateRangeDays], 
        [PerfDateRangeMax], 
        [PerfDateRangeMin], 
        [PerfShowFilterCounts],
        [WolrdShipCsvFilename], 
        [WorldShipOutputType], 
        [WorldShipLaunchAfterExport], 
        [WorldShipReferenceNumber1],
        [WorldShipReferenceNumber2],
        [WorldShipQvnFromName],
        [WorldShipQvnSubject],
        [WorldShipQvnMemo],
        [WorldShipQvnFailedAddress],
        [WorldShipQvnShipNotify],
        [WorldShipQvnDeliveryNotify],
        [WorldShipQvnExceptionNotify],
        WorldShipProcessOnExport,
        [StampsDefaultService],
        [StampsDefaultConfirmation],
        [StampsMailpiece],
        [StampsLabelSheet],
        [StampsHidePostage],
        [StampsMemo],
        [UspsDefaultService], 
        [UspsDefaultConfirmation], 
        [UspsDefaultRequestAddressService], 
        [UspsDefaultSendConfirmationEmail], 
        [UspsDefaultTemplate], 
        [DownloadAllowed],
	    [DownloadAutoEnable],
	    [DownloadAutoInterval],
	    DisplayShipmentOwnerOrder,
	    DisplayShipmentOwnerCustomer,
	    FilterGridSettings
   )
   VALUES 
   (
        @ClientID, 
        @StoreID, 
        @LicenseKey, 
        @PerfDateRangeType,
        @PerfDateRangeDays, 
        @PerfDateRangeMax, 
        @PerfDateRangeMin, 
        @PerfShowFilterCounts,
        @WolrdShipCsvFilename, 
        @WorldShipOutputType, 
        @WorldShipLaunchAfterExport, 
        @WorldShipReferenceNumber1,
        @WorldShipReferenceNumber2,
        @WorldShipQvnFromName,
        @WorldShipQvnSubject,
        @WorldShipQvnMemo,
        @WorldShipQvnFailedAddress,
        @WorldShipQvnShipNotify,
        @WorldShipQvnDeliveryNotify,
        @WorldShipQvnExceptionNotify,
        @WorldShipProcessOnExport,
        @StampsDefaultService,
        @StampsDefaultConfirmation,
        @StampsMailpiece,
        @StampsLabelSheet,
        @StampsHidePostage,
        @StampsMemo,
        @UspsDefaultService, 
        @UspsDefaultConfirmation, 
        @UspsDefaultRequestAddressService, 
        @UspsDefaultSendConfirmationEmail, 
        @UspsDefaultTemplate, 
        @DownloadAllowed,
	    @DownloadAutoEnable,
	    @DownloadAutoInterval,
	    @DisplayShipmentOwnerOrder,
	    @DisplayShipmentOwnerCustomer,
	    @FilterGridSettings
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT RowVersion
   FROM ClientStoreSettings
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateClientStoreSettings]
GO

CREATE PROCEDURE dbo.UpdateClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 varchar (200),
   @WorldShipReferenceNumber2 varchar (200),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @WorldShipProcessOnExport bit,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DisplayShipmentOwnerOrder varchar (200),
   @DisplayShipmentOwnerCustomer varchar (200),
   @FilterGridSettings text
)
WITH ENCRYPTION
AS
   UPDATE [ClientStoreSettings]
   SET 
    [LicenseKey] = @LicenseKey, 
    [PerfDateRangeType] = @PerfDateRangeType,
    [PerfDateRangeDays] = @PerfDateRangeDays, 
    [PerfDateRangeMax] = @PerfDateRangeMax, 
    [PerfDateRangeMin] = @PerfDateRangeMin, 
    [PerfShowFilterCounts] = @PerfShowFilterCounts,
    [WolrdShipCsvFilename] = @WolrdShipCsvFilename, 
    [WorldShipOutputType] = @WorldShipOutputType, 
    [WorldShipLaunchAfterExport] = @WorldShipLaunchAfterExport, 
    [WorldShipReferenceNumber1] = @WorldShipReferenceNumber1,
    [WorldShipReferenceNumber2] = @WorldShipReferenceNumber2,
    [WorldShipQvnFromName] = @WorldShipQvnFromName,
    [WorldShipQvnSubject] = @WorldShipQvnSubject,
    [WorldShipQvnMemo] = @WorldShipQvnMemo,
    [WorldShipQvnFailedAddress] = @WorldShipQvnFailedAddress,
    [WorldShipQvnShipNotify] = @WorldShipQvnShipNotify,
    [WorldShipQvnDeliveryNotify] = @WorldShipQvnDeliveryNotify,
    [WorldShipQvnExceptionNotify] = @WorldShipQvnExceptionNotify,
    WorldShipProcessOnExport = @WorldShipProcessOnExport,
    [StampsDefaultService] = @StampsDefaultService,
    [StampsDefaultConfirmation] = @StampsDefaultConfirmation,
    [StampsMailpiece] = @StampsMailpiece,
    [StampsLabelSheet] = @StampsLabelSheet,
    [StampsHidePostage] = @StampsHidePostage,
    [StampsMemo] = @StampsMemo,
    [UspsDefaultService] = @UspsDefaultService, 
    [UspsDefaultConfirmation] = @UspsDefaultConfirmation, 
    [UspsDefaultRequestAddressService] = @UspsDefaultRequestAddressService, 
    [UspsDefaultSendConfirmationEmail] = @UspsDefaultSendConfirmationEmail, 
    [UspsDefaultTemplate] = @UspsDefaultTemplate, 
    [DownloadAllowed] = @DownloadAllowed,
    [DownloadAutoEnable] = @DownloadAutoEnable,
    [DownloadAutoInterval] = @DownloadAutoInterval,
    DisplayShipmentOwnerOrder = @DisplayShipmentOwnerOrder,
    DisplayShipmentOwnerCustomer = @DisplayShipmentOwnerCustomer,
    FilterGridSettings = @FilterGridSettings
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM [ClientStoreSettings]
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID

   return 1
GO
