ALTER TABLE Shipments
   ALTER COLUMN ToStateProvinceCode nvarchar (25) NOT NULL
GO

-----------------------------
--- Procedure GetChangedShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedShipments]
GO

CREATE PROCEDURE GetChangedShipments
(
   @LastDBTS rowversion,
   @StoreID int
)
AS

   SELECT s.*
      FROM Orders o, Shipments s
      WHERE (s.RowVersion > @LastDBTS AND o.StoreID = @StoreID AND o.OrderID = s.OrderID)

GO