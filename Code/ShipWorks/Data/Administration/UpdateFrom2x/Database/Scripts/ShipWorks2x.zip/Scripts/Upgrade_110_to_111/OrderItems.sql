-----------------------------
--- Procedure SynchEBayOrderItem
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchEBayOrderItem]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchEBayOrderItem]
GO

CREATE PROCEDURE SynchEBayOrderItem
(
	@OrderID int,
	@Ordinal int,
	@Name nvarchar (300),
	@Code nvarchar (300),
	@Thumbnail nvarchar (350),
	@Image ntext,
	@UnitPrice money,
	@UnitCost money,
	@Weight float,
	@Quantity float,
	@eBayItemID bigint,
	@eBayTransID bigint,
	@MivaLineID int,
	@MivaProductCode nvarchar (300),
	@MivaCustomStatus nvarchar (50),
	@YahooProductID nvarchar (255)
)
AS
   
    -- If this eBay item already exists, we update it
    if exists (
        SELECT * 
        FROM OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID)
    begin
    
        -- Update the item
        UPDATE OrderItems
        SET [OrderID] = @OrderID,
            [Ordinal] = @Ordinal,
            [Name] = @Name,
            [Code] = @Code,
            [Thumbnail] = @Thumbnail,
            [Image] = @Image,
            [UnitPrice] = @UnitPrice,
            [UnitCost] = @UnitCost,
            [Weight] = @Weight,
            [Quantity] = @Quantity,
            [eBayItemID] = @eBayItemID,
            [eBayTransID] = @eBayTransID,
            [MivaLineID] = @MivaLineID,
            [MivaProductCode] = @MivaProductCode,
            [MivaCustomStatus] = @MivaCustomStatus,
            [YahooProductID] = @YahooProductID
        WHERE eBayItemID = @eBayItemID AND
              eBayTransID = @eBayTransID
              
        -- This just lets the .NET data provider know everything is OK
        SELECT OrderItemID, [RowVersion]
        FROM OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItems]
        (
	        [OrderID],
	        [Ordinal],
	        [Name],
	        [Code],
	        [Thumbnail],
	        [Image],
	        [UnitPrice],
	        [UnitCost],
	        [Weight],
	        [Quantity],
	        [eBayItemID],
	        [eBayTransID],
	        [MivaLineID],
	        [MivaProductCode],
	        [MivaCustomStatus],
	        [YahooProductID]
        )
        VALUES
        (
	        @OrderID,
	        @Ordinal,
	        @Name,
	        @Code,
	        @Thumbnail,
	        @Image,
	        @UnitPrice,
	        @UnitCost,
	        @Weight,
	        @Quantity,
	        @eBayItemID,
	        @eBayTransID,
	        @MivaLineID,
	        @MivaProductCode,
	        @MivaCustomStatus,
	        @YahooProductID
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderItemID, [RowVersion]
        FROM OrderItems
        WHERE OrderItemID = SCOPE_IDENTITY()

        return 1
    end
GO

-- Create trigger to track changes to orderitems
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_OrderItems]'))
    drop trigger [dbo].[TG_OrderItems]
GO

CREATE TRIGGER TG_OrderItems ON OrderItems FOR UPDATE
AS
    if ( (SELECT COUNT(*) FROM inserted) = 0)
       return;
       
    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = o.StoreID 
        FROM inserted i, Orders o
        WHERE i.OrderID = o.OrderID
       
    EXEC SetTableLastDbts 'OrderItems', @StoreID, @@DBTS
GO