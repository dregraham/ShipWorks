ALTER TABLE EmailLog
	DROP CONSTRAINT FK_EmailLog_Clients
GO

ALTER TABLE EmailLog
	DROP CONSTRAINT FK_EmailLog_Stores
GO

CREATE TABLE dbo.Tmp_EmailLog
	(
	    EmailLogID int IDENTITY (1, 1) NOT NULL,
	    OrderID int NOT NULL,
	    CustomerID int NOT NULL,
	    StoreID int NOT NULL,
	    ClientID int NOT NULL,
	    SentDate datetime NOT NULL,
	    EmailFrom nvarchar (250) NOT NULL,
	    EmailTo nvarchar (250) NOT NULL,
	    Cc nvarchar (250) NOT NULL,
	    Bcc nvarchar (250) NOT NULL,
	    Subject nvarchar (200) NOT NULL,
	    Template nvarchar (200) NOT NULL,
	    LocalPath nvarchar (350) NOT NULL,
	    Result int NOT NULL,
	    ErrorMessage nvarchar (150) NOT NULL,
	)
GO

SET IDENTITY_INSERT dbo.Tmp_EmailLog ON
GO
IF EXISTS(SELECT * FROM dbo.EmailLog)
	 EXEC('INSERT INTO dbo.Tmp_EmailLog (EmailLogID, OrderID, CustomerID, StoreID, ClientID, SentDate, EmailFrom, EmailTo,   Cc,   Bcc,   Subject, Template, LocalPath,     Result, ErrorMessage)
		                          SELECT EmailLogID, OrderID, -1,         StoreID, ClientID, SentDate, '''',      Recipient, '''', '''',  Subject, Template, SavedCopyPath, Result, ErrorMessage FROM dbo.EmailLog TABLOCKX')
GO

SET IDENTITY_INSERT dbo.Tmp_EmailLog OFF
GO

DROP TABLE dbo.EmailLog
GO

EXECUTE sp_rename N'dbo.Tmp_EmailLog', N'EmailLog', 'OBJECT'
GO

ALTER TABLE dbo.EmailLog ADD CONSTRAINT
	PK_EmailLog PRIMARY KEY CLUSTERED 
	(
	    EmailLogID
	)

GO

CREATE NONCLUSTERED INDEX IX_EmailLog_SentDate ON dbo.EmailLog
	(
	    SentDate
	)
GO

ALTER TABLE dbo.EmailLog WITH NOCHECK ADD CONSTRAINT
	FK_EmailLog_Stores FOREIGN KEY
	(
	    StoreID
	) 
	REFERENCES dbo.Stores
	(
	    StoreID
	)
GO

ALTER TABLE dbo.EmailLog WITH NOCHECK ADD CONSTRAINT
	FK_EmailLog_Clients FOREIGN KEY
	(
	    ClientID
	) 
	REFERENCES dbo.Clients
	(
	    ClientID
	)
GO

----------------------------
--- PROCEDURE GetAllEmailLogs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetAllEmailLogs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure GetAllEmailLogs
GO

CREATE PROCEDURE GetAllEmailLogs
(
   @StoreID int,
   @MinLogID int
)
AS
      SELECT e.*, o.OrderNumberDisplay as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Orders o, Customers c
        WHERE e.StoreID = @StoreID AND
              e.OrderID = o.OrderID AND 
              o.CustomerID = c.CustomerID AND
              e.EmailLogID > @MinLogID
      UNION
      SELECT e.*, '-' as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Customers c
        WHERE e.StoreID = @StoreID AND
              e.CustomerID = c.CustomerID AND
              e.EmailLogID > @MinLogID
GO

----------------------------
--- PROCEDURE AddEmailLog
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.AddEmailLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure AddEmailLog
GO

CREATE PROCEDURE AddEmailLog
(
	@OrderID int,
	@CustomerID int,
	@StoreID int,
	@ClientID int,
	@SentDate datetime,
	@EmailFrom nvarchar (250),
	@EmailTo nvarchar (250),
	@Cc nvarchar (250),
	@Bcc nvarchar (250),
	@Subject nvarchar (200),
	@Template nvarchar (200),
	@LocalPath nvarchar (350),
	@Result int,
	@ErrorMessage nvarchar (150)
)
AS
    -- Only one can be set
    if (@OrderID >= 0 AND @CustomerID >= 0)
    begin
       RAISERROR ('An email log entry cannot be associated with more than one object.', 16, 1)
       return
    end

    INSERT INTO EmailLog
    (
	    OrderID,
	    CustomerID,
	    StoreID,
	    ClientID,
	    SentDate,
	    EmailFrom,
	    EmailTo,
	    Cc,
	    Bcc,
	    Subject,
	    Template,
	    LocalPath,
	    Result,
	    ErrorMessage
	)
	VALUES
	(
	    @OrderID,
	    @CustomerID,
	    @StoreID,
	    @ClientID,
	    @SentDate,
	    @EmailFrom,
	    @EmailTo,
	    @Cc,
	    @Bcc,
	    @Subject,
	    @Template,
	    @LocalPath,
	    @Result,
	    @ErrorMessage
	)
	
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   DECLARE @scopeIdentity int
   SELECT @scopeIdentity = SCOPE_IDENTITY() - 1
   exec GetAllEmailLogs @StoreID, @scopeIdentity

   return 1
GO