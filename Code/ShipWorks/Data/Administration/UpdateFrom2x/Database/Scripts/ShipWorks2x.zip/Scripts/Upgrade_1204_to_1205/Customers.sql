-- Create the index on eBayBuyerID, which we use to lookup customers
CREATE INDEX IX_Customers_eBayBuyerID
  ON Customers(eBayBuyerID)
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_Customers]'))
    drop trigger [dbo].[TG_Customers]
GO

-- Create trigger to track changes to customers, and insures email address uniqueness
CREATE TRIGGER dbo.TG_Customers ON Customers FOR UPDATE, INSERT
AS      
    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID FROM inserted
    if (@StoreID is NULL)
       return;
        
    IF UPDATE(BillEmail)
    begin
    
        DECLARE @uniqueCount int
        DECLARE @totalCount int
        
        SELECT @uniqueCount = Count(DISTINCT BillEmail), @totalCount = Count(BillEmail)
        FROM Customers
        WHERE BillEmail != '' AND StoreID = @StoreID
                
        if (@uniqueCount != @totalCount)
        BEGIN
            RAISERROR ('Non-blank customer email addresses must be unique.', 16, 1)
            ROLLBACK TRANSACTION
            return
        END 
        
    end
    
    EXEC SetTableLastDbts 'Customers', @StoreID, @@DBTS
GO