CREATE TABLE [dbo].[UspsPackages](
	[UspsPackageID] [int] IDENTITY(1,1) NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	ShipmentID int NOT NULL,	
	LabelImagePath nvarchar(350) NOT NULL,
	LabelTypeCode nvarchar(10) NOT NULL,
	IsPrimaryLabel bit NOT NULL
 CONSTRAINT [PK_UspsPackageID] PRIMARY KEY CLUSTERED ([UspsPackageID] ASC),
 CONSTRAINT [FK_USpsPackages_Shipment] FOREIGN KEY ([ShipmentID]) REFERENCES [UspsShipments]([ShipmentID])
)
GO

-----------------------------
--- Procedure GetOrderUspsPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsPackages]
GO

CREATE PROCEDURE dbo.GetOrderUspsPackages
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
   FROM UspsPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUspsPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsPackages]
GO

CREATE PROCEDURE dbo.GetCustomerUspsPackages
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT p.*
   FROM UspsPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetUspsPackageRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUspsPackageRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUspsPackageRange]
GO

CREATE PROCEDURE dbo.GetUspsPackageRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
     FROM UspsPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure DeleteUspsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteUspsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteUspsPackage]
GO

CREATE PROCEDURE dbo.DeleteUspsPackage
(
    @UspsPackageID int
)
WITH ENCRYPTION
AS
   DELETE FROM UspsPackages
     WHERE UspsPackageID = @UspsPackageID
GO

-----------------------------
--- Procedure AddUspsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUspsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUspsPackage]
GO

CREATE PROCEDURE dbo.AddUspsPackage
(
    @ShipmentID int,
    @LabelImagePath nvarchar (350),
    @LabelTypeCode nvarchar(10),
    @IsPrimaryLabel bit
)
WITH ENCRYPTION
AS
    INSERT INTO UspsPackages
    (
        ShipmentID,
        LabelImagePath,
        LabelTypeCode,
        IsPrimaryLabel
    )
    VALUES
    (
        @ShipmentID,
        @LabelImagePath,
        @LabelTypeCode,
        @IsPrimaryLabel
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT UspsPackageID, [RowVersion]
      FROM UspsPackages
      WHERE UspsPackageID = SCOPE_IDENTITY()

    return 1
GO

-----------------------------
--- Procedure UpdateUspsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUspsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUspsPackage]
GO

CREATE PROCEDURE dbo.UpdateUspsPackage
(
    @UspsPackageID int,
    @RowVersion timestamp,
    @ShipmentID int,
    @LabelImagePath nvarchar (350),
    @LabelTypeCode nvarchar(10),
    @IsPrimaryLabel bit
)
WITH ENCRYPTION
AS
    UPDATE UspsPackages
    SET ShipmentID = @ShipmentID,
		LabelImagePath = @LabelImagePath,
		LabelTypeCode = @LabelTypeCode,
		IsPrimaryLabel = @IsPrimaryLabel
    WHERE UspsPackageID = @UspsPackageID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT UspsPackageID, [RowVersion]
      FROM UspsPackages
      WHERE UspsPackageID = @UspsPackageID

    return 1
GO