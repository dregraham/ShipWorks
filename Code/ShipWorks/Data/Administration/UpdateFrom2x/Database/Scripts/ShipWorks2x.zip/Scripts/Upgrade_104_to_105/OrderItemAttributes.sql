-----------------------------
--- Procedure GetItemAttributesRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetItemAttributesRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetItemAttributesRange]
GO

CREATE PROCEDURE GetItemAttributesRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT a.*
   FROM OrderItemAttributes a, OrderItems i, Orders o
   WHERE a.OrderItemID = i.OrderItemID AND
         i.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
         o.OrderID > @MinOrderID
GO
