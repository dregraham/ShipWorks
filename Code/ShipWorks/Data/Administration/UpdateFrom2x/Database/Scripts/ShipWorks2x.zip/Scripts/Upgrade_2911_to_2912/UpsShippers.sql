ALTER TABLE dbo.UpsShippers ADD 
	NegotiatedRates BIT NOT NULL CONSTRAINT DF_UpsShippers_NegotiatedRates DEFAULT 0
GO
	
ALTER TABLE dbo.UpsShippers DROP CONSTRAINT DF_UpsShippers_NegotiatedRates
GO
	
----------------------------
--- PROCEDURE AddUpsShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUpsShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUpsShipper]
GO

CREATE PROCEDURE dbo.AddUpsShipper
(
    @ShipperNumber nvarchar (10)  ,
    @UserID nvarchar (25)  ,
    @Password nvarchar (25)  ,
    @AccessKey nvarchar (50)  ,
    @UsePickupLocation bit ,
    @PrimaryCompanyOrName nvarchar (30)  ,
    @PrimaryAttention nvarchar (30)  ,
    @PrimaryAddress1 nvarchar (60)  ,
    @PrimaryAddress2 nvarchar (60)  ,
    @PrimaryAddress3 nvarchar (60)  ,
    @PrimaryCity nvarchar (50)  ,
    @PrimaryStateProvinceCode nvarchar (5)  ,
    @PrimaryPostalCode nvarchar (10)  ,
    @PrimaryCountryCode nvarchar (5)  ,
    @PrimaryContactTitle nvarchar (25)  ,
    @PrimaryContactEmail nvarchar (25)  ,
    @PrimaryContactPhone nvarchar (25)  ,
    @PrimaryContactFax nvarchar (25)  ,
    @PickupCompanyOrName nvarchar (30)  ,
    @PickupAttention nvarchar (30)  ,
    @PickupAddress1 nvarchar (60)  ,
    @PickupAddress2 nvarchar (60)  ,
    @PickupAddress3 nvarchar (60)  ,
    @PickupCity nvarchar (50)  ,
    @PickupStateProvinceCode nvarchar (5)  ,
    @PickupPostalCode nvarchar (10)  ,
    @PickupCountryCode nvarchar (5)  ,
    @PickupContactTitle nvarchar (25)  ,
    @PickupContactEmail nvarchar (25)  ,
    @PickupContactPhone nvarchar (25)  ,
    @PickupContactFax nvarchar (25)  ,
    @NegotiatedRates bit
)
WITH ENCRYPTION
AS
   INSERT INTO dbo.UpsShippers 
   (
        ShipperNumber,
        UserID,
        Password,
        AccessKey,
        UsePickupLocation,
        PrimaryCompanyOrName,
        PrimaryAttention,
        PrimaryAddress1,
        PrimaryAddress2,
        PrimaryAddress3,
        PrimaryCity,
        PrimaryStateProvinceCode,
        PrimaryPostalCode,
        PrimaryCountryCode,
        PrimaryContactTitle,
        PrimaryContactEmail,
        PrimaryContactPhone,
        PrimaryContactFax,
        PickupCompanyOrName,
        PickupAttention,
        PickupAddress1,
        PickupAddress2,
        PickupAddress3,
        PickupCity,
        PickupStateProvinceCode,
        PickupPostalCode,
        PickupCountryCode,
        PickupContactTitle,
        PickupContactEmail,
        PickupContactPhone,
        PickupContactFax,
        NegotiatedRates
   )
   VALUES 
   (
        @ShipperNumber,
        @UserID,
        @Password,
        @AccessKey,
        @UsePickupLocation,
        @PrimaryCompanyOrName,
        @PrimaryAttention,
        @PrimaryAddress1,
        @PrimaryAddress2,
        @PrimaryAddress3,
        @PrimaryCity,
        @PrimaryStateProvinceCode,
        @PrimaryPostalCode,
        @PrimaryCountryCode,
        @PrimaryContactTitle,
        @PrimaryContactEmail,
        @PrimaryContactPhone,
        @PrimaryContactFax,
        @PickupCompanyOrName,
        @PickupAttention,
        @PickupAddress1,
        @PickupAddress2,
        @PickupAddress3,
        @PickupCity,
        @PickupStateProvinceCode,
        @PickupPostalCode,
        @PickupCountryCode,
        @PickupContactTitle,
        @PickupContactEmail,
        @PickupContactPhone,
        @PickupContactFax,
        @NegotiatedRates
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT UpsShipperID, [RowVersion]
     FROM UpsShippers
     WHERE UpsShipperID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateUpsShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUpsShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUpsShipper]
GO

CREATE PROCEDURE dbo.UpdateUpsShipper
(
    @UpsShipperID int,
    @RowVersion timestamp,
    @ShipperNumber nvarchar (10)  ,
    @UserID nvarchar (25)  ,
    @Password nvarchar (25)  ,
    @AccessKey nvarchar (50)  ,
    @UsePickupLocation bit ,
    @PrimaryCompanyOrName nvarchar (30)  ,
    @PrimaryAttention nvarchar (30)  ,
    @PrimaryAddress1 nvarchar (60)  ,
    @PrimaryAddress2 nvarchar (60)  ,
    @PrimaryAddress3 nvarchar (60)  ,
    @PrimaryCity nvarchar (50)  ,
    @PrimaryStateProvinceCode nvarchar (5)  ,
    @PrimaryPostalCode nvarchar (10)  ,
    @PrimaryCountryCode nvarchar (5)  ,
    @PrimaryContactTitle nvarchar (25)  ,
    @PrimaryContactEmail nvarchar (25)  ,
    @PrimaryContactPhone nvarchar (25)  ,
    @PrimaryContactFax nvarchar (25)  ,
    @PickupCompanyOrName nvarchar (30)  ,
    @PickupAttention nvarchar (30)  ,
    @PickupAddress1 nvarchar (60)  ,
    @PickupAddress2 nvarchar (60)  ,
    @PickupAddress3 nvarchar (60)  ,
    @PickupCity nvarchar (50)  ,
    @PickupStateProvinceCode nvarchar (5)  ,
    @PickupPostalCode nvarchar (10)  ,
    @PickupCountryCode nvarchar (5)  ,
    @PickupContactTitle nvarchar (25)  ,
    @PickupContactEmail nvarchar (25)  ,
    @PickupContactPhone nvarchar (25)  ,
    @PickupContactFax nvarchar (25),
    @NegotiatedRates bit
)
WITH ENCRYPTION
AS
   UPDATE UpsShippers
      SET   ShipperNumber = @ShipperNumber,
            UserID = @UserID,
            Password = @Password,
            AccessKey = @AccessKey,
            UsePickupLocation = @UsePickupLocation,
            PrimaryCompanyOrName = @PrimaryCompanyOrName,
            PrimaryAttention = @PrimaryAttention,
            PrimaryAddress1 = @PrimaryAddress1,
            PrimaryAddress2 = @PrimaryAddress2,
            PrimaryAddress3 = @PrimaryAddress3,
            PrimaryCity = @PrimaryCity,
            PrimaryStateProvinceCode = @PrimaryStateProvinceCode,
            PrimaryPostalCode = @PrimaryPostalCode,
            PrimaryCountryCode = @PrimaryCountryCode,
            PrimaryContactTitle = @PrimaryContactTitle,
            PrimaryContactEmail = @PrimaryContactEmail,
            PrimaryContactPhone = @PrimaryContactPhone,
            PrimaryContactFax = @PrimaryContactFax,
            PickupCompanyOrName = @PickupCompanyOrName,
            PickupAttention = @PickupAttention,
            PickupAddress1 = @PickupAddress1,
            PickupAddress2 = @PickupAddress2,
            PickupAddress3 = @PickupAddress3,
            PickupCity = @PickupCity,
            PickupStateProvinceCode = @PickupStateProvinceCode,
            PickupPostalCode = @PickupPostalCode,
            PickupCountryCode = @PickupCountryCode,
            PickupContactTitle = @PickupContactTitle,
            PickupContactEmail = @PickupContactEmail,
            PickupContactPhone = @PickupContactPhone,
            PickupContactFax = @PickupContactFax,
            NegotiatedRates = @NegotiatedRates
      WHERE UpsShipperID = @UpsShipperID and [RowVersion] = @RowVersion
      
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT UpsShipperID, [RowVersion]
       FROM UpsShippers
       WHERE UpsShipperID = @UpsShipperID

    return 1
GO

-----------------------------
--- Procedure DeleteUpsShipper
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteUpsShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteUpsShipper]
GO

CREATE PROCEDURE dbo.DeleteUpsShipper
(
   @UpsShipperID int
)
WITH ENCRYPTION
AS
    DELETE FROM UpsShippers
    WHERE UpsShipperID = @UpsShipperID
GO

----------------------------
--- PROCEDURE GetAllUpsShippers
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllUpsShippers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllUpsShippers]
GO

CREATE PROCEDURE dbo.GetAllUpsShippers 
WITH ENCRYPTION
AS
   SELECT *
   FROM UpsShippers
GO