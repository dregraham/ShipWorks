-----------------------------
--- Procedure DeleteMivaSebenzaMsg
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteMivaSebenzaMsg]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteMivaSebenzaMsg]
GO

CREATE PROCEDURE dbo.DeleteMivaSebenzaMsg
(
   @MivaSebenzaMsgID int
)
WITH ENCRYPTION
AS
    DELETE FROM MivaSebenzaMsgs
    WHERE MivaSebenzaMsgID = @MivaSebenzaMsgID
GO

-----------------------------
--- Procedure GetMivaSebenzaMsgsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetMivaSebenzaMsgsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetMivaSebenzaMsgsRange]
GO

CREATE PROCEDURE dbo.GetMivaSebenzaMsgsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT m.*
   FROM MivaSebenzaMsgs m, Orders o
   WHERE m.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
         o.OrderID > @MinOrderID
GO

-----------------------------
--- Procedure GetMivaSebenzaMsgs
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetMivaSebenzaMsgs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetMivaSebenzaMsgs]
GO

CREATE PROCEDURE dbo.GetMivaSebenzaMsgs
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM MivaSebenzaMsgs
   WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure SynchMivaSebenzaMsg
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaSebenzaMsg]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaSebenzaMsg]
GO

CREATE PROCEDURE dbo.SynchMivaSebenzaMsg
(
	@OrderID int,
	@Data1 text ,
	@Data2 text ,
	@Data3 text
)
WITH ENCRYPTION
AS
   
    -- If this message already exists, we dont do anything
    if exists (
        SELECT * 
        FROM MivaSebenzaMsgs
        WHERE OrderID = @OrderID
        )
    begin
    
        -- This just lets the .NET data provider know everything is OK
        SELECT MivaSebenzaMsgID
          FROM MivaSebenzaMsgs
          WHERE OrderID = @OrderID
              
        return 1

    end
    
    -- This charge number does not already exist, we need to create it
    else 
    begin
        INSERT INTO [MivaSebenzaMsgs]
        (
            [OrderID], 
            [Data1], 
            [Data2],
            [Data3]
        )
        VALUES
        (
            @OrderID, 
            @Data1, 
            @Data2,
            @Data3
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT MivaSebenzaMsgID
        FROM MivaSebenzaMsgs
        WHERE MivaSebenzaMsgID = SCOPE_IDENTITY()

        return 1
    end
GO
