----------------------------
--- PROCEDURE GetUpsPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetUpsPreferences]
GO

CREATE PROCEDURE dbo.GetUpsPreferences
(
    @StoreID int,
    @ClientID int
)
AS
   -- See if there are any prefs for this store\client
   if (0 = (SELECT COUNT(*)
                FROM UpsPreferences
                WHERE StoreID = @StoreID AND ClientID = @ClientID) )
   begin
   
      -- There are not.  See if there are any for the store to use as a starting point
        INSERT INTO UpsPreferences 
        (
            ClientID,
            StoreID,
            DefaultShipperID,
            PickupTypeCode,
            DomesticServiceCode,
            InternationalServiceCode,
            PackagingTypeCode,
            PackageLength,
            PackageWidth,
            PackageHeight,
            PackageReferenceNumber,
            AdditionalHandling,
            DeliveryConfirmation,
            DeliveryConfirmationType,
            Insurance,
            InsuredValue,
            COD,
            CODFundsCode,
            CODAmount,
            ShipmentReferenceNumber,
            EmailFromName,
            EmailSubjectCode,
            EmailFailedAddress,
            EmailMemo,
            AddShipToEmail,
            AddBillToEmail,
            AddArbitraryEmail,
            AddArbitraryEmailAddress,
            ShipNotify,
            DeliveryNotify,
            ExceptionNotify,
            LabelTypeCode,
            DefaultTemplate,
            ThermalPrinterName
        )    
        SELECT TOP 1
            @ClientID,
            StoreID,
            DefaultShipperID,
            PickupTypeCode,
            DomesticServiceCode,
            InternationalServiceCode,
            PackagingTypeCode,
            PackageLength,
            PackageWidth,
            PackageHeight,
            PackageReferenceNumber,
            AdditionalHandling,
            DeliveryConfirmation,
            DeliveryConfirmationType,
            Insurance,
            InsuredValue,
            COD,
            CODFundsCode,
            CODAmount,
            ShipmentReferenceNumber,
            EmailFromName,
            EmailSubjectCode,
            EmailFailedAddress,
            EmailMemo,
            AddShipToEmail,
            AddBillToEmail,
            AddArbitraryEmail,
            AddArbitraryEmailAddress,
            ShipNotify,
            DeliveryNotify,
            ExceptionNotify,
            LabelTypeCode,
            DefaultTemplate,
            ThermalPrinterName
        FROM UpsPreferences WHERE StoreID = @StoreID
    end    
    
    SELECT *
        FROM UpsPreferences
        WHERE StoreID = @StoreID AND ClientID = @ClientID
GO