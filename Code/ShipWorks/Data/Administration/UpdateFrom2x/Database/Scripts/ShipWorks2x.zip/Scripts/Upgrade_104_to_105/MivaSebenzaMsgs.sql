-----------------------------
--- Procedure GetMivaSebenzaMsgsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetMivaSebenzaMsgsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetMivaSebenzaMsgsRange]
GO

CREATE PROCEDURE GetMivaSebenzaMsgsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT m.*
   FROM MivaSebenzaMsgs m, Orders o
   WHERE m.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
         o.OrderID > @MinOrderID
GO
