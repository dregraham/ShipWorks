-----------------------------
--- Procedure GetOrderItemsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderItemsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderItemsRange]
GO

CREATE PROCEDURE dbo.GetOrderItemsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT i.*
   FROM OrderItems i, Orders o
   WHERE i.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
         o.OrderID > @MinOrderID
GO