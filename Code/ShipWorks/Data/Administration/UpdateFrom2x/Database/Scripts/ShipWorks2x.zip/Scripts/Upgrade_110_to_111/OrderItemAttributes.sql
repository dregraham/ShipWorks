DECLARE attCursor CURSOR LOCAL FORWARD_ONLY STATIC READ_ONLY
  FOR SELECT AttributeID, OrderItemID, MivaAttributeID FROM OrderItemAttributes

OPEN attCursor

DECLARE @attributeID int
DECLARE @orderItemID int
DECLARE @mivaAttributeID int

FETCH NEXT FROM attCursor INTO @attributeID, @orderItemID, @mivaAttributeID

WHILE @@FETCH_STATUS = 0
BEGIN
    
    DECLARE @mivaLineID int
    SELECT @mivaLineID = MivaLineID
      FROM OrderItems
      WHERE OrderItemID = @orderItemID

    if (@mivaLineID > 0)
    begin

       DECLARE @strMivaLineID varchar(15)
       DECLARE @strMivaAttributeID varchar(15)

       SELECT @strMivaLineID = @mivaLineID
       SELECT @strMivaAttributeID = @mivaAttributeID

       DECLARE @patIndex int
       SELECT @patIndex = CHARINDEX(@strMivaLineID, @strMivaAttributeID)

       -- If the attributeID is old-style (starts with the miva line id) then strip the miva line id
       if (@patIndex > 0)
       begin

           -- Remove the MivaLineID from the beginning
           DECLARE @strNewAttributeID varchar(15)
           SELECT @strNewAttributeID = RIGHT(@strMivaAttributeID, LEN(@strMivaAttributeID) - LEN(@strMivaLineID))

           -- Update the ID
           UPDATE OrderItemAttributes
             SET MivaAttributeID = @strNewAttributeID
             WHERE AttributeID = @attributeID

       end

    end

    FETCH NEXT FROM attCursor INTO @attributeID, @orderItemID, @mivaAttributeID
END

CLOSE attCursor
DEALLOCATE attCursor