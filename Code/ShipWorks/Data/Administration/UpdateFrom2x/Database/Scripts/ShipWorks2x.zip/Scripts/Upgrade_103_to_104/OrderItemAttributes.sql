ALTER TABLE dbo.OrderItemAttributes ADD
	MivaOptionCode nvarchar(300) NOT NULL CONSTRAINT DF_OrderItemAttributes_MivaOptionCode DEFAULT ''
GO

ALTER TABLE dbo.OrderItemAttributes
	DROP CONSTRAINT DF_OrderItemAttributes_MivaOptionCode
GO

-----------------------------
--- Procedure AddItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddItemAttribute]
GO

CREATE PROCEDURE AddItemAttribute
(
    @OrderItemID int,
	@Code [nvarchar] (300),
	@Name [nvarchar] (300),
    @Description [nvarchar] (1500),
	@UnitPrice money,
	@MivaAttributeID int,
	@MivaOptionCode [nvarchar] (300)
)
AS
    INSERT INTO [OrderItemAttributes]
    (
	    [OrderItemID],
	    [Code],
	    [Name],
	    [Description],
	    [UnitPrice],
	    [MivaAttributeID],
	    [MivaOptionCode]
    )
    VALUES
    (
	    @OrderItemID,
	    @Code,
	    @Name,
	    @Description,
	    @UnitPrice,
	    @MivaAttributeID,
	    @MivaOptionCode
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT AttributeID, [RowVersion]
    FROM OrderItemAttributes
    WHERE AttributeID = SCOPE_IDENTITY()

    return 1
GO

-----------------------------
--- Procedure UpdateItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateItemAttribute]
GO

CREATE PROCEDURE UpdateItemAttribute
(
	@AttributeID int,
	@RowVersion timestamp,
    @OrderItemID int,
    @Code nvarchar (300),
	@Name nvarchar (300),
	@Description nvarchar (1500),
	@UnitPrice money,
	@MivaAttributeID int,
	@MivaOptionCode nvarchar (300)
)
AS
    UPDATE [OrderItemAttributes]
    SET [OrderItemID] = @OrderItemID,
        [Code] = @Code,
	    [Name] = @Name,
	    [Description] = @Description,
	    [UnitPrice] = @UnitPrice,
	    [MivaAttributeID] = @MivaAttributeID,
	    [MivaOptionCode] = @MivaOptionCode
    WHERE AttributeID = @AttributeID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT [RowVersion]
    FROM OrderItemAttributes
    WHERE AttributeID = @AttributeID

    return 1
GO

-----------------------------
--- Procedure SynchMivaItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaItemAttribute]
GO

CREATE PROCEDURE SynchMivaItemAttribute
(
	@OrderItemID int,
	@Code nvarchar (300),
	@Name nvarchar (300),
	@Description nvarchar (1500),
	@UnitPrice money,
	@MivaAttributeID int,
	@MivaOptionCode nvarchar (300)
)
AS
   
    -- If this Miva item attribute already exists, we dont do anything
    if exists (
        SELECT * 
        FROM OrderItemAttributes a
        WHERE a.MivaAttributeID = @MivaAttributeID AND
              a.OrderItemID = @OrderItemID)
    begin
    
        -- This just lets the .NET data provider know everything is OK
        SELECT AttributeID, [RowVersion]
        FROM OrderItemAttributes a
        WHERE a.MivaAttributeID = @MivaAttributeID AND
              a.OrderItemID = @OrderItemID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItemAttributes]
        (
	        [OrderItemID],
	        [Code],
	        [Name],
	        [Description],
	        [UnitPrice],
	        [MivaAttributeID],
	        [MivaOptionCode]
        )
        VALUES
        (
	        @OrderItemID,
	        @Code,
	        @Name,
	        @Description,
	        @UnitPrice,
	        @MivaAttributeID,
	        @MivaOptionCode
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT AttributeID, [RowVersion]
        FROM OrderItemAttributes
        WHERE AttributeID = SCOPE_IDENTITY()

        return 1
    end
GO
