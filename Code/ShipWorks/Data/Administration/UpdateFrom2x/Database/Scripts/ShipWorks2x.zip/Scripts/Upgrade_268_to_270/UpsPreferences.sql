EXECUTE sp_rename N'dbo.UpsPreferences.InsuredValue', N'Tmp_InsuranceUPS', 'COLUMN' 
GO
EXECUTE sp_rename N'dbo.UpsPreferences.Tmp_InsuranceUPS', N'InsuranceUPS', 'COLUMN' 
GO

ALTER TABLE dbo.UpsPreferences ALTER COLUMN InsuranceUPS bit NOT NULL
GO

UPDATE UpsPreferences SET InsuranceUPS = 1
GO

----------------------------
--- PROCEDURE GetUpsPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetUpsPreferences]
GO

CREATE PROCEDURE dbo.GetUpsPreferences
(
    @StoreID int,
    @ClientID int
)
WITH ENCRYPTION
AS
   -- See if there are any prefs for this store\client
   if (0 = (SELECT COUNT(*)
                FROM UpsPreferences
                WHERE StoreID = @StoreID AND ClientID = @ClientID) )
   begin
   
      -- There are not.  See if there are any for the store to use as a starting point
        INSERT INTO UpsPreferences 
        (
            ClientID,
            StoreID,
            DefaultShipperID,
            PickupTypeCode,
            DomesticServiceCode,
            InternationalServiceCode,
            PackagingTypeCode,
            PackageLength,
            PackageWidth,
            PackageHeight,
            PackageReferenceNumber,
            AdditionalHandling,
            DeliveryConfirmation,
            DeliveryConfirmationType,
            Insurance,
            InsuranceUPS,
            COD,
            CODFundsCode,
            CODAmount,
            ShipmentReferenceNumber,
            EmailFromName,
            EmailSubjectCode,
            EmailFailedAddress,
            EmailMemo,
            AddShipToEmail,
            AddBillToEmail,
            AddArbitraryEmail,
            AddArbitraryEmailAddress,
            ShipNotify,
            DeliveryNotify,
            ExceptionNotify,
            LabelTypeCode,
            DefaultTemplate,
            ThermalPrinterName
        )    
        SELECT TOP 1
            @ClientID,
            StoreID,
            DefaultShipperID,
            PickupTypeCode,
            DomesticServiceCode,
            InternationalServiceCode,
            PackagingTypeCode,
            PackageLength,
            PackageWidth,
            PackageHeight,
            PackageReferenceNumber,
            AdditionalHandling,
            DeliveryConfirmation,
            DeliveryConfirmationType,
            Insurance,
            InsuranceUPS,
            COD,
            CODFundsCode,
            CODAmount,
            ShipmentReferenceNumber,
            EmailFromName,
            EmailSubjectCode,
            EmailFailedAddress,
            EmailMemo,
            AddShipToEmail,
            AddBillToEmail,
            AddArbitraryEmail,
            AddArbitraryEmailAddress,
            ShipNotify,
            DeliveryNotify,
            ExceptionNotify,
            LabelTypeCode,
            DefaultTemplate,
            ThermalPrinterName
        FROM UpsPreferences WHERE StoreID = @StoreID
    end    
    
    SELECT *
        FROM UpsPreferences
        WHERE StoreID = @StoreID AND ClientID = @ClientID
GO

----------------------------
--- PROCEDURE AddUpsPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUpsPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddUpsPreferences]
GO

CREATE PROCEDURE dbo.AddUpsPreferences
(
    @ClientID int ,
    @StoreID int ,
    @DefaultShipperID int  ,
    @PickupTypeCode nvarchar (10) ,
    @DomesticServiceCode nvarchar (10) ,
    @InternationalServiceCode nvarchar (10) ,
    @PackagingTypeCode nvarchar (10) ,
    @PackageLength int ,
    @PackageWidth int ,
    @PackageHeight int ,
    @PackageReferenceNumber nvarchar (100) ,
    @AdditionalHandling bit ,
    @DeliveryConfirmation bit ,
    @DeliveryConfirmationType nvarchar (15) ,
    @Insurance bit ,
    @InsuranceUPS bit ,
    @COD bit ,
    @CODFundsCode nvarchar (10) ,
    @CODAmount money ,
    @ShipmentReferenceNumber nvarchar (100) ,
    @EmailFromName nvarchar (50) ,
    @EmailSubjectCode nvarchar (10) ,
    @EmailFailedAddress nvarchar (50) ,
    @EmailMemo nvarchar (250) ,
    @AddShipToEmail bit ,
    @AddBillToEmail bit ,
    @AddArbitraryEmail bit ,
    @AddArbitraryEmailAddress nvarchar (50) ,
    @ShipNotify bit ,
    @DeliveryNotify bit ,
    @ExceptionNotify bit ,
    @LabelTypeCode nvarchar (10) ,
    @DefaultTemplate nvarchar (50) ,
    @ThermalPrinterName nvarchar (350)
)
WITH ENCRYPTION
AS
   INSERT INTO UpsPreferences
   (
        ClientID,
        StoreID,
        DefaultShipperID,
        PickupTypeCode,
        DomesticServiceCode,
        InternationalServiceCode,
        PackagingTypeCode,
        PackageLength,
        PackageWidth,
        PackageHeight,
        PackageReferenceNumber,
        AdditionalHandling,
        DeliveryConfirmation,
        DeliveryConfirmationType,
        Insurance,
        InsuranceUPS,
        COD,
        CODFundsCode,
        CODAmount,
        ShipmentReferenceNumber,
        EmailFromName,
        EmailSubjectCode,
        EmailFailedAddress,
        EmailMemo,
        AddShipToEmail,
        AddBillToEmail,
        AddArbitraryEmail,
        AddArbitraryEmailAddress,
        ShipNotify,
        DeliveryNotify,
        ExceptionNotify,
        LabelTypeCode,
        DefaultTemplate,
        ThermalPrinterName
   )
   VALUES
   (
        @ClientID,
        @StoreID,
        @DefaultShipperID,
        @PickupTypeCode,
        @DomesticServiceCode,
        @InternationalServiceCode,
        @PackagingTypeCode,
        @PackageLength,
        @PackageWidth,
        @PackageHeight,
        @PackageReferenceNumber,
        @AdditionalHandling,
        @DeliveryConfirmation,
        @DeliveryConfirmationType,
        @Insurance,
        @InsuranceUPS,
        @COD,
        @CODFundsCode,
        @CODAmount,
        @ShipmentReferenceNumber,
        @EmailFromName,
        @EmailSubjectCode,
        @EmailFailedAddress,
        @EmailMemo,
        @AddShipToEmail,
        @AddBillToEmail,
        @AddArbitraryEmail,
        @AddArbitraryEmailAddress,
        @ShipNotify,
        @DeliveryNotify,
        @ExceptionNotify,
        @LabelTypeCode,
        @DefaultTemplate,
        @ThermalPrinterName
   )
   
    if (@@ROWCOUNT != 1)
        return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
     FROM UpsPreferences
     WHERE StoreID = @StoreID AND ClientID = @ClientID

   return 1
GO

----------------------------
--- PROCEDURE UpdateUpsPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUpsPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateUpsPreferences]
GO

CREATE PROCEDURE dbo.UpdateUpsPreferences
(
    @ClientID int ,
    @StoreID int ,
    @DefaultShipperID int  ,
    @PickupTypeCode nvarchar (10) ,
    @DomesticServiceCode nvarchar (10) ,
    @InternationalServiceCode nvarchar (10) ,
    @PackagingTypeCode nvarchar (10) ,
    @PackageLength int ,
    @PackageWidth int ,
    @PackageHeight int ,
    @PackageReferenceNumber nvarchar (100) ,
    @AdditionalHandling bit ,
    @DeliveryConfirmation bit ,
    @DeliveryConfirmationType nvarchar (15) ,
    @Insurance bit ,
    @InsuranceUPS bit ,
    @COD bit ,
    @CODFundsCode nvarchar (10) ,
    @CODAmount money ,
    @ShipmentReferenceNumber nvarchar (100) ,
    @EmailFromName nvarchar (50) ,
    @EmailSubjectCode nvarchar (10) ,
    @EmailFailedAddress nvarchar (50) ,
    @EmailMemo nvarchar (250) ,
    @AddShipToEmail bit ,
    @AddBillToEmail bit ,
    @AddArbitraryEmail bit ,
    @AddArbitraryEmailAddress nvarchar (50) ,
    @ShipNotify bit ,
    @DeliveryNotify bit ,
    @ExceptionNotify bit ,
    @LabelTypeCode nvarchar (10) ,
    @DefaultTemplate nvarchar (50) ,
    @ThermalPrinterName nvarchar (350)
)
WITH ENCRYPTION
AS
   UPDATE UpsPreferences
   SET  ClientID = @ClientID,
        StoreID = @StoreID,
        DefaultShipperID = @DefaultShipperID,
        PickupTypeCode = @PickupTypeCode,
        DomesticServiceCode = @DomesticServiceCode,
        InternationalServiceCode = @InternationalServiceCode,
        PackagingTypeCode = @PackagingTypeCode,
        PackageLength = @PackageLength,
        PackageWidth = @PackageWidth,
        PackageHeight = @PackageHeight,
        PackageReferenceNumber = @PackageReferenceNumber,
        AdditionalHandling = @AdditionalHandling,
        DeliveryConfirmation = @DeliveryConfirmation,
        DeliveryConfirmationType = @DeliveryConfirmationType,
        Insurance = @Insurance,
        InsuranceUPS = @InsuranceUPS,
        COD = @COD,
        CODFundsCode = @CODFundsCode,
        CODAmount = @CODAmount,
        ShipmentReferenceNumber = @ShipmentReferenceNumber,
        EmailFromName = @EmailFromName,
        EmailSubjectCode = @EmailSubjectCode,
        EmailFailedAddress = @EmailFailedAddress,
        EmailMemo = @EmailMemo,
        AddShipToEmail = @AddShipToEmail,
        AddBillToEmail = @AddBillToEmail,
        AddArbitraryEmail = @AddArbitraryEmail,
        AddArbitraryEmailAddress = @AddArbitraryEmailAddress,
        ShipNotify = @ShipNotify,
        DeliveryNotify = @DeliveryNotify,
        ExceptionNotify = @ExceptionNotify,
        LabelTypeCode = @LabelTypeCode,
        DefaultTemplate = @DefaultTemplate,
        ThermalPrinterName = @ThermalPrinterName
   WHERE StoreID = @StoreID AND ClientID = @ClientID
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, ClientID
   FROM UpsPreferences
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO
