----------------------------
--- PROCEDURE ImportClient
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportClient]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[ImportClient]
GO

CREATE PROCEDURE dbo.ImportClient
(
   @ClientID int,
   @ClientName nvarchar(50)
)
WITH ENCRYPTION
AS
	DECLARE @existingClientID INT
	
	-- see if a clientname already exists
	SELECT @existingClientID = ClientID FROM Clients WHERE ClientName = @ClientName

	IF @existingClientID IS NULL
	BEGIN
		INSERT INTO  Clients (ClientName)
		VALUES (@ClientName)

		IF (@@ROWCOUNT != 1)
			RETURN 0

		SELECT ClientID = SCOPE_IDENTITY()

		SET NOCOUNT ON
	END	
	ELSE
	BEGIN
		SELECT ClientID = @existingClientID;
	END
  
	RETURN 1
GO