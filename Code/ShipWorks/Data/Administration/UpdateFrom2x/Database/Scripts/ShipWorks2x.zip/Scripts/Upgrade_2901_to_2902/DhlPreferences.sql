ALTER TABLE dbo.DhlPreferences ADD LimitDeclaredValue bit NOT NULL CONSTRAINT DF_DhlPreferences_LimitDeclaredValue DEFAULT 0
GO

ALTER TABLE dbo.DhlPreferences DROP CONSTRAINT DF_DhlPreferences_LimitDeclaredValue
GO

ALTER TABLE dbo.DhlPreferences
	ALTER COLUMN ReferenceText nvarchar(200) NOT NULL
GO

ALTER TABLE dbo.DhlPreferences
	ALTER COLUMN Description nvarchar(200) NOT NULL
GO

----------------------------
--- PROCEDURE GetDhlPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetDhlPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetDhlPreferences]
GO

CREATE PROCEDURE dbo.GetDhlPreferences
(
	@StoreID int,
	@ClientID int
)
WITH ENCRYPTION
AS 
	-- See if there are any prefs for this store\client
	IF (0 = (SELECT COUNT(*)
				FROM DhlPreferences
				WHERE StoreID = @StoreID AND ClientID = @ClientID))
	BEGIN
		-- There are not.  See if there are any for the store to use as a starting point	
		INSERT INTO DhlPreferences
		(
			ClientID,
			StoreID,
			DefaultShipperID,
			DefaultDomesticService,
			DefaultPackage,
			ReferenceText,
			Description,
			Length,
			Width,
			Height,
			EmailNotify,
			EmailNotifyMessage,
			HoldForPickup,
			HazardousMaterials,
			LeaveAtDoor,
			ReturnService,
			CODCode,
			CODValue,
			InsuranceCode,
			BlankRecipientPhone,
			DefaultTemplate,
			CommercialInvoiceCopies,
			CommercialInvoiceTemplate,
			LimitDeclaredValue
		)
		SELECT TOP 1
			@ClientID,
			StoreID,
			DefaultShipperID,
			DefaultDomesticService,
			DefaultPackage,
			ReferenceText,
			Description,
			Length,
			Width,
			Height,
			EmailNotify,
			EmailNotifyMessage,
			HoldForPickup,
			HazardousMaterials,
			LeaveAtDoor,
			ReturnService,
			CODCode,
			CODValue,
			InsuranceCode,
			BlankRecipientPhone,
			DefaultTemplate,
			CommercialInvoiceCopies,
			CommercialInvoiceTemplate,
			LimitDeclaredValue
		FROM DhlPreferences WHERE StoreID = @StoreID
	END
	
	SELECT * 
		FROM DhlPreferences
		WHERE StoreID = @StoreID AND ClientID = @ClientID
GO

----------------------------
--- PROCEDURE AddDhlPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDhlPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddDhlPreferences]
GO

CREATE PROCEDURE dbo.AddDhlPreferences
(
	@ClientID int,
	@StoreID int,
	@DefaultShipperID int,
	@DefaultDomesticService int,
	@DefaultPackage int,
	@ReferenceText nvarchar(200),
	@Description nvarchar(200),
	@Length int,
	@Width int,
	@Height int,
	@EmailNotify bit,
	@EmailNotifyMessage nvarchar(255),
	@HoldForPickup bit,
	@HazardousMaterials bit,
	@LeaveAtDoor bit,
	@ReturnService bit,
	@CODCode int,
	@CODValue money, 
	@InsuranceCode int,
	@BlankRecipientPhone nvarchar(25),
	@DefaultTemplate nvarchar(50),
	@CommercialInvoiceCopies int,
	@CommercialInvoiceTemplate nvarchar(50),
	@LimitDeclaredValue bit
)
WITH ENCRYPTION
AS 
	INSERT INTO DhlPreferences
	(
		ClientID,
		StoreID,
		DefaultShipperID,
		DefaultDomesticService,
		DefaultPackage,
		ReferenceText,
		Description,
		Length,
		Width,
		Height,
		EmailNotify,
		EmailNotifyMessage,
		HoldForPickup,
		HazardousMaterials,
		LeaveAtDoor,
		ReturnService,
		CODCode,
		CODValue,
		InsuranceCode,
		BlankRecipientPhone,
		DefaultTemplate,
		CommercialInvoiceCopies,
		CommercialInvoiceTemplate,
		LimitDeclaredValue
	)
	VALUES
	(
		@ClientID,
		@StoreID,
		@DefaultShipperID,
		@DefaultDomesticService,
		@DefaultPackage,
		@ReferenceText,
		@Description,
		@Length,
		@Width,
		@Height,
		@EmailNotify,
		@EmailNotifyMessage,
		@HoldForPickup,
		@HazardousMaterials,
		@LeaveAtDoor,
		@ReturnService,
		@CODCode,
		@CODValue,
		@InsuranceCode,
		@BlankRecipientPhone,
		@DefaultTemplate,
		@CommercialInvoiceCopies,
		@CommercialInvoiceTemplate,
		@LimitDeclaredValue
	)
	
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT StoreID, ClientID
		FROM DhlPreferences
		WHERE StoreID = @StoreID AND ClientID = @ClientID
		
	RETURN 1
GO

----------------------------
--- PROCEDURE UpdateDhlPreferences
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateDhlPreferences]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateDhlPreferences]
GO

CREATE PROCEDURE dbo.UpdateDhlPreferences
(
	@ClientID int,
	@StoreID int,
	@DefaultShipperID int,
	@DefaultDomesticService int,
	@DefaultPackage int,
	@ReferenceText nvarchar(200),
	@Description nvarchar(200),
	@Length int,
	@Width int,
	@Height int,
	@EmailNotify bit,
	@EmailNotifyMessage nvarchar(255),
	@HoldForPickup bit,
	@HazardousMaterials bit,
	@LeaveAtDoor bit,
	@ReturnService bit,
	@CODCode int,
	@CODValue money, 
	@InsuranceCode int,
	@BlankRecipientPhone nvarchar(25),
	@DefaultTemplate nvarchar(50),
	@CommercialInvoiceCopies int,
	@CommercialInvoiceTemplate nvarchar(50),
	@LimitDeclaredValue bit
)
WITH ENCRYPTION 
AS
	UPDATE DhlPreferences
	SET 
		ClientID = @ClientID,
		StoreID = @StoreID,
		DefaultShipperID = @DefaultShipperID,
		DefaultDomesticService = @DefaultDomesticService,
		DefaultPackage = @DefaultPackage,
		ReferenceText = @ReferenceText,
		Description = @Description,
		Length = @Length,
		Width = @Width,
		Height = @Height,
		EmailNotify = @EmailNotify,
		EmailNotifyMessage = @EmailNotifyMessage,
		HoldForPickup = @HoldForPickup,
		HazardousMaterials = @HazardousMaterials,
		LeaveAtDoor = @LeaveAtDoor,
		ReturnService = @ReturnService,
		CODCode = @CODCode,
		CODValue = @CODValue,
		InsuranceCode = @InsuranceCode,
		BlankRecipientPhone = @BlankRecipientPhone,
		DefaultTemplate = @DefaultTemplate,
		CommercialInvoiceCopies = @CommercialInvoiceCopies,
		CommercialInvoiceTemplate = @CommercialInvoiceTemplate,
		LimitDeclaredValue = @LimitDeclaredValue
	WHERE StoreID = @StoreID AND ClientID = @ClientID
	
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT StoreID, ClientID
	FROM DhlPreferences
	WHERE ClientID = @ClientID AND StoreID = @StoreID
	
	RETURN 1
GO