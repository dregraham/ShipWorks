ALTER TABLE dbo.[Orders] ADD 
	AmeriCommerceStatusCode INT NOT NULL CONSTRAINT DF_Orders_AmeriCommerceStatusCodes DEFAULT 0
GO

ALTER TABLE dbo.[Orders] DROP CONSTRAINT DF_Orders_AmeriCommerceStatusCodes
GO

-----------------------------
--- TRIGGER TG_Orders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Orders]'))
   drop trigger dbo.[TG_Orders]
GO

CREATE TRIGGER dbo.TG_Orders ON Orders WITH ENCRYPTION FOR UPDATE
AS
    DECLARE @StoreID int
    DECLARE @OldCustomerID int
    DECLARE @NewCustomerID int
    
    SELECT TOP 1 @StoreID = StoreID, @NewCustomerID = CustomerID FROM inserted
    SELECT TOP 1 @OldCustomerID = CustomerID FROM deleted
    
    if (@StoreID IS NULL)
        return;
    
    EXEC SetTableLastDbts 'Orders', @StoreID, @@DBTS
    
    IF (@OldCustomerID != @NewCustomerID)
    begin
        -- If the customerID is updated, we just need to touch the customer of each order
        -- so that SW knows the customer calculated columns need looked at.
        UPDATE Customers
          SET ShipFirstName = ShipFirstName
          WHERE CustomerID in (SELECT CustomerID FROM inserted)
          
        -- Update all the old customers too
        UPDATE Customers
          SET ShipFirstName = ShipFirstName
          WHERE CustomerID in (SELECT CustomerID FROM deleted)
          
        print('TG_Orders - CustomerID Changed')
    end
    
GO

-----------------------------
--- TRIGGER TG_Orders_Deleted
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Orders_Deleted]'))
   drop trigger dbo.[TG_Orders_Deleted]
GO

CREATE TRIGGER dbo.TG_Orders_Deleted ON Orders WITH ENCRYPTION FOR DELETE
AS
    -- We just need to touch the customer of each deleted order
    -- so that SW knows the customer calculated columns need looked at.
    UPDATE Customers
      SET ShipFirstName = ShipFirstName
      WHERE CustomerID in (SELECT CustomerID FROM deleted)
GO

-----------------------------
--- TRIGGER TG_Orders_Customers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[TG_Orders_Customers]'))
   drop trigger dbo.[TG_Orders_Customers]
GO

CREATE TRIGGER dbo.TG_Orders_Customers ON Orders WITH ENCRYPTION INSTEAD OF INSERT
AS

    if ( (SELECT Count(*) FROM inserted) > 1 )
    begin
         RAISERROR ('Only one order can be added at a time.', 16, 1)
         ROLLBACK TRANSACTION
         return
    end

    DECLARE @customerID int
    SELECT @customerID = NULL
    
    -- See if a valid customer is already specified
    SELECT @customerID = i.CustomerID
      FROM inserted i, Customers c
      WHERE i.StoreID = c.StoreID AND i.CustomerID = c.CustomerID AND i.CustomerID > 0
      
    -- Determine the store type
    DECLARE @storeType int
    SELECT @storeType = StoreType
      FROM Stores s, inserted i
      WHERE s.StoreID = i.StoreID
      
    -- Get fields we need
    DECLARE @eBayBuyerID nvarchar (50)
    DECLARE @isManual bit
    SELECT @eBayBuyerID = eBayBuyerID, @isManual = IsManual
		FROM inserted

	-- Match up based on ebay buyer id (if ebay)
    if (@customerID IS NULL and @storeType = 1)
    begin
    		
		SELECT @customerID = c.CustomerID
		FROM inserted i, Customers c
		WHERE
			i.StoreID = c.StoreID AND
			(i.eBayBuyerID != '' AND i.eBayBuyerID = c.eBayBuyerID)
			
		if (@customerID IS NOT NULL) print('Matched on eBayBuyerID')
		
		-- If we didnt find it, then we have to check one more thing.  buyers can
		-- change their buyer id's.  So we see if we find an email match, and if we do
		-- that means they changed their buyer id.
		if (@customerID IS NULL)
		begin
			-- Match up customers based on bill email address
			SELECT @customerID = c.CustomerID
			FROM inserted i, Customers c
			WHERE
				i.StoreID = c.StoreID AND
				(i.BillEmail != '' AND i.BillEmail = c.BillEmail)
				
			if (@customerID IS NOT NULL) 
			begin
			    print('ebay buyer changed id, Matched on Email')
			    
			end
		end
    end

	-- Match up based on oscommerce cust id (if osc (or creloaded))
    if (@customerID IS NULL and (@storeType = 5 or @storeType = 9 or @storeType = 13))
    begin
		SELECT @customerID = c.CustomerID
		FROM inserted i, Customers c
		WHERE
			i.StoreID = c.StoreID AND
			(i.osCommerceCustomerID > 0 AND i.osCommerceCustomerID = c.osCommerceCustomerID)
			
		if (@customerID IS NOT NULL) print('Matched on osCommerce Customer ID')
			
    end
    
    -- Match up based on infopia cust id (if infopia)
    if (@customerID IS NULL and @storeType = 8)
    begin
        -- we're only going to trust the infopia id if the physical address matches as well.
    	-- if someone changed their email address AND billing address, they're going to be a new customer in ShipWorks.
		SELECT @customerID = c.CustomerID
		FROM inserted i, Customers c
		WHERE
			i.StoreID = c.StoreID AND
			(i.InfopiaCustomerID > 0 AND i.InfopiaCustomerID = c.InfopiaCustomerID)
			AND c.AddressHash = (i.BillFirstName + i.BillLastName + i.BillAddress1 + i.BillAddress2 + i.BillPostalCode)	
			
		if (@customerID IS NOT NULL) print('Matched on Infopia Customer ID')
			
    end
    
    -- Match up based on Magento cust id (if Magento)
    if (@customerID is NULL and @storeType = 21)
    begin
		SELECT @customerID = c.CustomerID
		FROM inserted i, Customers c
		WHERE
			i.StoreID = c.StoreID AND
			(i.MagentoCustomerID > 0 AND i.MagentoCustomerID = c.MagentoCustomerID)
			
		if (@customerID IS NOT NULL) print('Matched on Magento Customer ID');
    end

    -- If it didnt work based on a store specific id, try based on email (except ebay)
    if (@isManual = 1 or (@storeType != 1) )
    begin
    
		if (@customerID IS NULL)
		begin
			-- Match up customers based on bill email address
			SELECT @customerID = c.CustomerID
			FROM inserted i, Customers c
			WHERE
				i.StoreID = c.StoreID AND
				(i.BillEmail != '' AND i.BillEmail = c.BillEmail)
				
			if (@customerID IS NOT NULL) print('Matched on Email')
		end
	        
		-- If it didnt work based on email, try based on addresss
		if (@customerID IS NULL)
		begin

			-- Match up customers based on shipping address
			SELECT @customerID = c.CustomerID
				FROM inserted i, Customers c
				WHERE
					i.StoreID = c.StoreID AND
					c.AddressHash != '' AND
					c.AddressHash = (i.BillFirstName + i.BillLastName + i.BillAddress1 + i.BillAddress2 + i.BillPostalCode)
	    
			if (@customerID IS NOT NULL) print('Matched on Address')
		end
		
    end
    
    -- If we still have not found a correct customer, add an entry to the customers table
    if (@customerID IS NULL)
    begin
			print('No match, adding new customer.')
			
            -- Create a customer for each order that does not yet have a customer
            INSERT INTO Customers 
            (
                StoreID, 
                ShipEmail,     
                ShipFirstName,     
                ShipLastName,     
                ShipCompany,     
                ShipAddress1,     
                ShipAddress2,     
                ShipAddress3,     
                ShipCity,     
                ShipStateProvinceCode,     
                ShipPostalCode,     
                ShipCountryCode,     
                ShipPhone,     
                ShipFax,     
                BillEmail,     
                BillFirstName,     
                BillLastName,     
                BillCompany,     
                BillAddress1,     
                BillAddress2,     
                BillAddress3,     
                BillCity,     
                BillStateProvinceCode,     
                BillPostalCode,     
                BillCountryCode,     
                BillPhone,     
                BillFax,     
                Notes, 
                eBayBuyerID,
                MarketWorksBuyerNumber,
                osCommerceCustomerID,
                ProStoresCustomerNumber,
                InfopiaCustomerID,
                MagentoCustomerID
            )
            SELECT 
                StoreID, 
                ShipEmail,     
                ShipFirstName,     
                ShipLastName,     
                ShipCompany,     
                ShipAddress1,     
                ShipAddress2,     
                ShipAddress3,     
                ShipCity,     
                ShipStateProvinceCode,     
                ShipPostalCode,     
                ShipCountryCode,     
                ShipPhone,     
                ShipFax,    
                BillEmail, 
                BillFirstName, 
                BillLastName, 
                BillCompany, 
                BillAddress1, 
                BillAddress2, 
                BillAddress3, 
                BillCity, 
                BillStateProvinceCode, 
                BillPostalCode, 
                BillCountryCode, 
                BillPhone, 
                BillFax, 
                '',    
                eBayBuyerID,
                MarketWorksBuyerNumber,
                osCommerceCustomerID,
                '',
                InfopiaCustomerID,
                MagentoCustomerID
                
            FROM inserted i

          -- Now we know the customer ID
          SET @customerID = SCOPE_IDENTITY()
    end

    -- We do know the customer, update the existing customer record
    else
    begin
			DECLARE @doUpdate bit
			SELECT @doUpdate = 1
			
			-- For eBay, if this is a return customer who has not checked out yet, some address
			-- information will be blank.  We do not want to overwrite existing good address
			-- information with blank.
			if (@storeType = 1)
			begin
				
				-- If the buyer id is blank, see if the customer has a buyerid to use
				if (@eBayBuyerID = '')
				begin
					SELECT @eBayBuyerID = eBayBuyerID
						FROM Customers
						WHERE CustomerID = @customerID
						
					print('Order eBayBuyerID blank, using customers:')
					print(@eBayBuyerID)
					
				end

				DECLARE @firstName [nvarchar] (30)
				DECLARE @lastName [nvarchar] (30)
				DECLARE @address1 [nvarchar] (60)
				DECLARE @city [nvarchar] (50)
				
				SELECT @firstName = BillFirstName, @lastName = BillLastName, @address1 = BillAddress1, @city = BillCity
				  FROM inserted
				  
				-- If address info is blank, we wont do the update
				if (@firstName = '' and @lastName = '' and @address1 = '' and @city = '')
				begin
					SELECT @doUpdate = 0
				end
				
			end

			if (@doUpdate = 1)
			begin
			
				UPDATE c 
				SET
					c.ShipEmail = i.ShipEmail,     
					c.ShipFirstName = i.ShipFirstName,     
					c.ShipLastName = i.ShipLastName,     
					c.ShipCompany = i.ShipCompany,     
					c.ShipAddress1 = i.ShipAddress1,     
					c.ShipAddress2 = i.ShipAddress2,     
					c.ShipAddress3 = i.ShipAddress3,     
					c.ShipCity = i.ShipCity,     
					c.ShipStateProvinceCode = i.ShipStateProvinceCode,     
					c.ShipPostalCode = i.ShipPostalCode,     
					c.ShipCountryCode = i.ShipCountryCode,     
					c.ShipPhone = i.ShipPhone,     
					c.ShipFax = i.ShipFax,     
					c.BillEmail = i.BillEmail,     
					c.BillFirstName = i.BillFirstName,     
					c.BillLastName = i.BillLastName,     
					c.BillCompany = i.BillCompany,     
					c.BillAddress1 = i.BillAddress1,     
					c.BillAddress2 = i.BillAddress2,     
					c.BillAddress3 = i.BillAddress3,     
					c.BillCity = i.BillCity,     
					c.BillStateProvinceCode = i.BillStateProvinceCode,     
					c.BillPostalCode = i.BillPostalCode,     
					c.BillCountryCode = i.BillCountryCode,     
					c.BillPhone = i.BillPhone,     
					c.BillFax = i.BillFax,
					c.eBayBuyerID = @eBayBuyerID,
					c.MarketWorksBuyerNumber = i.MarketWorksBuyerNumber,
					c.osCommerceCustomerID = i.osCommerceCustomerID,
					c.InfopiaCustomerID = i.InfopiaCustomerID,
					c.MagentoCustomerID = i.MagentoCustomerID
					
				FROM Customers c, inserted i
				WHERE c.CustomerID = @customerID
				
			end
    end
         
    -- Now, we can insert the rows into the real orders table
    INSERT INTO Orders 
    (
        OrderNumber, 
        StoreID, 
        CustomerID, 
        OrderDate, 
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1, 
        ShipAddress2, 
        ShipAddress3, 
        ShipCity, 
        ShipStateProvinceCode, 
        ShipPostalCode, 
        ShipCountryCode, 
        ShipEmail, 
        ShipPhone,
        ShipFax,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1, 
        BillAddress2, 
        BillAddress3, 
        BillCity, 
        BillStateProvinceCode, 
        BillPostalCode, 
        BillCountryCode, 
        BillEmail, 
        BillPhone,
        BillFax,
        CustomerComments,
        RequestedShipping,
        Total, 
        Notes, 
        Status,
        IsManual,
        OrderNumberPrefix,
        OrderNumberPostfix,
        OnlineLastModified, 
        eBayOrderID, 
        eBayOrderCreated,
        eBayBuyerID, 
        eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate,
        eBayPaymentStatus, 
        eBayPaymentMethod, 
        eBayCheckoutStatus, 
        eBayCompleteStatus, 
        eBayLeftFeedback, 
        eBayLeftFeedbackType, 
        eBayLeftFeedbackComments, 
        eBayReceivedFeedbackType, 
        eBayReceivedFeedbackComments, 
        eBayMyEbayStatus,
        eBaySellerPaidStatus,
        eBayAllowEdit, 
        eBaySellingManagerRecord,
        PayPalAddressStatus,
        PayPalTransactionID,
        MarketWorksUserNumber,
        MarketWorksInvoiceNumber,
        MarketWorksBuyerNumber,
        MivaBatchID,
        MivaStatus,
        MarketWorksParcelID,
        osCommerceCustomerID,
        osCommerceStatusCode,
        YahooOrderID,
        ProStoresStatus,
        ProStoresConfirmation,
        ChannelAdvisorReportID,
        ChannelAdvisorResellerID,
        ChannelAdvisorDistributionCenter,
        ChannelAdvisorOrderID,
	    InfopiaCustomerID,
	    InfopiaStatus,
	    AmazonOrderID,
	    AmazonStatusDocumentID,
	    AmazonCommission,
	    XCartStatus,
	    OrderMotionShipmentID,
	    OrderMotionPromotion,
	    WasArchived,
	    ClickCartProStatusCode,
	    ClickCartProID,
	    PayPalFee,
	    PayPalPaymentStatus,
	    VolusionStatus,
	    NetworkSolutionsStatus,
	    NetworkSolutionsOrderID,
	    MagentoStatusCode,
	    MagentoCustomerID,
	    MagentoOrderID,
	    AmeriCommerceStatusCode 
    )
       SELECT         
        OrderNumber, 
        StoreID, 
        @customerID, 
        OrderDate, 
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1, 
        ShipAddress2, 
        ShipAddress3, 
        ShipCity, 
        ShipStateProvinceCode, 
        ShipPostalCode, 
        ShipCountryCode, 
        ShipEmail, 
        ShipPhone,
        ShipFax,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1, 
        BillAddress2, 
        BillAddress3, 
        BillCity, 
        BillStateProvinceCode, 
        BillPostalCode, 
        BillCountryCode, 
        BillEmail, 
        BillPhone,
        BillFax,
        CustomerComments,
        RequestedShipping,
        Total, 
        Notes, 
        Status,
        IsManual,
        OrderNumberPrefix,
        OrderNumberPostfix,
        OnlineLastModified, 
        eBayOrderID,
        eBayOrderCreated,
        @eBayBuyerID, 
        eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate,
        eBayPaymentStatus, 
        eBayPaymentMethod, 
        eBayCheckoutStatus, 
        eBayCompleteStatus, 
        eBayLeftFeedback, 
        eBayLeftFeedbackType, 
        eBayLeftFeedbackComments, 
        eBayReceivedFeedbackType, 
        eBayReceivedFeedbackComments, 
        eBayMyEbayStatus, 
        eBaySellerPaidStatus,
        eBayAllowEdit, 
        eBaySellingManagerRecord,
        PayPalAddressStatus,
        PayPalTransactionID,
        MarketWorksUserNumber,
        MarketWorksInvoiceNumber,
        MarketWorksBuyerNumber,
        MivaBatchID,
		MivaStatus,        
        MarketWorksParcelID,
        osCommerceCustomerID,
        osCommerceStatusCode,
        YahooOrderID,
        ProStoresStatus,
        ProStoresConfirmation,
        ChannelAdvisorReportID,
        ChannelAdvisorResellerID,
        ChannelAdvisorDistributionCenter,
        ChannelAdvisorOrderID,
	    InfopiaCustomerID,
	    InfopiaStatus,
	    AmazonOrderID,
	    AmazonStatusDocumentID,
	    AmazonCommission,
	    XCartStatus,
	    OrderMotionShipmentID,
	    OrderMotionPromotion,
	    WasArchived,
	    ClickCartProStatusCode,
	    ClickCartProID,
	    PayPalFee,
	    PayPalPaymentStatus,
	    VolusionStatus,
	    NetworkSolutionsStatus,
	    NetworkSolutionsOrderID,
	    MagentoStatusCode,
	    MagentoCustomerID,
	    MagentoOrderID,
	    AmeriCommerceStatusCode 
     FROM inserted i
GO

-----------------------------
--- Procedure GetOrderRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderRange]
GO

CREATE PROCEDURE dbo.GetOrderRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM [Orders]
   WHERE StoreID = @StoreID AND 
         ((OrderDate >= @DateRangeMin AND OrderDate <= @DateRangeMax) OR WasArchived = 1) AND
         OrderID > @MinOrderID
GO

-----------------------------
--- Procedure GetOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrder]
GO

CREATE PROCEDURE dbo.GetOrder
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM [Orders]
   WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure DoesOrderExist
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DoesOrderExist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DoesOrderExist]
GO

CREATE PROCEDURE dbo.DoesOrderExist
(
    @OrderID int
)
WITH ENCRYPTION
AS
   if exists (SELECT * FROM [Orders] WHERE OrderID = @OrderID)
      SELECT 1
   else
      SELECT 0
GO

-----------------------------
--- Procedure DoesOrderNumberExist
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DoesOrderNumberExist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DoesOrderNumberExist]
GO

CREATE PROCEDURE dbo.DoesOrderNumberExist
(
    @StoreID int,
    @OrderNumber int,
    @IsManual bit,
    @OrderNumberPostFix nvarchar(10)
)
WITH ENCRYPTION
AS
   if exists (SELECT * FROM [Orders] WHERE StoreID = @StoreID AND OrderNumber = @OrderNumber AND IsManual = @IsManual AND OrderNumberPostFix = @OrderNumberPostFix)
      SELECT 1
   else
      SELECT 0
GO

-----------------------------
--- Procedure GetOrderByNumber
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderByNumber]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderByNumber]
GO

CREATE PROCEDURE dbo.GetOrderByNumber
(
    @StoreID int,
    @OrderNumber int,
    @IsManual bit
)
WITH ENCRYPTION
AS
    SELECT *
    FROM [Orders] 
    WHERE StoreID = @StoreID 
        AND OrderNumber = @OrderNumber 
        AND IsManual = @IsManual
GO

-----------------------------
--- Procedure DeleteOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteOrder]
GO

CREATE PROCEDURE dbo.DeleteOrder
(
    @OrderID int
)
WITH ENCRYPTION
AS
   DELETE OrderItemAttributes
     FROM OrderItemAttributes a, OrderItems i
     WHERE a.OrderItemID = i.OrderItemID AND i.OrderID = @OrderID
     
   DELETE FROM OrderItems
     WHERE OrderID = @OrderID
     
   DELETE FROM OrderCharges
     WHERE OrderID = @OrderID
     
   DELETE FROM PaymentDetails
     WHERE OrderID = @OrderID
     
   DELETE FROM MivaSebenzaMsgs
     WHERE OrderID = @OrderID
     
   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE UpsPackages
      FROM UpsPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID

   DELETE UpsShipments
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
          
   DELETE FedexPackages
      FROM FedexPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE FedexShipments
     FROM FedexShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE DhlShipments
     FROM DhlShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID   

    DELETE ShipmentCommodities
      FROM ShipmentCommodities c, Shipments s
      WHERE c.ShipmentID = s.ShipmentID AND s.OrderID = @OrderID
     
   DELETE FROM Shipments
     WHERE OrderID = @OrderID

   DELETE FROM [Orders]
     WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure GetOrderCount
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderCount]
GO

CREATE PROCEDURE dbo.GetOrderCount
(
    @StoreID int
)
WITH ENCRYPTION
AS
   SELECT Count(*) AS OrderCount
      FROM Orders
      WHERE StoreID = @StoreID
GO

-----------------------------
--- Procedure GetChangedOrders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedOrders]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedOrders]
GO

CREATE PROCEDURE dbo.GetChangedOrders
(
   @LastDBTS rowversion,
   @MaxOrderID int,
   @StoreID int
)
WITH ENCRYPTION
AS

   SELECT o.*
      FROM Orders o
      WHERE (o.RowVersion > @LastDBTS AND o.StoreID = @StoreID) AND
            (o.OrderID <= @MaxOrderID OR @MaxOrderID < 0)

GO

-----------------------------
--- Procedure AddOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddOrder]
GO

CREATE PROCEDURE dbo.AddOrder
(
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @IsManual bit,
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @OnlineLastModified [datetime],
    @eBayOrderID [bigint],
    @eBayOrderCreated datetime,
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayCheckoutStatus [int],
    @eBayCompleteStatus [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMyEbayStatus [int],
    @eBaySellerPaidStatus int,
    @eBayAllowEdit [bit],
    @eBaySellingManagerRecord int,
    @PayPalAddressStatus int,
    @PayPalTransactionID varchar (50),
    @MarketWorksUserNumber int,
    @MarketWorksInvoiceNumber nvarchar(20),
    @MarketWorksBuyerNumber int,
    @MivaBatchID [int],
    @MivaStatus varchar(32),
    @MarketWorksParcelID int,
    @osCommerceCustomerID int,
    @osCommerceStatusCode int,
    @YahooOrderID varchar (50),
    @ProStoresStatus varchar(15),
    @ProStoresConfirmation varchar(12),
    @ChannelAdvisorReportID int,
    @ChannelAdvisorResellerID varchar(80),
    @ChannelAdvisorDistributionCenter varchar(80),
    @ChannelAdvisorOrderID varchar(20),
    @InfopiaCustomerID int,
	@InfopiaStatus varchar(32),
	@AmazonOrderID varchar(32),
	@AmazonStatusDocumentID bigint,
	@AmazonCommission money,
	@XCartStatus varchar(32),
	@OrderMotionShipmentID int,
	@OrderMotionPromotion nvarchar(50),
	@WasArchived bit,
	@ClickCartProStatusCode nvarchar(50),
	@ClickCartProID nvarchar(50),
	@PayPalFee money,
	@PayPalPaymentStatus smallint,
	@VolusionStatus nvarchar(25),
	@NetworkSolutionsStatus int,
	@NetworkSolutionsOrderID int,
	@MagentoStatusCode nvarchar(50),
	@MagentoCustomerID int,
	@MagentoOrderID int,
	@AmeriCommerceStatusCode int 
)
WITH ENCRYPTION
AS
    if (@OrderNumber <= 0)
    begin
      
        -- Determine the next OrderNumber to use
        SELECT @OrderNumber = MAX(OrderNumber) + 1
          FROM Orders
          WHERE StoreID = @StoreID
        
        if (@OrderNumber IS NULL)
           SELECT @OrderNumber = 1
           
    end

    INSERT INTO [Orders](
        [OrderNumber], 
        [StoreID], 
        [CustomerID], 
        [OrderDate], 
        [ShipFirstName],
        [ShipLastName],
        [ShipCompany],
        [ShipAddress1], 
        [ShipAddress2], 
        [ShipAddress3], 
        [ShipCity], 
        [ShipStateProvinceCode], 
        [ShipPostalCode], 
        [ShipCountryCode], 
        [ShipEmail], 
        [ShipPhone],
        [ShipFax],
        [BillFirstName],
        [BillLastName],
        [BillCompany],
        [BillAddress1], 
        [BillAddress2], 
        [BillAddress3], 
        [BillCity], 
        [BillStateProvinceCode], 
        [BillPostalCode], 
        [BillCountryCode], 
        [BillEmail], 
        [BillPhone],
        [BillFax],
        [CustomerComments],
        [RequestedShipping],
        [Total], 
        [Notes], 
        [Status],
        [IsManual],
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [OnlineLastModified], 
        [eBayOrderID], 
        [eBayOrderCreated],
        [eBayBuyerID], 
        [eBayBuyerFeedbackScore],
        [eBayBuyerFeedbackPrivate],
        [eBayPaymentStatus], 
        [eBayPaymentMethod], 
        [eBayCheckoutStatus], 
        [eBayCompleteStatus], 
        [eBayLeftFeedback], 
        [eBayLeftFeedbackType], 
        [eBayLeftFeedbackComments], 
        [eBayReceivedFeedbackType], 
        [eBayReceivedFeedbackComments], 
        [eBayMyEbayStatus], 
        eBaySellerPaidStatus,
        [eBayAllowEdit], 
        eBaySellingManagerRecord,
        PayPalAddressStatus,
        PayPalTransactionID,
        [MarketWorksUserNumber],
        [MarketWorksInvoiceNumber],
        [MarketWorksBuyerNumber],
        [MivaBatchID],
        MivaStatus,
        MarketWorksParcelID,
        osCommerceCustomerID,
        osCommerceStatusCode,
        YahooOrderID,
        ProStoresStatus,
        ProStoresConfirmation,
        ChannelAdvisorReportID,
        ChannelAdvisorResellerID,
        ChannelAdvisorDistributionCenter,
        ChannelAdvisorOrderID,
        InfopiaCustomerID,
	    InfopiaStatus,
	    AmazonOrderID,
	    AmazonStatusDocumentID,
	    AmazonCommission,
	    XCartStatus,
	    OrderMotionShipmentID,
	    OrderMotionPromotion,
	    WasArchived,
	    ClickCartProStatusCode,
	    ClickCartProID,
	    PayPalFee,
	    PayPalPaymentStatus,
	    VolusionStatus,
	    NetworkSolutionsStatus,
	    NetworkSolutionsOrderID,
	    MagentoStatusCode,
	    MagentoCustomerID,
	    MagentoOrderID,
	    AmeriCommerceStatusCode 
    )
    VALUES
    (
        @OrderNumber, 
        @StoreID, 
        @CustomerID, 
        @OrderDate, 
        @ShipFirstName,
        @ShipLastName,
        @ShipCompany,
        @ShipAddress1, 
        @ShipAddress2, 
        @ShipAddress3, 
        @ShipCity, 
        @ShipStateProvinceCode, 
        @ShipPostalCode, 
        @ShipCountryCode, 
        @ShipEmail, 
        @ShipPhone,
        @ShipFax,
        @BillFirstName,
        @BillLastName,
        @BillCompany,
        @BillAddress1, 
        @BillAddress2, 
        @BillAddress3, 
        @BillCity, 
        @BillStateProvinceCode, 
        @BillPostalCode, 
        @BillCountryCode, 
        @BillEmail, 
        @BillPhone,
        @BillFax,
        @CustomerComments,
        @RequestedShipping,
        @Total, 
        @Notes, 
        @Status,
        @IsManual,
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @OnlineLastModified, 
        @eBayOrderID, 
        @eBayOrderCreated,
        @eBayBuyerID, 
        @eBayBuyerFeedbackScore,
        @eBayBuyerFeedbackPrivate,
        @eBayPaymentStatus, 
        @eBayPaymentMethod, 
        @eBayCheckoutStatus, 
        @eBayCompleteStatus, 
        @eBayLeftFeedback, 
        @eBayLeftFeedbackType, 
        @eBayLeftFeedbackComments, 
        @eBayReceivedFeedbackType, 
        @eBayReceivedFeedbackComments, 
        @eBayMyEbayStatus, 
        @eBaySellerPaidStatus,
        @eBayAllowEdit, 
        @eBaySellingManagerRecord,
        @PayPalAddressStatus,
        @PayPalTransactionID,
        @MarketWorksUserNumber,
        @MarketWorksInvoiceNumber,
        @MarketWorksBuyerNumber,
        @MivaBatchID,
        @MivaStatus,
        @MarketWorksParcelID,
        @osCommerceCustomerID,
        @osCommerceStatusCode,
        @YahooOrderID,
        @ProStoresStatus,
        @ProStoresConfirmation,
        @ChannelAdvisorReportID,
        @ChannelAdvisorResellerID,
        @ChannelAdvisorDistributionCenter,
        @ChannelAdvisorOrderID,
        @InfopiaCustomerID,
	    @InfopiaStatus,
	    @AmazonOrderID,
	    @AmazonStatusDocumentID,
	    @AmazonCommission,
	    @XCartStatus,
	    @OrderMotionShipmentID,
	    @OrderMotionPromotion,
	    @WasArchived,
	    @ClickCartProStatusCode,
	    @ClickCartProID,
	    @PayPalFee,
	    @PayPalPaymentStatus,
	    @VolusionStatus,
	    @NetworkSolutionsStatus,
	    @NetworkSolutionsOrderID,
	    @MagentoStatusCode,
	    @MagentoCustomerID,
	    @MagentoOrderID,
	    @AmeriCommerceStatusCode 
    )

    SELECT OrderID, CustomerID, OrderNumber, [RowVersion], OrderNumberDisplay
      FROM Orders
      WHERE StoreID = @StoreID AND OrderNumber = @OrderNumber AND OrderNumberPrefix = @OrderNumberPrefix AND OrderNumberPostfix = @OrderNumberPostfix
    
    return @@ROWCOUNT
GO

-----------------------------
--- Procedure UpdateOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateOrder]
GO

CREATE PROCEDURE dbo.UpdateOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @OnlineLastModified [datetime],
    @eBayOrderID [bigint],
    @eBayOrderCreated datetime,
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayCheckoutStatus [int],
    @eBayCompleteStatus [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMyEbayStatus [int],
    @eBaySellerPaidStatus int,
    @eBayAllowEdit [bit],
    @eBaySellingManagerRecord int,
    @PayPalAddressStatus int,
    @PayPalTransactionID varchar (50),
    @MarketWorksUserNumber int,
    @MarketWorksInvoiceNumber nvarchar(20),
    @MarketWorksBuyerNumber int,
    @MivaBatchID [int],
    @MivaStatus varchar(32),
    @MarketWorksParcelID int,
    @osCommerceCustomerID int,
    @osCommerceStatusCode int,
    @YahooOrderID varchar(50),
    @ProStoresStatus varchar(15),
    @ProStoresConfirmation varchar(12),
    @ChannelAdvisorReportID int,
    @ChannelAdvisorResellerID varchar(80),
    @ChannelAdvisorDistributionCenter varchar(80),
    @ChannelAdvisorOrderID varchar(20),
    @InfopiaCustomerID int,
	@InfopiaStatus varchar(32),
	@AmazonOrderID varchar(32),
	@AmazonStatusDocumentID bigint,
	@AmazonCommission money,
	@XCartStatus varchar(32),
	@OrderMotionShipmentID int,
	@OrderMotionPromotion nvarchar(50),
	@WasArchived bit,
	@ClickCartProStatusCode nvarchar(50),
	@ClickCartProID nvarchar(50),
	@PayPalFee money,
	@PayPalPaymentStatus smallint,
	@VolusionStatus nvarchar(25),
	@NetworkSolutionsStatus int,
	@NetworkSolutionsOrderID int,
	@MagentoStatusCode nvarchar(50),
	@MagentoCustomerID int,
	@MagentoOrderID int,
	@AmeriCommerceStatusCode int
)
WITH ENCRYPTION
AS       
    UPDATE Orders
    SET OrderNumber = @OrderNumber,
        StoreID = @StoreID,
        CustomerID = @CustomerID,
        OrderDate = @OrderDate,
	    ShipFirstName = @ShipFirstName,
	    ShipLastName = @ShipLastName,
	    ShipCompany = @ShipCompany,
        ShipAddress1 = @ShipAddress1,
        ShipAddress2 = @ShipAddress2,
        ShipAddress3 = @ShipAddress3,
        ShipCity = @ShipCity,
        ShipStateProvinceCode = @ShipStateProvinceCode,
        ShipPostalCode = @ShipPostalCode,
        ShipCountryCode = @ShipCountryCode,
        ShipEmail = @ShipEmail,
        ShipPhone = @ShipPhone,
        ShipFax = @ShipFax,
	    BillFirstName = @BillFirstName,
	    BillLastName = @BillLastName,
	    BillCompany = @BillCompany,
        BillAddress1 = @BillAddress1,
        BillAddress2 = @BillAddress2,
        BillAddress3 = @BillAddress3,
        BillCity = @BillCity,
        BillStateProvinceCode = @BillStateProvinceCode,
        BillPostalCode = @BillPostalCode,
        BillCountryCode = @BillCountryCode,
        BillEmail = @BillEmail,
        BillPhone = @BillPhone,
        BillFax = @BillFax,
        CustomerComments = @CustomerComments,
        RequestedShipping = @RequestedShipping,
        Total = @Total,
        Notes = @Notes,
        Status = @Status,
        OrderNumberPrefix = @OrderNumberPrefix,
        OrderNumberPostfix = @OrderNumberPostfix,
        OnlineLastModified = @OnlineLastModified,
        eBayOrderID = @eBayOrderID,
        eBayOrderCreated = @eBayOrderCreated,
        eBayBuyerID = @eBayBuyerID,
        eBayBuyerFeedbackScore = @eBayBuyerFeedbackScore,
        eBayBuyerFeedbackPrivate = @eBayBuyerFeedbackPrivate,
        eBayPaymentStatus = @eBayPaymentStatus,
        eBayPaymentMethod = @eBayPaymentMethod,
        eBayCheckoutStatus = @eBayCheckoutStatus,
        eBayCompleteStatus = @eBayCompleteStatus,
        eBayLeftFeedback = @eBayLeftFeedback,
        eBayLeftFeedbackType = @eBayLeftFeedbackType,
        eBayLeftFeedbackComments = @eBayLeftFeedbackComments,
        eBayReceivedFeedbackType = @eBayReceivedFeedbackType,
        eBayReceivedFeedbackComments = @eBayReceivedFeedbackComments,
        eBayMyEbayStatus = @eBayMyEbayStatus,
        eBaySellerPaidStatus = @eBaySellerPaidStatus,
        eBayAllowEdit = @eBayAllowEdit,
        eBaySellingManagerRecord = @eBaySellingManagerRecord,
        PayPalAddressStatus = @PayPalAddressStatus,
        PayPalTransactionID = @PayPalTransactionID,
        MarketWorksUserNumber = @MarketWorksUserNumber,
        MarketWorksInvoiceNumber = @MarketWorksInvoiceNumber,
        MarketWorksBuyerNumber = @MarketWorksBuyerNumber,
        MivaBatchID = @MivaBatchID,
        MivaStatus = @MivaStatus,
        MarketWorksParcelID = @MarketWorksParcelID,
        osCommerceCustomerID = @osCommerceCustomerID,
        osCommerceStatusCode = @osCommerceStatusCode,
        YahooOrderID = @YahooOrderID,
        ProStoresStatus = @ProStoresStatus,
        ProStoresConfirmation = @ProStoresConfirmation,
        ChannelAdvisorReportID = @ChannelAdvisorReportID,
        ChannelAdvisorResellerID = @ChannelAdvisorResellerID,
        ChannelAdvisorDistributionCenter = @ChannelAdvisorDistributionCenter,
        ChannelAdvisorOrderID = @ChannelAdvisorOrderID,
        InfopiaCustomerID = InfopiaCustomerID,
	    InfopiaStatus = @InfopiaStatus,
	    AmazonOrderID = @AmazonOrderID,
	    AmazonStatusDocumentID = @AmazonStatusDocumentID,
	    AmazonCommission = @AmazonCommission,
	    XCartStatus = @XCartStatus,
	    OrderMotionShipmentID = @OrderMotionShipmentID,
	    OrderMotionPromotion = @OrderMotionPromotion,
	    WasArchived = @WasArchived,
	    ClickCartProStatusCode = @ClickCartProStatusCode,
	    ClickCartProID = @ClickCartProID,
	    PayPalFee = @PayPalFee,
	    PayPalPaymentStatus = @PayPalPaymentStatus,
	    VolusionStatus = @VolusionStatus,
	    NetworkSolutionsStatus = @NetworkSolutionsStatus,
	    NetworkSolutionsOrderID = @NetworkSolutionsOrderID,
	    MagentoStatusCode = @MagentoStatusCode,
	    MagentoCustomerID = @MagentoCustomerID,
	    MagentoOrderID = @MagentoOrderID,
	    AmeriCommerceStatusCode = @AmeriCommerceStatusCode  
    WHERE OrderID = @OrderID AND [RowVersion] = @RowVersion

    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT [RowVersion], OrderNumberDisplay
    FROM Orders
    WHERE [OrderID] = @OrderID
            
    return 1
GO

-----------------------------
--- Procedure IsEBayOrderEditAllowed
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IsEBayOrderEditAllowed]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[IsEBayOrderEditAllowed]
GO

CREATE PROCEDURE dbo.IsEBayOrderEditAllowed
(
    @OrderID [int],
    @EditAllowed bit OUTPUT
)
WITH ENCRYPTION
AS
    SELECT @EditAllowed = eBayAllowEdit
      FROM Orders
      WHERE OrderID = @OrderID
      
    if (@EditAllowed IS NULL)
      SELECT @EditAllowed = 0
GO

-----------------------------
--- Procedure SynchEBayOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchEBayOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchEBayOrder]
GO

CREATE PROCEDURE dbo.SynchEBayOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @OnlineLastModified [datetime],
    @eBayOrderID [bigint],
    @eBayOrderCreated datetime,
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayCheckoutStatus [int],
    @eBayCompleteStatus [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMyEbayStatus [int],
    @eBaySellerPaidStatus int,
    @eBayAllowEdit [bit],
    @eBaySellingManagerRecord int,
    @PayPalAddressStatus int,
    @PayPalTransactionID varchar (50),
    @MarketWorksUserNumber int,
    @MarketWorksInvoiceNumber nvarchar(20),
    @MarketWorksBuyerNumber int,
    @MivaBatchID [int],
    @MivaStatus varchar(32),
    @MarketWorksParcelID int,
    @osCommerceCustomerID int,
    @osCommerceStatusCode int,
    @YahooOrderID varchar(50),
    @ProStoresStatus varchar(15),
    @ProStoresConfirmation varchar(12),
    @ChannelAdvisorReportID int,
    @ChannelAdvisorResellerID varchar(80),
    @ChannelAdvisorDistributionCenter varchar(80),
    @ChannelAdvisorOrderID varchar(20),
    @InfopiaCustomerID int,
	@InfopiaStatus varchar(32),
	@AmazonOrderID varchar(32),
	@AmazonStatusDocumentID bigint,
	@AmazonCommission money,
	@XCartStatus varchar(32),
	@OrderMotionShipmentID int,
	@OrderMotionPromotion nvarchar(50),
	@WasArchived bit,
	@ClickCartProStatuscode nvarchar(50),
	@ClickCartProID nvarchar(50),
	@PayPalFee money,
	@PayPalPaymentStatus smallint,
	@VolusionStatus nvarchar(25),
	@NetworkSolutionsStatus int,
	@NetworkSolutionsOrderID int,
	@MagentoStatusCode nvarchar(50),
	@MagentoCustomerID int,
	@MagentoOrderID int,
	@AmeriCommerceStatusCode int, 
	@eBayItemID bigint,
	@eBayTransID bigint,
    @WasNew [bit] OUTPUT
)
WITH ENCRYPTION
AS 
    -- Assume its new by default
    SELECT @WasNew = 1

    -- If this eBay order already exists as a combined order
    if exists (
        SELECT * 
        FROM Orders
        WHERE @eBayOrderID != 0 AND 
              eBayOrderID = @eBayOrderID AND
              StoreID = @StoreID
    )
    begin
        
        SELECT @OrderID = MAX(OrderID), @OrderNumber = MAX(OrderNumber)
        FROM Orders
        WHERE eBayOrderID = @eBayOrderID AND
              StoreID = @StoreID
        
        -- Its not new
        SELECT @WasNew = 0
        
    end
    
    -- See if this eBay order exists as a single item, which we will find in the items table
    else if exists (
        SELECT * 
        FROM Orders o, OrderItems i
        WHERE @eBayItemID != 0 AND 
              i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              o.OrderID = i.OrderID AND 
              o.StoreID = @StoreID
    )
    begin
    
        SELECT @OrderID = MAX(o.OrderID), @OrderNumber = MAX(o.OrderNumber)
        FROM Orders o, OrderItems i
        WHERE i.eBayItemID = @eBayItemID AND
              i.eBayTransID = @eBayTransID AND
              o.OrderID = i.OrderID AND 
              o.StoreID = @StoreID
              
        -- Its not new
        SELECT @WasNew = 0

    end
    
    -- If its new, then create the order
    if (@WasNew != 0)
    begin       
        -- Determine the next OrderNumber to use
        SELECT @OrderNumber = MAX(OrderNumber) + 1
          FROM Orders
          WHERE StoreID = @StoreID
        
        if (@OrderNumber IS NULL)
           SELECT @OrderNumber = 1
    
        INSERT INTO [Orders](
            [OrderNumber], 
            [StoreID], 
            [CustomerID], 
            [OrderDate], 
            [ShipFirstName],
            [ShipLastName],
            [ShipCompany],
            [ShipAddress1], 
            [ShipAddress2], 
            [ShipAddress3], 
            [ShipCity], 
            [ShipStateProvinceCode], 
            [ShipPostalCode], 
            [ShipCountryCode], 
            [ShipEmail], 
            [ShipPhone],
            [ShipFax],
            [BillFirstName],
            [BillLastName],
            [BillCompany],
            [BillAddress1], 
            [BillAddress2], 
            [BillAddress3], 
            [BillCity], 
            [BillStateProvinceCode], 
            [BillPostalCode], 
            [BillCountryCode], 
            [BillEmail], 
            [BillPhone],
            [BillFax],
            [CustomerComments],
            [RequestedShipping],
            [Total], 
            [Notes], 
            [Status],
            [IsManual],
            [OrderNumberPrefix],
            [OrderNumberPostfix],
            [OnlineLastModified], 
            [eBayOrderID], 
            [eBayOrderCreated],
            [eBayBuyerID], 
            [eBayBuyerFeedbackScore],
            [eBayBuyerFeedbackPrivate],
            [eBayPaymentStatus], 
            [eBayPaymentMethod], 
            [eBayCheckoutStatus], 
            [eBayCompleteStatus], 
            [eBayLeftFeedback], 
            [eBayLeftFeedbackType], 
            [eBayLeftFeedbackComments], 
            [eBayReceivedFeedbackType], 
            [eBayReceivedFeedbackComments], 
            [eBayMyEbayStatus], 
            eBaySellerPaidStatus,
            [eBayAllowEdit], 
            eBaySellingManagerRecord,
            PayPalAddressStatus,
            PayPalTransactionID,
            [MarketWorksUserNumber],
            [MarketWorksInvoiceNumber],
            [MarketWorksBuyerNumber],
            [MivaBatchID],
            MivaStatus,
            MarketWorksParcelID,
            osCommerceCustomerID,
            osCommerceStatusCode,
            YahooOrderID,
            ProStoresStatus,
            ProStoresConfirmation,
            ChannelAdvisorReportID,
            ChannelAdvisorResellerID,
            ChannelAdvisorDistributionCenter,
            ChannelAdvisorOrderID,
            InfopiaCustomerID,
	        InfopiaStatus,
	        AmazonOrderID,
	        AmazonStatusDocumentID,
	        AmazonCommission,
	        XCartStatus,
	        OrderMotionShipmentID,
	        OrderMotionPromotion,
	        WasArchived,
	        ClickCartProStatusCode,
	        ClickCartProID,
	        PayPalFee,
	        PayPalPaymentStatus,
	        VolusionStatus,
	        NetworkSolutionsStatus,
	        NetworkSolutionsOrderID,
	        MagentoStatusCode,
	        MagentoCustomerID,
	        MagentoOrderID,
	        AmeriCommerceStatusCode 
        )
        VALUES
        (
            @OrderNumber, 
            @StoreID, 
            @CustomerID, 
            @OrderDate, 
            @ShipFirstName,
            @ShipLastName,
            @ShipCompany,
            @ShipAddress1, 
            @ShipAddress2, 
            @ShipAddress3, 
            @ShipCity, 
            @ShipStateProvinceCode, 
            @ShipPostalCode, 
            @ShipCountryCode, 
            @ShipEmail, 
            @ShipPhone,
            @ShipFax,
            @BillFirstName,
            @BillLastName,
            @BillCompany,
            @BillAddress1, 
            @BillAddress2, 
            @BillAddress3, 
            @BillCity, 
            @BillStateProvinceCode, 
            @BillPostalCode, 
            @BillCountryCode, 
            @BillEmail, 
            @BillPhone,
            @BillFax,
            @CustomerComments,
            @RequestedShipping,
            @Total, 
            @Notes, 
            @Status,
            0, -- IsManual
            @OrderNumberPrefix,
            @OrderNumberPostfix,
            @OnlineLastModified, 
            @eBayOrderID, 
            @eBayOrderCreated,
            @eBayBuyerID, 
            @eBayBuyerFeedbackScore,
            @eBayBuyerFeedbackPrivate,
            @eBayPaymentStatus, 
            @eBayPaymentMethod, 
            @eBayCheckoutStatus, 
            @eBayCompleteStatus, 
            @eBayLeftFeedback, 
            @eBayLeftFeedbackType, 
            @eBayLeftFeedbackComments, 
            @eBayReceivedFeedbackType, 
            @eBayReceivedFeedbackComments, 
            @eBayMyEbayStatus, 
            @eBaySellerPaidStatus,
            @eBayAllowEdit, 
            @eBaySellingManagerRecord,
            @PayPalAddressStatus,
            @PayPalTransactionID,
            @MarketWorksUserNumber,
            @MarketWorksInvoiceNumber,
            @MarketWorksBuyerNumber,
            @MivaBatchID,
            @MivaStatus,
            @MarketWorksParcelID,
            @osCommerceCustomerID,
            @osCommerceStatusCode,
            @YahooOrderID,
            @ProStoresStatus,
            @ProStoresConfirmation,
            @ChannelAdvisorReportID,
            @ChannelAdvisorResellerID,
            @ChannelAdvisorDistributionCenter,
            @ChannelAdvisorOrderID,
            @InfopiaCustomerID,
	        @InfopiaStatus,
	        @AmazonOrderID,
	        @AmazonStatusDocumentID,
	        @AmazonCommission,
	        @XCartStatus,
	        @OrderMotionShipmentID,
	        @OrderMotionPromotion,
	        @WasArchived,
	        @ClickCartProStatusCode,
	        @ClickCartProID,
	        @PayPalFee,
	        @PayPalPaymentStatus,
	        @VolusionStatus,
	        @NetworkSolutionsStatus,
	        @NetworkSolutionsOrderID,
	        @MagentoStatusCode,
	        @MagentoCustomerID,
	        @MagentoOrderID,
	        @AmeriCommerceStatusCode   
        )
        
        SELECT OrderID, CustomerID, OrderNumber, [RowVersion], IsManual, OrderNumberDisplay
           FROM Orders
           WHERE OrderNumber = @OrderNumber AND StoreID = @StoreID AND IsManual = 0
        
        return @@ROWCOUNT
        
    end
    
    -- Its not new, we have to update it
    else
    begin
    
        UPDATE Orders
        SET OrderNumber = @OrderNumber,
            StoreID = @StoreID,
            CustomerID = @CustomerID,
            OrderDate = @OrderDate,
	        ShipFirstName = @ShipFirstName,
	        ShipLastName = @ShipLastName,
	        ShipCompany = @ShipCompany,
            ShipAddress1 = @ShipAddress1,
            ShipAddress2 = @ShipAddress2,
            ShipAddress3 = @ShipAddress3,
            ShipCity = @ShipCity,
            ShipStateProvinceCode = @ShipStateProvinceCode,
            ShipPostalCode = @ShipPostalCode,
            ShipCountryCode = @ShipCountryCode,
            ShipEmail = @ShipEmail,
            ShipPhone = @ShipPhone,
            ShipFax = @ShipFax,
	        BillFirstName = @BillFirstName,
	        BillLastName = @BillLastName,
	        BillCompany = @BillCompany,
            BillAddress1 = @BillAddress1,
            BillAddress2 = @BillAddress2,
            BillAddress3 = @BillAddress3,
            BillCity = @BillCity,
            BillStateProvinceCode = @BillStateProvinceCode,
            BillPostalCode = @BillPostalCode,
            BillCountryCode = @BillCountryCode,
            BillEmail = @BillEmail,
            BillPhone = @BillPhone,
            BillFax = @BillFax,
            CustomerComments = @CustomerComments,
            RequestedShipping = @RequestedShipping,
            Total = @Total,
            Notes = @Notes,
            Status = @Status,
            OrderNumberPrefix = @OrderNumberPrefix,
            OrderNumberPostfix = @OrderNumberPostfix,
            OnlineLastModified = @OnlineLastModified,
            eBayOrderID = @eBayOrderID,
            eBayOrderCreated = @eBayOrderCreated,
            eBayBuyerID = @eBayBuyerID,
            eBayBuyerFeedbackScore = @eBayBuyerFeedbackScore,
            eBayBuyerFeedbackPrivate = @eBayBuyerFeedbackPrivate,
            eBayPaymentStatus = @eBayPaymentStatus,
            eBayPaymentMethod = @eBayPaymentMethod,
            eBayCheckoutStatus = @eBayCheckoutStatus,
            eBayCompleteStatus = @eBayCompleteStatus,
            eBayLeftFeedback = @eBayLeftFeedback,
            eBayLeftFeedbackType = @eBayLeftFeedbackType,
            eBayLeftFeedbackComments = @eBayLeftFeedbackComments,
            eBayReceivedFeedbackType = @eBayReceivedFeedbackType,
            eBayReceivedFeedbackComments = @eBayReceivedFeedbackComments,
            eBayMyEbayStatus = @eBayMyEbayStatus,
            eBaySellerPaidStatus = @eBaySellerPaidStatus,
            eBayAllowEdit = @eBayAllowEdit,
            eBaySellingManagerRecord = @eBaySellingManagerRecord,
            PayPalAddressStatus = @PayPalAddressStatus,
            PayPalTransactionID = @PayPalTransactionID,
            MarketWorksUserNumber = @MarketWorksUserNumber,
            MarketWorksInvoiceNumber = @MarketWorksInvoiceNumber,
            MarketWorksBuyerNumber = @MarketWorksBuyerNumber,
            MivaBatchID = @MivaBatchID,
            MivaStatus = @MivaStatus,
            MarketWorksParcelID = @MarketWorksParcelID,
            osCommerceCustomerID = @osCommerceCustomerID,
            osCommerceStatusCode = @osCommerceStatusCode,
            YahooOrderID = @YahooOrderID,
            ProStoresStatus = @ProStoresStatus,
            ProStoresConfirmation = @ProStoresConfirmation,
            ChannelAdvisorReportID = @ChannelAdvisorReportID,
            ChannelAdvisorResellerID = @ChannelAdvisorResellerID,
            ChannelAdvisorDistributionCenter = @ChannelAdvisorDistributionCenter,
            ChannelAdvisorOrderID = @ChannelAdvisorOrderID,
            InfopiaCustomerID = @InfopiaCustomerID,
	        InfopiaStatus = @InfopiaStatus,
	        AmazonOrderID = @AmazonOrderID,
	        AmazonStatusDocumentID = @AmazonStatusDocumentID,
	        AmazonCommission = @AmazonCommission,
	        XCartStatus = @XCartStatus,
	        OrderMotionShipmentID = @OrderMotionShipmentID,
	        OrderMotionPromotion = @OrderMotionPromotion,
	        WasArchived = @WasArchived,
	        ClickCartProStatusCode = @ClickCartProStatusCode,
	        ClickCartProID = @ClickCartProID,
	        PayPalFee = @PayPalFee,
	        PayPalPaymentStatus = @PayPalPaymentStatus,
	        VolusionStatus = @VolusionStatus,
	        NetworkSolutionsStatus = @NetworkSolutionsStatus,
	        NetworkSolutionsOrderID = @NetworkSolutionsOrderID,
	        MagentoStatusCode = @MagentoStatusCode,
	        MagentoCustomerID = @MagentoCustomerID,
	        MagentoOrderID = @MagentoOrderID,
	        AmeriCommerceStatusCode = @AmeriCommerceStatusCode  
        WHERE OrderID = @OrderID
    
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT OrderID, CustomerID, OrderNumber, [RowVersion], OrderNumberDisplay
        FROM Orders
        WHERE OrderID = @OrderID
        
        return 1
    end
GO

-----------------------------
--- Procedure SaveEBayFeedback
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveEBayFeedback]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveEBayFeedback]
GO

CREATE PROCEDURE dbo.SaveEBayFeedback
(
   @OrderID [int],
   @eBayLeftFeedback [bit],
   @eBayLeftFeedbackType [int],
   @eBayLeftFeedbackComments [nvarchar] (80),
   @eBayReceivedFeedbackType [int],
   @eBayReceivedFeedbackComments [nvarchar] (80)
)
WITH ENCRYPTION
AS
   -- We can safely update the received feedback
   UPDATE Orders
     SET [eBayReceivedFeedbackType] = @eBayReceivedFeedbackType,
         [eBayReceivedFeedbackComments] = @eBayReceivedFeedbackComments
     WHERE OrderID = @OrderID
   
    SET NOCOUNT ON
    
   DECLARE @feedbackLeft bit
   DECLARE @feedbackLeftType int
   
   -- Determine if we know feedback has already been left
   SELECT @feedbackLeft = eBayLeftFeedback, @feedbackLeftType = eBayLeftFeedbackType
     FROM Orders
     WHERE OrderID = @OrderID
            
   -- Only update the left feedback if it hadnt already been left (or the type is unknown)
   if (@feedbackLeft = 0 OR @feedbackLeftType = -1)
   begin
   
      UPDATE Orders
         SET [eBayLeftFeedback] = @eBayLeftFeedback,
             [eBayLeftFeedbackType] = @eBayLeftFeedbackType,
             [eBayReceivedFeedbackComments] = @eBayReceivedFeedbackComments
         WHERE OrderID = @OrderID
   end

    SELECT *
    FROM Orders
    WHERE OrderID = @OrderID

    return 1
GO

-----------------------------
--- Procedure SaveEBayStatus
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveEBayStatus]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveEBayStatus]
GO

CREATE PROCEDURE dbo.SaveEBayStatus
(
   @OrderID [int],
   @Status [nvarchar] (50),
   @eBayMyEbayStatus int,
   @eBaySellerPaidStatus int
)
WITH ENCRYPTION
AS
   UPDATE Orders
     SET Status = @Status,
         eBayMyEbayStatus = @eBayMyEbayStatus,
         eBaySellerPaidStatus = @eBaySellerPaidStatus
     WHERE OrderID = @OrderID
     
    if (@@ROWCOUNT != 1)
       return 0

    SET NOCOUNT ON

    SELECT *
    FROM Orders
    WHERE OrderID = @OrderID

    return 1
GO

-----------------------------
--- Procedure SynchMivaOrder
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaOrder]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaOrder]
GO

CREATE PROCEDURE dbo.SynchMivaOrder
(
    @OrderID [int],
    @RowVersion [timestamp],
    @OrderNumber [int],
    @StoreID [int],
    @CustomerID [int],
    @OrderDate [datetime],
	@ShipFirstName [nvarchar] (30) ,
	@ShipLastName [nvarchar] (30) ,
	@ShipCompany [nvarchar] (30) ,
    @ShipAddress1 [nvarchar] (60),
    @ShipAddress2 [nvarchar] (60),
    @ShipAddress3 [nvarchar] (60),
    @ShipCity [nvarchar] (50),
    @ShipStateProvinceCode [nvarchar] (25),
    @ShipPostalCode [nvarchar] (10),
    @ShipCountryCode [nvarchar] (5),
    @ShipEmail [nvarchar] (50),
    @ShipPhone [nvarchar] (25) ,
    @ShipFax [nvarchar] (25) ,
	@BillFirstName [nvarchar] (30) ,
	@BillLastName [nvarchar] (30) ,
	@BillCompany [nvarchar] (30) ,
    @BillAddress1 [nvarchar] (60),
    @BillAddress2 [nvarchar] (60),
    @BillAddress3 [nvarchar] (60),
    @BillCity [nvarchar] (50),
    @BillStateProvinceCode [nvarchar] (25),
    @BillPostalCode [nvarchar] (10),
    @BillCountryCode [nvarchar] (5),
    @BillEmail [nvarchar] (50),
    @BillPhone [nvarchar] (25) ,
    @BillFax [nvarchar] (25) ,
    @CustomerComments ntext,
    @RequestedShipping [nvarchar] (50),
    @Total [money],
    @Notes ntext,
    @Status [nvarchar] (50),
    @OrderNumberPrefix [nvarchar] (10),
    @OrderNumberPostfix [nvarchar] (10),
    @OnlineLastModified [datetime],
    @eBayOrderID [bigint],
    @eBayOrderCreated datetime,
    @eBayBuyerID [nvarchar] (50),
    @eBayBuyerFeedbackScore [int],
    @eBayBuyerFeedbackPrivate [bit],
    @eBayPaymentStatus [int],
    @eBayPaymentMethod [int],
    @eBayCheckoutStatus [int],
    @eBayCompleteStatus [int],
    @eBayLeftFeedback [bit],
    @eBayLeftFeedbackType [int],
    @eBayLeftFeedbackComments [nvarchar] (80),
    @eBayReceivedFeedbackType [int],
    @eBayReceivedFeedbackComments [nvarchar] (80),
    @eBayMyEbayStatus [int],
    @eBaySellerPaidStatus int,
    @eBayAllowEdit [bit],
    @eBaySellingManagerRecord int,
    @PayPalAddressStatus int,
    @PayPalTransactionID varchar (50),
    @MarketWorksUserNumber int,
    @MarketWorksInvoiceNumber nvarchar(20),
    @MarketWorksBuyerNumber int,
    @MivaBatchID [int],
    @MivaStatus varchar(32),
    @MarketWorksParcelID int,
    @osCommerceCustomerID int,
    @osCommerceStatusCode int,
    @YahooOrderID varchar(50),
    @ProStoresStatus varchar(15),
    @ProStoresConfirmation varchar(12),
    @ChannelAdvisorReportID int,
    @ChannelAdvisorResellerID varchar(80),
    @ChannelAdvisorDistributionCenter varchar(80),
    @ChannelAdvisorOrderID varchar(20),
    @InfopiaCustomerID int,
	@InfopiaStatus varchar(32),
	@AmazonOrderID varchar(32),
	@AmazonStatusDocumentID bigint,
	@AmazonCommission money,
	@XCartStatus varchar(32),
	@OrderMotionShipmentID int,
	@OrderMotionPromotion nvarchar(50),
	@WasArchived bit,
	@ClickCartProStatusCode nvarchar(50),
	@ClickCartProID nvarchar(50),
	@PayPalFee money,
	@PayPalPaymentStatus smallint,
	@VolusionStatus nvarchar(25),
	@NetworkSolutionsStatus int,
	@NetworkSolutionsOrderID int,
	@MagentoStatusCode nvarchar(50),
	@MagentoCustomerID int,
	@MagentoOrderID int,
	@AmeriCommerceStatusCode int 
)
WITH ENCRYPTION
AS       
    -- If this Miva order number already exists, just update its batch
    if exists (
        SELECT * FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND
              IsManual = 0 )
    begin
        -- Update the batch id.  Dont worry about RowVersion mismatch - just do it.
        UPDATE Orders
        SET MivaBatchID = @MivaBatchID 
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND 
              IsManual = 0
              
        SET NOCOUNT ON

        -- Select the updated row back into .NET
        SELECT *
        FROM Orders
        WHERE StoreID = @StoreID AND 
              OrderNumber = @OrderNumber AND
              IsManual = 0
              
        return 1
    end
    
    -- This order number does not already exist, we need to create it
    else 
    begin
        INSERT INTO [Orders](
            [OrderNumber], 
            [StoreID], 
            [CustomerID], 
            [OrderDate], 
            [ShipFirstName],
            [ShipLastName],
            [ShipCompany],
            [ShipAddress1], 
            [ShipAddress2], 
            [ShipAddress3], 
            [ShipCity], 
            [ShipStateProvinceCode], 
            [ShipPostalCode], 
            [ShipCountryCode], 
            [ShipEmail], 
            [ShipPhone],
            [ShipFax],
            [BillFirstName],
            [BillLastName],
            [BillCompany],
            [BillAddress1], 
            [BillAddress2], 
            [BillAddress3], 
            [BillCity], 
            [BillStateProvinceCode], 
            [BillPostalCode], 
            [BillCountryCode], 
            [BillEmail], 
            [BillPhone],
            [BillFax],
            [CustomerComments],
            [RequestedShipping],
            [Total], 
            [Notes], 
            [Status],
            [IsManual],
            [OrderNumberPrefix],
            [OrderNumberPostfix],
            [OnlineLastModified], 
            [eBayOrderID], 
            [eBayOrderCreated],
            [eBayBuyerID], 
            [eBayBuyerFeedbackScore],
            [eBayBuyerFeedbackPrivate],
            [eBayPaymentStatus], 
            [eBayPaymentMethod], 
            [eBayCheckoutStatus], 
            [eBayCompleteStatus], 
            [eBayLeftFeedback], 
            [eBayLeftFeedbackType], 
            [eBayLeftFeedbackComments], 
            [eBayReceivedFeedbackType], 
            [eBayReceivedFeedbackComments], 
            [eBayMyEbayStatus], 
            eBaySellerPaidStatus,
            [eBayAllowEdit], 
            eBaySellingManagerRecord,
            PayPalAddressStatus,
            PayPalTransactionID,
            [MarketWorksUserNumber],
            [MarketWorksInvoiceNumber],
            [MarketWorksBuyerNumber],
            [MivaBatchID],
            MivaStatus,
            MarketWorksParcelID,
            osCommerceCustomerID,
            osCommerceStatusCode,
            YahooOrderID,
            ProStoresStatus,
            ProStoresConfirmation,
            ChannelAdvisorReportID,
            ChannelAdvisorResellerID,
            ChannelAdvisorDistributionCenter,
            ChannelAdvisorOrderID,
            InfopiaCustomerID,
	        InfopiaStatus,
	        AmazonOrderID,
	        AmazonStatusDocumentID,
	        AmazonCommission, 
	        XCartStatus,
	        OrderMotionShipmentID,
	        OrderMotionPromotion,
	        WasArchived,
	        ClickCartProStatusCode,
	        ClickCartProID,
	        PayPalFee,
	        PayPalPaymentStatus,
	        VolusionStatus,
	        NetworkSolutionsStatus,
	        NetworkSolutionsOrderID,
	        MagentoStatusCode,
	        MagentoCustomerID,
	        MagentoOrderID,
	        AmeriCommerceStatusCode 
        )
        VALUES
        (
            @OrderNumber, 
            @StoreID, 
            @CustomerID, 
            @OrderDate, 
            @ShipFirstName,
            @ShipLastName,
            @ShipCompany,
            @ShipAddress1, 
            @ShipAddress2, 
            @ShipAddress3, 
            @ShipCity, 
            @ShipStateProvinceCode, 
            @ShipPostalCode, 
            @ShipCountryCode, 
            @ShipEmail, 
            @ShipPhone,
            @ShipFax,
            @BillFirstName,
            @BillLastName,
            @BillCompany,
            @BillAddress1, 
            @BillAddress2, 
            @BillAddress3, 
            @BillCity, 
            @BillStateProvinceCode, 
            @BillPostalCode, 
            @BillCountryCode, 
            @BillEmail, 
            @BillPhone,
            @BillFax,
            @CustomerComments,
            @RequestedShipping,
            @Total, 
            @Notes, 
            @Status,
            0, -- IsManual
            @OrderNumberPrefix,
            @OrderNumberPostfix,
            @OnlineLastModified, 
            @eBayOrderID, 
            @eBayOrderCreated,
            @eBayBuyerID, 
            @eBayBuyerFeedbackScore,
            @eBayBuyerFeedbackPrivate,
            @eBayPaymentStatus, 
            @eBayPaymentMethod, 
            @eBayCheckoutStatus, 
            @eBayCompleteStatus, 
            @eBayLeftFeedback, 
            @eBayLeftFeedbackType, 
            @eBayLeftFeedbackComments, 
            @eBayReceivedFeedbackType, 
            @eBayReceivedFeedbackComments, 
            @eBayMyEbayStatus,
            @eBaySellerPaidStatus, 
            @eBayAllowEdit, 
            @eBaySellingManagerRecord,
            @PayPalAddressStatus,
            @PayPalTransactionID,
            @MarketWorksUserNumber,
            @MarketWorksInvoiceNumber,
            @MarketWorksBuyerNumber,
            @MivaBatchID,
            @MivaStatus,
            @MarketWorksParcelID,
            @osCommerceCustomerID,
            @osCommerceStatusCode,
            @YahooOrderID,
            @ProStoresStatus,
            @ProStoresConfirmation,
            @ChannelAdvisorReportID,
            @ChannelAdvisorResellerID,
            @ChannelAdvisorDistributionCenter,
            @ChannelAdvisorOrderID,
            @InfopiaCustomerID,
	        @InfopiaStatus,
	        @AmazonOrderID,
	        @AmazonStatusDocumentID,
	        @AmazonCommission,
	        @XCartStatus,
	        @OrderMotionShipmentID,
	        @OrderMotionPromotion,
	        @WasArchived,
	        @ClickCartProStatusCode,
	        @ClickCartProID,
	        @PayPalFee,
	        @PayPalPaymentStatus,
	        @VolusionStatus,
	        @NetworkSolutionsStatus,
	        @NetworkSolutionsOrderID,
	        @MagentoStatusCode,
	        @MagentoCustomerID,
	        @MagentoOrderID,
	        @AmeriCommerceStatusCode 
        )
        
        SELECT OrderID, CustomerID, OrderNumber, [RowVersion], IsManual, OrderNumberDisplay
           FROM Orders
           WHERE OrderNumber = @OrderNumber AND StoreID = @StoreID AND IsManual = 0
        
        return @@ROWCOUNT

    end
GO

----------------------------
--- PROCEDURE GetOrderCustomer
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderCustomer]
GO

CREATE PROCEDURE dbo.GetOrderCustomer
(
	@OrderId int		   
)
WITH ENCRYPTION
AS
	SELECT CustomerID FROM Orders
	WHERE OrderID = @OrderId	
GO


----------------------------
--- PROCEDURE GetOrderStatistics
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderStatistics]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderStatistics]
GO

CREATE PROCEDURE dbo.GetOrderStatistics
(
	@StoreID int,
	@DateRangeMax DATETIME
)
WITH ENCRYPTION
AS 
	SELECT
		Min(OrderDate) as MinDate,
		Max(OrderDate) as MaxDate,
		Count(OrderDate) as TotalCount
	FROM dbo.Orders
	WHERE
		(OrderDate <= @DateRangeMax OR WasArchived = 1)
		AND StoreID = @StoreID

GO