----------------------------
--- PROCEDURE AddAction
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddAction]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddAction]
GO

CREATE PROCEDURE dbo.AddAction
(
   @StoreID int,
   @ActionName nvarchar(50),
   @TriggerType smallint,
   @TriggerSettings text,
   @TasksXml text,
   @Enabled bit
)
WITH ENCRYPTION
AS
   INSERT INTO Actions 
   (
      StoreID,
      ActionName,
      TriggerType,
      TriggerSettings,
      TasksXml,
      Enabled
   )
   VALUES 
   (
      @StoreID,
      @ActionName,
      @TriggerType,
      @TriggerSettings,
      @TasksXml,
      @Enabled
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT ActionID
     FROM Actions
     WHERE ActionID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateAction
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateAction]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateAction]
GO

CREATE PROCEDURE dbo.UpdateAction
(
   @ActionID int,
   @StoreID int,
   @ActionName nvarchar(50),
   @TriggerSettings text,
   @TriggerType smallint,
   @TasksXml text,
   @Enabled bit
)
WITH ENCRYPTION
AS
   UPDATE Actions
      SET StoreID = @StoreID,
          ActionName = @ActionName,
          TriggerType = @TriggerType,
          TriggerSettings = @TriggerSettings,
          TasksXml = @TasksXml,
          Enabled = @Enabled
      WHERE ActionID = @ActionID
      
   if (@@ROWCOUNT != 1)
      return 0

   return 1
GO

-----------------------------
--- Procedure DeleteAction
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteAction]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteAction]
GO

CREATE PROCEDURE dbo.DeleteAction
(
   @ActionID int
)
WITH ENCRYPTION
AS
    DELETE FROM Actions
    WHERE ActionID = @ActionID
GO

----------------------------
--- PROCEDURE GetAllActions
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllActions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllActions]
GO

CREATE PROCEDURE dbo.GetAllActions 
(
   @StoreID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM Actions
   WHERE StoreID = @StoreID
GO
