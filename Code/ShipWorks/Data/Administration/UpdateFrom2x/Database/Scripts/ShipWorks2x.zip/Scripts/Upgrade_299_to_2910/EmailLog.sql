
----------------------------
--- PROCEDURE GetAllEmailLogs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetAllEmailLogs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure GetAllEmailLogs
GO

CREATE PROCEDURE dbo.GetAllEmailLogs
(
   @StoreID int,
   @MinLogID int
)
WITH ENCRYPTION
AS
      SELECT e.*, o.OrderNumberDisplay as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Orders o, Customers c
        WHERE e.StoreID = @StoreID AND
              e.OrderID = o.OrderID AND 
              o.CustomerID = c.CustomerID AND
              e.EmailLogID > @MinLogID
      UNION
      SELECT e.*, '-' as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Customers c
        WHERE e.StoreID = @StoreID AND
              e.CustomerID = c.CustomerID AND
              e.EmailLogID > @MinLogID
GO

----------------------------
--- PROCEDURE AddEmailLog
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.AddEmailLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure AddEmailLog
GO

CREATE PROCEDURE dbo.AddEmailLog
(
	@OrderID int,
	@CustomerID int,
	@StoreID int,
	@ClientID int,
	@SentDate datetime,
	@EmailFrom nvarchar (250),
	@EmailTo nvarchar (250),
	@Cc nvarchar (250),
	@Bcc nvarchar (250),
	@Subject nvarchar (200),
	@Template nvarchar (200),
	@LocalPath nvarchar (350),
	@Result int,
	@ErrorMessage nvarchar (150)
)
WITH ENCRYPTION
AS
    -- Only one can be set
    if (@OrderID >= 0 AND @CustomerID >= 0)
    begin
       RAISERROR ('An email log entry cannot be associated with more than one object.', 16, 1)
       return
    end

    INSERT INTO EmailLog
    (
	    OrderID,
	    CustomerID,
	    StoreID,
	    ClientID,
	    SentDate,
	    EmailFrom,
	    EmailTo,
	    Cc,
	    Bcc,
	    Subject,
	    Template,
	    LocalPath,
	    Result,
	    ErrorMessage
	)
	VALUES
	(
	    @OrderID,
	    @CustomerID,
	    @StoreID,
	    @ClientID,
	    @SentDate,
	    @EmailFrom,
	    @EmailTo,
	    @Cc,
	    @Bcc,
	    @Subject,
	    @Template,
	    @LocalPath,
	    @Result,
	    @ErrorMessage
	)
	
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   DECLARE @scopeIdentity int
   SELECT @scopeIdentity = SCOPE_IDENTITY() - 1
   exec GetAllEmailLogs @StoreID, @scopeIdentity

   return 1
GO


----------------------------
--- PROCEDURE GetLatestEmailLogs
---
--- NOTE: THIS IS CURRENTLY NOT USED
---
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetLatestEmailLogs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure GetLatestEmailLogs
GO

CREATE PROCEDURE dbo.GetLatestEmailLogs
(
   @StoreID int,
   @TopCount int,
   @ExcludeStart int,
   @ExcludeEnd int
)
WITH ENCRYPTION
AS
    DECLARE @RowCount int
    DECLARE @ExcludeCount int
    
    SELECT @ExcludeCount = Count(*)
      FROM EmailLog
      WHERE (EmailLogID >= @ExcludeStart AND EmailLogID <= @ExcludeEnd) AND
            StoreID = @StoreID
      
    SELECT @RowCount = @TopCount - @ExcludeCount
    
    if (@RowCount <= 0)
    begin
        SELECT *
        FROM EmailLog
        WHERE EmailLogID < 0
        
        return
    end
    
    SET ROWCOUNT @RowCount
    
    SELECT e.*, o.OrderNumber
      FROM EmailLog e, Orders o
      WHERE (EmailLogID < @ExcludeStart OR EmailLogID > @ExcludeEnd) AND
            e.StoreID = @StoreID AND
            e.OrderID = o.OrderID 
      ORDER BY SentDate DESC

    SET ROWCOUNT 0
GO

----------------------------
--- PROCEDURE GetOrdersEmailLogs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetOrdersEmailLogs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure GetOrdersEmailLogs
GO

CREATE PROCEDURE dbo.GetOrdersEmailLogs
(
   @StoreID int,
   @DateRangeMax datetime,
   @DateRangeMin datetime
)
WITH ENCRYPTION
AS
      SELECT e.*, o.OrderNumberDisplay as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Orders o, Customers c
        WHERE e.StoreID = @StoreID AND
              e.OrderID = o.OrderID AND 
              o.CustomerID = c.CustomerID AND
			  ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1)
			  
GO

----------------------------
--- PROCEDURE GetOrdersEmailLogs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetCustomersEmailLogs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure GetCustomersEmailLogs
GO

CREATE PROCEDURE dbo.GetCustomersEmailLogs
(
   @StoreID int,
   @DateRangeMax datetime,
   @DateRangeMin datetime
)
WITH ENCRYPTION
AS
      SELECT e.*, '-' as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Shipments s, Customers c
        WHERE 
			s.StoreID = @StoreID AND
			s.ProcessedDate >= @DateRangeMin AND s.ProcessedDate <= @DateRangeMax AND
			s.Processed = 1 AND 			
			s.StoreID = e.StoreID AND							
			s.CustomerID = c.CustomerID AND
            e.CustomerID = c.CustomerID		 			 						  
GO

----------------------------
--- PROCEDURE AddEmailLog
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.ImportEmailLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure ImportEmailLog
GO

CREATE PROCEDURE dbo.ImportEmailLog
(
	@OrderID int,
	@CustomerID int,
	@StoreID int,
	@ClientID int,
	@SentDate datetime,
	@EmailFrom nvarchar (250),
	@EmailTo nvarchar (250),
	@Cc nvarchar (250),
	@Bcc nvarchar (250),
	@Subject nvarchar (200),
	@Template nvarchar (200),
	@LocalPath nvarchar (350),
	@Result int,
	@ErrorMessage nvarchar (150)
)
WITH ENCRYPTION
AS
    -- Only one can be set
    if (@OrderID >= 0 AND @CustomerID >= 0)
    begin
       RAISERROR ('An email log entry cannot be associated with more than one object.', 16, 1)
       return
    end

    INSERT INTO EmailLog
    (
	    OrderID,
	    CustomerID,
	    StoreID,
	    ClientID,
	    SentDate,
	    EmailFrom,
	    EmailTo,
	    Cc,
	    Bcc,
	    Subject,
	    Template,
	    LocalPath,
	    Result,
	    ErrorMessage
	)
	VALUES
	(
	    @OrderID,
	    @CustomerID,
	    @StoreID,
	    @ClientID,
	    @SentDate,
	    @EmailFrom,
	    @EmailTo,
	    @Cc,
	    @Bcc,
	    @Subject,
	    @Template,
	    @LocalPath,
	    @Result,
	    @ErrorMessage
	)
	
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON   

   SELECT SCOPE_IDENTITY() AS EmailLogId
   
   return 1
GO


----------------------------
--- PROCEDURE GetEmailLog
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetEmailLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure GetEmailLog
GO

CREATE PROCEDURE dbo.GetEmailLog
(
	@EmailLogID int
)
WITH ENCRYPTION
AS
	SELECT e.*, o.OrderNumberDisplay as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Orders o, Customers c
        WHERE e.OrderID = o.OrderID AND 
              o.CustomerID = c.CustomerID AND
              e.EmailLogID = @EmailLogID
      UNION
      SELECT e.*, '-' as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Customers c
        WHERE e.CustomerID = c.CustomerID AND
              e.EmailLogID = @EmailLogID
GO           


----------------------------
--- PROCEDURE GetEmailLogOwner
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetEmailLogOwner]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetEmailLogOwner]
GO

CREATE PROCEDURE dbo.GetEmailLogOwner
(
	@EmailLogID int		   
)
WITH ENCRYPTION
AS
	DECLARE 
	@CustomerID INT,
	@OrderID INT

	SELECT @CustomerID = customerId, @OrderID = orderId
	FROM EmailLog
	WHERE EmailLogID = @EmailLogID

	IF @CustomerID = -1
	BEGIN
		SELECT @OrderID as [OwnerID], 1 as [IsOrder]		
	END 
	ELSE
	BEGIN
		SELECT @CustomerID as [OwnerID], 0 as [IsOrder]
	END

	RETURN 1	
GO

----------------------------
--- PROCEDURE GetCustomerEmailLogIDs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerEmailLogIDs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerEmailLogIDs]
GO

CREATE PROCEDURE dbo.GetCustomerEmailLogIDs
(
	@CustomerID int		   
)
WITH ENCRYPTION
AS
	SELECT EmailLogID FROM EmailLog WHERE CustomerID = @CustomerID

GO

----------------------------
--- PROCEDURE GetOrderEmailLogIDs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderEmailLogIDs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderEmailLogIDs]
GO

CREATE PROCEDURE dbo.GetOrderEmailLogIDs
(
	@OrderID int		   
)
WITH ENCRYPTION
AS
	SELECT EmailLogID FROM EmailLog WHERE OrderID = @OrderID

GO

