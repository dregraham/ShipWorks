-----------------------------
--- Procedure GetMivaSebenzaMsgsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetMivaSebenzaMsgsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetMivaSebenzaMsgsRange]
GO

CREATE PROCEDURE dbo.GetMivaSebenzaMsgsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT m.*
   FROM MivaSebenzaMsgs m, Orders o
   WHERE m.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
         o.OrderID > @MinOrderID
GO