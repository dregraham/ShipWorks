ALTER TABLE dbo.Shipments
	DROP CONSTRAINT FK_Shipments_Stores
GO

CREATE TABLE dbo.Tmp_Shipments
	(
	ShipmentID int NOT NULL IDENTITY (1, 1),
	RowVersion timestamp NOT NULL,
	StoreID int NOT NULL,
	OrderID int NOT NULL,
	CustomerID int NOT NULL,
	ShipmentType int NOT NULL,
	Processed bit NOT NULL,
	ProcessedDate datetime NOT NULL,
	ShippedDate datetime NOT NULL,
	ServiceUsed nvarchar(50) NOT NULL,
	TrackingNumber nvarchar(50) NOT NULL,
	Notes ntext NOT NULL,
	CommoditiesCreated bit NOT NULL,
	TotalCharges money NOT NULL,
	TotalWeight float(53) NOT NULL,
	ToFirstName nvarchar(30) NOT NULL,
	ToLastName nvarchar(30) NOT NULL,
	ToCompany nvarchar(30) NOT NULL,
	ToAddress1 nvarchar(60) NOT NULL,
	ToAddress2 nvarchar(60) NOT NULL,
	ToAddress3 nvarchar(60) NOT NULL,
	ToCity nvarchar(50) NOT NULL,
	ToStateProvinceCode nvarchar(25) NOT NULL,
	ToPostalCode nvarchar(10) NOT NULL,
	ToCountryCode nvarchar(5) NOT NULL,
	ToPhone nvarchar(25) NOT NULL,
	ToFax nvarchar(25) NOT NULL,
	ToEmail nvarchar(50) NOT NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO

SET IDENTITY_INSERT dbo.Tmp_Shipments ON
GO

IF EXISTS(SELECT * FROM dbo.Shipments)
	 EXEC('INSERT INTO dbo.Tmp_Shipments (ShipmentID, StoreID, OrderID, CustomerID, ShipmentType, Processed, ProcessedDate, ShippedDate, ServiceUsed, TrackingNumber, Notes, CommoditiesCreated, TotalCharges, TotalWeight, ToFirstName, ToLastName, ToCompany, ToAddress1, ToAddress2, ToAddress3, ToCity, ToStateProvinceCode, ToPostalCode, ToCountryCode, ToPhone, ToFax, ToEmail)
		                           SELECT ShipmentID, StoreID, OrderID, CustomerID, ShipmentType, Processed, ProcessedDate, ShippedDate, ServiceUsed, TrackingNumber, Notes, CommoditiesCreated, TotalCharges, TotalWeight, ToFirstName, ToLastName, ToCompany, ToAddress1, ToAddress2, ToAddress3, ToCity, ToStateProvinceCode, ToPostalCode, ToCountryCode, ToPhone, ToFax, ToEmail FROM dbo.Shipments TABLOCKX')
GO

SET IDENTITY_INSERT dbo.Tmp_Shipments OFF
GO

ALTER TABLE dbo.FedexShipments
	DROP CONSTRAINT FK_FedexShipments_Shipments
GO

ALTER TABLE dbo.UpsShipments
	DROP CONSTRAINT FK_UpsShipments_Shipments
GO

ALTER TABLE dbo.ShipmentCommodities
	DROP CONSTRAINT FK_ShipmentCommodities_Shipment
GO

ALTER TABLE dbo.UspsShipments
	DROP CONSTRAINT FK_UspsShipments_Shipments
GO

DROP TABLE dbo.Shipments
GO

EXECUTE sp_rename N'dbo.Tmp_Shipments', N'Shipments', 'OBJECT'
GO

ALTER TABLE dbo.Shipments ADD CONSTRAINT
	PK_Shipments PRIMARY KEY CLUSTERED 
	(
	ShipmentID
	)
GO

CREATE NONCLUSTERED INDEX IX_Shipments_OrderID ON dbo.Shipments
	(
	OrderID
	)
GO

CREATE NONCLUSTERED INDEX IX_Shipments_CustomerID ON dbo.Shipments
	(
	CustomerID
	)
GO

ALTER TABLE dbo.Shipments WITH NOCHECK ADD CONSTRAINT
	FK_Shipments_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

CREATE TRIGGER TG_Shipments ON dbo.Shipments FOR UPDATE
AS
    if ( (SELECT COUNT(*) FROM inserted) = 0)
       return;

    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID
        FROM inserted

    EXEC SetTableLastDbts 'Shipments', @StoreID, @@DBTS
GO


ALTER TABLE dbo.UspsShipments WITH NOCHECK ADD CONSTRAINT
	FK_UspsShipments_Shipments FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO

ALTER TABLE dbo.ShipmentCommodities WITH NOCHECK ADD CONSTRAINT
	FK_ShipmentCommodities_Shipment FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO

ALTER TABLE dbo.UpsShipments WITH NOCHECK ADD CONSTRAINT
	FK_UpsShipments_Shipments FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO

ALTER TABLE dbo.FedexShipments WITH NOCHECK ADD CONSTRAINT
	FK_FedexShipments_Shipments FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO
