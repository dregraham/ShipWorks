-----------------------------
--- TABLE ShipmentCommodities
-----------------------------
ALTER TABLE dbo.ShipmentCommodities ADD
	ECCN nvarchar(5) NOT NULL CONSTRAINT DF_ShipmentCommodities_ECCN DEFAULT '',
	ScheduleBNumber nvarchar(10) NOT NULL CONSTRAINT DF_ShipmentCommodities_ScheduleBNumber DEFAULT '',
	ExportInformationCode nvarchar(2) NOT NULL CONSTRAINT DF_ShipmentCommodities_ExportInformationCode DEFAULT '',
	ExportLicenseType smallint NOT NULL CONSTRAINT DF_ShipmentCommodities_ExportLicenseType DEFAULT 0
GO

ALTER TABLE dbo.ShipmentCommodities DROP CONSTRAINT DF_ShipmentCommodities_ECCN
GO
ALTER TABLE dbo.ShipmentCommodities DROP CONSTRAINT DF_ShipmentCommodities_ScheduleBNumber
GO
ALTER TABLE dbo.ShipmentCommodities DROP CONSTRAINT DF_ShipmentCommodities_ExportInformationCode
GO
ALTER TABLE dbo.ShipmentCommodities DROP CONSTRAINT DF_ShipmentCommodities_ExportLicenseType
GO

-----------------------------
--- Procedure GetOrderShipmentCommodities
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentCommodities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentCommodities]
GO

CREATE PROCEDURE dbo.GetOrderShipmentCommodities
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT c.*
   FROM ShipmentCommodities c, Shipments s
   WHERE c.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerShipmentCommodities
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentCommodities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentCommodities]
GO

CREATE PROCEDURE dbo.GetCustomerShipmentCommodities
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT c.*
   FROM ShipmentCommodities c, Shipments s
   WHERE c.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderShipmentCommodityRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentCommodityRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentCommodityRange]
GO

CREATE PROCEDURE dbo.GetOrderShipmentCommodityRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT c.*
     FROM ShipmentCommodities c, Shipments s, Orders o
     WHERE c.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerShipmentCommodityRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentCommodityRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentCommodityRange]
GO

CREATE PROCEDURE dbo.GetCustomerShipmentCommodityRange
(
    @StoreID int,
    @MinCustomerID int
)
WITH ENCRYPTION
AS
   SELECT c.*
     FROM ShipmentCommodities c, Shipments s
     WHERE c.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure DeleteShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteShipmentCommodity]
GO

CREATE PROCEDURE dbo.DeleteShipmentCommodity
(
    @CommodityID int
)
WITH ENCRYPTION
AS
   DELETE FROM ShipmentCommodities
     WHERE CommodityID = @CommodityID
GO

-----------------------------
--- Procedure UpdateShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateShipmentCommodity]
GO

CREATE PROCEDURE dbo.UpdateShipmentCommodity
(
	@CommodityID int,
	@RowVersion timestamp,
	@ShipmentID int,
	@Description nvarchar (200),
	@Quantity float,
	@Weight float,
	@UnitValue money,
	@UnitOfMeasure int,
	@OriginCountry varchar (20),
	@HarmonizedCode varchar (14),
	@ExportLicenseNumber varchar (12),
	@ExportLicenseExpiration datetime,
	@ECCN nvarchar (5),
	@ScheduleBNumber nvarchar(10),
	@ExportInformationCode nvarchar(2),
	@ExportLicenseType smallint
)
WITH ENCRYPTION
AS
    UPDATE [ShipmentCommodities]
    SET 	
		ShipmentID = @ShipmentID,
		Description = @Description,
		Quantity = @Quantity,
		Weight = @Weight,
		UnitValue = @UnitValue,
		UnitOfMeasure = @UnitOfMeasure,
		OriginCountry = @OriginCountry,
		HarmonizedCode = @HarmonizedCode,
		ExportLicenseNumber = @ExportLicenseNumber,
		ExportLicenseExpiration = @ExportLicenseExpiration,
		ECCN = @ECCN,
		ScheduleBNumber = @ScheduleBNumber,
		ExportInformationCode = @ExportInformationCode,
		ExportLicenseType = @ExportLicenseType
		
    WHERE CommodityID = @CommodityID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT CommodityID, [RowVersion]
    FROM ShipmentCommodities
    WHERE CommodityID = @CommodityID

    return 1
GO

-----------------------------
--- Procedure AddShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddShipmentCommodity]
GO

CREATE PROCEDURE dbo.AddShipmentCommodity
(
	@ShipmentID int,
	@Description nvarchar (200),
	@Quantity float,
	@Weight float,
	@UnitValue money,
	@UnitOfMeasure int,
	@OriginCountry varchar (20),
	@HarmonizedCode varchar (14),
	@ExportLicenseNumber varchar (12),
	@ExportLicenseExpiration datetime,
	@ECCN nvarchar (5),
	@ScheduleBNumber nvarchar(10),
	@ExportInformationCode nvarchar(2),
	@ExportLicenseType smallint
)
WITH ENCRYPTION
AS
    
    INSERT INTO [ShipmentCommodities]
    (
		ShipmentID,
		Description,
		Quantity,
		Weight,
		UnitValue,
		UnitOfMeasure,
		OriginCountry,
		HarmonizedCode,
		ExportLicenseNumber,
		ExportLicenseExpiration,
		ECCN,
		ScheduleBNumber,
		ExportInformationCode,
		ExportLicenseType
    )
    VALUES
    (
		@ShipmentID,
		@Description,
		@Quantity,
		@Weight,
		@UnitValue,
		@UnitOfMeasure,
		@OriginCountry,
		@HarmonizedCode,
		@ExportLicenseNumber,
		@ExportLicenseExpiration,
		@ECCN,
		@ScheduleBNumber,
		@ExportInformationCode,
		@ExportLicenseType
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT CommodityID, [RowVersion]
    FROM ShipmentCommodities
    WHERE CommodityID = SCOPE_IDENTITY()

    return 1

GO