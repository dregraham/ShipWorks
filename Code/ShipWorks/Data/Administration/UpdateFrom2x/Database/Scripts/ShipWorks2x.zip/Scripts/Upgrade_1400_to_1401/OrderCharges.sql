---------------------
--- Procedure DeleteOrderCharge
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteOrderCharge]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteOrderCharge]
GO

CREATE PROCEDURE dbo.DeleteOrderCharge
(
   @ChargeID int
)
WITH ENCRYPTION
AS
    DELETE FROM OrderCharges
    WHERE ChargeID = @ChargeID
GO

-----------------------------
--- Procedure GetChargesRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChargesRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChargesRange]
GO

CREATE PROCEDURE dbo.GetChargesRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT c.*
   FROM OrderCharges c, Orders o
   WHERE c.OrderID = o.OrderID AND
         o.StoreID = @StoreID AND 
         o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
         o.OrderID > @MinOrderID
GO

-----------------------------
--- Procedure GetOrderCharges
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderCharges]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderCharges]
GO

CREATE PROCEDURE dbo.GetOrderCharges
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT *
   FROM [OrderCharges]
   WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure UpdateOrderCharge
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateOrderCharge]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateOrderCharge]
GO

CREATE PROCEDURE dbo.UpdateOrderCharge
(
    @ChargeID int,
    @RowVersion timestamp,
	@OrderID int,
	@Type nvarchar (25) ,
	@Description nvarchar (100) ,
	@Amount money ,
	@MivaChargeID int
)
WITH ENCRYPTION
AS
    UPDATE [OrderCharges]
    SET [OrderID] = @OrderID, 
        [Type] = @Type, 
        [Description] = @Description,
        [Amount] = @Amount,
        [MivaChargeID] = @MivaChargeID
    WHERE ChargeID = @ChargeID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ChargeID, RowVersion
    FROM OrderCharges
    WHERE ChargeID = @ChargeID

    return 1
GO

-----------------------------
--- Procedure SynchEBayOrderCharge
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchEBayOrderCharge]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchEBayOrderCharge]
GO

CREATE PROCEDURE dbo.SynchEBayOrderCharge
(
	@OrderID int,
	@Type nvarchar (25) ,
	@Description nvarchar (100) ,
	@Amount money ,
	@MivaChargeID int
)
WITH ENCRYPTION
AS
   
    -- If this eBay charge already exists, we just update it
    if exists (
        SELECT * 
        FROM OrderCharges
        WHERE Type = @Type AND
              OrderID = @OrderID)
    begin
    
        UPDATE OrderCharges
        SET [OrderID] = @OrderID, 
            [Type] = @Type, 
            [Description] = @Description,
            [Amount] = @Amount,
            [MivaChargeID] = @MivaChargeID
        WHERE Type = @Type AND
              OrderID = @OrderID
              
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        -- Select the values back into .NET
        SELECT ChargeID, RowVersion
        FROM OrderCharges
        WHERE Type = @Type AND
              OrderID = @OrderID
              
        return 1

    end
    
    -- This charge does not already exist, we need to create it
    else 
    begin
        INSERT INTO [OrderCharges]
        (
            [OrderID], 
            [Type], 
            [Description],
            [Amount],
            [MivaChargeID]
        )
        VALUES
        (
            @OrderID, 
            @Type, 
            @Description,
            @Amount,
            @MivaChargeID
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ChargeID, RowVersion
        FROM OrderCharges
        WHERE ChargeID = SCOPE_IDENTITY()

        return 1
    end
GO

-----------------------------
--- Procedure SynchMivaOrderCharge
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaOrderCharge]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaOrderCharge]
GO

CREATE PROCEDURE dbo.SynchMivaOrderCharge
(
	@OrderID int,
	@Type nvarchar (25) ,
	@Description nvarchar (100) ,
	@Amount money ,
	@MivaChargeID int
)
WITH ENCRYPTION
AS
   
    -- If this Miva charge already exists, we dont do anything
    if exists (
        SELECT * 
        FROM OrderCharges
        WHERE MivaChargeID = @MivaChargeID AND
              OrderID = @OrderID)
    begin
    
        -- This just lets the .NET data provider know everything is OK
        SELECT ChargeID, RowVersion
        FROM OrderCharges
        WHERE MivaChargeID = @MivaChargeID AND
              OrderID = @OrderID
              
        return 1

    end
    
    -- This charge number does not already exist, we need to create it
    else 
    begin
        INSERT INTO [OrderCharges]
        (
            [OrderID], 
            [Type], 
            [Description],
            [Amount],
            [MivaChargeID]
        )
        VALUES
        (
            @OrderID, 
            @Type, 
            @Description,
            @Amount,
            @MivaChargeID
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ChargeID, RowVersion
        FROM OrderCharges
        WHERE ChargeID = SCOPE_IDENTITY()

        return 1
    end
GO

-----------------------------
--- Procedure AddOrderChage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddOrderCharge]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddOrderCharge]
GO

CREATE PROCEDURE dbo.AddOrderCharge
(
	@OrderID int,
	@Type nvarchar (25) ,
	@Description nvarchar (100) ,
	@Amount money ,
	@MivaChargeID int
)
WITH ENCRYPTION
AS
    INSERT INTO [OrderCharges]
    (
        [OrderID], 
        [Type], 
        [Description],
        [Amount],
        [MivaChargeID]
    )
    VALUES
    (
        @OrderID, 
        @Type, 
        @Description,
        @Amount,
        @MivaChargeID
    )
    
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT ChargeID, RowVersion
   FROM OrderCharges
   WHERE ChargeID = SCOPE_IDENTITY()

   return 1
GO