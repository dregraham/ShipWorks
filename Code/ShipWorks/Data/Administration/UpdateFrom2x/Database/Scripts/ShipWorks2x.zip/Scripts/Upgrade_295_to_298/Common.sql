----------------------------
--- Database Schema Version 
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetSchemaVersion]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetSchemaVersion]
GO

CREATE PROCEDURE dbo.GetSchemaVersion 
WITH ENCRYPTION
AS 
SELECT '2.9.8.0' AS 'SchemaVersion'
GO

----------------------------
--- SetSessionClientID
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SetSessionClientID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SetSessionClientID]
GO

CREATE PROCEDURE dbo.SetSessionClientID
(
    @ClientID int
)
WITH ENCRYPTION
AS
    DECLARE @BinVar binary(128)
    SET @BinVar = CAST( @ClientID AS binary(128) )
    SET CONTEXT_INFO @BinVar
GO
