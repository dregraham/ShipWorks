-----------------------------
--- Procedure GetChangedShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedShipments]
GO

CREATE PROCEDURE GetChangedShipments
(
   @LastDBTS rowversion,
   @MaxOrderID int,
   @StoreID int
)
AS
   if (@MaxOrderID < 0)
   begin
      SELECT s.*
         FROM Shipments s
         WHERE s.RowVersion > @LastDBTS AND s.StoreID = @StoreID
   end
   else
   begin
      SELECT s.*
        FROM Shipments s
        WHERE s.RowVersion > @LastDBTS AND s.StoreID = @StoreID AND s.OrderID <= @MaxOrderID
   end
GO
