-----------------------------
--- TABLE DhlShipments
-----------------------------
CREATE TABLE dbo.DhlShipments
(
	ShipmentID int NOT NULL,
	[RowVersion] timestamp NOT NULL,
	ServiceType smallint NOT NULL,
	HoldForPickup bit NOT NULL,
	HazardousMaterial bit NOT NULL,
	LeaveAtDoor bit NOT NULL,
	ReturnService bit NOT NULL,
	CodType	smallint NOT NULL,
	CodAmount money NOT NULL,
	ProtectionType smallint NOT NULL,
	DhlEmailRecipient bit NOT NULL,
	DhlEmailOtherEnable bit NOT NULL,
	DhlEmailOtherAddress nvarchar(35) NOT NULL,
	DhlEmailMessage nvarchar(255) NOT NULL,
	ShipToResidential bit NOT NULL,
	ShipFromShipperID int NOT NULL,
	ShipFromContactName nvarchar(30) NOT NULL,
	ShipFromContactCompany	nvarchar(30) NOT NULL,
	ShipFromAddress1 nvarchar(60) NOT NULL,
	ShipFromAddress2 nvarchar(60) NOT NULL,
	ShipFromCity nvarchar(50) NOT NULL,
	ShipFromStateProvinceCode nvarchar(5) NOT NULL,
	ShipFromPostalCode nvarchar(10) NOT NULL,
	ShipFromCountryCode nvarchar(5) NOT NULL,
	ShipFromContactEmail nvarchar(35) NOT NULL,
	ShipFromContactPhone nvarchar(25) NOT NULL,
	ShipFromContactFax nvarchar(25) NOT NULL, 
	PackageType smallint NOT NULL,
	Length int NOT NULL,
	Width int NOT NULL,
	Height int NOT NULL,
	Weight float NOT NULL,
	LabelImagePath nvarchar(350) NOT NULL,
	ReferenceText nvarchar(25) NOT NULL,
	Description nvarchar(50) NOT NULL,
	EmployerIDType smallint NOT NULL,
	EmployerIDNumber nvarchar(9) NOT NULL,
	PartiesRelated bit NOT NULL,
	BillingCode smallint NOT NULL,
	BillingAccountNumber nvarchar(11) NOT NULL,
	DutyPaymentCode smallint NOT NULL,
	DutyPaymentAccountNumber nvarchar(11) NOT NULL,
	OverrideZ1 bit NOT NULL,
	OverrideZ2 bit NOT NULL,
	OverrideES bit NOT NULL,
	OverrideRP bit NOT NULL,
	Dutiable bit NOT NULL,
	DeclaredValue money NOT NULL,
	ExportTransactionNumber nvarchar(30) NOT NULL,
	SEDRequired smallint NOT NULL,
	OverrideZ5 bit NOT NULL,
	CONSTRAINT [IX_DhlShipments_ShipmentID] UNIQUE NONCLUSTERED(ShipmentID),
	CONSTRAINT [FK_DhlShipments_Shipments] FOREIGN KEY ([ShipmentID]) REFERENCES [Shipments] ([ShipmentID])
)
GO

-----------------------------
--- Procedure GetOrderDhlShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderDhlShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderDhlShipments]
GO

CREATE PROCEDURE dbo.GetOrderDhlShipments
(
	@OrderID int
)
WITH ENCRYPTION
AS
	SELECT u.*
	FROM DhlShipments u, Shipments s
	WHERE u.ShipmentID = s.ShipmentID AND
		s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerDhlShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerDhlShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerDhlShipments]
GO

CREATE PROCEDURE dbo.GetCustomerDhlShipments
(
	@CustomerID int
)
WITH ENCRYPTION
AS
	SELECT u.*
	FROM DhlShipments u, Shipments s
	WHERE u.ShipmentID = s.ShipmentID AND
		s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderDhlShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderDhlShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderDhlShipmentRange]
GO

CREATE PROCEDURE dbo.GetOrderDhlShipmentRange
(
	@StoreID int,
	@DateRangeMax datetime,
	@DateRangeMin datetime,
	@MinOrderID int
)
WITH ENCRYPTION
AS 
	SELECT u.*
		FROM DhlShipments u, Shipments s, Orders o
		WHERE u.ShipmentID = s.ShipmentID AND
			s.StoreID = @StoreID AND
			s.OrderID = o.OrderID AND
			o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
			o.OrderID > @MinOrderID
GO


-----------------------------
--- Procedure GetCustomerDhlShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerDhlShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerDhlShipmentRange]
GO

CREATE PROCEDURE dbo.GetCustomerDhlShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
WITH ENCRYPTION
AS
   SELECT u.*
     FROM DhlShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO


-----------------------------
--- Procedure UpdateDhlShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateDhlShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateDhlShipment]
GO

CREATE PROCEDURE dbo.UpdateDhlShipment
(
	@ShipmentID int,
	@RowVersion timestamp,
	@ServiceType smallint, 
	@HoldForPickup bit,
	@HazardousMaterial bit,
	@LeaveAtDoor bit,
	@ReturnService bit,
	@CodType	smallint,
	@CodAmount money, 
	@ProtectionType smallint,
	@DhlEmailRecipient bit,
	@DhlEmailOtherEnable bit,
	@DhlEmailOtherAddress nvarchar(35),
	@DhlEmailMessage nvarchar(255),
	@ShipToResidential bit,
	@ShipFromShipperID int,
	@ShipFromContactName nvarchar(30),
	@ShipFromContactCompany	nvarchar(30),
	@ShipFromAddress1 nvarchar(60),
	@ShipFromAddress2 nvarchar(60),
	@ShipFromCity nvarchar(50),
	@ShipFromStateProvinceCode nvarchar(5),
	@ShipFromPostalCode nvarchar(10),
	@ShipFromCountryCode nvarchar(5),
	@ShipFromContactEmail nvarchar(35),
	@ShipFromContactPhone nvarchar(25),
	@ShipFromContactFax nvarchar(25),
	@PackageType smallint,
	@Length int,
	@Width int,
	@Height int,
	@Weight float,
	@LabelImagePath nvarchar(350),
	@ReferenceText nvarchar(25),
	@Description nvarchar(50),
	@EmployerIDType smallint,
	@EmployerIDNumber nvarchar(9),
	@PartiesRelated bit,
	@BillingCode smallint,
	@BillingAccountNumber nvarchar(11),
	@DutyPaymentCode smallint,
	@DutyPaymentAccountNumber nvarchar(11),
	@OverrideZ1 bit,
	@OverrideZ2 bit,
	@OverrideES bit,
	@OverrideRP bit,
	@Dutiable bit,
	@DeclaredValue money,
	@ExportTransactionNumber nvarchar(30),
	@SEDRequired smallint,
	@OverrideZ5 bit
	)
WITH ENCRYPTION 
AS 
	UPDATE DhlShipments
	SET
		ServiceType = @ServiceType, 
		HoldForPickup = @HoldForPickup,
		HazardousMaterial = @HazardousMaterial,
		LeaveAtDoor = @LeaveAtDoor,
		ReturnService = @ReturnService,
		CodType	= @CodType,
		CodAmount = @CodAmount,
		ProtectionType = @ProtectionType,
		DhlEmailRecipient = @DhlEmailRecipient,
		DhlEmailOtherEnable = @DhlEmailOtherEnable,
		DhlEmailOtherAddress = @DhlEmailOtherAddress,
		DhlEmailMessage = @DhlEmailMessage,
		ShipToResidential = @ShipToResidential,
		ShipFromShipperID = @ShipFromShipperID,
		ShipFromContactName = @ShipFromContactName,
		ShipFromContactCompany	= @ShipFromContactCompany,
		ShipFromAddress1 = @ShipFromAddress1, 
		ShipFromAddress2 = @ShipFromAddress2,
		ShipFromCity = @ShipFromCity,
		ShipFromStateProvinceCode = @ShipFromStateProvinceCode,
		ShipFromPostalCode = @ShipFromPostalCode,
		ShipFromCountryCode = @ShipFromCountryCode,
		ShipFromContactEmail = @ShipFromContactEmail,
		ShipFromContactPhone = @ShipFromContactPhone,
		ShipFromContactFax = @ShipFromContactFax,
		PackageType = @PackageType,
		Length = @Length,
		Width = @Width,
		Height = @Height,
		Weight = @Weight,
		LabelImagePath = @LabelImagePath,
		ReferenceTExt = @ReferenceText,
		Description = @Description,
		EmployerIDType = @EmployerIDType,
		EmployerIDNumber = @EmployerIDNumber,
		PartiesRelated = @PartiesRelated,
		BillingCode = @BillingCode, 
		BillingAccountNumber = @BillingAccountNumber, 
		DutyPaymentCode = @DutyPaymentCode, 
		DutyPaymentAccountNumber = @DutyPaymentAccountNumber,
		OverrideZ1 = @OverrideZ1,
		OverrideZ2 = @OverrideZ2,
		OverrideES = @OverrideES,
		OverrideRP = @OverrideRP,
		Dutiable = @Dutiable,
		DeclaredValue = @DeclaredValue,
		ExportTransactionNumber = @ExportTransactionNumber,
		SEDRequired = @SEDRequired,
		OverrideZ5 = @OverrideZ5
			
	WHERE
		ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
		
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT ShipmentID, [RowVersion]
	FROM DhlShipments
	WHERE ShipmentID = @ShipmentID
	
	RETURN 1
GO

-----------------------------
--- Procedure AddDhlShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDhlShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddDhlShipment]
GO

CREATE PROCEDURE dbo.AddDhlShipment
(
	@ShipmentID int,
	@ServiceType smallint, 
	@HoldForPickup bit,
	@HazardousMaterial bit,
	@LeaveAtDoor bit,
	@ReturnService bit,
	@CodType	smallint,
	@CodAmount money, 
	@ProtectionType smallint,
	@DhlEmailRecipient bit,
	@DhlEmailOtherEnable bit,
	@DhlEmailOtherAddress nvarchar(35),
	@DhlEmailMessage nvarchar(255),
	@ShipToResidential bit,
	@ShipFromShipperID int,
	@ShipFromContactName nvarchar(30),
	@ShipFromContactCompany	nvarchar(30),
	@ShipFromAddress1 nvarchar(60),
	@ShipFromAddress2 nvarchar(60),
	@ShipFromCity nvarchar(50),
	@ShipFromStateProvinceCode nvarchar(5),
	@ShipFromPostalCode nvarchar(10),
	@ShipFromCountryCode nvarchar(5),
	@ShipFromContactEmail nvarchar(35),
	@ShipFromContactPhone nvarchar(25),
	@ShipFromContactFax nvarchar(25),
	@PackageType smallint,
	@Length int,
	@Width int,
	@Height int,
	@Weight float,
	@LabelImagePath nvarchar(350),
	@ReferenceText nvarchar(25),
	@Description nvarchar(50),
	@EmployerIDType smallint,
	@EmployerIDNumber nvarchar(9),
	@PartiesRelated bit,
	@BillingCode smallint,
	@BillingAccountNumber nvarchar(11),
	@DutyPaymentCode smallint,
	@DutyPaymentAccountNumber nvarchar(11),
	@OverrideZ1 bit,
	@OverrideZ2 bit,
	@OverrideES bit,
	@OverrideRP bit,
	@Dutiable bit,
	@DeclaredValue money,
	@ExportTransactionNumber nvarchar(30),
	@SEDRequired smallint,
	@OverrideZ5 bit
)
WITH ENCRYPTION
AS 
	IF (EXISTS(SELECT * FROM DhlShipments WHERE ShipmentID = @ShipmentID))
	BEGIN
		SELECT * FROM DhlShipments WHERE ShipmentID = @ShipmentID
	END
	ELSE
	BEGIN
		INSERT INTO [DhlShipments]
		(
			ShipmentID,
			ServiceType, 
			HoldForPickup,
			HazardousMaterial,
			LeaveAtDoor,
			ReturnService,
			CodType,
			CodAmount, 
			ProtectionType,
			DhlEmailRecipient,
			DhlEmailOtherEnable,
			DhlEmailOtherAddress,
			DhlEmailMessage,
			ShipToResidential,
			ShipFromShipperID,
			ShipFromContactName,
			ShipFromContactCompany,
			ShipFromAddress1,
			ShipFromAddress2,
			ShipFromCity,
			ShipFromStateProvinceCode,
			ShipFromPostalCode,
			ShipFromCountryCode,
			ShipFromContactEmail,
			ShipFromContactPhone,
			ShipFromContactFax,
			PackageType,
			Length,
			Width,
			Height,
			Weight,
			LabelImagePath,
			ReferenceText,
			Description,
			EmployerIDType,
			EmployerIDNumber,
			PartiesRelated,
			BillingCode,
			BillingAccountNumber,
			DutyPaymentCode,
			DutyPaymentAccountNumber,
			OverrideZ1,
			OverrideZ2,
			OverrideES,
			OverrideRP,
			Dutiable,
			DeclaredValue,
			ExportTransactionNumber,
			SEDRequired,
			OverrideZ5
					)
		VALUES
		(
			@ShipmentID,
			@ServiceType, 
			@HoldForPickup,
			@HazardousMaterial,
			@LeaveAtDoor,
			@ReturnService,
			@CodType,
			@CodAmount, 
			@ProtectionType,
			@DhlEmailRecipient,
			@DhlEmailOtherEnable,
			@DhlEmailOtherAddress,
			@DhlEmailMessage,
			@ShipToResidential,
			@ShipFromShipperID,
			@ShipFromContactName,
			@ShipFromContactCompany,
			@ShipFromAddress1,
			@ShipFromAddress2,
			@ShipFromCity,
			@ShipFromStateProvinceCode,
			@ShipFromPostalCode,
			@ShipFromCountryCode,
			@ShipFromContactEmail,
			@ShipFromContactPhone,
			@ShipFromContactFax,
			@PackageType,
			@Length,
			@Width,
			@Height,
			@Weight,
			@LabelImagePath,
			@ReferenceText,
			@Description,
			@EmployerIDType,
			@EmployerIDNumber,
			@PartiesRelated,
			@BillingCode,
			@BillingAccountNumber,
			@DutyPaymentCode,
			@DutyPaymentAccountNumber,
			@OverrideZ1,
			@OverrideZ2,
			@OverrideES,
			@OverrideRP,
			@Dutiable,
			@DeclaredValue,
			@ExportTransactionNumber,
			@SEDRequired,
			@OverrideZ5
					)
		
		IF (@@ROWCOUNT != 1)
			RETURN 0
			
		SET NOCOUNT ON
		
		SELECT ShipmentID, RowVersion
		FROM DhlShipments
		WHERE ShipmentID = @ShipmentID
		
		RETURN 1
	END
GO

