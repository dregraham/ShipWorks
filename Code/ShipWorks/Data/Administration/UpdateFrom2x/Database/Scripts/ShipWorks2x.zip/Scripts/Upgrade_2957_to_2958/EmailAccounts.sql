ALTER TABLE dbo.EmailAccounts ADD
	SmtpSecurity int NOT NULL CONSTRAINT DF_EmailAccounts_SmtpSecurity DEFAULT 0
GO

ALTER TABLE dbo.EmailAccounts DROP CONSTRAINT DF_EmailAccounts_SmtpSecurity
GO

----------------------------
--- PROCEDURE AddEmailAccount
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddEmailAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddEmailAccount]
GO

CREATE PROCEDURE dbo.AddEmailAccount
(
	@StoreID int,
	@EmailAddress nvarchar (50),
	@FromName nvarchar (50),
	@PopServer nvarchar (250),
	@PopPort int,
	@SmtpServer nvarchar (250),
	@SmtpPort int,
	@AuthenticateType int,
	@Username nvarchar (50),
	@Password nvarchar (50),
	@RememberPassword bit,
	@SmtpSecurity int
)
WITH ENCRYPTION
AS
   INSERT INTO EmailAccounts
   (
        StoreID,
        EmailAddress,
        FromName,
        PopServer,
        PopPort,
        SmtpServer,
        SmtpPort,
        AuthenticateType,
        Username,
        [Password],
        RememberPassword,
        SmtpSecurity
   )
   VALUES 
   (
        @StoreID,
        @EmailAddress,
        @FromName,
        @PopServer,
        @PopPort,
        @SmtpServer,
        @SmtpPort,
        @AuthenticateType,
        @Username,
        @Password,
        @RememberPassword,
        @SmtpSecurity
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT AccountID
     FROM EmailAccounts
     WHERE AccountID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateEmailAccount
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateEmailAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateEmailAccount]
GO

CREATE PROCEDURE dbo.UpdateEmailAccount
(
    @AccountID int,
	@StoreID int ,
	@EmailAddress nvarchar (50),
	@FromName nvarchar (50),
	@PopServer nvarchar (250),
	@PopPort int,
	@SmtpServer nvarchar (250),
	@SmtpPort int,
	@AuthenticateType int,
	@Username nvarchar (50),
	@Password nvarchar (50),
	@RememberPassword bit,
	@SmtpSecurity int
)
WITH ENCRYPTION
AS
   UPDATE EmailAccounts
      SET   StoreID = @StoreID,
            EmailAddress = @EmailAddress,
            FromName = @FromName,
            PopServer = @PopServer,
            PopPort = @PopPort,
            SmtpServer = @SmtpServer,
            SmtpPort = @SmtpPort,
            AuthenticateType = @AuthenticateType,
            Username = @Username,
            [Password] = @Password,
            RememberPassword = @RememberPassword,
            SmtpSecurity = @SmtpSecurity
      WHERE AccountID = @AccountID
      
   if (@@ROWCOUNT != 1)
      return 0

   return 1
GO

-----------------------------
--- Procedure DeleteEmailAccount
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteEmailAccount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteEmailAccount]
GO

CREATE PROCEDURE dbo.DeleteEmailAccount
(
   @AccountID int
)
WITH ENCRYPTION
AS
    DELETE FROM EmailAccounts
    WHERE AccountID = @AccountID
GO

----------------------------
--- PROCEDURE GetEmailAccounts
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetEmailAccounts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetEmailAccounts]
GO

CREATE PROCEDURE dbo.GetEmailAccounts 
WITH ENCRYPTION
AS
   SELECT *
     FROM EmailAccounts
GO
