-----------------------------
--- Procedure DeleteCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteCustomer]
GO

CREATE PROCEDURE DeleteCustomer
(
   @CustomerID int
)
AS
    DELETE UpsPackages
      FROM UpsPackages p, Shipments s
      WHERE p.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID
     
   DELETE UpsShipments
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID
     
    DELETE ShipmentCommodities
      FROM ShipmentCommodities c, Shipments s
      WHERE c.ShipmentID = s.ShipmentID AND s.CustomerID = @CustomerID

   DELETE FROM Shipments
     WHERE CustomerID = @CustomerID

    DELETE FROM Customers
       WHERE CustomerID = @CustomerID
GO