if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_Users_Change]'))
    drop trigger [dbo].TG_Users_Change
GO

-- Create trigger to track changes to users
CREATE TRIGGER dbo.TG_Users_Change ON Users WITH ENCRYPTION FOR UPDATE, INSERT
AS
    if ( (SELECT COUNT(*) FROM inserted) = 0)
       return;

    IF UPDATE(Username)
    begin
    
        DECLARE @uniqueCount int
        DECLARE @totalCount int
        
        SELECT @uniqueCount = Count(DISTINCT Username), @totalCount = Count(Username)
        FROM Users
                
        if (@uniqueCount != @totalCount)
        BEGIN
            RAISERROR ('Usernames must be unique.', 16, 1)
            ROLLBACK TRANSACTION
            return
        END 

    end
    
    if update(isadmin)
    begin
    
        if ((select count(*) from users where isadmin = 1 and deleted = 0) = 0)
        BEGIN
            RAISERROR ('There must be a least one active Administrator user.', 16, 1)
            ROLLBACK TRANSACTION
            return
        END 
        
    end
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_Users_Deleted]'))
    drop trigger [dbo].TG_Users_Deleted
GO

-- Trigger to make sure the last admin user is not deleted
CREATE TRIGGER dbo.TG_Users_Deleted ON Users WITH ENCRYPTION FOR DELETE
AS
    if ((select count(*) from users where isadmin = 1 and deleted = 0) = 0)
    BEGIN
        RAISERROR ('There must be a least one active Administrator user.', 16, 1)
        ROLLBACK TRANSACTION
        return
    END 
GO

----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IsAdminUser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[IsAdminUser]
GO

CREATE PROCEDURE dbo.IsAdminUser
(
	@Username nvarchar (50),
	@Password varchar (32)
)
WITH ENCRYPTION
AS
    select count(*) as 'IsAdmin' from users where Username = @Username and Password = @Password and IsAdmin = 1 and Deleted = 0
    
    return 0
GO

----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUser]
GO

CREATE PROCEDURE dbo.AddUser
(
	@Username nvarchar (50),
	@Password varchar (32),
	@IsAdmin bit,
	@Deleted bit
)
WITH ENCRYPTION
AS
   INSERT INTO Users
   (
	    Username,
	    Password,
	    IsAdmin,
	    Deleted
   )
   VALUES 
   (
	    @Username,
	    @Password,
	    @IsAdmin,
	    @Deleted
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT UserID
     FROM Users
     WHERE UserID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateUser
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUser]
GO

CREATE PROCEDURE dbo.UpdateUser
(
	@UserID int,
	@Username nvarchar (50),
	@Password varchar (32),
	@IsAdmin bit,
	@Deleted bit
)
WITH ENCRYPTION
AS
   UPDATE Users
      SET   
	   Username = @Username,
	   Password = @Password,
	   IsAdmin = @IsAdmin,
	   Deleted = @Deleted
      WHERE UserID = @UserID
      
   if (@@ROWCOUNT != 1)
      return 0

   return 1
GO

----------------------------
--- PROCEDURE GetUsers
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUsers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUsers]
GO

CREATE PROCEDURE dbo.GetUsers 
WITH ENCRYPTION
AS
   SELECT *
     FROM Users
GO
