----
--- PROCEDURE AddFeedbackPreset
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFeedbackPreset]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddFeedbackPreset]
GO

CREATE PROCEDURE dbo.AddFeedbackPreset
(
   @Comment nvarchar(80),
   @FeedbackType int
)
WITH ENCRYPTION
AS
   INSERT INTO FeedbackPresets 
   (
      Comment,
      FeedbackType
   )
   VALUES 
   (
      @Comment,
      @FeedbackType
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT PresetID
     FROM FeedbackPresets
     WHERE PresetID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateFeedbackPreset
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFeedbackPreset]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFeedbackPreset]
GO

CREATE PROCEDURE dbo.UpdateFeedbackPreset
(
   @PresetID int,
   @Comment nvarchar(80),
   @FeedbackType int
)
WITH ENCRYPTION
AS
   UPDATE FeedbackPresets
      SET Comment = @Comment,
          FeedbackType = @FeedbackType
      WHERE PresetID = @PresetID
      
   if (@@ROWCOUNT != 1)
      return 0

   return 1
GO

-----------------------------
--- Procedure DeleteFeedbackPreset
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteFeedbackPreset]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteFeedbackPreset]
GO

CREATE PROCEDURE dbo.DeleteFeedbackPreset
(
   @PresetID int
)
WITH ENCRYPTION
AS
    DELETE FROM FeedbackPresets
    WHERE PresetID = @PresetID
GO

----------------------------
--- PROCEDURE GetAllFeedbackPresets
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllFeedbackPresets]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllFeedbackPresets]
GO

CREATE PROCEDURE dbo.GetAllFeedbackPresets 
WITH ENCRYPTION
AS
   SELECT *
   FROM FeedbackPresets
GO
