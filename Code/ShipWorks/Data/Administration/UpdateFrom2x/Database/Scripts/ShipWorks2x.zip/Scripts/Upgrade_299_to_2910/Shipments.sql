----------------------------
--- PROCEDURE GetShipmentOwner
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetShipmentOwner]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetShipmentOwner]
GO

CREATE PROCEDURE dbo.GetShipmentOwner
(
	@ShipmentID int		   
)
WITH ENCRYPTION
AS
	DECLARE 
	@CustomerID INT,
	@OrderID INT

	SELECT @CustomerID = customerId, @OrderID = orderId
	FROM shipments 
	WHERE ShipmentId = @ShipmentId

	IF @CustomerID = -1
	BEGIN
		SELECT @OrderID as [Owner], 1 as [IsOrder]		
	END 
	ELSE
	BEGIN
		SELECT @CustomerID as [Owner], 0 as [IsOrder]
	END

	RETURN 1	
GO

----------------------------
--- PROCEDURE GetCustomerShipmentIDs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentIDs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentIDs]
GO

CREATE PROCEDURE dbo.GetCustomerShipmentIDs
(
	@CustomerID int		   
)
WITH ENCRYPTION
AS
	SELECT ShipmentID FROM Shipments WHERE CustomerID = @CustomerID
GO


----------------------------
--- PROCEDURE GetOrderShipmentIDs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentIDs]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentIDs]
GO

CREATE PROCEDURE dbo.GetOrderShipmentIDs
(
	@OrderID int		   
)
WITH ENCRYPTION
AS
	SELECT ShipmentID FROM Shipments WHERE OrderID = @OrderID
GO

-----------------------------
--- Procedure GetOrderShipmentsRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentsRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentsRange]
GO

CREATE PROCEDURE dbo.GetOrderShipmentsRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
    -- Get all shipments within the order range
    SELECT s.*
        FROM Shipments s, Orders o
        WHERE s.StoreID = @StoreID AND
              s.OrderID = o.OrderID AND
              ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
              o.OrderID > @MinOrderID
                  
GO