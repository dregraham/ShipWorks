-----------------------------
--- Procedure AddUpsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUpsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUpsShipment]
GO

CREATE PROCEDURE AddUpsShipment
(
    @ShipmentID int,
    @DescriptionOfGoods nvarchar (100)  ,
    @DocumentsOnly bit ,
    @CustomsValue money ,
    @ReferenceNumber nvarchar (50)  ,
    @ServiceCode nvarchar (10)  ,
    @LabelTypeCode  nvarchar (10)  ,
    @Voided bit ,
    @ArrivalDate datetime ,
    @NotificationEmailFromName nvarchar (50)  ,
    @NotificationEmailSubjectCode nvarchar (50)  ,
    @NotificationEmailFailedAddress nvarchar (50)  ,
    @NotificationEmailMemo nvarchar (150)  ,
    @NotificationEmailRecipients nvarchar (1500),
    @ShipToResidential bit ,
    @ShipToShipperNumber nvarchar (10)  ,
    @ShipFromCompanyOrName nvarchar (30)  ,
    @ShipFromAttention nvarchar (30)  ,
    @ShipFromAddress1 nvarchar (60)  ,
    @ShipFromAddress2 nvarchar (60)  ,
    @ShipFromAddress3 nvarchar (60)  ,
    @ShipFromCity nvarchar (50)  ,
    @ShipFromStateProvinceCode nvarchar (5)  ,
    @ShipFromPostalCode nvarchar (10)  ,
    @ShipFromCountryCode nvarchar (5)  ,
    @ShipFromContactEmail nvarchar (25)  ,
    @ShipFromContactPhone nvarchar (25)  ,
    @ShipFromContactFax nvarchar (25)  ,
    @ShipFromShipperNumber nvarchar (10) 
)
AS
    if (exists(SELECT * FROM UpsShipments WHERE ShipmentID = @ShipmentID))
    begin
    
        select * from UpsShipments WHERE ShipmentID = @ShipmentID
        
    end
    else
    begin
        INSERT INTO [UpsShipments]
        (
	        ShipmentID,
            DescriptionOfGoods,
            DocumentsOnly,
            CustomsValue,
            ReferenceNumber,
            ServiceCode,
            LabelTypeCode,
            Voided,
            ArrivalDate,
            NotificationEmailFromName,
            NotificationEmailSubjectCode,
            NotificationEmailFailedAddress,
            NotificationEmailMemo,
            NotificationEmailRecipients,
            ShipToResidential,
            ShipToShipperNumber,
	        ShipFromCompanyOrName,
	        ShipFromAttention,
	        ShipFromAddress1,
	        ShipFromAddress2,
	        ShipFromAddress3,
	        ShipFromCity,
	        ShipFromStateProvinceCode,
	        ShipFromPostalCode,
	        ShipFromCountryCode,
            ShipFromContactEmail,
	        ShipFromContactPhone,
	        ShipFromContactFax,
            ShipFromShipperNumber
        )
        VALUES
        (
            @ShipmentID,
            @DescriptionOfGoods,
            @DocumentsOnly,
            @CustomsValue,
            @ReferenceNumber,
            @ServiceCode,
            @LabelTypeCode,
            @Voided,
            @ArrivalDate,
            @NotificationEmailFromName,
            @NotificationEmailSubjectCode,
            @NotificationEmailFailedAddress,
            @NotificationEmailMemo,
            @NotificationEmailRecipients,
            @ShipToResidential,
            @ShipToShipperNumber,
            @ShipFromCompanyOrName,
            @ShipFromAttention,
            @ShipFromAddress1,
            @ShipFromAddress2,
            @ShipFromAddress3,
            @ShipFromCity,
            @ShipFromStateProvinceCode,
            @ShipFromPostalCode,
            @ShipFromCountryCode,
            @ShipFromContactEmail,
            @ShipFromContactPhone,
            @ShipFromContactFax,
            @ShipFromShipperNumber    
        )
            
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ShipmentID, RowVersion
        FROM UpsShipments
        WHERE ShipmentID = @ShipmentID

        return 1   
  end
  
GO