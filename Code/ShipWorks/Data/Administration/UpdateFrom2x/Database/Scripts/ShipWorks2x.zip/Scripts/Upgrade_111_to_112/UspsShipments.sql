-----------------------------
--- Procedure AddUspsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUspsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUspsShipment]
GO

CREATE PROCEDURE AddUspsShipment
(
    @ShipmentID int,
	@ServiceType int ,
	@ConfirmationType int ,
	@AddressService bit  ,
	@SendEmail bit ,
	@LabelImageFull nvarchar (350) ,
	@LabelImageLabel nvarchar (350),
	@LabelImageBarcode nvarchar (350) 
)
AS
    if (exists(SELECT * FROM UspsShipments WHERE ShipmentID = @ShipmentID))
    begin
    
        select * from UspsShipments WHERE ShipmentID = @ShipmentID
        
    end
    else
    begin
    
        INSERT INTO [UspsShipments]
        (
            ShipmentID,
            ServiceType,
	        ConfirmationType,
	        AddressService,
	        SendEmail,
	        LabelImageFull,
	        LabelImageLabel,
	        LabelImageBarcode
        )
        VALUES
        (
            @ShipmentID,
            @ServiceType,
	        @ConfirmationType,
	        @AddressService,
	        @SendEmail,
	        @LabelImageFull,
	        @LabelImageLabel,
	        @LabelImageBarcode
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ShipmentID, [RowVersion]
        FROM UspsShipments
        WHERE ShipmentID = @ShipmentID

        return 1
                
  end
    
GO