ALTER TABLE ClientStoreSettings ALTER COLUMN [WorldShipReferenceNumber1] varchar (50) NOT NULL
ALTER TABLE ClientStoreSettings ALTER COLUMN [WorldShipReferenceNumber2] varchar (50) NOT NULL
ALTER TABLE ClientStoreSettings ALTER COLUMN [EndiciaRubberStamp1] [varchar] (200) NOT NULL
ALTER TABLE ClientStoreSettings ALTER COLUMN [EndiciaRubberStamp2] [varchar] (200) NOT NULL
ALTER TABLE ClientStoreSettings ALTER COLUMN [EndiciaRubberStamp3] [varchar] (200) NOT NULL
ALTER TABLE ClientStoreSettings ALTER COLUMN [EndiciaRubberStamp4] [varchar] (200) NOT NULL
ALTER TABLE ClientStoreSettings ALTER COLUMN [EndiciaRubberStamp5] [varchar] (200) NOT NULL

GO

ALTER TABLE ClientStoreSettings ADD DisplayShipmentOwnerOrder varchar(200) NOT NULL DEFAULT ''
ALTER TABLE ClientStoreSettings ADD DisplayShipmentOwnerCustomer varchar(200) NOT NULL DEFAULT ''

ALTER TABLE ClientStoreSettings ALTER COLUMN DisplayShipmentOwnerOrder varchar(200) NOT NULL
ALTER TABLE ClientStoreSettings ALTER COLUMN DisplayShipmentOwnerCustomer varchar(200) NOT NULL

GO

UPDATE ClientStoreSettings
  SET DisplayShipmentOwnerOrder = 'Order {//Order/Number}'

UPDATE ClientStoreSettings
  SET DisplayShipmentOwnerCustomer = '{//Customer/eBay/BuyerID}'
  FROM Stores s
  WHERE s.StoreID = ClientStoreSettings.StoreID and s.StoreType = 1 -- ebay

UPDATE ClientStoreSettings
   SET DisplayShipmentOwnerCustomer = '{//Customer/Address[@type=''bill'']/LastName}, {//Customer/Address[@type=''bill'']/FirstName}'
   FROM Stores s
   WHERE s.StoreID = ClientStoreSettings.StoreID and s.StoreType != 1 -- not ebay
   
GO

----------------------------
--- PROCEDURE GetAllClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetAllClientStoreSettings]
GO

CREATE PROCEDURE GetAllClientStoreSettings
AS
   SELECT *
   FROM [ClientStoreSettings]
GO

----------------------------
--- PROCEDURE DeleteClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteClientStoreSettings]
GO

CREATE PROCEDURE DeleteClientStoreSettings
(
   @ClientID int,
   @StoreID int
)
AS
   DELETE FROM [ClientStoreSettings]
   WHERE 
      [ClientID] = @ClientID AND
      [StoreID] = @StoreID
GO

----------------------------
--- PROCEDURE AddClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddClientStoreSettings]
GO

CREATE PROCEDURE AddClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 varchar (50),
   @WorldShipReferenceNumber2 varchar (50),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaUnattendedPrinting bit,
   @EndiciaSpecifyLayout bit,
   @EndiciaDefaultLayoutFile nvarchar(350),
   @EndiciaStealthMode bit,
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @EndiciaRubberStamp1 varchar(200),
   @EndiciaRubberStamp2 varchar(200),
   @EndiciaRubberStamp3 varchar(200),
   @EndiciaRubberStamp4 varchar(200),
   @EndiciaRubberStamp5 varchar(200),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DisplayShipmentOwnerOrder varchar (200),
   @DisplayShipmentOwnerCustomer varchar (200)
)
AS
   INSERT INTO [ClientStoreSettings]
   (
        [ClientID], 
        [StoreID], 
        [LicenseKey], 
        [PerfDateRangeType],
        [PerfDateRangeDays], 
        [PerfDateRangeMax], 
        [PerfDateRangeMin], 
        [PerfShowFilterCounts],
        [WolrdShipCsvFilename], 
        [WorldShipOutputType], 
        [WorldShipLaunchAfterExport], 
        [WorldShipReferenceNumber1],
        [WorldShipReferenceNumber2],
        [WorldShipQvnFromName],
        [WorldShipQvnSubject],
        [WorldShipQvnMemo],
        [WorldShipQvnFailedAddress],
        [WorldShipQvnShipNotify],
        [WorldShipQvnDeliveryNotify],
        [WorldShipQvnExceptionNotify],
        [StampsDefaultService],
        [StampsDefaultConfirmation],
        [StampsMailpiece],
        [StampsLabelSheet],
        [StampsHidePostage],
        [StampsMemo],
        [EndiciaSetService], 
        [EndiciaSetConfirmation], 
        [EndiciaSetWeight], 
        [EndiciaSetDate], 
        [EndiciaDefaultDomesticService], 
        [EndiciaDefaultInternationalService],
        [EndiciaDefaultConfirmation], 
        [EndiciaDefaultDateAdvance], 
        [EndiciaUnattendedPrinting], 
        [EndiciaSpecifyLayout], 
        [EndiciaDefaultLayoutFile], 
        [EndiciaStealthMode],
        [EndiciaTestMode], 
        [EndiciaCloseOnComplete], 
        [EndiciaRubberStamp1],
        [EndiciaRubberStamp2],
        [EndiciaRubberStamp3],
        [EndiciaRubberStamp4],
        [EndiciaRubberStamp5],
        [UspsDefaultService], 
        [UspsDefaultConfirmation], 
        [UspsDefaultRequestAddressService], 
        [UspsDefaultSendConfirmationEmail], 
        [UspsUseLiveServer], 
        [UspsDefaultTemplate], 
        [DownloadAllowed],
	    [DownloadAutoEnable],
	    [DownloadAutoInterval],
	    DisplayShipmentOwnerOrder,
	    DisplayShipmentOwnerCustomer
   )
   VALUES 
   (
        @ClientID, 
        @StoreID, 
        @LicenseKey, 
        @PerfDateRangeType,
        @PerfDateRangeDays, 
        @PerfDateRangeMax, 
        @PerfDateRangeMin, 
        @PerfShowFilterCounts,
        @WolrdShipCsvFilename, 
        @WorldShipOutputType, 
        @WorldShipLaunchAfterExport, 
        @WorldShipReferenceNumber1,
        @WorldShipReferenceNumber2,
        @WorldShipQvnFromName,
        @WorldShipQvnSubject,
        @WorldShipQvnMemo,
        @WorldShipQvnFailedAddress,
        @WorldShipQvnShipNotify,
        @WorldShipQvnDeliveryNotify,
        @WorldShipQvnExceptionNotify,
        @StampsDefaultService,
        @StampsDefaultConfirmation,
        @StampsMailpiece,
        @StampsLabelSheet,
        @StampsHidePostage,
        @StampsMemo,
        @EndiciaSetService, 
        @EndiciaSetConfirmation, 
        @EndiciaSetWeight, 
        @EndiciaSetDate, 
        @EndiciaDefaultDomesticService, 
        @EndiciaDefaultInternationalService,
        @EndiciaDefaultConfirmation, 
        @EndiciaDefaultDateAdvance, 
        @EndiciaUnattendedPrinting, 
        @EndiciaSpecifyLayout, 
        @EndiciaDefaultLayoutFile, 
        @EndiciaStealthMode,
        @EndiciaTestMode, 
        @EndiciaCloseOnComplete, 
        @EndiciaRubberStamp1,
        @EndiciaRubberStamp2,
        @EndiciaRubberStamp3,
        @EndiciaRubberStamp4,
        @EndiciaRubberStamp5,
        @UspsDefaultService, 
        @UspsDefaultConfirmation, 
        @UspsDefaultRequestAddressService, 
        @UspsDefaultSendConfirmationEmail, 
        @UspsUseLiveServer, 
        @UspsDefaultTemplate, 
        @DownloadAllowed,
	    @DownloadAutoEnable,
	    @DownloadAutoInterval,
	    @DisplayShipmentOwnerOrder,
	    @DisplayShipmentOwnerCustomer
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT RowVersion
   FROM ClientStoreSettings
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateClientStoreSettings]
GO

CREATE PROCEDURE UpdateClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 varchar (50),
   @WorldShipReferenceNumber2 varchar (50),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaUnattendedPrinting bit,
   @EndiciaSpecifyLayout bit,
   @EndiciaDefaultLayoutFile nvarchar(350),
   @EndiciaStealthMode bit,
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @EndiciaRubberStamp1 varchar(200),
   @EndiciaRubberStamp2 varchar(200),
   @EndiciaRubberStamp3 varchar(200),
   @EndiciaRubberStamp4 varchar(200),
   @EndiciaRubberStamp5 varchar(200),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DisplayShipmentOwnerOrder varchar (200),
   @DisplayShipmentOwnerCustomer varchar (200)
)
AS
   UPDATE [ClientStoreSettings]
   SET 
    [LicenseKey] = @LicenseKey, 
    [PerfDateRangeType] = @PerfDateRangeType,
    [PerfDateRangeDays] = @PerfDateRangeDays, 
    [PerfDateRangeMax] = @PerfDateRangeMax, 
    [PerfDateRangeMin] = @PerfDateRangeMin, 
    [PerfShowFilterCounts] = @PerfShowFilterCounts,
    [WolrdShipCsvFilename] = @WolrdShipCsvFilename, 
    [WorldShipOutputType] = @WorldShipOutputType, 
    [WorldShipLaunchAfterExport] = @WorldShipLaunchAfterExport, 
    [WorldShipReferenceNumber1] = @WorldShipReferenceNumber1,
    [WorldShipReferenceNumber2] = @WorldShipReferenceNumber2,
    [WorldShipQvnFromName] = @WorldShipQvnFromName,
    [WorldShipQvnSubject] = @WorldShipQvnSubject,
    [WorldShipQvnMemo] = @WorldShipQvnMemo,
    [WorldShipQvnFailedAddress] = @WorldShipQvnFailedAddress,
    [WorldShipQvnShipNotify] = @WorldShipQvnShipNotify,
    [WorldShipQvnDeliveryNotify] = @WorldShipQvnDeliveryNotify,
    [WorldShipQvnExceptionNotify] = @WorldShipQvnExceptionNotify,
    [StampsDefaultService] = @StampsDefaultService,
    [StampsDefaultConfirmation] = @StampsDefaultConfirmation,
    [StampsMailpiece] = @StampsMailpiece,
    [StampsLabelSheet] = @StampsLabelSheet,
    [StampsHidePostage] = @StampsHidePostage,
    [StampsMemo] = @StampsMemo,
    [EndiciaSetService] = @EndiciaSetService, 
    [EndiciaSetConfirmation] = @EndiciaSetConfirmation, 
    [EndiciaSetWeight] = @EndiciaSetWeight, 
    [EndiciaSetDate] = @EndiciaSetDate, 
    [EndiciaDefaultDomesticService] = @EndiciaDefaultDomesticService, 
    [EndiciaDefaultInternationalService] = @EndiciaDefaultInternationalService,
    [EndiciaDefaultConfirmation] = @EndiciaDefaultConfirmation, 
    [EndiciaDefaultDateAdvance] = @EndiciaDefaultDateAdvance, 
    [EndiciaUnattendedPrinting] = @EndiciaUnattendedPrinting, 
    [EndiciaSpecifyLayout] = @EndiciaSpecifyLayout, 
    [EndiciaDefaultLayoutFile] = @EndiciaDefaultLayoutFile,
    [EndiciaStealthMode] = @EndiciaStealthMode, 
    [EndiciaTestMode] = @EndiciaTestMode, 
    [EndiciaCloseOnComplete] = @EndiciaCloseOnComplete, 
    [EndiciaRubberStamp1] = @EndiciaRubberStamp1,
    [EndiciaRubberStamp2] = @EndiciaRubberStamp2,
    [EndiciaRubberStamp3] = @EndiciaRubberStamp3,
    [EndiciaRubberStamp4] = @EndiciaRubberStamp4,
    [EndiciaRubberStamp5] = @EndiciaRubberStamp5,
    [UspsDefaultService] = @UspsDefaultService, 
    [UspsDefaultConfirmation] = @UspsDefaultConfirmation, 
    [UspsDefaultRequestAddressService] = @UspsDefaultRequestAddressService, 
    [UspsDefaultSendConfirmationEmail] = @UspsDefaultSendConfirmationEmail, 
    [UspsUseLiveServer] = @UspsUseLiveServer, 
    [UspsDefaultTemplate] = @UspsDefaultTemplate, 
    [DownloadAllowed] = @DownloadAllowed,
    [DownloadAutoEnable] = @DownloadAutoEnable,
    [DownloadAutoInterval] = @DownloadAutoInterval,
    DisplayShipmentOwnerOrder = @DisplayShipmentOwnerOrder,
    DisplayShipmentOwnerCustomer = @DisplayShipmentOwnerCustomer
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM [ClientStoreSettings]
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID

   return 1
GO