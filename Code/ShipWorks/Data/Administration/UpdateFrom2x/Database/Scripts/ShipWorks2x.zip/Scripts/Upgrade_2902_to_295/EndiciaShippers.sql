-----------------------------
--- TABLE EndiciaShippers
-----------------------------
CREATE TABLE dbo.EndiciaShippers
(
	EndiciaShipperID int IDENTITY (1, 1) NOT NULL,
	[RowVersion] timestamp NOT NULL,
	Company nvarchar(35) NOT NULL,
	ContactName nvarchar(35) NOT NULL,
	Address1 nvarchar(60) NOT NULL,
	Address2 nvarchar(60) NOT NULL,
	Address3 nvarchar(60) NOT NULL,
	City nvarchar(50) NOT NULL,
	StateProvinceCode nvarchar(5) NOT NULL,
	PostalCode nvarchar(10) NOT NULL,
	ContactEmail nvarchar(35) NOT NULL,
	ContactPhone nvarchar(25) NOT NULL,
	CONSTRAINT PK_EndiciaShippers PRIMARY KEY CLUSTERED ( EndiciaShipperID )
)
GO


----------------------------
--- PROCEDURE AddEndiciaShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddEndiciaShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddEndiciaShipper]
GO

CREATE PROCEDURE dbo.AddEndiciaShipper
(
	@Company nvarchar(35),
	@ContactName nvarchar(35),
	@Address1 nvarchar(60),
	@Address2 nvarchar(60),
	@Address3 nvarchar(60),
	@City nvarchar(50),
	@StateProvinceCode nvarchar(5),
	@PostalCode nvarchar(10),
	@ContactEmail nvarchar(35),
	@ContactPhone nvarchar(25)
)
WITH ENCRYPTION
AS
	INSERT INTO EndiciaShippers
	(
		Company,
		ContactName,
		Address1,
		Address2,
		Address3,
		City,
		StateProvinceCode,
		PostalCode,
		ContactEmail,
		ContactPhone
	)
	VALUES
	(
		@Company,
		@ContactName,
		@Address1,
		@Address2,
		@Address3,
		@City,
		@StateProvinceCode,
		@PostalCode,
		@ContactEmail,
		@ContactPhone
	)
	
	if (@@ROWCOUNT != 1)
		return 0
		
	SET NOCOUNT ON
	
	SELECT EndiciaShipperID, [RowVersion]
		FROM EndiciaShippers
		WHERE EndiciaShipperID = SCOPE_IDENTITY()
		
	RETURN 1
GO
		
----------------------------
--- PROCEDURE UpdateEndiciaShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateEndiciaShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateEndiciaShipper]
GO

CREATE PROCEDURE dbo.UpdateEndiciaShipper
(
	@EndiciaShipperID int,
	@RowVersion timestamp,
	@Company nvarchar(35),
	@ContactName nvarchar(35),
	@Address1 nvarchar(60),
	@Address2 nvarchar(60),
	@Address3 nvarchar(60),
	@City nvarchar(50),
	@StateProvinceCode nvarchar(5),
	@PostalCode nvarchar(10),
	@ContactEmail nvarchar(35),
	@ContactPhone nvarchar(25)
)
WITH ENCRYPTION
AS 
	UPDATE EndiciaShippers
		SET
			Company = @Company,
			ContactName = @ContactName,
			Address1 = @Address1,
			Address2 = @Address2,
			Address3 = @Address3,
			City = @City,
			StateProvinceCode = @StateProvinceCode,
			PostalCode = @PostalCode,
			ContactEmail = @ContactEmail,
			ContactPhone = @ContactPhone
		WHERE EndiciaShipperID = @EndiciaShipperID AND [RowVersion] = @RowVersion
		
	IF (@@ROWCOUNT != 1)
		RETURN 0
		
	SET NOCOUNT ON
	
	SELECT EndiciaShipperID, [RowVersion]
		FROM EndiciaShippers
		WHERE EndiciaShipperID = @EndiciaShipperID
		
	RETURN 1
GO

-----------------------------
--- Procedure DeleteEndiciaShipper
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteEndiciaShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteEndiciaShipper]
GO

CREATE PROCEDURE dbo.DeleteEndiciaShipper
(
	@EndiciaShipperID int
)
WITH ENCRYPTION
AS
	DELETE FROM EndiciaShippers
	WHERE EndiciaShipperID = @EndiciaShipperID
GO


----------------------------
--- PROCEDURE GetAllEndiciaShippers
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllEndiciaShippers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllEndiciaShippers]
GO

CREATE PROCEDURE dbo.GetAllEndiciaShippers 
WITH ENCRYPTION
AS
   SELECT *
   FROM EndiciaShippers
GO
