ALTER TABLE dbo.UspsShipments ADD
	LayoutPrinterOverride bit NOT NULL CONSTRAINT DF_UspsShipments_LayoutPrinterOverride DEFAULT 0,
	LayoutPrinterName varchar(350) NOT NULL CONSTRAINT DF_UspsShipments_LayoutPrinterName DEFAULT '',
	LayoutPaperSource smallint NOT NULL CONSTRAINT DF_UspsShipments_LayoutPaperSource DEFAULT 0,
	LayoutPaperSize smallint NOT NULL CONSTRAINT DF_UspsShipments_LayoutPaperSize DEFAULT 0,
	LayoutOffsetTop float NOT NULL CONSTRAINT DF_UspsShipments_LayoutOffsetTop DEFAULT 0.0,
	LayoutOffsetLeft float NOT NULL CONSTRAINT DF_UspsShipments_LayoutOffsetLeft DEFAULT 0.0,
	LayoutOrientation smallint NOT NULL CONSTRAINT DF_UspsShipments_LayoutOrientation DEFAULT 0,
	LayoutFacing smallint NOT NULL CONSTRAINT DF_UspsShipments_LayoutFacing DEFAULT 0,
	LayoutFeed smallint NOT NULL CONSTRAINT DF_UspsShipments_LayoutFeed DEFAULT 0,
	LayoutJustify smallint NOT NULL CONSTRAINT DF_UspsShipments_LayoutJustify DEFAULT 0,
	LayoutRotate bit NOT NULL CONSTRAINT DF_UspsShipments_LayoutRotate DEFAULT 0,
	LayoutCustomWidth float NOT NULL CONSTRAINT DF_UspsShipments_LayoutCustomWidth DEFAULT 0,
	LayoutCustomHeight float NOT NULL CONSTRAINT DF_UspsShipments_LayoutCustomHeight DEFAULT 0,
	SendReturnAddress bit NOT NULL CONSTRAINT DF_UspsShipments_SendReturnAddress DEFAULT 0,
	ShipFromCompany nvarchar(30) NOT NULL CONSTRAINT DF_UspsShipments_ShipFromCompany DEFAULT '',
	ShipFromContactName nvarchar(30) NOT NULL CONSTRAINT DF_UspsShipments_ShipFromContactName DEFAULT '',
	ShipFromAddress1 nvarchar(60) NOT NULL CONSTRAINT DF_UspsShipments_ShipFromAddress1 DEFAULT '',
	ShipFromAddress2 nvarchar(60) NOT NULL CONSTRAINT DF_UspsShipments_ShipFromAddress2 DEFAULT '',
	ShipFromAddress3 nvarchar(60) NOT NULL CONSTRAINT DF_UspsShipments_ShipFromAddress3 DEFAULT '',
	ShipFromCity nvarchar(50) NOT NULL CONSTRAINT DF_UspsShipments_ShipFromCity DEFAULT '',
	ShipFromStateProvinceCode nvarchar(5) NOT NULL CONSTRAINT DF_UspsShipments_ShipFromStateProvinceCode DEFAULT '',
	ShipFromPostalCode nvarchar(10) NOT NULL CONSTRAINT DF_UspsShipments_ShipFromPostalCode DEFAULT '',
	ShipFromEndiciaShipperID int NOT NULL CONSTRAINT DF_UspsShipments_ShipFromEndiciaShipperID DEFAULT 0,
	LayoutUseConcatBarcode bit NOT NULL CONSTRAINT DF_UspsShipments_LayoutUseConcatBarcode DEFAULT 0,
	LayoutBarcodeX float NOT NULL CONSTRAINT DF_UspsShipments_LayoutBarcodeX DEFAULT 0,
	LayoutBarcodeY float NOT NULL CONSTRAINT DF_UspsShipments_LayoutBarcodeY DEFAULT 0
GO

ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutPrinterOverride
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutPrinterName
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutPaperSource
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutPaperSize
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutOffsetTop
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutOffsetLeft
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutOrientation
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutFacing
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutFeed
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutJustify
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutRotate
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutCustomWidth
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutCustomHeight
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_SendReturnAddress
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromCompany
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromContactName
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromAddress1
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromAddress2
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromAddress3
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromCity
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromStateProvinceCode
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromPostalCode
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_ShipFromEndiciaShipperID
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutUseConcatBarcode
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutBarcodeX
GO
ALTER TABLE dbo.UspsShipments DROP CONSTRAINT DF_UspsShipments_LayoutBarcodeY
GO

-----------------------------
--- Procedure GetOrderUspsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsShipments]
GO

CREATE PROCEDURE dbo.GetOrderUspsShipments
(
    @OrderID int
)
WITH ENCRYPTION
AS
   SELECT u.*
   FROM UspsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerUspsShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsShipments]
GO

CREATE PROCEDURE dbo.GetCustomerUspsShipments
(
    @CustomerID int
)
WITH ENCRYPTION
AS
   SELECT u.*
   FROM UspsShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderUspsShipmentRange]
GO

CREATE PROCEDURE dbo.GetOrderUspsShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerUspsShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerUspsShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerUspsShipmentRange]
GO

CREATE PROCEDURE dbo.GetCustomerUspsShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
WITH ENCRYPTION
AS
   SELECT u.*
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure UpdateUspsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUspsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUspsShipment]
GO

CREATE PROCEDURE dbo.UpdateUspsShipment
(
    @ShipmentID int,
    @RowVersion timestamp,
    @PackagingType int,
	@ServiceType int ,
	@ConfirmationType int ,
	@AddressService bit  ,
	@SendEmail bit ,
	@LabelImageFull nvarchar (350) ,
	@LabelImageLabel nvarchar (350),
	@LabelImageBarcode nvarchar (350) ,
    @Stealth bit ,
    @SpecifyLayout bit,
    @Layout nvarchar (350) ,
    @DeclaredValue money ,
    @InsuranceType int,
    @Oversize bit,
    @NonMachinable bit,
    @Width float,
    @Length float,
    @Depth float,
    @ReferenceID varchar(200),
	@RubberStamp1 varchar (200) ,
	@RubberStamp2 varchar (200) ,
	@RubberStamp3 varchar (200) ,
	@RubberStamp4 varchar (200) ,
	@CustomsForm int ,
	@CustomsDescription nvarchar (200) ,
	@CustomsContentType int,
	@TrackingIsCustomsNumber bit,
	@LayoutPrinterOverride bit,
	@LayoutPrinterName varchar(350),
	@LayoutPaperSource smallint,
	@LayoutPaperSize smallint,
	@LayoutOffsetTop float,
	@LayoutOffsetLeft float,
	@LayoutOrientation smallint,
	@LayoutFacing smallint,
	@LayoutFeed smallint,
	@LayoutJustify smallint,
	@LayoutRotate bit,
	@LayoutCustomWidth float,
	@LayoutCustomHeight float,
	@SendReturnAddress bit,
	@ShipFromCompany nvarchar(30),
	@ShipFromContactName nvarchar(30),
	@ShipFromAddress1 nvarchar(60),
	@ShipFromAddress2 nvarchar(60),
	@ShipFromAddress3 nvarchar(60),
	@ShipFromCity nvarchar(50),
	@ShipFromStateProvinceCode nvarchar(5),
	@ShipFromPostalCode nvarchar(10),
	@ShipFromEndiciaShipperID int,
	@LayoutUseConcatBarcode bit,
	@LayoutBarcodeX float,
	@LayoutBarcodeY float
)
WITH ENCRYPTION
AS
    UPDATE [UspsShipments]
    SET PackagingType = @PackagingType,
        ServiceType = @ServiceType,
	    ConfirmationType = @ConfirmationType,
	    AddressService = @AddressService,
	    SendEmail = @SendEmail,
	    LabelImageFull = @LabelImageFull,
	    LabelImageLabel = @LabelImageLabel,
	    LabelImageBarcode = @LabelImageBarcode,
		Stealth = @Stealth,
		SpecifyLayout = @SpecifyLayout,
		Layout = @Layout,
		DeclaredValue = @DeclaredValue,
		InsuranceType = @InsuranceType,
		Oversize = @Oversize,
		NonMachinable = @NonMachinable,
		Width = @Width,
		Length = @Length,
		Depth = @Depth,
		ReferenceID = @ReferenceID,
		RubberStamp1 = @RubberStamp1,
		RubberStamp2 = @RubberStamp2,
		RubberStamp3 = @RubberStamp3,
		RubberStamp4 = @RubberStamp4,
		CustomsForm = @CustomsForm,
		CustomsDescription = @CustomsDescription,
		CustomsContentType = @CustomsContentType,
		TrackingIsCustomsNumber = @TrackingIsCustomsNumber,
		LayoutPrinterOverride = @LayoutPrinterOverride,
		LayoutPrinterName = @LayoutPrinterName,
		LayoutPaperSource = @LayoutPaperSource,
		LayoutPaperSize = @LayoutPaperSize,
		LayoutOffsetTop = @LayoutOffsetTop,
		LayoutOffsetLeft = @LayoutOffsetLeft,
		LayoutOrientation = @LayoutOrientation,
		LayoutFacing = @LayoutFacing,
		LayoutFeed = @LayoutFeed,
		LayoutJustify = @LayoutJustify,
		LayoutRotate = @LayoutRotate,
		LayoutCustomWidth = @LayoutCustomWidth,
		LayoutCustomHeight = @LayoutCustomHeight,
		SendReturnAddress = @SendReturnAddress,
		ShipFromCompany = @ShipFromCompany,
		ShipFromContactName = @ShipFromContactName,
		ShipFromAddress1 = @ShipFromAddress1,
		ShipFromAddress2 = @ShipFromAddress2,
		ShipFromAddress3 = @ShipFromAddress3,
		ShipFromCity = @ShipFromCity,
		ShipFromStateProvinceCode = @ShipFromStateProvinceCode,
		ShipFromPostalCode = @ShipFromPostalCode,
		ShipFromEndiciaShipperID = @ShipFromEndiciaShipperID,
		LayoutUseConcatBarcode = @LayoutUseConcatBarcode,
		LayoutBarcodeX = @LayoutBarcodeX,
		LayoutBarcodeY = @LayoutBarcodeY
    WHERE ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM UspsShipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

-----------------------------
--- Procedure AddUspsShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUspsShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUspsShipment]
GO

CREATE PROCEDURE dbo.AddUspsShipment
(
    @ShipmentID int,
    @PackagingType int,
	@ServiceType int ,
	@ConfirmationType int ,
	@AddressService bit  ,
	@SendEmail bit ,
	@LabelImageFull nvarchar (350) ,
	@LabelImageLabel nvarchar (350),
	@LabelImageBarcode nvarchar (350) ,
    @Stealth bit ,
    @SpecifyLayout bit,
    @Layout nvarchar (350) ,
    @DeclaredValue money ,
    @InsuranceType int,
    @Oversize bit,
    @NonMachinable bit,
    @Width float,
    @Length float,
    @Depth float,
    @ReferenceID varchar(200),
	@RubberStamp1 varchar (200) ,
	@RubberStamp2 varchar (200) ,
	@RubberStamp3 varchar (200) ,
	@RubberStamp4 varchar (200) ,
	@CustomsForm int ,
	@CustomsDescription nvarchar (200) ,
	@CustomsContentType int,
	@TrackingIsCustomsNumber bit,
	@LayoutPrinterOverride bit,
	@LayoutPrinterName varchar(350),
	@LayoutPaperSource smallint,
	@LayoutPaperSize smallint,
	@LayoutOffsetTop float,
	@LayoutOffsetLeft float,
	@LayoutOrientation smallint,
	@LayoutFacing smallint,
	@LayoutFeed smallint,
	@LayoutJustify smallint,
	@LayoutRotate bit,
	@LayoutCustomWidth float,
	@LayoutCustomHeight float,
	@SendReturnAddress bit,
	@ShipFromCompany nvarchar(30),
	@ShipFromContactName nvarchar(30),
	@ShipFromAddress1 nvarchar(60),
	@ShipFromAddress2 nvarchar(60),
	@ShipFromAddress3 nvarchar(60),
	@ShipFromCity nvarchar(50),
	@ShipFromStateProvinceCode nvarchar(5),
	@ShipFromPostalCode nvarchar(10),
	@ShipFromEndiciaShipperID int,
	@LayoutUseConcatBarcode bit,
	@LayoutBarcodeX float,
	@LayoutBarcodeY float
)
WITH ENCRYPTION
AS
    if (exists(SELECT * FROM UspsShipments WHERE ShipmentID = @ShipmentID))
    begin
    
        select * from UspsShipments WHERE ShipmentID = @ShipmentID
        
    end
    else
    begin
    
        INSERT INTO [UspsShipments]
        (
            ShipmentID,
            PackagingType,
            ServiceType,
	        ConfirmationType,
	        AddressService,
	        SendEmail,
	        LabelImageFull,
	        LabelImageLabel,
	        LabelImageBarcode,
			Stealth,
			SpecifyLayout,
			Layout,
			DeclaredValue,
			InsuranceType,
			Oversize,
			NonMachinable,
			Width,
			Length,
			Depth,
			ReferenceID,
			RubberStamp1,
			RubberStamp2,
			RubberStamp3,
			RubberStamp4,
			CustomsForm,
			CustomsDescription,
			CustomsContentType,
			TrackingIsCustomsNumber,
			LayoutPrinterOverride,
			LayoutPrinterName,
			LayoutPaperSource,
			LayoutPaperSize,
			LayoutOffsetTop,
			LayoutOffsetLeft,
			LayoutOrientation,
			LayoutFacing,
			LayoutFeed,
			LayoutJustify,
			LayoutRotate,
			LayoutCustomWidth,
			LayoutCustomHeight,
			SendReturnAddress,
			ShipFromCompany,
			ShipFromContactName,
			ShipFromAddress1,
			ShipFromAddress2,
			ShipFromAddress3,
			ShipFromCity,
			ShipFromStateProvinceCode,
			ShipFromPostalCode,
			ShipFromEndiciaShipperID,
			LayoutUseConcatBarcode,
			LayoutBarcodeX,
			LayoutBarcodeY
        )
        VALUES
        (
            @ShipmentID,
            @PackagingType,
            @ServiceType,
	        @ConfirmationType,
	        @AddressService,
	        @SendEmail,
	        @LabelImageFull,
	        @LabelImageLabel,
	        @LabelImageBarcode,
			@Stealth,
			@SpecifyLayout,
			@Layout,
			@DeclaredValue,
			@InsuranceType,
			@Oversize,
			@NonMachinable,
			@Width,
			@Length,
			@Depth,
			@ReferenceID,
			@RubberStamp1,
			@RubberStamp2,
			@RubberStamp3,
			@RubberStamp4,
			@CustomsForm,
			@CustomsDescription,
			@CustomsContentType,
			@TrackingIsCustomsNumber,
			@LayoutPrinterOverride,
			@LayoutPrinterName,
			@LayoutPaperSource,
			@LayoutPaperSize,
			@LayoutOffsetTop,
			@LayoutOffsetLeft,
			@LayoutOrientation,
			@LayoutFacing,
			@LayoutFeed,
			@LayoutJustify,
			@LayoutRotate,
			@LayoutCustomWidth,
			@LayoutCustomHeight,
			@SendReturnAddress,
			@ShipFromCompany,
			@ShipFromContactName,
			@ShipFromAddress1,
			@ShipFromAddress2,
			@ShipFromAddress3,
			@ShipFromCity,
			@ShipFromStateProvinceCode,
			@ShipFromPostalCode,
			@ShipFromEndiciaShipperID,
			@LayoutUseConcatBarcode,
			@LayoutBarcodeX,
			@LayoutBarcodeY
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ShipmentID, [RowVersion]
        FROM UspsShipments
        WHERE ShipmentID = @ShipmentID

        return 1
                
  end
    
GO