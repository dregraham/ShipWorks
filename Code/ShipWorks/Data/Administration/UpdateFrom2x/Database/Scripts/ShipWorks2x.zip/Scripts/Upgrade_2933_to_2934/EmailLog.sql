----------------------------
--- PROCEDURE GetCustomersEmailLogs
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'dbo.GetCustomersEmailLogs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure GetCustomersEmailLogs
GO

CREATE PROCEDURE dbo.GetCustomersEmailLogs
(
   @StoreID int,
   @DateRangeMax datetime,
   @DateRangeMin datetime
)
WITH ENCRYPTION
AS
      SELECT DISTINCT e.*, '-' as OrderNumberDisplay, c.BillLastName + ', ' + c.BillFirstName as CustomerDisplay
        FROM EmailLog e, Shipments s, Customers c
        WHERE 
			s.StoreID = @StoreID AND
			s.ProcessedDate >= @DateRangeMin AND s.ProcessedDate <= @DateRangeMax AND
			s.Processed = 1 AND 			
			s.StoreID = e.StoreID AND							
			s.CustomerID = c.CustomerID AND
            e.CustomerID = c.CustomerID		 			 						  
GO