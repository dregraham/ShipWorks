-----------------------------
--- TABLE FedexShipments
-----------------------------
CREATE TABLE FedexShipments
(
	ShipmentID int NOT NULL ,
	[RowVersion] timestamp NOT NULL,
    ReferenceNumber nvarchar (50) NOT NULL ,
    ServiceType smallint NOT NULL ,
    Voided bit NOT NULL,
    ArrivalDate datetime NOT NULL,
    ShipToResidential bit NOT NULL,
    ShipFromShipperID int NOT NULL ,
	ShipFromContactName nvarchar (30) NOT NULL ,
	ShipFromCompany nvarchar (30) NOT NULL ,
	ShipFromAddress1 nvarchar (60) NOT NULL ,
	ShipFromAddress2 nvarchar (60) NOT NULL ,
	ShipFromCity nvarchar (50) NOT NULL ,
	ShipFromStateProvinceCode nvarchar (5) NOT NULL ,
	ShipFromPostalCode nvarchar (10) NOT NULL ,
	ShipFromCountryCode nvarchar (5) NOT NULL ,
    ShipFromContactEmail nvarchar (25) NOT NULL ,
	ShipFromContactPhone nvarchar (25) NOT NULL ,
	ShipFromContactFax nvarchar (25) NOT NULL ,
    CONSTRAINT [IX_FedexShipments_ShipmentID] UNIQUE NONCLUSTERED (ShipmentID),
	CONSTRAINT [FK_FedexShipments_Shipments] FOREIGN KEY ([ShipmentID]) REFERENCES [Shipments] ([ShipmentID]) 
)
GO

-----------------------------
--- Procedure GetOrderFedexShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderFedexShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderFedexShipments]
GO

CREATE PROCEDURE GetOrderFedexShipments
(
    @OrderID int
)
AS
   SELECT u.*
   FROM FedexShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerFedexShipments
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerFedexShipments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerFedexShipments]
GO

CREATE PROCEDURE GetCustomerFedexShipments
(
    @CustomerID int
)
AS
   SELECT u.*
   FROM FedexShipments u, Shipments s
   WHERE u.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderFedexShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderFedexShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderFedexShipmentRange]
GO

CREATE PROCEDURE GetOrderFedexShipmentRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT u.*
     FROM FedexShipments u, Shipments s, Orders o
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerFedexShipmentRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerFedexShipmentRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerFedexShipmentRange]
GO

CREATE PROCEDURE GetCustomerFedexShipmentRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT u.*
     FROM FedexShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure UpdateFedexShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFedexShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFedexShipment]
GO

CREATE PROCEDURE UpdateFedexShipment
(
    @ShipmentID int,
    @RowVersion timestamp ,
    @ReferenceNumber nvarchar (50)  ,
    @ServiceType nvarchar (10)  ,
    @Voided bit ,
    @ArrivalDate datetime ,
    @ShipToResidential bit ,
    @ShipFromShipperID int  ,
	@ShipFromContactName nvarchar (30)  ,
	@ShipFromCompany nvarchar (30)  ,
	@ShipFromAddress1 nvarchar (60)  ,
	@ShipFromAddress2 nvarchar (60)  ,
	@ShipFromCity nvarchar (50)  ,
	@ShipFromStateProvinceCode nvarchar (5)  ,
	@ShipFromPostalCode nvarchar (10)  ,
	@ShipFromCountryCode nvarchar (5)  ,
    @ShipFromContactEmail nvarchar (25)  ,
	@ShipFromContactPhone nvarchar (25)  ,
	@ShipFromContactFax nvarchar (25)
)
AS
    UPDATE [FedexShipments]
    SET 
        ReferenceNumber = @ReferenceNumber,
        ServiceType = @ServiceType,
        Voided = @Voided,
        ArrivalDate = @ArrivalDate,
        ShipToResidential = @ShipToResidential,
	    ShipFromShipperID = @ShipFromShipperID,
	    ShipFromContactName = @ShipFromContactName,
	    ShipFromCompany = @ShipFromCompany,
	    ShipFromAddress1 = @ShipFromAddress1,
	    ShipFromAddress2 = @ShipFromAddress2,
	    ShipFromCity = @ShipFromCity,
	    ShipFromStateProvinceCode = @ShipFromStateProvinceCode,
	    ShipFromPostalCode = @ShipFromPostalCode,
	    ShipFromCountryCode = @ShipFromCountryCode,
        ShipFromContactEmail = @ShipFromContactEmail,
	    ShipFromContactPhone = @ShipFromContactPhone,
	    ShipFromContactFax = @ShipFromContactFax
    WHERE ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM FedexShipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

-----------------------------
--- Procedure AddFedexShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFedexShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddFedexShipment]
GO

CREATE PROCEDURE AddFedexShipment
(
    @ShipmentID int,
    @ReferenceNumber nvarchar (50)  ,
    @ServiceType nvarchar (10)  ,
    @Voided bit ,
    @ArrivalDate datetime ,
    @ShipToResidential bit ,
    @ShipFromShipperID int  ,
	@ShipFromContactName nvarchar (30)  ,
	@ShipFromCompany nvarchar (30)  ,
	@ShipFromAddress1 nvarchar (60)  ,
	@ShipFromAddress2 nvarchar (60)  ,
	@ShipFromCity nvarchar (50)  ,
	@ShipFromStateProvinceCode nvarchar (5)  ,
	@ShipFromPostalCode nvarchar (10)  ,
	@ShipFromCountryCode nvarchar (5)  ,
    @ShipFromContactEmail nvarchar (25)  ,
	@ShipFromContactPhone nvarchar (25)  ,
	@ShipFromContactFax nvarchar (25)
)
AS
    if (exists(SELECT * FROM FedexShipments WHERE ShipmentID = @ShipmentID))
    begin
    
        select * from FedexShipments WHERE ShipmentID = @ShipmentID
        
    end
    else
    begin
        INSERT INTO [FedexShipments]
        (
	        ShipmentID,
            ReferenceNumber,
            ServiceType,
            Voided,
            ArrivalDate,
            ShipToResidential,
            ShipFromShipperID,
	        ShipFromContactName,
	        ShipFromCompany,
	        ShipFromAddress1,
	        ShipFromAddress2,
	        ShipFromCity,
	        ShipFromStateProvinceCode,
	        ShipFromPostalCode,
	        ShipFromCountryCode,
            ShipFromContactEmail ,
	        ShipFromContactPhone,
	        ShipFromContactFax
        )
        VALUES
        (
	        @ShipmentID,
            @ReferenceNumber,
            @ServiceType,
            @Voided,
            @ArrivalDate,
            @ShipToResidential,
            @ShipFromShipperID,
	        @ShipFromContactName,
	        @ShipFromCompany,
	        @ShipFromAddress1,
	        @ShipFromAddress2,
	        @ShipFromCity,
	        @ShipFromStateProvinceCode,
	        @ShipFromPostalCode,
	        @ShipFromCountryCode,
            @ShipFromContactEmail ,
	        @ShipFromContactPhone,
	        @ShipFromContactFax
        )
            
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT ShipmentID, RowVersion
        FROM FedexShipments
        WHERE ShipmentID = @ShipmentID

        return 1   
  end
  
GO