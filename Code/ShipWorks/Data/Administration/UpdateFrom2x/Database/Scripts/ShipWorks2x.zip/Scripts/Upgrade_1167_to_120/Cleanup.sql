-----------------------------
--- Drop
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[FedexClosings]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
   drop table FedexClosings
GO

-----------------------------
--- Drop
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[FedexPreferences]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
   drop table FedexPreferences
GO

-----------------------------
--- Drop
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[FedexPackages]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
   drop table FedexPackages
GO


-----------------------------
--- Drop
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[FedexShipments]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
   drop table FedexShipments
GO

-----------------------------
--- Drop
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[FedexShippers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
   drop table [FedexShippers]
GO
