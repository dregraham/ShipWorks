UPDATE UpsPreferences
  SET PackageReferenceNumber = '{//Reference}'
  WHERE PackageReferenceNumber = 'Order Sw_OrderNumber'

UPDATE UpsPreferences
  SET ShipmentReferenceNumber = '{//Reference}'
  WHERE ShipmentReferenceNumber = 'Order Sw_OrderNumber'
GO
