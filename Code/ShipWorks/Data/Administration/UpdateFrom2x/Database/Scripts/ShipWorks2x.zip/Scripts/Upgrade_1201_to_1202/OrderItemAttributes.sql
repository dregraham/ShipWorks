-----------------------------
--- Procedure SynchMivaItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaItemAttribute]
GO

CREATE PROCEDURE dbo.SynchMivaItemAttribute
(
	@OrderItemID int,
	@Code nvarchar (300),
	@Name nvarchar (300),
	@Description nvarchar (1500),
	@UnitPrice money,
	@MivaAttributeID int,
	@MivaOptionCode nvarchar (300)
)
AS
   
    -- If this Miva item attribute already exists, we dont do anything
    if exists (
        SELECT * 
        FROM OrderItemAttributes a
        WHERE a.MivaAttributeID = @MivaAttributeID AND
              a.Code = @Code AND 
              a.OrderItemID = @OrderItemID)
    begin
    
        -- This just lets the .NET data provider know everything is OK
        SELECT AttributeID, [RowVersion]
        FROM OrderItemAttributes a
        WHERE a.MivaAttributeID = @MivaAttributeID AND
              a.Code = @Code AND
              a.OrderItemID = @OrderItemID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItemAttributes]
        (
	        [OrderItemID],
	        [Code],
	        [Name],
	        [Description],
	        [UnitPrice],
	        [MivaAttributeID],
	        [MivaOptionCode]
        )
        VALUES
        (
	        @OrderItemID,
	        @Code,
	        @Name,
	        @Description,
	        @UnitPrice,
	        @MivaAttributeID,
	        @MivaOptionCode
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT AttributeID, [RowVersion]
        FROM OrderItemAttributes
        WHERE AttributeID = SCOPE_IDENTITY()

        return 1
    end
GO
