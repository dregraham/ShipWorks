-----------------------------
--- TABLE Customers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[Customers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
   drop table [Customers]
GO

CREATE TABLE [Customers] 
(
	[CustomerID] [int] IDENTITY (1, 1) NOT NULL ,
	[RowVersion] [timestamp] NOT NULL ,
	[StoreID] [int] NOT NULL ,
	[ShipEmail] [nvarchar] (50) NOT NULL ,
	[ShipFirstName] [nvarchar] (30) NOT NULL ,
	[ShipLastName] [nvarchar] (30) NOT NULL ,
	[ShipCompany] [nvarchar] (30) NOT NULL ,
	[ShipAddress1] [nvarchar] (60) NOT NULL ,
	[ShipAddress2] [nvarchar] (60) NOT NULL ,
	[ShipAddress3] [nvarchar] (60) NOT NULL ,
	[ShipCity] [nvarchar] (50) NOT NULL ,
	[ShipStateProvinceCode] [nvarchar] (25) NOT NULL ,
	[ShipPostalCode] [nvarchar] (10) NOT NULL ,
	[ShipCountryCode] [nvarchar] (5) NOT NULL ,
	[ShipPhone] [nvarchar] (25) NOT NULL ,
	[ShipFax] [nvarchar] (25) NOT NULL ,
	[BillEmail] [nvarchar] (50) NOT NULL ,
	[BillFirstName] [nvarchar] (30) NOT NULL ,
	[BillLastName] [nvarchar] (30) NOT NULL ,
	[BillCompany] [nvarchar] (30) NOT NULL ,
	[BillAddress1] [nvarchar] (60) NOT NULL ,
	[BillAddress2] [nvarchar] (60) NOT NULL ,
	[BillAddress3] [nvarchar] (60) NOT NULL ,
	[BillCity] [nvarchar] (50) NOT NULL ,
	[BillStateProvinceCode] [nvarchar] (25) NOT NULL ,
	[BillPostalCode] [nvarchar] (10) NOT NULL ,
	[BillCountryCode] [nvarchar] (5) NOT NULL ,
	[BillPhone] [nvarchar] (25) NOT NULL ,
	[BillFax] [nvarchar] (25) NOT NULL ,
	[Notes] ntext NOT NULL ,
	[eBayBuyerID] [nvarchar] (50) NOT NULL ,
	[AddressHash] AS BillFirstName + BillLastName + BillAddress1 + BillAddress2 + BillPostalCode,
    tempOrderID int NOT NULL,
    tempOrderDate datetime NOT NULL,
	CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED ([CustomerID]),
	CONSTRAINT [FK_Customers_Stores] FOREIGN KEY ([StoreID]) REFERENCES [Stores] ([StoreID])
)
GO

-- For eBay we were not tracking billing address.  Now, copy all shipping address info
-- to billing address where there was no billing address before.
-- Only do this if there are any orders, due to a bug in the Orders trigger, that has
-- not yet been updated at this point in the upgrade.
if ((SELECT COUNT(*) FROM Orders WHERE BillEmail = '' AND BillAddress1 = '' AND BillLastName = '') > 0)
begin
    UPDATE Orders
    SET 
        BillFirstName = ShipFirstName,
        BillLastName = ShipLastName,
        BillCompany = ShipCompany,
        BillAddress1 = ShipAddress1,
        BillAddress2 = ShipAddress2,
        BillAddress3 = ShipAddress3,
        BillCity = ShipCity,
        BillStateProvinceCode = ShipStateProvinceCode,
        BillPostalCode = ShipPostalCode,
        BillCountryCode = ShipCountryCode,
        BillEmail = ShipEmail,
        BillPhone = ShipPhone,
        BillFax = ShipFax
    WHERE BillEmail = '' AND BillAddress1 = '' AND BillLastName = ''
end
GO

-- Add each order as a customer
INSERT INTO Customers 
(
    StoreID, 
    ShipEmail,     
    ShipFirstName,     
    ShipLastName,     
    ShipCompany,     
    ShipAddress1,     
    ShipAddress2,     
    ShipAddress3,     
    ShipCity,     
    ShipStateProvinceCode,     
    ShipPostalCode,     
    ShipCountryCode,     
    ShipPhone,     
    ShipFax,     
    BillEmail,     
    BillFirstName,     
    BillLastName,     
    BillCompany,     
    BillAddress1,     
    BillAddress2,     
    BillAddress3,     
    BillCity,     
    BillStateProvinceCode,     
    BillPostalCode,     
    BillCountryCode,     
    BillPhone,     
    BillFax,     
    Notes, 
    eBayBuyerID,
    tempOrderID, 
    tempOrderDate
)
SELECT 
    StoreID, 
    ShipEmail,     
    ShipFirstName,     
    ShipLastName,     
    ShipCompany,     
    ShipAddress1,     
    ShipAddress2,     
    ShipAddress3,     
    ShipCity,     
    ShipStateProvinceCode,     
    ShipPostalCode,     
    ShipCountryCode,     
    ShipPhone,     
    ShipFax,    
    BillEmail, 
    BillFirstName, 
    BillLastName, 
    BillCompany, 
    BillAddress1, 
    BillAddress2, 
    BillAddress3, 
    BillCity, 
    BillStateProvinceCode, 
    BillPostalCode, 
    BillCountryCode, 
    BillPhone, 
    BillFax, 
    '',    
    eBayBuyerID,
    OrderID, 
    OrderDate
 FROM Orders
GO

-- Create the index on BillEmail, which we use to lookup customers
CREATE INDEX IX_Customers_BillEmail
  ON Customers(BillEmail)

-- Create the index on the AddressHash column
CREATE INDEX IX_Customers_AddressHash
  ON Customers(AddressHash)
  
-- Drop the orders trigger
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_Orders]'))
   DROP TRIGGER TG_Orders
GO

-- Update the Orders table to have the initial customer ids
UPDATE Orders
  SET CustomerID = c.CustomerID
  FROM Customers c
  WHERE OrderID = c.tempOrderID
GO

---------------------------------------------------------------
-- Remove all duplicate customers, based on email and\or address matching
-- and update orders as we go
-----------------------------------------------------------------
DECLARE custCursor CURSOR LOCAL FORWARD_ONLY STATIC READ_ONLY
FOR SELECT c1.CustomerID, c1.tempOrderID, c3.tempOrderID 
     FROM Customers c1, Customers c3
     WHERE c1.StoreID = c3.StoreID AND
           c1.tempOrderID < 
              (SELECT MAX(c2.tempOrderID)
                  FROM Customers c2
                  WHERE c1.StoreID = c2.StoreID AND
                       (
                        (c1.BillEmail != '' AND c2.BillEmail = c1.BillEmail)
                          OR
                        (c1.AddressHash != '' and c1.AddressHash = c2.AddressHash) 
                       )
              )
           AND
           c3.tempOrderID = 
              (SELECT MAX(c2.tempOrderID)
                  FROM Customers c2
                  WHERE c1.StoreID = c2.StoreID AND
                       (
                        (c1.BillEmail != '' AND c2.BillEmail = c1.BillEmail)
                          OR
                        (c1.AddressHash != '' and c1.AddressHash = c2.AddressHash) 
                       )
              )
     ORDER BY c1.tempOrderID DESC

OPEN custCursor

DECLARE @CustomerID int
DECLARE @tempCurrentOrderID int
DECLARE @tempLatestOrderID int

FETCH NEXT FROM custCursor INTO @CustomerID, @tempCurrentOrderID, @tempLatestOrderID

WHILE @@FETCH_STATUS = 0
BEGIN
    
    DECLARE @custID int
    SELECT @custID = CustomerID
      FROM Orders
      WHERE OrderID = @tempLatestOrderID

    update orders
      set customerid = @custID
      where OrderID = @tempCurrentOrderID

    delete customers
      where CustomerID = @CustomerID

    FETCH NEXT FROM custCursor INTO @CustomerID, @tempCurrentOrderID, @tempLatestOrderID
END

CLOSE custCursor
DEALLOCATE custCursor

GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_Customers]'))
    drop trigger [dbo].[TG_Customers]
GO

-- Delete unused columns
ALTER TABLE Customers DROP COLUMN tempOrderID
ALTER TABLE Customers DROP COLUMN tempOrderDate
GO

-- Now we can add the customer constraint to the orders table
ALTER TABLE Orders
  ADD CONSTRAINT [FK_Orders_Customers] FOREIGN KEY ([CustomerID]) REFERENCES [Customers] ([CustomerID])
GO

-- Recreate the orders trigger
CREATE TRIGGER TG_Orders ON Orders FOR UPDATE
AS
    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID FROM inserted
       
    EXEC SetTableLastDbts 'Orders', @StoreID, @@DBTS
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TG_Customers]'))
    drop trigger [dbo].[TG_Customers]
GO

-- Create trigger to track changes to customers, and insures email address uniqueness
CREATE TRIGGER TG_Customers ON Customers FOR UPDATE, INSERT
AS
    if ( (SELECT COUNT(*) FROM inserted) = 0)
       return;
       
    DECLARE @StoreID int
    
    SELECT TOP 1 @StoreID = StoreID
        FROM inserted
        
    DECLARE @uniqueCount int
    DECLARE @totalCount int
    
    SELECT @uniqueCount = Count(DISTINCT BillEmail), @totalCount = Count(BillEmail)
      FROM Customers
      WHERE BillEmail != '' AND StoreID = @StoreID
            
    if (@uniqueCount != @totalCount)
    BEGIN
         RAISERROR ('Non-blank customer email addresses must be unique.', 16, 1)
         ROLLBACK TRANSACTION
         return
    END 

    EXEC SetTableLastDbts 'Customers', @StoreID, @@DBTS
GO

-----------------------------
--- Procedure AddCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddCustomer]
GO

CREATE PROCEDURE AddCustomer
(
    @StoreID int,
    @ShipEmail nvarchar (50),
    @ShipFirstName nvarchar (30),
    @ShipLastName nvarchar (30),
    @ShipCompany nvarchar (30),
    @ShipAddress1 nvarchar (60),
    @ShipAddress2 nvarchar (60),
    @ShipAddress3 nvarchar (60),
    @ShipCity nvarchar (50),
    @ShipStateProvinceCode nvarchar (25),
    @ShipPostalCode nvarchar (10),
    @ShipCountryCode nvarchar (5),
    @ShipPhone nvarchar (25),
    @ShipFax nvarchar (25),
    @BillEmail nvarchar (50),
    @BillFirstName nvarchar (30),
    @BillLastName nvarchar (30),
    @BillCompany nvarchar (30),
    @BillAddress1 nvarchar (60),
    @BillAddress2 nvarchar (60),
    @BillAddress3 nvarchar (60),
    @BillCity nvarchar (50),
    @BillStateProvinceCode nvarchar (25),
    @BillPostalCode nvarchar (10),
    @BillCountryCode nvarchar (5),
    @BillPhone nvarchar (25),
    @BillFax nvarchar (25),
    @Notes ntext,
    @eBayBuyerID nvarchar (50)
)
AS
    -- Add each order as a customer
    INSERT INTO Customers 
    (
        StoreID, 
        ShipEmail,     
        ShipFirstName,     
        ShipLastName,     
        ShipCompany,     
        ShipAddress1,     
        ShipAddress2,     
        ShipAddress3,     
        ShipCity,     
        ShipStateProvinceCode,     
        ShipPostalCode,     
        ShipCountryCode,     
        ShipPhone,     
        ShipFax,     
        BillEmail,     
        BillFirstName,     
        BillLastName,     
        BillCompany,     
        BillAddress1,     
        BillAddress2,     
        BillAddress3,     
        BillCity,     
        BillStateProvinceCode,     
        BillPostalCode,     
        BillCountryCode,     
        BillPhone,     
        BillFax,     
        Notes, 
        eBayBuyerID
    )
    VALUES
    ( 
        @StoreID, 
        @ShipEmail,     
        @ShipFirstName,     
        @ShipLastName,     
        @ShipCompany,     
        @ShipAddress1,     
        @ShipAddress2,     
        @ShipAddress3,     
        @ShipCity,     
        @ShipStateProvinceCode,     
        @ShipPostalCode,     
        @ShipCountryCode,     
        @ShipPhone,     
        @ShipFax,     
        @BillEmail,     
        @BillFirstName,     
        @BillLastName,     
        @BillCompany,     
        @BillAddress1,     
        @BillAddress2,     
        @BillAddress3,     
        @BillCity,     
        @BillStateProvinceCode,     
        @BillPostalCode,     
        @BillCountryCode,     
        @BillPhone,     
        @BillFax,     
        @Notes, 
        @eBayBuyerID
    )
    
    SELECT 
        CustomerID, 
        [RowVersion],         
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = Customers.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = Customers.CustomerID), 0.00) AS TotalAmount
    FROM Customers
    WHERE CustomerID = SCOPE_IDENTITY()

GO

-----------------------------
--- Procedure UpdateCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateCustomer]
GO

CREATE PROCEDURE UpdateCustomer
(
    @CustomerID int,
    @RowVersion timestamp,
    @StoreID int,
    @ShipEmail nvarchar (50),
    @ShipFirstName nvarchar (30),
    @ShipLastName nvarchar (30),
    @ShipCompany nvarchar (30),
    @ShipAddress1 nvarchar (60),
    @ShipAddress2 nvarchar (60),
    @ShipAddress3 nvarchar (60),
    @ShipCity nvarchar (50),
    @ShipStateProvinceCode nvarchar (25),
    @ShipPostalCode nvarchar (10),
    @ShipCountryCode nvarchar (5),
    @ShipPhone nvarchar (25),
    @ShipFax nvarchar (25),
    @BillEmail nvarchar (50),
    @BillFirstName nvarchar (30),
    @BillLastName nvarchar (30),
    @BillCompany nvarchar (30),
    @BillAddress1 nvarchar (60),
    @BillAddress2 nvarchar (60),
    @BillAddress3 nvarchar (60),
    @BillCity nvarchar (50),
    @BillStateProvinceCode nvarchar (25),
    @BillPostalCode nvarchar (10),
    @BillCountryCode nvarchar (5),
    @BillPhone nvarchar (25),
    @BillFax nvarchar (25),
    @Notes ntext,
    @eBayBuyerID nvarchar (50)
)
AS
    UPDATE Customers
    SET
        StoreID = @StoreID, 
        ShipEmail = @ShipEmail,     
        ShipFirstName = @ShipFirstName,
        ShipLastName = @ShipLastName,
        ShipCompany = @ShipCompany,
        ShipAddress1 = @ShipAddress1,
        ShipAddress2 = @ShipAddress2,
        ShipAddress3 = @ShipAddress3,
        ShipCity = @ShipCity,
        ShipStateProvinceCode = @ShipStateProvinceCode,
        ShipPostalCode = @ShipPostalCode,
        ShipCountryCode = @ShipCountryCode,
        ShipPhone = @ShipPhone,
        ShipFax = @ShipFax,
        BillEmail = @BillEmail,
        BillFirstName = @BillFirstName,
        BillLastName = @BillLastName,
        BillCompany = @BillCompany,
        BillAddress1 = @BillAddress1,
        BillAddress2 = @BillAddress2,
        BillAddress3 = @BillAddress3,
        BillCity = @BillCity,
        BillStateProvinceCode = @BillStateProvinceCode,
        BillPostalCode = @BillPostalCode,
        BillCountryCode = @BillCountryCode,
        BillPhone = @BillPhone,
        BillFax = @BillFax,
        Notes = @Notes, 
        eBayBuyerID = @eBayBuyerID
    WHERE CustomerID = @CustomerID AND [RowVersion] = @RowVersion
    
    SELECT 
        CustomerID, 
        [RowVersion],         
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = Customers.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = Customers.CustomerID), 0.00) AS TotalAmount
    FROM Customers
    WHERE CustomerID = @CustomerID
    
GO

-----------------------------
--- Procedure DoesCustomerExist
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DoesCustomerExist]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DoesCustomerExist]
GO

CREATE PROCEDURE DoesCustomerExist
(
    @CustomerID int
)
AS
   if exists (SELECT * FROM [Customers] WHERE CustomerID = @CustomerID)
      SELECT 1
   else
      SELECT 0
GO

-----------------------------
--- Procedure GetLatestCustomers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLatestCustomers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetLatestCustomers]
GO

CREATE PROCEDURE GetLatestCustomers
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT   
        CustomerID,
        [RowVersion],  
        StoreID, 
        ShipEmail,
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1,
        ShipAddress2,
        ShipAddress3,
        ShipCity,
        ShipStateProvinceCode,
        ShipPostalCode,
        ShipCountryCode,
        ShipPhone,
        ShipFax,
        BillEmail,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1,
        BillAddress2,
        BillAddress3,
        BillCity,
        BillStateProvinceCode,
        BillPostalCode,
        BillCountryCode,
        BillPhone, 
        BillFax,
        Notes, 
        eBayBuyerID,
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = Customers.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = Customers.CustomerID), 0.00) AS TotalAmount
     FROM Customers
     WHERE 
       StoreID = @StoreID AND 
       CustomerID > @MinCustomerID
GO

-----------------------------
--- Procedure GetLatestCustomersCount
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLatestCustomersCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetLatestCustomersCount]
GO

CREATE PROCEDURE GetLatestCustomersCount
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT Count(*)
     FROM Customers
     WHERE 
       StoreID = @StoreID AND 
       CustomerID > @MinCustomerID
GO

-----------------------------
--- Procedure GetCustomerOrders
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerOrders]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerOrders]
GO

CREATE PROCEDURE GetCustomerOrders
(
    @CustomerID int
)
AS
   SELECT *
   FROM [Orders]
   WHERE CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetChangedCustomers
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangedCustomers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetChangedCustomers]
GO

CREATE PROCEDURE GetChangedCustomers
(
   @LastDBTS rowversion,
   @StoreID int,
   @MaxCustomerID int
)
AS
   SELECT   
        CustomerID,
        [RowVersion],  
        StoreID, 
        ShipEmail,
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1,
        ShipAddress2,
        ShipAddress3,
        ShipCity,
        ShipStateProvinceCode,
        ShipPostalCode,
        ShipCountryCode,
        ShipPhone,
        ShipFax,
        BillEmail,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1,
        BillAddress2,
        BillAddress3,
        BillCity,
        BillStateProvinceCode,
        BillPostalCode,
        BillCountryCode,
        BillPhone, 
        BillFax,
        Notes, 
        eBayBuyerID,
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = c.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = c.CustomerID), 0.00) AS TotalAmount
      FROM Customers c
      WHERE (c.RowVersion > @LastDBTS AND c.StoreID = @StoreID) AND
            (@MaxCustomerID < 0 OR c.CustomerID <= @MaxCustomerID)

GO

-----------------------------
--- Procedure GetCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomer]
GO

CREATE PROCEDURE GetCustomer
(
   @CustomerID int
)
AS
   SELECT   
        CustomerID,
        [RowVersion],  
        StoreID, 
        ShipEmail,
        ShipFirstName,
        ShipLastName,
        ShipCompany,
        ShipAddress1,
        ShipAddress2,
        ShipAddress3,
        ShipCity,
        ShipStateProvinceCode,
        ShipPostalCode,
        ShipCountryCode,
        ShipPhone,
        ShipFax,
        BillEmail,
        BillFirstName,
        BillLastName,
        BillCompany,
        BillAddress1,
        BillAddress2,
        BillAddress3,
        BillCity,
        BillStateProvinceCode,
        BillPostalCode,
        BillCountryCode,
        BillPhone, 
        BillFax,
        Notes, 
        eBayBuyerID,
        (SELECT Count(o.OrderID) FROM Orders o WHERE o.CustomerID = c.CustomerID) AS TotalOrders,
        ISNULL((SELECT Sum(o.Total) FROM Orders o WHERE o.CustomerID = c.CustomerID), 0.00) AS TotalAmount
      FROM Customers c
      WHERE c.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure DeleteCustomer
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteCustomer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteCustomer]
GO

CREATE PROCEDURE DeleteCustomer
(
   @CustomerID int
)
AS
    DELETE FROM Customers
    WHERE CustomerID = @CustomerID
GO