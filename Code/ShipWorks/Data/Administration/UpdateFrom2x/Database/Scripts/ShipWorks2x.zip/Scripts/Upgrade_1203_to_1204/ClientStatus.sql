----------------------------
--- PROCEDURE EnsureClientStatusExists
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EnsureClientStatusExists]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[EnsureClientStatusExists]
GO

CREATE PROCEDURE dbo.EnsureClientStatusExists
AS
    if not exists (select * from tempdb..sysobjects where id = object_id(N'tempdb..##ClientStatus'))
    begin
    
        CREATE TABLE ##ClientStatus 
        (
	        [ClientID] int NOT NULL ,
	        [Refreshing] bit NOT NULL ,
	        [Downloading] bit NOT NULL ,
	        [Saving] bit NOT NULL ,
	        CONSTRAINT [PK_ClientStatus] PRIMARY KEY CLUSTERED (ClientID) 
        )
        
    end
    
    DECLARE @ClientID int
    SELECT @ClientID = CAST(context_info AS int)
       FROM master.dbo.sysprocesses
       WHERE spid = @@spid

    -- See if our client exists
    if (0 = (SELECT COUNT(*) FROM ##ClientStatus WHERE ClientID = @ClientID))
    begin
        INSERT INTO ##ClientStatus
        (
            ClientID,
            Refreshing,
            Downloading,
            Saving
        )
        VALUES
        (
            @ClientID,
            0,
            0,
            0
        )
    end
GO

----------------------------
--- PROCEDURE DownloadStart
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DownloadStart]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DownloadStart]
GO

CREATE PROCEDURE dbo.DownloadStart

AS

    EXEC EnsureClientStatusExists
    
    DECLARE @ClientID int
    DECLARE @Result int
    
    BEGIN TRAN
    
    -- See if no one else is downloading
    if (0 = (select count(*) from ##ClientStatus where Downloading = 1 and ClientID != @ClientID))
    begin
    
        -- Mark that we are downloading
        UPDATE ##ClientStatus
          SET Downloading = 1
          WHERE ClientID = @ClientID
        
        SET @Result = 1
        
    end
    else
    begin

       SET @Result = 0
       
    end
    
    COMMIT
    
    SELECT @Result as Result
GO

----------------------------
--- PROCEDURE DownloadStop
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DownloadStop]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DownloadStop]
GO

CREATE PROCEDURE dbo.DownloadStop
AS

    EXEC EnsureClientStatusExists
    
    DECLARE @ClientID int
    
    SELECT @ClientID = CAST(context_info AS int)
       FROM master.dbo.sysprocesses
       WHERE spid = @@spid

    -- Mark that we are no longer downloading
    UPDATE ##ClientStatus
        SET Downloading = 0
        WHERE ClientID = @ClientID

GO

----------------------------
--- PROCEDURE RefreshingStart
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RefreshingStart]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RefreshingStart]
GO

CREATE PROCEDURE dbo.RefreshingStart
AS

    EXEC EnsureClientStatusExists
    
    DECLARE @ClientID int
    DECLARE @Result int
    
    BEGIN TRAN
    
    -- See if anyone else is saving
    if (0 = (select count(*) from ##ClientStatus where Saving = 1 and ClientID != @ClientID))
    begin
    
        -- Mark that we are downloading
        UPDATE ##ClientStatus
          SET Refreshing = 1
          WHERE ClientID = @ClientID
        
        SET @Result = 1

    end
    else
    begin

       SET @Result = 0
       
    end
    
    COMMIT
    
    SELECT @Result as Result
GO

----------------------------
--- PROCEDURE RefreshingStop
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RefreshingStop]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[RefreshingStop]
GO

CREATE PROCEDURE dbo.RefreshingStop
AS

    EXEC EnsureClientStatusExists
    
    DECLARE @ClientID int
    
    SELECT @ClientID = CAST(context_info AS int)
       FROM master.dbo.sysprocesses
       WHERE spid = @@spid

    -- Mark that we are no longer downloading
    UPDATE ##ClientStatus
        SET Refreshing = 0
        WHERE ClientID = @ClientID

GO

----------------------------
--- PROCEDURE SavingStart
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SavingStart]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SavingStart]
GO

CREATE PROCEDURE dbo.SavingStart
AS

    EXEC EnsureClientStatusExists
    
    DECLARE @ClientID int
    DECLARE @Result int
    
    BEGIN TRAN
    
    -- See if anyone else is refreshing
    if (0 = (select count(*) from ##ClientStatus where Refreshing = 1 and ClientID != @ClientID))
    begin
    
        -- Mark that we are downloading
        UPDATE ##ClientStatus
          SET Saving = 1
          WHERE ClientID = @ClientID
        
        SET @Result = 1
    
    end    
    else
    begin

       SET @Result = 0
       
    end
    
    COMMIT
    
    SELECT @Result as Result
GO

----------------------------
--- PROCEDURE SavingStop
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SavingStop]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SavingStop]
GO

CREATE PROCEDURE dbo.SavingStop
AS

    EXEC EnsureClientStatusExists
    
    DECLARE @ClientID int
    
    SELECT @ClientID = CAST(context_info AS int)
       FROM master.dbo.sysprocesses
       WHERE spid = @@spid

    -- Mark that we are no longer downloading
    UPDATE ##ClientStatus
        SET Saving = 0
        WHERE ClientID = @ClientID

GO