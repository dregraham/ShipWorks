ALTER TABLE Shipments
   ALTER COLUMN ToStateProvinceCode nvarchar (25)
GO


-----------------------------
--- Procedure UpdateShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateShipment]
GO

CREATE PROCEDURE UpdateShipment
(
    @ShipmentID int,
    @RowVersion timestamp,
    @OrderID int ,
    @ShipmentType int,
    @Processed bit ,
    @ProcessedDate datetime ,
    @ShippedDate datetime ,
    @ServiceUsed nvarchar(50) ,
    @TrackingNumber nvarchar(50) ,
    @TotalCharges money ,
    @TotalWeight float , 
    @ToFirstName nvarchar (30)  ,
    @ToLastName nvarchar (30)  ,
    @ToCompany nvarchar (30)  ,
    @ToAddress1 nvarchar (60)  ,
    @ToAddress2 nvarchar (60)  ,
    @ToAddress3 nvarchar (60)  ,
    @ToCity nvarchar (50)  ,
    @ToStateProvinceCode nvarchar (25)  ,
    @ToPostalCode nvarchar (10)  ,
    @ToCountryCode nvarchar (5)  ,
    @ToPhone nvarchar (25)  ,
    @ToFax nvarchar (25) ,
    @ToEmail nvarchar (50)
)
AS
    UPDATE [Shipments]
    SET OrderID = @OrderID,
        ShipmentType = @ShipmentType,
        Processed = @Processed,
        ProcessedDate = @ProcessedDate,
        ShippedDate = @ShippedDate,
        ServiceUsed = @ServiceUsed,
        TrackingNumber = @TrackingNumber,
        TotalCharges = @TotalCharges,
        TotalWeight = @TotalWeight, 
        ToFirstName = @ToFirstName,
        ToLastName = @ToLastName,
        ToCompany = @ToCompany,
        ToAddress1 = @ToAddress1,
        ToAddress2 = @ToAddress2,
        ToAddress3 = @ToAddress3,
        ToCity = @ToCity,
        ToStateProvinceCode = @ToStateProvinceCode,
        ToPostalCode = @ToPostalCode,
        ToCountryCode = @ToCountryCode,
        ToPhone = @ToPhone,
        ToFax = @ToFax,
        ToEmail = @ToEmail
    WHERE ShipmentID = @ShipmentID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT ShipmentID, [RowVersion]
    FROM Shipments
    WHERE ShipmentID = @ShipmentID

    return 1
GO

----------------------------
--- Procedure AddShipment
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddShipment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddShipment]
GO

CREATE PROCEDURE AddShipment
(
    @OrderID int ,
    @ShipmentType int,
    @Processed bit ,
    @ProcessedDate datetime ,
    @ShippedDate datetime ,
    @ServiceUsed nvarchar(50) ,
    @TrackingNumber nvarchar(50) ,
    @TotalCharges money ,
    @TotalWeight float , 
    @ToFirstName nvarchar (30)  ,
    @ToLastName nvarchar (30)  ,
    @ToCompany nvarchar (30)  ,
    @ToAddress1 nvarchar (60)  ,
    @ToAddress2 nvarchar (60)  ,
    @ToAddress3 nvarchar (60)  ,
    @ToCity nvarchar (50)  ,
    @ToStateProvinceCode nvarchar (25)  ,
    @ToPostalCode nvarchar (10)  ,
    @ToCountryCode nvarchar (5)  ,
    @ToPhone nvarchar (25)  ,
    @ToFax nvarchar (25) ,
    @ToEmail nvarchar (50)
)
AS
    INSERT INTO [Shipments]
    (
        OrderID ,
        ShipmentType,
        Processed ,
        ProcessedDate  ,
        ShippedDate  ,
        ServiceUsed  ,
        TrackingNumber  ,
        TotalCharges  ,
        TotalWeight  , 
        ToFirstName ,
        ToLastName ,
        ToCompany  ,
        ToAddress1  ,
        ToAddress2  ,
        ToAddress3 ,
        ToCity ,
        ToStateProvinceCode ,
        ToPostalCode ,
        ToCountryCode ,
        ToPhone ,
        ToFax ,
        ToEmail
    )
    VALUES
    (
        @OrderID ,
        @ShipmentType,
        @Processed ,
        @ProcessedDate  ,
        @ShippedDate  ,
        @ServiceUsed  ,
        @TrackingNumber  ,
        @TotalCharges  ,
        @TotalWeight  , 
        @ToFirstName ,
        @ToLastName ,
        @ToCompany  ,
        @ToAddress1  ,
        @ToAddress2  ,
        @ToAddress3 ,
        @ToCity ,
        @ToStateProvinceCode ,
        @ToPostalCode ,
        @ToCountryCode ,
        @ToPhone ,
        @ToFax ,
        @ToEmail
    )
    
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT ShipmentID, RowVersion
   FROM Shipments
   WHERE ShipmentID = SCOPE_IDENTITY()

   return 1
GO