-----------------------------
--- TABLE AmazonInventory
-----------------------------
CREATE TABLE dbo.AmazonInventory 
(
	AmazonInventoryID int IDENTITY (1, 1) NOT NULL ,
	StoreID int NOT NULL,
	SKU varchar(100) NOT NULL,
	AmazonASIN varchar(32) NOT NULL,
	CONSTRAINT [PK_AmazonInventory] PRIMARY KEY  CLUSTERED (AmazonInventoryID),
	CONSTRAINT [FK_AmazonInventory_Stores] FOREIGN KEY ([StoreID]) REFERENCES [Stores] ([StoreID])
)
GO