ALTER TABLE dbo.ShipmentCommodities
	DROP CONSTRAINT FK_ShipmentCommodities_Shipment
GO

CREATE TABLE dbo.Tmp_ShipmentCommodities
	(
	CommodityID int NOT NULL IDENTITY (1, 1),
	RowVersion timestamp NOT NULL,
	ShipmentID int NOT NULL,
	Description nvarchar(200) NOT NULL,
	Quantity float(53) NOT NULL,
	Weight float(53) NOT NULL,
	UnitValue money NOT NULL,
	UnitOfMeasure int NOT NULL,
	OriginCountry varchar(20) NOT NULL,
	HarmonizedCode varchar(14) NOT NULL,
	ExportLicenseNumber varchar(12) NOT NULL,
	ExportLicenseExpiration datetime NOT NULL
	)  ON [PRIMARY]
GO

SET IDENTITY_INSERT dbo.Tmp_ShipmentCommodities ON
GO

IF EXISTS(SELECT * FROM dbo.ShipmentCommodities)
	 EXEC('INSERT INTO dbo.Tmp_ShipmentCommodities (CommodityID, ShipmentID, Description, Quantity, Weight, UnitValue, UnitOfMeasure, OriginCountry, HarmonizedCode, ExportLicenseNumber, ExportLicenseExpiration)
		                                     SELECT CommodityID, ShipmentID, Description, Quantity, Weight, UnitValue, 27,            OriginCountry, HarmonizedCode, ExportLicenseNumber, ExportLicenseExpiration FROM dbo.ShipmentCommodities TABLOCKX')
GO

SET IDENTITY_INSERT dbo.Tmp_ShipmentCommodities OFF
GO

DROP TABLE dbo.ShipmentCommodities
GO

EXECUTE sp_rename N'dbo.Tmp_ShipmentCommodities', N'ShipmentCommodities', 'OBJECT'
GO

ALTER TABLE dbo.ShipmentCommodities ADD CONSTRAINT
	PK_ShipmentCommodities PRIMARY KEY CLUSTERED 
	(
	CommodityID
	) ON [PRIMARY]

GO

ALTER TABLE dbo.ShipmentCommodities WITH NOCHECK ADD CONSTRAINT
	FK_ShipmentCommodities_Shipment FOREIGN KEY
	(
	ShipmentID
	) REFERENCES dbo.Shipments
	(
	ShipmentID
	)
GO

-----------------------------
--- Procedure GetOrderShipmentCommodities
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentCommodities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentCommodities]
GO

CREATE PROCEDURE dbo.GetOrderShipmentCommodities
(
    @OrderID int
)
AS
   SELECT c.*
   FROM ShipmentCommodities c, Shipments s
   WHERE c.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerShipmentCommodities
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentCommodities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentCommodities]
GO

CREATE PROCEDURE dbo.GetCustomerShipmentCommodities
(
    @CustomerID int
)
AS
   SELECT c.*
   FROM ShipmentCommodities c, Shipments s
   WHERE c.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderShipmentCommodityRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentCommodityRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentCommodityRange]
GO

CREATE PROCEDURE dbo.GetOrderShipmentCommodityRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT c.*
     FROM ShipmentCommodities c, Shipments s, Orders o
     WHERE c.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerShipmentCommodityRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentCommodityRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentCommodityRange]
GO

CREATE PROCEDURE dbo.GetCustomerShipmentCommodityRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT c.*
     FROM ShipmentCommodities c, Shipments s
     WHERE c.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure DeleteShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteShipmentCommodity]
GO

CREATE PROCEDURE dbo.DeleteShipmentCommodity
(
    @CommodityID int
)
AS
   DELETE FROM ShipmentCommodities
     WHERE CommodityID = @CommodityID
GO

-----------------------------
--- Procedure UpdateShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateShipmentCommodity]
GO

CREATE PROCEDURE dbo.UpdateShipmentCommodity
(
	@CommodityID int,
	@RowVersion timestamp,
	@ShipmentID int,
	@Description nvarchar (200),
	@Quantity float,
	@Weight float,
	@UnitValue money,
	@UnitOfMeasure int,
	@OriginCountry varchar (20),
	@HarmonizedCode varchar (14),
	@ExportLicenseNumber varchar (12),
	@ExportLicenseExpiration datetime
)
AS
    UPDATE [ShipmentCommodities]
    SET 	
		ShipmentID = @ShipmentID,
		Description = @Description,
		Quantity = @Quantity,
		Weight = @Weight,
		UnitValue = @UnitValue,
		UnitOfMeasure = @UnitOfMeasure,
		OriginCountry = @OriginCountry,
		HarmonizedCode = @HarmonizedCode,
		ExportLicenseNumber = @ExportLicenseNumber,
		ExportLicenseExpiration = @ExportLicenseExpiration
    WHERE CommodityID = @CommodityID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT CommodityID, [RowVersion]
    FROM ShipmentCommodities
    WHERE CommodityID = @CommodityID

    return 1
GO

-----------------------------
--- Procedure AddShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddShipmentCommodity]
GO

CREATE PROCEDURE dbo.AddShipmentCommodity
(
	@ShipmentID int,
	@Description nvarchar (200),
	@Quantity float,
	@Weight float,
	@UnitValue money,
	@UnitOfMeasure int,
	@OriginCountry varchar (20),
	@HarmonizedCode varchar (14),
	@ExportLicenseNumber varchar (12),
	@ExportLicenseExpiration datetime
)
AS
    
    INSERT INTO [ShipmentCommodities]
    (
		ShipmentID,
		Description,
		Quantity,
		Weight,
		UnitValue,
		UnitOfMeasure,
		OriginCountry,
		HarmonizedCode,
		ExportLicenseNumber,
		ExportLicenseExpiration
    )
    VALUES
    (
		@ShipmentID,
		@Description,
		@Quantity,
		@Weight,
		@UnitValue,
		@UnitOfMeasure,
		@OriginCountry,
		@HarmonizedCode,
		@ExportLicenseNumber,
		@ExportLicenseExpiration
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT CommodityID, [RowVersion]
    FROM ShipmentCommodities
    WHERE CommodityID = SCOPE_IDENTITY()

    return 1

GO