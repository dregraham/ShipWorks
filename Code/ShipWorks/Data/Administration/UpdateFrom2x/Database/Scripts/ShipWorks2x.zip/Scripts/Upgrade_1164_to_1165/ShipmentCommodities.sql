-----------------------------
--- TABLE ShipmentCommodities
-----------------------------
CREATE TABLE ShipmentCommodities
(
	CommodityID int IDENTITY (1, 1) NOT NULL  ,
	[RowVersion] timestamp NOT NULL,
	ShipmentID int NOT NULL,
	Description nvarchar (200) NOT NULL,
	Quantity float NOT NULL,
	Weight float NOT NULL,
	UnitValue money NOT NULL,
	OriginCountry varchar (20) NOT NULL,
	HarmonizedCode varchar (14) NOT NULL,
	ExportLicenseNumber varchar (12) NOT NULL,
	ExportLicenseExpiration datetime NOT NULL,
	CONSTRAINT [PK_ShipmentCommodities] PRIMARY KEY CLUSTERED (CommodityID)  ,
	CONSTRAINT [FK_ShipmentCommodities_Shipment] FOREIGN KEY ([ShipmentID]) REFERENCES [Shipments] ([ShipmentID])
)
GO

-----------------------------
--- Procedure GetOrderShipmentCommodities
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentCommodities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentCommodities]
GO

CREATE PROCEDURE GetOrderShipmentCommodities
(
    @OrderID int
)
AS
   SELECT c.*
   FROM ShipmentCommodities c, Shipments s
   WHERE c.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetCustomerShipmentCommodities
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentCommodities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentCommodities]
GO

CREATE PROCEDURE GetCustomerShipmentCommodities
(
    @CustomerID int
)
AS
   SELECT c.*
   FROM ShipmentCommodities c, Shipments s
   WHERE c.ShipmentID = s.ShipmentID AND
         s.CustomerID = @CustomerID
GO

-----------------------------
--- Procedure GetOrderShipmentCommodityRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetOrderShipmentCommodityRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetOrderShipmentCommodityRange]
GO

CREATE PROCEDURE GetOrderShipmentCommodityRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT c.*
     FROM ShipmentCommodities c, Shipments s, Orders o
     WHERE c.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.OrderID = o.OrderID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure GetCustomerShipmentCommodityRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCustomerShipmentCommodityRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetCustomerShipmentCommodityRange]
GO

CREATE PROCEDURE GetCustomerShipmentCommodityRange
(
    @StoreID int,
    @MinCustomerID int
)
AS
   SELECT c.*
     FROM ShipmentCommodities c, Shipments s
     WHERE c.ShipmentID = s.ShipmentID AND 
           s.StoreID = @StoreID AND
           s.CustomerID > @MinCustomerID AND
           s.CustomerID <> -1
     
GO

-----------------------------
--- Procedure DeleteShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteShipmentCommodity]
GO

CREATE PROCEDURE DeleteShipmentCommodity
(
    @CommodityID int
)
AS
   DELETE FROM ShipmentCommodities
     WHERE CommodityID = @CommodityID
GO

-----------------------------
--- Procedure UpdateShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateShipmentCommodity]
GO

CREATE PROCEDURE UpdateShipmentCommodity
(
	@CommodityID int,
	@RowVersion timestamp,
	@ShipmentID int,
	@Description nvarchar (200),
	@Quantity float,
	@Weight float,
	@UnitValue money,
	@OriginCountry varchar (20),
	@HarmonizedCode varchar (14),
	@ExportLicenseNumber varchar (12),
	@ExportLicenseExpiration datetime
)
AS
    UPDATE [ShipmentCommodities]
    SET 	
		ShipmentID = @ShipmentID,
		Description = @Description,
		Quantity = @Quantity,
		Weight = @Weight,
		UnitValue = @UnitValue,
		OriginCountry = @OriginCountry,
		HarmonizedCode = @HarmonizedCode,
		ExportLicenseNumber = @ExportLicenseNumber,
		ExportLicenseExpiration = @ExportLicenseExpiration
    WHERE CommodityID = @CommodityID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT CommodityID, [RowVersion]
    FROM ShipmentCommodities
    WHERE CommodityID = @CommodityID

    return 1
GO

-----------------------------
--- Procedure AddShipmentCommodity
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddShipmentCommodity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddShipmentCommodity]
GO

CREATE PROCEDURE AddShipmentCommodity
(
	@ShipmentID int,
	@Description nvarchar (200),
	@Quantity float,
	@Weight float,
	@UnitValue money,
	@OriginCountry varchar (20),
	@HarmonizedCode varchar (14),
	@ExportLicenseNumber varchar (12),
	@ExportLicenseExpiration datetime
)
AS
    
    INSERT INTO [ShipmentCommodities]
    (
		ShipmentID,
		Description,
		Quantity,
		Weight,
		UnitValue,
		OriginCountry,
		HarmonizedCode,
		ExportLicenseNumber,
		ExportLicenseExpiration
    )
    VALUES
    (
		@ShipmentID,
		@Description,
		@Quantity,
		@Weight,
		@UnitValue,
		@OriginCountry,
		@HarmonizedCode,
		@ExportLicenseNumber,
		@ExportLicenseExpiration
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT CommodityID, [RowVersion]
    FROM ShipmentCommodities
    WHERE CommodityID = SCOPE_IDENTITY()

    return 1

GO