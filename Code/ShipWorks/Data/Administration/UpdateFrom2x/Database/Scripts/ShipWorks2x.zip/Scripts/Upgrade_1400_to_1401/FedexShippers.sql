----------------------------
--- PROCEDURE AddFedexShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFedexShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddFedexShipper]
GO

CREATE PROCEDURE dbo.AddFedexShipper
(
    @AccountNumber int ,
    @MeterNumber int ,
    @UseAlternate bit ,
    @Company nvarchar (35) ,
    @ContactName nvarchar (35) ,
    @Address1 nvarchar (60) ,
    @Address2 nvarchar (60) ,
    @City nvarchar (50) ,
    @StateProvinceCode nvarchar (5) ,
    @PostalCode nvarchar (10) ,
    @CountryCode nvarchar (5) ,
    @ContactEmail nvarchar (35) ,
    @ContactPhone nvarchar (25) ,
    @ContactFax nvarchar (25) ,
    @AlternateCompany nvarchar (35) ,
    @AlternateContactName nvarchar (35) ,
    @AlternateAddress1 nvarchar (60) ,
    @AlternateAddress2 nvarchar (60) ,
    @AlternateCity nvarchar (50) ,
    @AlternateStateProvinceCode nvarchar (5) ,
    @AlternatePostalCode nvarchar (10) ,
    @AlternateCountryCode nvarchar (5) ,
    @AlternateContactEmail nvarchar (35) ,
    @AlternateContactPhone nvarchar (25) ,
    @AlternateContactFax nvarchar (25),
    @SignatureReleaseNumber varchar (10)
)
WITH ENCRYPTION
AS
   INSERT INTO FedexShippers 
   (
        AccountNumber,
        MeterNumber,
        UseAlternate,
        Company,
        ContactName,
        Address1,
        Address2,
        City,
        StateProvinceCode,
        PostalCode,
        CountryCode,
        ContactEmail,
        ContactPhone,
        ContactFax,
        AlternateCompany,
        AlternateContactName,
        AlternateAddress1,
        AlternateAddress2,
        AlternateCity,
        AlternateStateProvinceCode,
        AlternatePostalCode,
        AlternateCountryCode,
        AlternateContactEmail,
        AlternateContactPhone,
        AlternateContactFax,
        SignatureReleaseNumber
   )
   VALUES 
   (
        @AccountNumber,
        @MeterNumber,
        @UseAlternate,
        @Company,
        @ContactName,
        @Address1,
        @Address2,
        @City,
        @StateProvinceCode,
        @PostalCode,
        @CountryCode,
        @ContactEmail,
        @ContactPhone,
        @ContactFax,
        @AlternateCompany,
        @AlternateContactName,
        @AlternateAddress1,
        @AlternateAddress2,
        @AlternateCity,
        @AlternateStateProvinceCode,
        @AlternatePostalCode,
        @AlternateCountryCode,
        @AlternateContactEmail,
        @AlternateContactPhone,
        @AlternateContactFax,
        @SignatureReleaseNumber
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT FedexShipperID, [RowVersion]
     FROM FedexShippers
     WHERE FedexShipperID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateFedexShipper
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFedexShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFedexShipper]
GO

CREATE PROCEDURE dbo.UpdateFedexShipper
(
    @FedexShipperID int,
    @RowVersion timestamp,
    @AccountNumber int ,
    @MeterNumber int ,
    @UseAlternate bit ,
    @Company nvarchar (35) ,
    @ContactName nvarchar (35) ,
    @Address1 nvarchar (60) ,
    @Address2 nvarchar (60) ,
    @City nvarchar (50) ,
    @StateProvinceCode nvarchar (5) ,
    @PostalCode nvarchar (10) ,
    @CountryCode nvarchar (5) ,
    @ContactEmail nvarchar (35) ,
    @ContactPhone nvarchar (25) ,
    @ContactFax nvarchar (25) ,
    @AlternateCompany nvarchar (35) ,
    @AlternateContactName nvarchar (35) ,
    @AlternateAddress1 nvarchar (60) ,
    @AlternateAddress2 nvarchar (60) ,
    @AlternateCity nvarchar (50) ,
    @AlternateStateProvinceCode nvarchar (5) ,
    @AlternatePostalCode nvarchar (10) ,
    @AlternateCountryCode nvarchar (5) ,
    @AlternateContactEmail nvarchar (35) ,
    @AlternateContactPhone nvarchar (25) ,
    @AlternateContactFax nvarchar (25),
    @SignatureReleaseNumber varchar (10)
)
WITH ENCRYPTION
AS
   UPDATE FedexShippers
      SET           
        AccountNumber = @AccountNumber,
        MeterNumber = @MeterNumber,
        UseAlternate = @UseAlternate,
        Company = @Company,
        ContactName = @ContactName,
        Address1 = @Address1,
        Address2 = @Address2,
        City = @City,
        StateProvinceCode = @StateProvinceCode,
        PostalCode = @PostalCode,
        CountryCode = @CountryCode,
        ContactEmail = @ContactEmail,
        ContactPhone = @ContactPhone,
        ContactFax = @ContactFax,
        AlternateCompany = @AlternateCompany,
        AlternateContactName = @AlternateContactName,
        AlternateAddress1 = @AlternateAddress1,
        AlternateAddress2 = @AlternateAddress2,
        AlternateCity = @AlternateCity,
        AlternateStateProvinceCode = @AlternateStateProvinceCode,
        AlternatePostalCode = @AlternatePostalCode,
        AlternateCountryCode = @AlternateCountryCode,
        AlternateContactEmail = @AlternateContactEmail,
        AlternateContactPhone = @AlternateContactPhone,
        AlternateContactFax = @AlternateContactFax,
        SignatureReleaseNumber = @SignatureReleaseNumber
      WHERE FedexShipperID = @FedexShipperID and [RowVersion] = @RowVersion
      
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT FedexShipperID, [RowVersion]
       FROM FedexShippers
       WHERE FedexShipperID = @FedexShipperID

    return 1
GO

-----------------------------
--- Procedure DeleteFedexShipper
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteFedexShipper]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteFedexShipper]
GO

CREATE PROCEDURE dbo.DeleteFedexShipper
(
   @FedexShipperID int
)
WITH ENCRYPTION
AS
    DELETE FROM FedexShippers
    WHERE FedexShipperID = @FedexShipperID
GO

----------------------------
--- PROCEDURE GetAllFedexShippers
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllFedexShippers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllFedexShippers]
GO

CREATE PROCEDURE dbo.GetAllFedexShippers 
WITH ENCRYPTION
AS
   SELECT *
   FROM FedexShippers
GO