ALTER TABLE dbo.Filters
	DROP COLUMN GridUseCustom
GO

ALTER TABLE dbo.Filters
    DROP COLUMN GridCustomSettings
GO

----------------------------
--- PROCEDURE AddFilter
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddFilter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddFilter]
GO

CREATE PROCEDURE dbo.AddFilter
(
   @FilterName nvarchar(50),
   @FilterXML text
)
AS
   INSERT INTO Filters 
   (
      FilterName,
      FilterXML
   )
   VALUES 
   (
      @FilterName,
      @FilterXML
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT FilterID
     FROM Filters
     WHERE FilterID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE UpdateFilter
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFilter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFilter]
GO

CREATE PROCEDURE dbo.UpdateFilter
(
   @FilterID int,
   @FilterName nvarchar(50),
   @FilterXML text
)
AS
   UPDATE Filters
      SET FilterName = @FilterName,
          FilterXML = @FilterXML
      WHERE FilterID = @FilterID
      
   if (@@ROWCOUNT != 1)
      return 0

   return 1
GO

-----------------------------
--- Procedure DeleteFilter
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteFilter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteFilter]
GO

CREATE PROCEDURE dbo.DeleteFilter
(
   @FilterID int
)
AS
    DELETE FROM Filters
    WHERE FilterID = @FilterID
GO

----------------------------
--- PROCEDURE GetAllFilters
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllFilters]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetAllFilters]
GO

CREATE PROCEDURE dbo.GetAllFilters 
AS
   SELECT *
   FROM Filters
GO
