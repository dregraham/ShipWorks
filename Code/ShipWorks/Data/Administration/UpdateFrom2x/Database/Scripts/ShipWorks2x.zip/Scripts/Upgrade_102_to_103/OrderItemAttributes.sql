ALTER TABLE dbo.OrderItemAttributes
	DROP CONSTRAINT FK_OrderItemAttributes_OrderItems
GO

CREATE TABLE dbo.Tmp_OrderItemAttributes
	(
	AttributeID int NOT NULL IDENTITY (1, 1),
	RowVersion timestamp NOT NULL,
	OrderItemID int NOT NULL,
	Code nvarchar(300) NOT NULL,
	Name nvarchar(300) NOT NULL,
	Description nvarchar(1500) NOT NULL,
	UnitPrice money NOT NULL,
	MivaAttributeID int NOT NULL
	)
GO

SET IDENTITY_INSERT dbo.Tmp_OrderItemAttributes ON
GO

IF EXISTS(SELECT * FROM dbo.OrderItemAttributes)
	 EXEC('INSERT INTO dbo.Tmp_OrderItemAttributes (AttributeID, OrderItemID, Code, Name, Description, UnitPrice, MivaAttributeID)
		SELECT AttributeID, OrderItemID, Label, Label, Description, UnitPrice, MivaAttributeID FROM dbo.OrderItemAttributes TABLOCKX')
GO

SET IDENTITY_INSERT dbo.Tmp_OrderItemAttributes OFF
GO

DROP TABLE dbo.OrderItemAttributes
GO

EXECUTE sp_rename N'dbo.Tmp_OrderItemAttributes', N'OrderItemAttributes', 'OBJECT'
GO

ALTER TABLE dbo.OrderItemAttributes ADD CONSTRAINT
	PK_OrderItemAttributes PRIMARY KEY CLUSTERED 
	(
	   AttributeID
	)

GO

CREATE NONCLUSTERED INDEX IX_OrderItemAttributes_OrderItemID ON dbo.OrderItemAttributes
	(
	   OrderItemID
	)
GO

ALTER TABLE dbo.OrderItemAttributes WITH NOCHECK ADD CONSTRAINT
	FK_OrderItemAttributes_OrderItems FOREIGN KEY (OrderItemID) 
	   REFERENCES dbo.OrderItems (OrderItemID)
GO

-----------------------------
--- Procedure AddItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddItemAttribute]
GO

CREATE PROCEDURE AddItemAttribute
(
    @OrderItemID int,
	@Code [nvarchar] (300),
	@Name [nvarchar] (300),
	@Description [nvarchar] (1500),
	@UnitPrice money,
	@MivaAttributeID int
)
AS
    INSERT INTO [OrderItemAttributes]
    (
	    [OrderItemID],
	    [Code],
	    [Name],
	    [Description],
	    [UnitPrice],
	    [MivaAttributeID]
    )
    VALUES
    (
	    @OrderItemID,
	    @Code,
	    @Name,
	    @Description,
	    @UnitPrice,
	    @MivaAttributeID
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT AttributeID, [RowVersion]
    FROM OrderItemAttributes
    WHERE AttributeID = SCOPE_IDENTITY()

    return 1
GO

-----------------------------
--- Procedure UpdateItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateItemAttribute]
GO

CREATE PROCEDURE UpdateItemAttribute
(
	@AttributeID int,
	@RowVersion timestamp,
    @OrderItemID int,
    @Code nvarchar (300),
	@Name nvarchar (300),
	@Description nvarchar (1500),
	@UnitPrice money,
	@MivaAttributeID int
)
AS
    UPDATE [OrderItemAttributes]
    SET [OrderItemID] = @OrderItemID,
        [Code] = @Code,
	    [Name] = @Name,
	    [Description] = @Description,
	    [UnitPrice] = @UnitPrice,
	    [MivaAttributeID] = @MivaAttributeID
    WHERE AttributeID = @AttributeID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT [RowVersion]
    FROM OrderItemAttributes
    WHERE AttributeID = @AttributeID

    return 1
GO

-----------------------------
--- Procedure SynchMivaItemAttribute
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SynchMivaItemAttribute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SynchMivaItemAttribute]
GO

CREATE PROCEDURE SynchMivaItemAttribute
(
	@OrderItemID int,
	@Code nvarchar (300),
	@Name nvarchar (300),
	@Description nvarchar (1500),
	@UnitPrice money,
	@MivaAttributeID int
)
AS
   
    -- If this Miva item attribute already exists, we dont do anything
    if exists (
        SELECT * 
        FROM OrderItemAttributes a
        WHERE a.MivaAttributeID = @MivaAttributeID AND
              a.OrderItemID = @OrderItemID)
    begin
    
        -- This just lets the .NET data provider know everything is OK
        SELECT AttributeID, [RowVersion]
        FROM OrderItemAttributes a
        WHERE a.MivaAttributeID = @MivaAttributeID AND
              a.OrderItemID = @OrderItemID
              
        return 1

    end
    
    -- This item does not already exist, we need to create it
    else 
    begin
    
        INSERT INTO [OrderItemAttributes]
        (
	        [OrderItemID],
	        [Code],
	        [Name],
	        [Description],
	        [UnitPrice],
	        [MivaAttributeID]
        )
        VALUES
        (
	        @OrderItemID,
	        @Code,
	        @Name,
	        @Description,
	        @UnitPrice,
	        @MivaAttributeID
        )
        
        if (@@ROWCOUNT != 1)
            return 0

        SET NOCOUNT ON

        SELECT AttributeID, [RowVersion]
        FROM OrderItemAttributes
        WHERE AttributeID = SCOPE_IDENTITY()

        return 1
    end
GO
