-----------------------------
--- Procedure GetFedexPackageRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetFedexPackageRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetFedexPackageRange]
GO

CREATE PROCEDURE dbo.GetFedexPackageRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
WITH ENCRYPTION
AS
   SELECT p.*
     FROM FedexPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           ((o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax) OR o.WasArchived = 1) AND
           o.OrderID > @MinOrderID
     
GO