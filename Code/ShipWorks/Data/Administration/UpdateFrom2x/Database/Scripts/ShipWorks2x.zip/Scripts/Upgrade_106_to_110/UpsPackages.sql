ALTER TABLE UpsPackages DROP COLUMN ReferenceNumber
GO

-----------------------------
--- Procedure GetUpsPackages
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsPackages]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUpsPackages]
GO

CREATE PROCEDURE GetUpsPackages
(
    @OrderID int
)
AS
   SELECT p.*
   FROM UpsPackages p, Shipments s
   WHERE p.ShipmentID = s.ShipmentID AND
         s.OrderID = @OrderID
GO

-----------------------------
--- Procedure GetUpsPackageRange
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUpsPackageRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[GetUpsPackageRange]
GO

CREATE PROCEDURE GetUpsPackageRange
(
    @StoreID int,
    @DateRangeMax datetime,
    @DateRangeMin datetime,
    @MinOrderID int
)
AS
   SELECT p.*
     FROM UpsPackages p, Shipments s, Orders o
     WHERE p.ShipmentID = s.ShipmentID AND s.OrderID = o.OrderID AND o.StoreID = @StoreID AND
           o.OrderDate >= @DateRangeMin AND o.OrderDate <= @DateRangeMax AND
           o.OrderID > @MinOrderID
     
GO

-----------------------------
--- Procedure DeleteUpsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteUpsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[DeleteUpsPackage]
GO

CREATE PROCEDURE DeleteUpsPackage
(
    @UpsPackageID int
)
AS
   DELETE FROM UpsPackages
     WHERE UpsPackageID = @UpsPackageID
GO

-----------------------------
--- Procedure AddUpsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUpsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AddUpsPackage]
GO

CREATE PROCEDURE AddUpsPackage
(
    @ShipmentID int,
    @PackagingTypeCode nvarchar (10),
    @Length int,
    @Width int,
    @Height int,
    @Weight float,
    @AdditionalHandling bit,
    @DeliveryConfirmation bit,
    @DeliveryConfirmationType nvarchar (15),
    @Insurance bit,
    @InsuredValue money,
    @COD bit,
    @CODFundsCode nvarchar (10),
    @CODAmount money,
    @TrackingNumber nvarchar (50),
    @LabelImageFull nvarchar (350) ,
    @LabelImageLabel nvarchar (350) ,
    @LabelImageEpl nvarchar (350) ,
    @LabelWarsawPath nvarchar (350) ,
    @LabelHtmlPath nvarchar (350)
)
AS
    INSERT INTO UpsPackages
    (
        ShipmentID,
        PackagingTypeCode,
        Length,
        Width,
        Height,
        Weight,
        AdditionalHandling,
        DeliveryConfirmation,
        DeliveryConfirmationType,
        Insurance,
        InsuredValue,
        COD,
        CODFundsCode,
        CODAmount,
        TrackingNumber,
        LabelImageFull,
        LabelImageLabel,
        LabelImageEpl,
        LabelWarsawPath,
        LabelHtmlPath
    )
    VALUES
    (
        @ShipmentID,
        @PackagingTypeCode,
        @Length,
        @Width,
        @Height,
        @Weight,
        @AdditionalHandling,
        @DeliveryConfirmation,
        @DeliveryConfirmationType,
        @Insurance,
        @InsuredValue,
        @COD,
        @CODFundsCode,
        @CODAmount,
        @TrackingNumber,
        @LabelImageFull,
        @LabelImageLabel,
        @LabelImageEpl,
        @LabelWarsawPath,
        @LabelHtmlPath
    )
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT UpsPackageID, [RowVersion]
      FROM UpsPackages
      WHERE UpsPackageID = SCOPE_IDENTITY()

    return 1
GO

-----------------------------
--- Procedure UpdateUpsPackage
-----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateUpsPackage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateUpsPackage]
GO

CREATE PROCEDURE UpdateUpsPackage
(
    @UpsPackageID int,
    @RowVersion timestamp,
    @ShipmentID int,
    @PackagingTypeCode nvarchar (10),
    @Length int,
    @Width int,
    @Height int,
    @Weight float,
    @AdditionalHandling bit,
    @DeliveryConfirmation bit,
    @DeliveryConfirmationType nvarchar (15),
    @Insurance bit,
    @InsuredValue money,
    @COD bit,
    @CODFundsCode nvarchar (10),
    @CODAmount money,
    @TrackingNumber nvarchar (50),
    @LabelImageFull nvarchar (350) ,
    @LabelImageLabel nvarchar (350) ,
    @LabelImageEpl nvarchar (350) ,
    @LabelWarsawPath nvarchar (350) ,
    @LabelHtmlPath nvarchar (350)
)
AS
    UPDATE UpsPackages
    SET ShipmentID = @ShipmentID,
        PackagingTypeCode = @PackagingTypeCode,
        Length = @Length,
        Width = @Width,
        Height = @Height,
        Weight = @Weight,
        AdditionalHandling = @AdditionalHandling,
        DeliveryConfirmation = @DeliveryConfirmation,
        DeliveryConfirmationType = @DeliveryConfirmationType,
        Insurance = @Insurance,
        InsuredValue = @InsuredValue,
        COD = @COD,
        CODFundsCode = @CODFundsCode,
        CODAmount = @CODAmount,
        TrackingNumber = @TrackingNumber,
        LabelImageFull = @LabelImageFull,
        LabelImageLabel = @LabelImageLabel,
        LabelImageEpl = @LabelImageEpl,
        LabelWarsawPath = @LabelWarsawPath,
        LabelHtmlPath = @LabelHtmlPath
    WHERE UpsPackageID = @UpsPackageID AND [RowVersion] = @RowVersion
    
    if (@@ROWCOUNT != 1)
        return 0

    SET NOCOUNT ON

    SELECT UpsPackageID, [RowVersion]
      FROM UpsPackages
      WHERE UpsPackageID = @UpsPackageID

    return 1
GO

 