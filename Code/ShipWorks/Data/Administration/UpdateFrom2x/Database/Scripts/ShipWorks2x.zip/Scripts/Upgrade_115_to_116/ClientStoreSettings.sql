ALTER TABLE ClientStoreSettings DROP COLUMN DownloadNewPlaySound
GO
ALTER TABLE ClientStoreSettings DROP COLUMN DownloadNewPlaySoundFile
GO
ALTER TABLE ClientStoreSettings DROP COLUMN DownloadNewSendEmail
GO
ALTER TABLE ClientStoreSettings DROP COLUMN DownloadNewSendEmailTemplate
GO
ALTER TABLE ClientStoreSettings DROP COLUMN DownloadNewPrint
GO
ALTER TABLE ClientStoreSettings DROP COLUMN DownloadNewPrintTemplate
GO
ALTER TABLE ClientStoreSettings DROP COLUMN DownloadErrorPlaySound
GO
ALTER TABLE ClientStoreSettings DROP COLUMN DownloadErrorPlaySoundFile
GO

----------------------------
--- PROCEDURE GetAllClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetAllClientStoreSettings]
GO

CREATE PROCEDURE GetAllClientStoreSettings
AS
   SELECT *
   FROM [ClientStoreSettings]
GO

----------------------------
--- PROCEDURE DeleteClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteClientStoreSettings]
GO

CREATE PROCEDURE DeleteClientStoreSettings
(
   @ClientID int,
   @StoreID int
)
AS
   DELETE FROM [ClientStoreSettings]
   WHERE 
      [ClientID] = @ClientID AND
      [StoreID] = @StoreID
GO

----------------------------
--- PROCEDURE AddClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddClientStoreSettings]
GO

CREATE PROCEDURE AddClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 nvarchar (50),
   @WorldShipReferenceNumber2 nvarchar (50),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaUnattendedPrinting bit,
   @EndiciaSpecifyLayout bit,
   @EndiciaDefaultLayoutFile nvarchar(350),
   @EndiciaStealthMode bit,
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @EndiciaRubberStamp1 nvarchar(50),
   @EndiciaRubberStamp2 nvarchar(50),
   @EndiciaRubberStamp3 nvarchar(50),
   @EndiciaRubberStamp4 nvarchar(50),
   @EndiciaRubberStamp5 nvarchar(50),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int
)
AS
   INSERT INTO [ClientStoreSettings]
   (
        [ClientID], 
        [StoreID], 
        [LicenseKey], 
        [PerfDateRangeType],
        [PerfDateRangeDays], 
        [PerfDateRangeMax], 
        [PerfDateRangeMin], 
        [PerfShowFilterCounts],
        [WolrdShipCsvFilename], 
        [WorldShipOutputType], 
        [WorldShipLaunchAfterExport], 
        [WorldShipReferenceNumber1],
        [WorldShipReferenceNumber2],
        [WorldShipQvnFromName],
        [WorldShipQvnSubject],
        [WorldShipQvnMemo],
        [WorldShipQvnFailedAddress],
        [WorldShipQvnShipNotify],
        [WorldShipQvnDeliveryNotify],
        [WorldShipQvnExceptionNotify],
        [StampsDefaultService],
        [StampsDefaultConfirmation],
        [StampsMailpiece],
        [StampsLabelSheet],
        [StampsHidePostage],
        [StampsMemo],
        [EndiciaSetService], 
        [EndiciaSetConfirmation], 
        [EndiciaSetWeight], 
        [EndiciaSetDate], 
        [EndiciaDefaultDomesticService], 
        [EndiciaDefaultInternationalService],
        [EndiciaDefaultConfirmation], 
        [EndiciaDefaultDateAdvance], 
        [EndiciaUnattendedPrinting], 
        [EndiciaSpecifyLayout], 
        [EndiciaDefaultLayoutFile], 
        [EndiciaStealthMode],
        [EndiciaTestMode], 
        [EndiciaCloseOnComplete], 
        [EndiciaRubberStamp1],
        [EndiciaRubberStamp2],
        [EndiciaRubberStamp3],
        [EndiciaRubberStamp4],
        [EndiciaRubberStamp5],
        [UspsDefaultService], 
        [UspsDefaultConfirmation], 
        [UspsDefaultRequestAddressService], 
        [UspsDefaultSendConfirmationEmail], 
        [UspsUseLiveServer], 
        [UspsDefaultTemplate], 
        [DownloadAllowed],
	    [DownloadAutoEnable],
	    [DownloadAutoInterval]
   )
   VALUES 
   (
        @ClientID, 
        @StoreID, 
        @LicenseKey, 
        @PerfDateRangeType,
        @PerfDateRangeDays, 
        @PerfDateRangeMax, 
        @PerfDateRangeMin, 
        @PerfShowFilterCounts,
        @WolrdShipCsvFilename, 
        @WorldShipOutputType, 
        @WorldShipLaunchAfterExport, 
        @WorldShipReferenceNumber1,
        @WorldShipReferenceNumber2,
        @WorldShipQvnFromName,
        @WorldShipQvnSubject,
        @WorldShipQvnMemo,
        @WorldShipQvnFailedAddress,
        @WorldShipQvnShipNotify,
        @WorldShipQvnDeliveryNotify,
        @WorldShipQvnExceptionNotify,
        @StampsDefaultService,
        @StampsDefaultConfirmation,
        @StampsMailpiece,
        @StampsLabelSheet,
        @StampsHidePostage,
        @StampsMemo,
        @EndiciaSetService, 
        @EndiciaSetConfirmation, 
        @EndiciaSetWeight, 
        @EndiciaSetDate, 
        @EndiciaDefaultDomesticService, 
        @EndiciaDefaultInternationalService,
        @EndiciaDefaultConfirmation, 
        @EndiciaDefaultDateAdvance, 
        @EndiciaUnattendedPrinting, 
        @EndiciaSpecifyLayout, 
        @EndiciaDefaultLayoutFile, 
        @EndiciaStealthMode,
        @EndiciaTestMode, 
        @EndiciaCloseOnComplete, 
        @EndiciaRubberStamp1,
        @EndiciaRubberStamp2,
        @EndiciaRubberStamp3,
        @EndiciaRubberStamp4,
        @EndiciaRubberStamp5,
        @UspsDefaultService, 
        @UspsDefaultConfirmation, 
        @UspsDefaultRequestAddressService, 
        @UspsDefaultSendConfirmationEmail, 
        @UspsUseLiveServer, 
        @UspsDefaultTemplate, 
        @DownloadAllowed,
	    @DownloadAutoEnable,
	    @DownloadAutoInterval
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT RowVersion
   FROM ClientStoreSettings
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateClientStoreSettings]
GO

CREATE PROCEDURE UpdateClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 nvarchar (50),
   @WorldShipReferenceNumber2 nvarchar (50),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @EndiciaSetService bit,
   @EndiciaSetConfirmation bit,
   @EndiciaSetWeight bit,
   @EndiciaSetDate bit,
   @EndiciaDefaultDomesticService int,
   @EndiciaDefaultInternationalService int,
   @EndiciaDefaultConfirmation int,
   @EndiciaDefaultDateAdvance int,
   @EndiciaUnattendedPrinting bit,
   @EndiciaSpecifyLayout bit,
   @EndiciaDefaultLayoutFile nvarchar(350),
   @EndiciaStealthMode bit,
   @EndiciaTestMode bit,
   @EndiciaCloseOnComplete bit,
   @EndiciaRubberStamp1 nvarchar(50),
   @EndiciaRubberStamp2 nvarchar(50),
   @EndiciaRubberStamp3 nvarchar(50),
   @EndiciaRubberStamp4 nvarchar(50),
   @EndiciaRubberStamp5 nvarchar(50),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsUseLiveServer bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int
)
AS
   UPDATE [ClientStoreSettings]
   SET 
    [LicenseKey] = @LicenseKey, 
    [PerfDateRangeType] = @PerfDateRangeType,
    [PerfDateRangeDays] = @PerfDateRangeDays, 
    [PerfDateRangeMax] = @PerfDateRangeMax, 
    [PerfDateRangeMin] = @PerfDateRangeMin, 
    [PerfShowFilterCounts] = @PerfShowFilterCounts,
    [WolrdShipCsvFilename] = @WolrdShipCsvFilename, 
    [WorldShipOutputType] = @WorldShipOutputType, 
    [WorldShipLaunchAfterExport] = @WorldShipLaunchAfterExport, 
    [WorldShipReferenceNumber1] = @WorldShipReferenceNumber1,
    [WorldShipReferenceNumber2] = @WorldShipReferenceNumber2,
    [WorldShipQvnFromName] = @WorldShipQvnFromName,
    [WorldShipQvnSubject] = @WorldShipQvnSubject,
    [WorldShipQvnMemo] = @WorldShipQvnMemo,
    [WorldShipQvnFailedAddress] = @WorldShipQvnFailedAddress,
    [WorldShipQvnShipNotify] = @WorldShipQvnShipNotify,
    [WorldShipQvnDeliveryNotify] = @WorldShipQvnDeliveryNotify,
    [WorldShipQvnExceptionNotify] = @WorldShipQvnExceptionNotify,
    [StampsDefaultService] = @StampsDefaultService,
    [StampsDefaultConfirmation] = @StampsDefaultConfirmation,
    [StampsMailpiece] = @StampsMailpiece,
    [StampsLabelSheet] = @StampsLabelSheet,
    [StampsHidePostage] = @StampsHidePostage,
    [StampsMemo] = @StampsMemo,
    [EndiciaSetService] = @EndiciaSetService, 
    [EndiciaSetConfirmation] = @EndiciaSetConfirmation, 
    [EndiciaSetWeight] = @EndiciaSetWeight, 
    [EndiciaSetDate] = @EndiciaSetDate, 
    [EndiciaDefaultDomesticService] = @EndiciaDefaultDomesticService, 
    [EndiciaDefaultInternationalService] = @EndiciaDefaultInternationalService,
    [EndiciaDefaultConfirmation] = @EndiciaDefaultConfirmation, 
    [EndiciaDefaultDateAdvance] = @EndiciaDefaultDateAdvance, 
    [EndiciaUnattendedPrinting] = @EndiciaUnattendedPrinting, 
    [EndiciaSpecifyLayout] = @EndiciaSpecifyLayout, 
    [EndiciaDefaultLayoutFile] = @EndiciaDefaultLayoutFile,
    [EndiciaStealthMode] = @EndiciaStealthMode, 
    [EndiciaTestMode] = @EndiciaTestMode, 
    [EndiciaCloseOnComplete] = @EndiciaCloseOnComplete, 
    [EndiciaRubberStamp1] = @EndiciaRubberStamp1,
    [EndiciaRubberStamp2] = @EndiciaRubberStamp2,
    [EndiciaRubberStamp3] = @EndiciaRubberStamp3,
    [EndiciaRubberStamp4] = @EndiciaRubberStamp4,
    [EndiciaRubberStamp5] = @EndiciaRubberStamp5,
    [UspsDefaultService] = @UspsDefaultService, 
    [UspsDefaultConfirmation] = @UspsDefaultConfirmation, 
    [UspsDefaultRequestAddressService] = @UspsDefaultRequestAddressService, 
    [UspsDefaultSendConfirmationEmail] = @UspsDefaultSendConfirmationEmail, 
    [UspsUseLiveServer] = @UspsUseLiveServer, 
    [UspsDefaultTemplate] = @UspsDefaultTemplate, 
    [DownloadAllowed] = @DownloadAllowed,
    [DownloadAutoEnable] = @DownloadAutoEnable,
    [DownloadAutoInterval] = @DownloadAutoInterval
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM [ClientStoreSettings]
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID

   return 1
GO