ALTER TABLE dbo.[Stores] 
	ALTER COLUMN [StorePassword] [nvarchar] (80) NOT NULL
GO

----------------------------
--- PROCEDURE GetAllStores
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllStores]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure dbo.[GetAllStores]
GO

CREATE PROCEDURE dbo.GetAllStores
WITH ENCRYPTION
AS
   SELECT
	    StoreID,
	    RowVersion,
        StoreType, 
        StoreName, 
        LicenseKey,
        CompanyName, 
        CompanyAddress1, 
        CompanyAddress2, 
        CompanyAddress3, 
        CompanyCity, 
        CompanyStateProvCode, 
        CompanyPostalCode, 
        CompanyCountryCode, 
        CompanyUrl, 
        CompanyFax, 
        CompanyPhone, 
        CompanyEmail, 
        CompanyLogo,
        LastUpdateTime, 
        DownloadAddressCasing,
        EmailDefaultAccountID, 
        EmailLogSaveMessage,
        EmailLogSaveMessageImages,
        FilterLayout,
        OrderStatusStrings, 
        ItemStatusStrings, 
        OrderNumberPrefix,
        OrderNumberPostfix,
        StoreUsername, 
        StorePassword, 
        StoreSavePassword, 
        MivaPassphrase, 
        MivaSiteID, 
        MivaModuleUrl, 
        MivaStoreCode, 
        MivaConnectSecure, 
        MivaRemovedDeletedBatches, 
        MivaSebenzaExtraMsg, 
        MivaLiveManualOrderNumbers,
        MivaStatusCodes,
        MivaSebenzaOrderStatus,
        MivaSebenzaOrderStatusEmail,
        eBayUserID, 
        eBayToken, 
        eBayTokenExpire,
        eBayDownloadItemDetails,
        eBayDownloadPayPalDetails,
        PayPalApiUsername,
        PayPalApiPassword,
        PayPalApiSignature,
		PayPalApiCredentialType,	
		ShopSiteCgiUrl,
		ShopSiteConnectSecure,
		ShopSiteTimeZoneID,
        YahooPopServer,
        YahooTrackingEmailAccountID,
        YahooTrackingEmailPassword,
        MarketWorksAccountType,
        MarketWorksDownloadFlags,
        osCommerceModuleUrl,
        osCommerceStatusCodes,
        ProStoresStoreName,
        ProStoresAdminUrl,
        ProStoresXteUrl,
        ProStoresPrefix,
		ProStoresApiEntryPoint,
		ProStoresApiXml,
		ProStoresApiRestSecure,
		ProStoresApiScriptSuffix,
		ProStoresApiToken,
        ChannelAdvisorProfileID,
        ChannelAdvisorTimeZone,
        ChannelAdvisorTimeZoneDst,
        ChannelAdvisorLastReportTime,
        ChannelAdvisorXmlApiUsername,
        ChannelAdvisorXmlApiPassword,
        ChannelAdvisorDateFormat,
        ChannelAdvisorWeightUnit,
        ChannelAdvisorAccountKey,
        InfopiaToken,
        AmazonMerchantName,
        AmazonMerchantToken,
        AmazonAccessKeyID,
        AmazonCertificateName,
	    AmazonCookie,
	    AmazonCookieExpires,
	    AmazonCookieWaitUntil,
	    AmazonWeightDownloads,
	    XCartModuleUrl,
	    XCartStatusCodes,
	    OrderMotionPopServer,
	    OrderMotionBizID,
	    OrderMotionUrl,
	    ClickCartProUrl,
	    ClickCartProStatusCodes,
	    PayPalLastTransactionDate,
	    VolusionUrl,
	    VolusionEncryptedPassword,
	    VolusionPaymentMethods, 
	    VolusionShippingMethods,
	    VolusionTimeZone,
	    VolusionTimeZoneDst,
	    NetworkSolutionsUserToken,
	    NetworkSolutionsStatusCodes,
	    NetworkSolutionsDownloadStatus,
	    MagentoModuleUrl,
	    MagentoStatusCodes,
	    MagentoStoreCode,
	    MagentoTrackingEmails,
	    OrderDynamicsLicense,
	    AuctionSoundClient,
	    AmeriCommerceUrl,
	    AmeriCommerceStatusCodes,
	    AmeriCommerceStoreID,
	    CommerceInterfaceUrl,
	    CommerceInterfaceStatusCodes
	FROM [Stores]
GO

----------------------------
--- PROCEDURE DeleteStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure dbo.[DeleteStore]
GO

CREATE PROCEDURE dbo.DeleteStore
(
   @StoreID int
)
WITH ENCRYPTION
AS
   DELETE OrderItemAttributes
     FROM OrderItemAttributes a, OrderItems i, Orders o
     WHERE a.OrderItemID = i.OrderItemID AND i.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE OrderItems
     FROM OrderItems i, Orders o
     WHERE i.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE OrderCharges
     FROM OrderCharges c, Orders o
     WHERE c.OrderID = o.OrderID AND o.StoreID = @StoreID

   DELETE PaymentDetails
     FROM PaymentDetails p, Orders o
     WHERE p.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE MivaSebenzaMsgs
     FROM MivaSebenzaMsgs m, Orders o
     WHERE m.OrderID = o.OrderID AND o.StoreID = @StoreID
     
   DELETE UpsPackages
     FROM UpsPackages p, Shipments s
     WHERE p.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE UpsShipments
     FROM UpsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE FedexPackages
     FROM FedexPackages p, Shipments s
     WHERE p.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE FedexShipments
     FROM FedexShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID
     
   DELETE UspsPackages
     FROM UspsPackages p, Shipments s
     WHERE p.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE UspsShipments
     FROM UspsShipments u, Shipments s
     WHERE u.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE ShipmentCommodities
     FROM ShipmentCommodities c, Shipments s
     WHERE c.ShipmentID = s.ShipmentID AND s.StoreID = @StoreID

   DELETE Shipments
     FROM Shipments s
     WHERE s.StoreID = @StoreID
     
   DELETE FROM UpsPreferences
     WHERE [StoreID] = @StoreID
     
   DELETE From FedexPreferences
     WHERE [StoreID] = @StoreID
   
   DELETE From EndiciaPreferences
     WHERE [StoreID] = @StoreID

   DELETE From DhlPreferences
	 WHERE [StoreID] = @StoreID
	 
   DELETE FROM EmailAccounts
     WHERE [StoreID] = @StoreID
  
   DELETE FROM Orders
     WHERE [StoreID] = @StoreID

   DELETE FROM Downloaded
     WHERE [StoreID] = @StoreID
     
   DELETE FROM MivaBatches
     WHERE [StoreID] = @StoreID
     
   DELETE FROM DownloadLog
     WHERE [StoreID] = @StoreID
     
   DELETE FROM EmailLog
     WHERE [StoreID] = @StoreID
    
    DELETE FROM Actions
     WHERE [StoreID] = @StoreID
 
    DELETE FROM Notifications
     WHERE [StoreID] = @StoreID
     
    DELETE FROM AmazonInventory
     WHERE [StoreID] = @StoreID
     
   DELETE FROM YahooInventory
     WHERE [StoreID] = @StoreID

   DELETE FROM Customers
     WHERE [StoreID] = @StoreID   
     
   DELETE FROM [Stores]
     WHERE [StoreID] = @StoreID
     
GO

----------------------------
--- PROCEDURE AddStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddStore]
GO

CREATE PROCEDURE dbo.AddStore
(
   @StoreType int,  
   @StoreName nvarchar(75),
   @LicenseKey nvarchar (150),  
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int,  
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit,
   @FilterLayout text,
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(80),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit, 
   @MivaLiveManualOrderNumbers bit,
   @MivaStatusCodes text,
   @MivaSebenzaOrderStatus bit,
   @MivaSebenzaOrderStatusEmail bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @eBayDownloadPayPalDetails bit,
   @PayPalApiUsername nvarchar (80),
   @PayPalApiPassword nvarchar (80),
   @PayPalApiSignature nvarchar (80),
   @PayPalApiCredentialType smallint,	
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @YahooTrackingEmailAccountID int,
   @YahooTrackingEmailPassword varchar(30),
   @MarketWorksAccountType smallint,
   @MarketWorksDownloadFlags int,
   @osCommerceModuleUrl nvarchar (300),
   @osCommerceStatusCodes text,
   @ProStoresStoreName varchar(30),
   @ProStoresAdminUrl varchar(100),
   @ProStoresXteUrl varchar(75),
   @ProStoresPrefix varchar(30),
   @ProStoresApiEntryPoint nvarchar(300),
   @ProStoresApiXml nvarchar(300),
   @ProStoresApiRestSecure nvarchar(300),
   @ProStoresApiScriptSuffix nvarchar(50),
   @ProStoresApiToken text,
   @ChannelAdvisorProfileID int,
   @ChannelAdvisorTimeZone int,
   @ChannelAdvisorTimeZoneDst bit,
   @ChannelAdvisorLastReportTime datetime,
   @ChannelAdvisorXmlApiUsername varchar(50),
   @ChannelAdvisorXmlApiPassword varchar(50),
   @ChannelAdvisorDateFormat varchar(20),
   @ChannelAdvisorWeightUnit smallint,
   @ChannelAdvisorAccountKey varchar(50),
   @InfopiaToken varchar(128),
   @AmazonMerchantName varchar(64),
   @AmazonMerchantToken varchar(32),
   @AmazonAccessKeyID varchar(32),
   @AmazonCertificateName varchar(32),
   @AmazonCookie text,
   @AmazonCookieExpires datetime,
   @AmazonCookieWaitUntil datetime,
   @AmazonWeightDownloads text,
   @XCartModuleUrl nvarchar(300),
   @XCartStatusCodes text,
   @OrderMotionPopServer nvarchar(150),
   @OrderMotionBizID text,
   @OrderMotionUrl nvarchar(300),
   @ClickCartProUrl nvarchar(300),
   @ClickCartProStatusCodes TEXT,
   @PayPalLastTransactionDate datetime,
   @VolusionUrl nvarchar(300), 
   @VolusionEncryptedPassword nvarchar(100),
   @VolusionPaymentMethods text,
   @VolusionShippingMethods text,
   @VolusionTimeZone int,
   @VolusionTimeZoneDst bit,
   @NetworkSolutionsUserToken varchar(50),
   @NetworkSolutionsStatusCodes text,
   @NetworkSolutionsDownloadStatus int,
   @MagentoModuleUrl nvarchar(300),
   @MagentoStatusCodes TEXT,
   @MagentoStoreCode varchar(20),
   @MagentoTrackingEmails bit,
   @OrderDynamicsLicense varchar(40),
   @AuctionSoundClient varchar(20),
   @AmeriCommerceUrl varchar(300),
   @AmeriCommerceStatusCodes TEXT,
   @AmeriCommerceStoreID int,
   @CommerceInterfaceUrl  varchar(300),
   @CommerceInterfaceStatusCodes TEXT
)
WITH ENCRYPTION
AS
   INSERT INTO [Stores]
   (
        [StoreType], 
        [StoreName], 
        [LicenseKey],
        [CompanyName], 
        [CompanyAddress1], 
        [CompanyAddress2], 
        [CompanyAddress3], 
        [CompanyCity], 
        [CompanyStateProvCode], 
        [CompanyPostalCode], 
        [CompanyCountryCode], 
        [CompanyUrl], 
        [CompanyFax], 
        [CompanyPhone], 
        [CompanyEmail], 
        [CompanyLogo],
        [LastUpdateTime], 
        [DownloadAddressCasing],
        [EmailDefaultAccountID], 
        [EmailLogSaveMessage],
        [EmailLogSaveMessageImages],
        FilterLayout,
        [OrderStatusStrings], 
        [ItemStatusStrings], 
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [StoreUsername], 
        [StorePassword], 
        [StoreSavePassword], 
        [MivaPassphrase], 
        [MivaSiteID], 
        [MivaModuleUrl], 
        [MivaStoreCode], 
        [MivaConnectSecure], 
        [MivaRemovedDeletedBatches], 
        [MivaSebenzaExtraMsg], 
        [MivaLiveManualOrderNumbers],
        MivaStatusCodes,
        MivaSebenzaOrderStatus,
        MivaSebenzaOrderStatusEmail,
        [eBayUserID], 
        [eBayToken], 
        [eBayTokenExpire],
        [eBayDownloadItemDetails],
        eBayDownloadPayPalDetails,
        PayPalApiUsername,
        PayPalApiPassword,
        PayPalApiSignature,
		PayPalApiCredentialType,	
		[ShopSiteCgiUrl],
		[ShopSiteConnectSecure],
		[ShopSiteTimeZoneID],
        [YahooPopServer],
        YahooTrackingEmailAccountID,
        YahooTrackingEmailPassword,
        [MarketWorksAccountType],
        MarketWorksDownloadFlags,
        osCommerceModuleUrl,
        osCommerceStatusCodes,
        ProStoresStoreName,
        ProStoresAdminUrl,
        ProStoresXteUrl,
        ProStoresPrefix,
        ProStoresApiEntryPoint,
	    ProStoresApiXml,
	    ProStoresApiRestSecure,
	    ProStoresApiScriptSuffix,
	    ProStoresApiToken,
        ChannelAdvisorProfileID,
        ChannelAdvisorTimeZone,
        ChannelAdvisorTimeZoneDst,
        ChannelAdvisorLastReportTime,
        ChannelAdvisorXmlApiUsername,
        ChannelAdvisorXmlApiPassword,
        ChannelAdvisorDateFormat,
        ChannelAdvisorWeightUnit,
        ChannelAdvisorAccountKey,
        InfopiaToken,
        AmazonMerchantName,
        AmazonMerchantToken,
        AmazonAccessKeyID,
        AmazonCertificateName,
        AmazonCookie,
        AmazonCookieExpires,
        AmazonCookieWaitUntil,
        AmazonWeightDownloads,
        XCartModuleUrl,
        XCartStatusCodes,
        OrderMotionPopServer,
        OrderMotionBizID,
        OrderMotionUrl,
        ClickCartProUrl,
        ClickCartProStatusCodes,
        PayPalLastTransactionDate,
        VolusionUrl,
        VolusionEncryptedPassword,
        VolusionPaymentMethods,
        VolusionShippingMethods,
        VolusionTimeZone,
        VolusionTimeZoneDst,
        NetworkSolutionsUserToken,
        NetworkSolutionsStatusCodes,
        NetworkSolutionsDownloadStatus,
        MagentoModuleUrl,
        MagentoStatusCodes,
        MagentoStoreCode,
        MagentoTrackingEmails,
        OrderDynamicsLicense,
        AuctionSoundClient,
        AmeriCommerceUrl,
        AmeriCommerceStatusCodes,
        AmeriCommerceStoreID,
        CommerceInterfaceUrl,
        CommerceInterfaceStatusCodes
   )
   VALUES 
   (
        @StoreType, 
        @StoreName, 
        @LicenseKey,
        @CompanyName, 
        @CompanyAddress1,
        @CompanyAddress2, 
        @CompanyAddress3, 
        @CompanyCity, 
        @CompanyStateProvCode, 
        @CompanyPostalCode, 
        @CompanyCountryCode, 
        @CompanyUrl, 
        @CompanyFax, 
        @CompanyPhone, 
        @CompanyEmail, 
        @CompanyLogo,
        @LastUpdateTime, 
        @DownloadAddressCasing,
        @EmailDefaultAccountID, 
        @EmailLogSaveMessage,
        @EmailLogSaveMessageImages,
        @FilterLayout,
        @OrderStatusStrings,
        @ItemStatusStrings, 
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @StoreUsername, 
        @StorePassword, 
        @StoreSavePassword, 
        @MivaPassphrase, 
        @MivaSiteID, 
        @MivaModuleUrl, 
        @MivaStoreCode, 
        @MivaConnectSecure, 
        @MivaRemovedDeletedBatches, 
        @MivaSebenzaExtraMsg, 
        @MivaLiveManualOrderNumbers,
        @MivaStatusCodes,
        @MivaSebenzaOrderStatus,
        @MivaSebenzaOrderStatusEmail,
        @eBayUserID, 
        @eBayToken, 
        @eBayTokenExpire,
        @eBayDownloadItemDetails,
        @eBayDownloadPayPalDetails,
        @PayPalApiUsername,
        @PayPalApiPassword,
        @PayPalApiSignature,
		@PayPalApiCredentialType,	
		@ShopSiteCgiUrl,
		@ShopSiteConnectSecure,
		@ShopSiteTimeZoneID,
        @YahooPopServer,
        @YahooTrackingEmailAccountID,
        @YahooTrackingEmailPassword,
        @MarketWorksAccountType,
        @MarketWorksDownloadFlags,
        @osCommerceModuleUrl,
        @osCommerceStatusCodes,
        @ProStoresStoreName,
        @ProStoresAdminUrl,
        @ProStoresXteUrl,
        @ProStoresPrefix,
		@ProStoresApiEntryPoint,
		@ProStoresApiXml,
		@ProStoresApiRestSecure,
		@ProStoresApiScriptSuffix,
		@ProStoresApiToken,
        @ChannelAdvisorProfileID,
        @ChannelAdvisorTimeZone,
        @ChannelAdvisorTimeZoneDst,
        @ChannelAdvisorLastReportTime,
        @ChannelAdvisorXmlApiUsername,
        @ChannelAdvisorXmlApiPassword,
        @ChannelAdvisorDateFormat,
        @ChannelAdvisorWeightUnit,
        @ChannelAdvisorAccountKey,
        @InfopiaToken,
        @AmazonMerchantName,
        @AmazonMerchantToken,
        @AmazonAccessKeyID,
        @AmazonCertificateName,
        @AmazonCookie,
        @AmazonCookieExpires,
        @AmazonCookieWaitUntil,
        @AmazonWeightDownloads,
        @XCartModuleUrl,
        @XCartStatusCodes,
        @OrderMotionPopServer,
        @OrderMotionBizID,
        @OrderMotionUrl,
        @ClickCartProUrl,
        @ClickCartProStatusCodes,
        @PayPalLastTransactionDate,
        @VolusionUrl,
        @VolusionEncryptedPassword,
        @VolusionPaymentMethods,
        @VolusionShippingMethods,
        @VolusionTimeZone,
        @VolusionTimeZoneDst,
        @NetworkSolutionsUserToken,
        @NetworkSolutionsStatusCodes,
        @NetworkSolutionsDownloadStatus,
        @MagentoModuleUrl,
        @MagentoStatusCodes,
        @MagentoStoreCode,
        @MagentoTrackingEmails,
        @OrderDynamicsLicense,
        @AuctionSoundClient,
        @AmeriCommerceUrl,
        @AmeriCommerceStatusCodes,
        @AmeriCommerceStoreID,
        @CommerceInterfaceUrl,
        @CommerceInterfaceStatusCodes
)
   
   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT StoreID, RowVersion
   FROM Stores
   WHERE StoreID = SCOPE_IDENTITY()

   return 1
GO

----------------------------
--- PROCEDURE ImportStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[ImportStore]
GO

CREATE PROCEDURE dbo.ImportStore
(
   @StoreID int,
   @StoreType int,  
   @StoreName nvarchar(75),
   @LicenseKey nvarchar (150),  
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int,  
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit,
   @FilterLayout text,
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(80),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit, 
   @MivaLiveManualOrderNumbers bit,
   @MivaStatusCodes text,
   @MivaSebenzaOrderStatus bit,
   @MivaSebenzaOrderStatusEmail bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @eBayDownloadPayPalDetails bit,
   @PayPalApiUsername nvarchar (80),
   @PayPalApiPassword nvarchar (80),
   @PayPalApiSignature nvarchar (80),
   @PayPalApiCredentialType smallint,	
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @YahooTrackingEmailAccountID int,
   @YahooTrackingEmailPassword varchar(30),
   @MarketWorksAccountType smallint,
   @MarketWorksDownloadFlags int,
   @osCommerceModuleUrl nvarchar (300),
   @osCommerceStatusCodes text,
   @ProStoresStoreName varchar(30),
   @ProStoresAdminUrl varchar(100),
   @ProStoresXteUrl varchar(75),
   @ProStoresPrefix varchar(30),
   @ProStoresApiEntryPoint nvarchar(300),
   @ProStoresApiXml nvarchar(300),
   @ProStoresApiRestSecure nvarchar(300),
   @ProStoresApiScriptSuffix nvarchar(50),
   @ProStoresApiToken text,
   @ChannelAdvisorProfileID int,
   @ChannelAdvisorTimeZone int,
   @ChannelAdvisorTimeZoneDst bit,
   @ChannelAdvisorLastReportTime datetime,
   @ChannelAdvisorXmlApiUsername varchar(50),
   @ChannelAdvisorXmlApiPassword varchar(50),
   @ChannelAdvisorDateFormat varchar(20),
   @ChannelAdvisorWeightUnit smallint,
   @ChannelAdvisorAccountKey varchar(50),
   @InfopiaToken varchar(128),
   @AmazonMerchantName varchar(64),
   @AmazonMerchantToken varchar(32),
   @AmazonAccessKeyID varchar(32),
   @AmazonCertificateName varchar(32),
   @AmazonCookie text,
   @AmazonCookieExpires datetime,
   @AmazonCookieWaitUntil datetime,
   @AmazonWeightDownloads text,
   @XCartModuleUrl nvarchar(300),
   @XCartStatusCodes text,
   @OrderMotionPopServer nvarchar(150),
   @OrderMotionBizID text,
   @OrderMotionUrl nvarchar(300),
   @ClickCartProUrl nvarchar(300),
   @ClickCartProStatusCodes TEXT,
   @PayPalLastTransactionDate datetime,
   @VolusionUrl nvarchar(300),
   @VolusionEncryptedPassword nvarchar(100),
   @VolusionPaymentMethods text,
   @VolusionShippingMethods text,
   @VolusionTimeZone int,
   @VolusionTimeZoneDst bit,
   @NetworkSolutionsUserToken varchar(50),
   @NetworkSolutionsStatusCodes text,
   @NetworkSolutionsDownloadStatus int,
   @MagentoModuleUrl nvarchar(300),
   @MagentoStatusCodes TEXT,
   @MagentoStoreCode varchar(20),
   @MagentoTrackingEmails bit,
   @OrderDynamicsLicense varchar(40),
   @AuctionSoundClient varchar(20),
   @AmeriCommerceUrl varchar(300),
   @AmeriCommerceStatusCodes TEXT,
   @AmeriCommerceStoreID int,
   @CommerceInterfaceUrl varchar(300),
   @CommerceInterfaceStatusCodes TEXT
   
)
WITH ENCRYPTION
AS
   SET IDENTITY_INSERT dbo.Stores ON
   INSERT INTO [Stores]
   (
	    [StoreID],
        [StoreType], 
        [StoreName], 
        [LicenseKey],
        [CompanyName], 
        [CompanyAddress1], 
        [CompanyAddress2], 
        [CompanyAddress3], 
        [CompanyCity], 
        [CompanyStateProvCode], 
        [CompanyPostalCode], 
        [CompanyCountryCode], 
        [CompanyUrl], 
        [CompanyFax], 
        [CompanyPhone], 
        [CompanyEmail], 
        [CompanyLogo],
        [LastUpdateTime], 
        [DownloadAddressCasing],
        [EmailDefaultAccountID], 
        [EmailLogSaveMessage],
        [EmailLogSaveMessageImages],
        FilterLayout,
        [OrderStatusStrings], 
        [ItemStatusStrings], 
        [OrderNumberPrefix],
        [OrderNumberPostfix],
        [StoreUsername], 
        [StorePassword], 
        [StoreSavePassword], 
        [MivaPassphrase], 
        [MivaSiteID], 
        [MivaModuleUrl], 
        [MivaStoreCode], 
        [MivaConnectSecure], 
        [MivaRemovedDeletedBatches], 
        [MivaSebenzaExtraMsg], 
        [MivaLiveManualOrderNumbers],
        MivaStatusCodes,
        MivaSebenzaOrderStatus,
        MivaSebenzaOrderStatusEmail,
        [eBayUserID], 
        [eBayToken], 
        [eBayTokenExpire],
        [eBayDownloadItemDetails],
        eBayDownloadPayPalDetails,
        PayPalApiUsername,
        PayPalApiPassword,
        PayPalApiSignature,
		PayPalApiCredentialType,	
		[ShopSiteCgiUrl],
		[ShopSiteConnectSecure],
		[ShopSiteTimeZoneID],
        [YahooPopServer],
        YahooTrackingEmailAccountID,
        YahooTrackingEmailPassword,
        [MarketWorksAccountType],
        MarketWorksDownloadFlags,
        osCommerceModuleUrl,
        osCommerceStatusCodes,
        ProStoresStoreName,
        ProStoresAdminUrl,
        ProStoresXteUrl,
        ProStoresPrefix,
        ProStoresApiEntryPoint,
	    ProStoresApiXml,
	    ProStoresApiRestSecure,
	    ProStoresApiScriptSuffix,
	    ProStoresApiToken,
        ChannelAdvisorProfileID,
        ChannelAdvisorTimeZone,
        ChannelAdvisorTimeZoneDst,
        ChannelAdvisorLastReportTime,
        ChannelAdvisorXmlApiUsername,
        ChannelAdvisorXmlApiPassword,
        ChannelAdvisorDateFormat,
        ChannelAdvisorWeightUnit,
        ChannelAdvisorAccountKey,
        InfopiaToken,
        AmazonMerchantName,
        AmazonMerchantToken,
        AmazonAccessKeyID,
        AmazonCertificateName,
        AmazonCookie,
        AmazonCookieExpires,
        AmazonCookieWaitUntil,
        AmazonWeightDownloads,
        XCartModuleUrl,
        XCartStatusCodes,
        OrderMotionPopServer,
        OrderMotionBizID,
        OrderMotionUrl,
        ClickCartProUrl,
        ClickCartProStatusCodes,
        PayPalLastTransactionDate,
        VolusionUrl,
        VolusionEncryptedPassword,
        VolusionPaymentMethods,
        VolusionShippingMethods,
        VolusionTimeZone,
        VolusionTimeZoneDst,
        NetworkSolutionsUserToken,
        NetworkSolutionsStatusCodes,
        NetworkSolutionsDownloadStatus,
        MagentoModuleUrl,
        MagentoStatusCodes,
        MagentoStoreCode,
        MagentoTrackingEmails,
        OrderDynamicsLicense,
        AuctionSoundClient,
        AmeriCommerceUrl,
        AmeriCommerceStatusCodes,
        AmeriCommerceStoreID,
        CommerceInterfaceUrl,
        CommerceInterfaceStatusCodes
   )
   VALUES 
   (
		@StoreID,
        @StoreType, 
        @StoreName, 
        @LicenseKey,
        @CompanyName, 
        @CompanyAddress1,
        @CompanyAddress2, 
        @CompanyAddress3, 
        @CompanyCity, 
        @CompanyStateProvCode, 
        @CompanyPostalCode, 
        @CompanyCountryCode, 
        @CompanyUrl, 
        @CompanyFax, 
        @CompanyPhone, 
        @CompanyEmail, 
        @CompanyLogo,
        @LastUpdateTime, 
        @DownloadAddressCasing,
        @EmailDefaultAccountID, 
        @EmailLogSaveMessage,
        @EmailLogSaveMessageImages,
        @FilterLayout,
        @OrderStatusStrings,
        @ItemStatusStrings, 
        @OrderNumberPrefix,
        @OrderNumberPostfix,
        @StoreUsername, 
        @StorePassword, 
        @StoreSavePassword, 
        @MivaPassphrase, 
        @MivaSiteID, 
        @MivaModuleUrl, 
        @MivaStoreCode, 
        @MivaConnectSecure, 
        @MivaRemovedDeletedBatches, 
        @MivaSebenzaExtraMsg, 
        @MivaLiveManualOrderNumbers,
        @MivaStatusCodes,
        @MivaSebenzaOrderStatus,
        @MivaSebenzaOrderStatusEmail,
        @eBayUserID, 
        @eBayToken, 
        @eBayTokenExpire,
        @eBayDownloadItemDetails,
        @eBayDownloadPayPalDetails,
        @PayPalApiUsername,
        @PayPalApiPassword,
        @PayPalApiSignature,
		@PayPalApiCredentialType,	
		@ShopSiteCgiUrl,
		@ShopSiteConnectSecure,
		@ShopSiteTimeZoneID,
        @YahooPopServer,
        @YahooTrackingEmailAccountID,
        @YahooTrackingEmailPassword,
        @MarketWorksAccountType,
        @MarketWorksDownloadFlags,
        @osCommerceModuleUrl,
        @osCommerceStatusCodes,
        @ProStoresStoreName,
        @ProStoresAdminUrl,
        @ProStoresXteUrl,
        @ProStoresPrefix,
		@ProStoresApiEntryPoint,
		@ProStoresApiXml,
		@ProStoresApiRestSecure,
		@ProStoresApiScriptSuffix,
		@ProStoresApiToken,
        @ChannelAdvisorProfileID,
        @ChannelAdvisorTimeZone,
        @ChannelAdvisorTimeZoneDst,
        @ChannelAdvisorLastReportTime,
        @ChannelAdvisorXmlApiUsername,
        @ChannelAdvisorXmlApiPassword,
        @ChannelAdvisorDateFormat,
        @ChannelAdvisorWeightUnit,
        @ChannelAdvisorAccountKey,
        @InfopiaToken,
        @AmazonMerchantName,
        @AmazonMerchantToken,
        @AmazonAccessKeyID,
        @AmazonCertificateName,
        @AmazonCookie,
        @AmazonCookieExpires,
        @AmazonCookieWaitUntil,
        @AmazonWeightDownloads,
        @XCartModuleUrl,
        @XCartStatusCodes,
        @OrderMotionPopServer,
        @OrderMotionBizID,
        @OrderMotionUrl,
        @ClickCartProUrl,
        @ClickCartProStatusCodes,
        @PayPalLastTransactionDate,
        @VolusionUrl,
        @VolusionEncryptedPassword,
        @VolusionPaymentMethods,
        @VolusionShippingMethods,
        @VolusionTimeZone,
        @VolusionTimeZoneDst,
        @NetworkSolutionsUserToken,
        @NetworkSolutionsStatusCodes,
        @NetworkSolutionsDownloadStatus,
        @MagentoModuleUrl,
        @MagentoStatusCodes,
        @MagentoStoreCode,
        @MagentoTrackingEmails,
        @OrderDynamicsLicense,
        @AuctionSoundClient,
        @AmeriCommerceUrl,
        @AmeriCommerceStatusCodes,
        @AmeriCommerceStoreID,
        @CommerceInterfaceUrl,
        @CommerceInterfaceStatusCodes
)
SET IDENTITY_INSERT dbo.Stores OFF
GO

----------------------------
--- PROCEDURE SaveLastUpdateTime
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveLastUpdateTime]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveLastUpdateTime]
GO

CREATE PROCEDURE dbo.SaveLastUpdateTime
(
   @StoreID int,
   @LastUpdateTime datetime
)
WITH ENCRYPTION
AS
    UPDATE [Stores]
    SET [LastUpdateTime]=@LastUpdateTime
    WHERE [StoreID] = @StoreID

   SET NOCOUNT ON

   SELECT StoreID, RowVersion
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE SaveEmailSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SaveEmailSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[SaveEmailSettings]
GO

CREATE PROCEDURE dbo.SaveEmailSettings
(
   @StoreID int,
   @EmailDefaultAccountID int,
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit
)
WITH ENCRYPTION
AS
    UPDATE Stores
      SET EmailDefaultAccountID = @EmailDefaultAccountID,
          EmailLogSaveMessage = @EmailLogSaveMessage,
          EmailLogSaveMessageImages = @EmailLogSaveMessageImages
      WHERE StoreID = @StoreID

   SET NOCOUNT ON

   SELECT StoreID, RowVersion
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateStore
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateStore]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateStore]
GO

CREATE PROCEDURE dbo.UpdateStore
(
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @StoreType int,  
   @StoreName nvarchar(75),  
   @LicenseKey nvarchar (150),
   @CompanyName nvarchar(60), 
   @CompanyAddress1 nvarchar(60),  
   @CompanyAddress2 nvarchar(60),  
   @CompanyAddress3 nvarchar(60),  
   @CompanyCity nvarchar(50),  
   @CompanyStateProvCode nvarchar(5),  
   @CompanyPostalCode nvarchar(10),  
   @CompanyCountryCode nvarchar(5),  
   @CompanyUrl nvarchar(150),  
   @CompanyFax nvarchar(50),  
   @CompanyPhone nvarchar(50),  
   @CompanyEmail nvarchar(50),
   @CompanyLogo nvarchar(300),  
   @LastUpdateTime datetime,  
   @DownloadAddressCasing bit,
   @EmailDefaultAccountID int, 
   @EmailLogSaveMessage bit,
   @EmailLogSaveMessageImages bit, 
   @FilterLayout text,
   @OrderStatusStrings nvarchar(500),  
   @ItemStatusStrings nvarchar(500),  
   @OrderNumberPrefix nvarchar(10),
   @OrderNumberPostfix nvarchar(10),
   @StoreUsername nvarchar(50),  
   @StorePassword nvarchar(80),  
   @StoreSavePassword bit,  
   @MivaPassphrase nvarchar(50),  
   @MivaSiteID nchar(8),
   @MivaModuleUrl nvarchar(300),  
   @MivaStoreCode nvarchar(50),  
   @MivaConnectSecure bit,  
   @MivaRemovedDeletedBatches bit,  
   @MivaSebenzaExtraMsg bit,  
   @MivaLiveManualOrderNumbers bit,
   @MivaStatusCodes text,
   @MivaSebenzaOrderStatus bit,
   @MivaSebenzaOrderStatusEmail bit,
   @eBayUserID nvarchar(50),  
   @eBayToken text,  
   @eBayTokenExpire datetime,
   @eBayDownloadItemDetails bit,
   @eBayDownloadPayPalDetails bit,
   @PayPalApiUsername nvarchar (80),
   @PayPalApiPassword nvarchar (80),
   @PayPalApiSignature nvarchar (80),
   @PayPalApiCredentialType smallint,	
   @ShopSiteCgiUrl nvarchar (300),
   @ShopSiteConnectSecure bit,
   @ShopSiteTimeZoneID smallint,
   @YahooPopServer nvarchar (150),
   @YahooTrackingEmailAccountID int,
   @YahooTrackingEmailPassword varchar(30),
   @MarketWorksAccountType smallint,
   @MarketWorksDownloadFlags int,
   @osCommerceModuleUrl nvarchar (300),
   @osCommerceStatusCodes text,
   @ProStoresStoreName varchar(30),
   @ProStoresAdminUrl varchar(100),
   @ProStoresXteUrl varchar(75),
   @ProStoresPrefix varchar(30),
   @ProStoresApiEntryPoint nvarchar(300),
   @ProStoresApiXml nvarchar(300),
   @ProStoresApiRestSecure nvarchar(300),
   @ProStoresApiScriptSuffix nvarchar(50),
   @ProStoresApiToken text,
   @ChannelAdvisorProfileID int,
   @ChannelAdvisorTimeZone int,
   @ChannelAdvisorTimeZoneDst bit,
   @ChannelAdvisorLastReportTime datetime,
   @ChannelAdvisorXmlApiUsername varchar(50),
   @ChannelAdvisorXmlApiPassword varchar(50),
   @ChannelAdvisorDateFormat varchar(20),
   @ChannelAdvisorWeightUnit smallint,
   @ChannelAdvisorAccountKey varchar(50), 
   @InfopiaToken varchar(128),
   @AmazonMerchantName varchar(64),
   @AmazonMerchantToken varchar(32),
   @AmazonAccessKeyID varchar(32),
   @AmazonCertificateName varchar(32),
   @AmazonCookie text,
   @AmazonCookieExpires datetime,
   @AmazonCookieWaitUntil datetime,
   @AmazonWeightDownloads text,
   @XCartModuleUrl nvarchar(300),
   @XCartStatusCodes text,
   @OrderMotionPopServer nvarchar(150),
   @OrderMotionBizID text,
   @OrderMotionUrl nvarchar(300),
   @ClickCartProUrl nvarchar(300),
   @ClickCartProStatusCodes text,
   @PayPalLastTransactionDate datetime,
   @VolusionUrl nvarchar(300),
   @VolusionEncryptedPassword nvarchar(100),
   @VolusionPaymentMethods text,
   @VolusionShippingMethods text,
   @VolusionTimeZone int,
   @VolusionTimeZoneDst bit,
   @NetworkSolutionsUserToken varchar(50),
   @NetworkSolutionsStatusCodes text,
   @NetworkSolutionsDownloadStatus int,
   @MagentoModuleUrl nvarchar(300),
   @MagentoStatusCodes TEXT,
   @MagentoStoreCode varchar(20),
   @MagentoTrackingEmails bit,
   @OrderDynamicsLicense varchar(40),
   @AuctionSoundClient varchar(20),
   @AmeriCommerceUrl varchar(300),
   @AmeriCommerceStatusCodes TEXT,
   @AmeriCommerceStoreID int,
   @CommerceInterfaceUrl varchar(300),
   @CommerceInterfaceStatusCodes TEXT
)
WITH ENCRYPTION
AS
   UPDATE [Stores]
   SET [StoreType]=@StoreType, 
       [StoreName]=@StoreName, 
       [LicenseKey]=@LicenseKey,
       [CompanyName]=@CompanyName, 
       [CompanyAddress1]=@CompanyAddress1, 
       [CompanyAddress2]=@CompanyAddress2, 
       [CompanyAddress3]=@CompanyAddress3, 
       [CompanyCity]=@CompanyCity, 
       [CompanyStateProvCode]=@CompanyStateProvCode, 
       [CompanyPostalCode]=@CompanyPostalCode, 
       [CompanyCountryCode]=@CompanyCountryCode, 
       [CompanyUrl]=@CompanyUrl, 
       [CompanyFax]=@CompanyFax, 
       [CompanyPhone]=@CompanyPhone, 
       [CompanyEmail]=@CompanyEmail, 
       [CompanyLogo]=@CompanyLogo,
       [LastUpdateTime]=@LastUpdateTime, 
       [DownloadAddressCasing]=@DownloadAddressCasing,
       [EmailDefaultAccountID]=@EmailDefaultAccountID, 
       [EmailLogSaveMessage]=@EmailLogSaveMessage,
       [EmailLogSaveMessageImages]=@EmailLogSaveMessageImages,
       FilterLayout = @FilterLayout,
       [OrderStatusStrings]=@OrderStatusStrings, 
       [ItemStatusStrings]=@ItemStatusStrings, 
       [OrderNumberPrefix]=@OrderNumberPrefix,
       [OrderNumberPostfix]=@OrderNumberPostfix,
       [StoreUsername]=@StoreUsername, 
       [StorePassword]=@StorePassword, 
       [StoreSavePassword]=@StoreSavePassword, 
       [MivaPassphrase]=@MivaPassphrase, 
       [MivaSiteID]=@MivaSiteID,
       [MivaModuleUrl]=@MivaModuleUrl, 
       [MivaStoreCode]=@MivaStoreCode, 
       [MivaConnectSecure]=@MivaConnectSecure, 
       [MivaRemovedDeletedBatches]=@MivaRemovedDeletedBatches, 
       [MivaSebenzaExtraMsg]=@MivaSebenzaExtraMsg, 
       [MivaLiveManualOrderNumbers]=@MivaLiveManualOrderNumbers,
       MivaStatusCodes = @MivaStatusCodes,
       MivaSebenzaOrderStatus = @MivaSebenzaOrderStatus,
       MivaSebenzaOrderStatusEmail = @MivaSebenzaOrderStatusEmail,
       [eBayUserID]=@eBayUserID, 
       [eBayToken]=@eBayToken, 
       [eBayTokenExpire]=@eBayTokenExpire,
       [eBayDownloadItemDetails]=@eBayDownloadItemDetails,
       eBayDownloadPayPalDetails = @eBayDownloadPayPalDetails,
       PayPalApiUsername = @PayPalApiUsername,
       PayPalApiPassword = @PayPalApiPassword,
       PayPalApiSignature = @PayPalApiSignature,
	   PayPalApiCredentialType = @PayPalApiCredentialType,	
	   [ShopSiteCgiUrl]=@ShopSiteCgiUrl,
	   [ShopSiteConnectSecure]=@ShopSiteConnectSecure,
	   [ShopSiteTimeZoneID] = @ShopSiteTimeZoneID,
       [YahooPopServer]=@YahooPopServer,
       YahooTrackingEmailAccountID = @YahooTrackingEmailAccountID,
       YahooTrackingEmailPassword = @YahooTrackingEmailPassword,
       [MarketWorksAccountType] = @MarketWorksAccountType,
       MarketWorksDownloadFlags = @MarketWorksDownloadFlags,
       osCommerceModuleUrl = @osCommerceModuleUrl,
       osCommerceStatusCodes = @osCommerceStatusCodes,
       ProStoresStoreName = @ProStoresStoreName,
	   ProStoresAdminUrl = @ProStoresAdminUrl,
	   ProStoresXteUrl = @ProStoresXteUrl,
	   ProStoresPrefix = @ProStoresPrefix,
	   ProStoresApiEntryPoint = @ProStoresApiEntryPoint,
	   ProStoresApiXml = @ProStoresApiXml,
	   ProStoresApiRestSecure = @ProStoresApiRestSecure,
	   ProStoresApiScriptSuffix = @ProStoresApiScriptSuffix,
	   ProStoresApiToken = @ProStoresApiToken,
	   ChannelAdvisorProfileID = @ChannelAdvisorProfileID,
	   ChannelAdvisorTimeZone = @ChannelAdvisorTimeZone,
	   ChannelAdvisorTimeZoneDst = @ChannelAdvisorTimeZoneDst,
	   ChannelAdvisorLastReportTime = @ChannelAdvisorLastReportTime,
       ChannelAdvisorXmlApiUsername = @ChannelAdvisorXmlApiUsername,
       ChannelAdvisorXmlApiPassword = @ChannelAdvisorXmlApiPassword,
       ChannelAdvisorDateFormat = @ChannelAdvisorDateFormat,
       ChannelAdvisorWeightUnit = @ChannelAdvisorWeightUnit,
       ChannelAdvisorAccountKey = @ChannelAdvisorAccountKey,
       InfopiaToken = @InfopiaToken,
       AmazonMerchantName = @AmazonMerchantName,
       AmazonMerchantToken = @AmazonMerchantToken,
       AmazonAccessKeyID = @AmazonAccessKeyID,
       AmazonCertificateName = @AmazonCertificateName,
       AmazonCookie = @AmazonCookie,
       AmazonCookieExpires = @AmazonCookieExpires,
       AmazonCookieWaitUntil = @AmazonCookieWaitUntil,
       AmazonWeightDownloads = @AmazonWeightDownloads,
       XCartModuleUrl = @XCartModuleUrl,
       XCartStatusCodes = @XCartStatusCodes,
       OrderMotionPopServer = @OrderMotionPopServer,
       OrderMotionBizID = @OrderMotionBizID,
       OrderMotionUrl = @OrderMotionUrl,
       ClickCartProUrl = @ClickCartProUrl,
       ClickCartProStatusCodes = @ClickCartProStatusCodes,
       PayPalLastTransactionDate = @PayPalLastTransactionDate,
       VolusionUrl = @VolusionUrl,
       VolusionEncryptedPassword = @VolusionEncryptedPassword,
       VolusionPaymentMethods = @VolusionPaymentMethods,
       VolusionShippingMethods = @VolusionShippingMethods,
       VolusionTimeZone = @VolusionTimeZone,
       VolusionTimeZoneDst = @VolusionTimeZoneDst,
       NetworkSolutionsUserToken = @NetworkSolutionsUserToken,
       NetworkSolutionsStatusCodes = @NetworkSolutionsStatusCodes,
       NetworkSolutionsDownloadStatus = @NetworkSolutionsDownloadStatus,
       MagentoModuleUrl = @MagentoModuleUrl,
       MagentoStatusCodes = @MagentoStatusCodes,
       MagentoStoreCode = @MagentoStoreCode,
       MagentoTrackingEmails = @MagentoTrackingEmails,
       OrderDynamicsLicense = @OrderDynamicsLicense,
       AuctionSoundClient = @AuctionSoundClient,
       AmeriCommerceUrl = @AmeriCommerceUrl,
       AmeriCommerceStatusCodes = @AmeriCommerceStatusCodes,
       AmeriCommerceStoreID = @AmeriCommerceStoreID,
       CommerceInterfaceUrl = @CommerceInterfaceUrl,
       CommerceInterfaceStatusCodes = @CommerceInterfaceStatusCodes
    WHERE [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateFilterLayout
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateFilterLayout]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[UpdateFilterLayout]
GO

CREATE PROCEDURE dbo.UpdateFilterLayout
(
   @StoreID int,
   @FilterLayout text
)
WITH ENCRYPTION
AS

   -- We purposely leave out the StoreID test here so that the settings act as global, not per-store.
   UPDATE Stores
      SET FilterLayout = @FilterLayout
      WHERE -- StoreID = @StoreID and 
            not (FilterLayout LIKE @FilterLayout)
      
    if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM Stores
   WHERE [StoreID] = @StoreID

   return 1
GO
   

