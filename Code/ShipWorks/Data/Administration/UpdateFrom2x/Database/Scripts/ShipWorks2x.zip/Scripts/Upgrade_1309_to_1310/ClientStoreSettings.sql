ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Stores
GO

ALTER TABLE dbo.ClientStoreSettings
	DROP CONSTRAINT FK_ClientStoreSettings_Clients
GO

CREATE TABLE dbo.Tmp_ClientStoreSettings
	(
	ClientID int NOT NULL,
	StoreID int NOT NULL,
	RowVersion timestamp NOT NULL,
	LicenseKey nvarchar(150) NOT NULL,
	PerfDateRangeType int NOT NULL,
	PerfDateRangeDays int NOT NULL,
	PerfDateRangeMax datetime NOT NULL,
	PerfDateRangeMin datetime NOT NULL,
	PerfShowFilterCounts bit NOT NULL,
	WolrdShipCsvFilename nvarchar(350) NOT NULL,
	WorldShipOutputType int NOT NULL,
	WorldShipLaunchAfterExport bit NOT NULL,
	WorldShipReferenceNumber1 varchar(200) NOT NULL,
	WorldShipReferenceNumber2 varchar(200) NOT NULL,
	WorldShipQvnFromName nvarchar(30) NOT NULL,
	WorldShipQvnSubject int NOT NULL,
	WorldShipQvnMemo nvarchar(150) NOT NULL,
	WorldShipQvnFailedAddress nvarchar(50) NOT NULL,
	WorldShipQvnShipNotify bit NOT NULL,
	WorldShipQvnDeliveryNotify bit NOT NULL,
	WorldShipQvnExceptionNotify bit NOT NULL,
	WorldShipProcessOnExport bit NOT NULL,
	StampsDefaultService int NOT NULL,
	StampsDefaultConfirmation int NOT NULL,
	StampsMailpiece int NOT NULL,
	StampsLabelSheet int NOT NULL,
	StampsHidePostage bit NOT NULL,
	StampsMemo nvarchar(50) NOT NULL,
	UspsDefaultService int NOT NULL,
	UspsDefaultConfirmation int NOT NULL,
	UspsDefaultRequestAddressService bit NOT NULL,
	UspsDefaultSendConfirmationEmail bit NOT NULL,
	UspsDefaultTemplate nvarchar(50) NOT NULL,
	DownloadAllowed bit NOT NULL,
	DownloadAutoEnable bit NOT NULL,
	DownloadAutoInterval int NOT NULL,
	DisplayShipmentOwnerOrder varchar(200) NOT NULL,
	DisplayShipmentOwnerCustomer varchar(200) NOT NULL
	)
GO

IF EXISTS(SELECT * FROM dbo.ClientStoreSettings)
	 EXEC('INSERT INTO dbo.Tmp_ClientStoreSettings (ClientID, StoreID, LicenseKey, PerfDateRangeType, PerfDateRangeDays, PerfDateRangeMax, PerfDateRangeMin, PerfShowFilterCounts, WolrdShipCsvFilename, WorldShipOutputType, WorldShipLaunchAfterExport, WorldShipReferenceNumber1, WorldShipReferenceNumber2, WorldShipQvnFromName, WorldShipQvnSubject, WorldShipQvnMemo, WorldShipQvnFailedAddress, WorldShipQvnShipNotify, WorldShipQvnDeliveryNotify, WorldShipQvnExceptionNotify, WorldShipProcessOnExport, StampsDefaultService, StampsDefaultConfirmation, StampsMailpiece, StampsLabelSheet, StampsHidePostage, StampsMemo, UspsDefaultService, UspsDefaultConfirmation, UspsDefaultRequestAddressService, UspsDefaultSendConfirmationEmail, UspsDefaultTemplate, DownloadAllowed, DownloadAutoEnable, DownloadAutoInterval, DisplayShipmentOwnerOrder, DisplayShipmentOwnerCustomer)
		                                     SELECT ClientID, StoreID, LicenseKey, PerfDateRangeType, PerfDateRangeDays, PerfDateRangeMax, PerfDateRangeMin, PerfShowFilterCounts, WolrdShipCsvFilename, WorldShipOutputType, WorldShipLaunchAfterExport, WorldShipReferenceNumber1, WorldShipReferenceNumber2, WorldShipQvnFromName, WorldShipQvnSubject, WorldShipQvnMemo, WorldShipQvnFailedAddress, WorldShipQvnShipNotify, WorldShipQvnDeliveryNotify, WorldShipQvnExceptionNotify, 1,                        StampsDefaultService, StampsDefaultConfirmation, StampsMailpiece, StampsLabelSheet, StampsHidePostage, StampsMemo, UspsDefaultService, UspsDefaultConfirmation, UspsDefaultRequestAddressService, UspsDefaultSendConfirmationEmail, UspsDefaultTemplate, DownloadAllowed, DownloadAutoEnable, DownloadAutoInterval, DisplayShipmentOwnerOrder, DisplayShipmentOwnerCustomer FROM dbo.ClientStoreSettings WITH (HOLDLOCK TABLOCKX)')
GO

DROP TABLE dbo.ClientStoreSettings
GO

EXECUTE sp_rename N'dbo.Tmp_ClientStoreSettings', N'ClientStoreSettings', 'OBJECT' 
GO

ALTER TABLE dbo.ClientStoreSettings ADD CONSTRAINT
	PK_ClientStoreSettings PRIMARY KEY CLUSTERED 
	(
	ClientID,
	StoreID
	)
GO

ALTER TABLE dbo.ClientStoreSettings ADD CONSTRAINT
	FK_ClientStoreSettings_Clients FOREIGN KEY
	(
	ClientID
	) REFERENCES dbo.Clients
	(
	ClientID
	)
GO

ALTER TABLE dbo.ClientStoreSettings ADD CONSTRAINT
	FK_ClientStoreSettings_Stores FOREIGN KEY
	(
	StoreID
	) REFERENCES dbo.Stores
	(
	StoreID
	)
GO

----------------------------
--- PROCEDURE GetAllClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[GetAllClientStoreSettings]
GO

CREATE PROCEDURE dbo.GetAllClientStoreSettings
AS
   SELECT *
   FROM [ClientStoreSettings]
GO

----------------------------
--- PROCEDURE DeleteClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DeleteClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [DeleteClientStoreSettings]
GO

CREATE PROCEDURE dbo.DeleteClientStoreSettings
(
   @ClientID int,
   @StoreID int
)
AS
   DELETE FROM [ClientStoreSettings]
   WHERE 
      [ClientID] = @ClientID AND
      [StoreID] = @StoreID
GO

----------------------------
--- PROCEDURE AddClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[AddClientStoreSettings]
GO

CREATE PROCEDURE dbo.AddClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 varchar (200),
   @WorldShipReferenceNumber2 varchar (200),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @WorldShipProcessOnExport bit,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DisplayShipmentOwnerOrder varchar (200),
   @DisplayShipmentOwnerCustomer varchar (200)
)
AS
   INSERT INTO [ClientStoreSettings]
   (
        [ClientID], 
        [StoreID], 
        [LicenseKey], 
        [PerfDateRangeType],
        [PerfDateRangeDays], 
        [PerfDateRangeMax], 
        [PerfDateRangeMin], 
        [PerfShowFilterCounts],
        [WolrdShipCsvFilename], 
        [WorldShipOutputType], 
        [WorldShipLaunchAfterExport], 
        [WorldShipReferenceNumber1],
        [WorldShipReferenceNumber2],
        [WorldShipQvnFromName],
        [WorldShipQvnSubject],
        [WorldShipQvnMemo],
        [WorldShipQvnFailedAddress],
        [WorldShipQvnShipNotify],
        [WorldShipQvnDeliveryNotify],
        [WorldShipQvnExceptionNotify],
        WorldShipProcessOnExport,
        [StampsDefaultService],
        [StampsDefaultConfirmation],
        [StampsMailpiece],
        [StampsLabelSheet],
        [StampsHidePostage],
        [StampsMemo],
        [UspsDefaultService], 
        [UspsDefaultConfirmation], 
        [UspsDefaultRequestAddressService], 
        [UspsDefaultSendConfirmationEmail], 
        [UspsDefaultTemplate], 
        [DownloadAllowed],
	    [DownloadAutoEnable],
	    [DownloadAutoInterval],
	    DisplayShipmentOwnerOrder,
	    DisplayShipmentOwnerCustomer
   )
   VALUES 
   (
        @ClientID, 
        @StoreID, 
        @LicenseKey, 
        @PerfDateRangeType,
        @PerfDateRangeDays, 
        @PerfDateRangeMax, 
        @PerfDateRangeMin, 
        @PerfShowFilterCounts,
        @WolrdShipCsvFilename, 
        @WorldShipOutputType, 
        @WorldShipLaunchAfterExport, 
        @WorldShipReferenceNumber1,
        @WorldShipReferenceNumber2,
        @WorldShipQvnFromName,
        @WorldShipQvnSubject,
        @WorldShipQvnMemo,
        @WorldShipQvnFailedAddress,
        @WorldShipQvnShipNotify,
        @WorldShipQvnDeliveryNotify,
        @WorldShipQvnExceptionNotify,
        @WorldShipProcessOnExport,
        @StampsDefaultService,
        @StampsDefaultConfirmation,
        @StampsMailpiece,
        @StampsLabelSheet,
        @StampsHidePostage,
        @StampsMemo,
        @UspsDefaultService, 
        @UspsDefaultConfirmation, 
        @UspsDefaultRequestAddressService, 
        @UspsDefaultSendConfirmationEmail, 
        @UspsDefaultTemplate, 
        @DownloadAllowed,
	    @DownloadAutoEnable,
	    @DownloadAutoInterval,
	    @DisplayShipmentOwnerOrder,
	    @DisplayShipmentOwnerCustomer
   )

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT RowVersion
   FROM ClientStoreSettings
   WHERE ClientID = @ClientID AND StoreID = @StoreID

   return 1
GO

----------------------------
--- PROCEDURE UpdateClientStoreSettings
----------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateClientStoreSettings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   drop procedure [dbo].[UpdateClientStoreSettings]
GO

CREATE PROCEDURE dbo.UpdateClientStoreSettings
(
   @ClientID int,
   @StoreID int,
   @RowVersion timestamp,
   @IgnoreConcurrency bit,
   @LicenseKey nvarchar(150),
   @PerfDateRangeType int,
   @PerfDateRangeDays int,
   @PerfDateRangeMax datetime,
   @PerfDateRangeMin datetime,
   @PerfShowFilterCounts bit,
   @WolrdShipCsvFilename nvarchar(350),
   @WorldShipOutputType int,
   @WorldShipLaunchAfterExport bit,
   @WorldShipReferenceNumber1 varchar (200),
   @WorldShipReferenceNumber2 varchar (200),
   @WorldShipQvnFromName nvarchar (30) ,
   @WorldShipQvnSubject int ,
   @WorldShipQvnMemo nvarchar (150) ,
   @WorldShipQvnFailedAddress nvarchar (50) ,
   @WorldShipQvnShipNotify bit ,
   @WorldShipQvnDeliveryNotify bit ,
   @WorldShipQvnExceptionNotify bit ,
   @WorldShipProcessOnExport bit,
   @StampsDefaultService int,
   @StampsDefaultConfirmation int,
   @StampsMailpiece int,
   @StampsLabelSheet int,
   @StampsHidePostage bit,
   @StampsMemo nvarchar(50),
   @UspsDefaultService int,
   @UspsDefaultConfirmation int,
   @UspsDefaultRequestAddressService bit,
   @UspsDefaultSendConfirmationEmail bit,
   @UspsDefaultTemplate nvarchar(50),
   @DownloadAllowed bit,
   @DownloadAutoEnable bit,
   @DownloadAutoInterval int,
   @DisplayShipmentOwnerOrder varchar (200),
   @DisplayShipmentOwnerCustomer varchar (200)
)
AS
   UPDATE [ClientStoreSettings]
   SET 
    [LicenseKey] = @LicenseKey, 
    [PerfDateRangeType] = @PerfDateRangeType,
    [PerfDateRangeDays] = @PerfDateRangeDays, 
    [PerfDateRangeMax] = @PerfDateRangeMax, 
    [PerfDateRangeMin] = @PerfDateRangeMin, 
    [PerfShowFilterCounts] = @PerfShowFilterCounts,
    [WolrdShipCsvFilename] = @WolrdShipCsvFilename, 
    [WorldShipOutputType] = @WorldShipOutputType, 
    [WorldShipLaunchAfterExport] = @WorldShipLaunchAfterExport, 
    [WorldShipReferenceNumber1] = @WorldShipReferenceNumber1,
    [WorldShipReferenceNumber2] = @WorldShipReferenceNumber2,
    [WorldShipQvnFromName] = @WorldShipQvnFromName,
    [WorldShipQvnSubject] = @WorldShipQvnSubject,
    [WorldShipQvnMemo] = @WorldShipQvnMemo,
    [WorldShipQvnFailedAddress] = @WorldShipQvnFailedAddress,
    [WorldShipQvnShipNotify] = @WorldShipQvnShipNotify,
    [WorldShipQvnDeliveryNotify] = @WorldShipQvnDeliveryNotify,
    [WorldShipQvnExceptionNotify] = @WorldShipQvnExceptionNotify,
    WorldShipProcessOnExport = @WorldShipProcessOnExport,
    [StampsDefaultService] = @StampsDefaultService,
    [StampsDefaultConfirmation] = @StampsDefaultConfirmation,
    [StampsMailpiece] = @StampsMailpiece,
    [StampsLabelSheet] = @StampsLabelSheet,
    [StampsHidePostage] = @StampsHidePostage,
    [StampsMemo] = @StampsMemo,
    [UspsDefaultService] = @UspsDefaultService, 
    [UspsDefaultConfirmation] = @UspsDefaultConfirmation, 
    [UspsDefaultRequestAddressService] = @UspsDefaultRequestAddressService, 
    [UspsDefaultSendConfirmationEmail] = @UspsDefaultSendConfirmationEmail, 
    [UspsDefaultTemplate] = @UspsDefaultTemplate, 
    [DownloadAllowed] = @DownloadAllowed,
    [DownloadAutoEnable] = @DownloadAutoEnable,
    [DownloadAutoInterval] = @DownloadAutoInterval,
    DisplayShipmentOwnerOrder = @DisplayShipmentOwnerOrder,
    DisplayShipmentOwnerCustomer = @DisplayShipmentOwnerCustomer
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID AND ([RowVersion] = @RowVersion OR @IgnoreConcurrency != 0)

   if (@@ROWCOUNT != 1)
      return 0

   SET NOCOUNT ON

   SELECT [RowVersion]
   FROM [ClientStoreSettings]
   WHERE [ClientID] = @ClientID AND [StoreID] = @StoreID

   return 1
GO
